#include <odr/internal/font/sfnt_font.hpp>

#include <odr/internal/font/sfnt_transform.hpp>
#include <odr/internal/util/byte_string.hpp>
#include <odr/internal/util/string_util.hpp>

#include <algorithm>
#include <array>
#include <cstdint>
#include <functional>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace odr::internal::font::sfnt {

namespace bs = util::byte_string;

namespace {

// The enumerators below are the on-disk codes (OpenType spec).

/// `cmap`/`name` platform IDs.
enum class PlatformId : std::uint16_t {
  unicode = 0,
  macintosh = 1,
  windows = 3,
};

/// Windows-platform (`PlatformId::windows`) encoding IDs.
enum class WindowsEncoding : std::uint16_t {
  symbol = 0,
  unicode_bmp = 1,
  unicode_full = 10,
};

/// Unicode-platform (`PlatformId::unicode`) encoding IDs that name a full
/// (beyond-BMP) repertoire; the rest are treated as plain Unicode.
enum class UnicodeEncoding : std::uint16_t {
  unicode_2_0_full = 4,
  unicode_full = 6,
};

/// Macintosh-platform (`PlatformId::macintosh`) encoding IDs.
enum class MacintoshEncoding : std::uint16_t {
  roman = 0,
};

/// `cmap` subtable format (the leading `u16` of a subtable).
enum class CmapFormat : std::uint16_t {
  byte_encoding = 0,      // format 0
  segment_mapping = 4,    // format 4
  trimmed_mapping = 6,    // format 6
  segmented_coverage = 12 // format 12
};

/// `name` record IDs we extract a font name from.
enum class NameId : std::uint16_t {
  full = 4,
  postscript = 6,
};

struct CmapEntry {
  PlatformId platform;
  std::uint16_t encoding;
  std::uint32_t offset;
};

struct NameEntry {
  PlatformId platform;
  NameId name_id;
  std::uint16_t name_length;
  std::uint16_t name_local_offset;

  [[nodiscard]] bool utf16() const {
    return platform == PlatformId::windows || platform == PlatformId::unicode;
  }
};

// The decoders below read a fixed record from the **front** of @p d (the view
// is positioned at the record by the caller); the remaining bytes are ignored.

/// `head`'s bounding box: `xMin`/`yMin`/`xMax`/`yMax` as four `int16`.
[[nodiscard]] FontBBox read_bbox(const std::string_view d) {
  return {static_cast<std::int16_t>(bs::read_u16_be(d)),
          static_cast<std::int16_t>(bs::read_u16_be(d.substr(2))),
          static_cast<std::int16_t>(bs::read_u16_be(d.substr(4))),
          static_cast<std::int16_t>(bs::read_u16_be(d.substr(6)))};
}

/// A `cmap` encoding record: platformID, encodingID, subtable offset.
[[nodiscard]] CmapEntry read_cmap_entry(const std::string_view d) {
  return {static_cast<PlatformId>(bs::read_u16_be(d)),
          bs::read_u16_be(d.substr(2)), bs::read_u32_be(d.substr(4))};
}

/// A `name` record; encodingID/languageID (+2..+6) are skipped.
[[nodiscard]] NameEntry read_name_entry(const std::string_view d) {
  return {static_cast<PlatformId>(bs::read_u16_be(d)),
          static_cast<NameId>(bs::read_u16_be(d.substr(6))),
          bs::read_u16_be(d.substr(8)), bs::read_u16_be(d.substr(10))};
}

/// Decode a UTF-16BE `name` string (Windows/Unicode platforms), surrogate pairs
/// included, into UTF-8. @p d is exactly the string's bytes.
[[nodiscard]] std::string read_utf16be(const std::string_view d) {
  const std::size_t len = d.size();
  std::string out;
  for (std::size_t i = 0; i + 1 < len; i += 2) {
    char32_t cp = bs::read_u16_be(d.substr(i));
    if (cp >= 0xd800 && cp <= 0xdbff && i + 3 < len) {
      const char32_t lo = bs::read_u16_be(d.substr(i + 2));
      if (lo >= 0xdc00 && lo <= 0xdfff) {
        cp = 0x10000 + ((cp - 0xd800) << 10) + (lo - 0xdc00);
        i += 2;
      }
    }
    util::string::append_c32(cp, out);
  }
  return out;
}

/// Decode a single-byte (Mac/Latin-1) `name` string into UTF-8. @p d is exactly
/// the string's bytes.
[[nodiscard]] std::string read_latin1(const std::string_view d) {
  std::string out;
  for (const char c : d) {
    util::string::append_c32(static_cast<std::uint8_t>(c), out);
  }
  return out;
}

/// Preference among `cmap` subtables: Unicode full > Unicode BMP > symbol >
/// Mac.
[[nodiscard]] std::uint32_t cmap_score(const PlatformId platform,
                                       const std::uint16_t encoding) {
  switch (platform) {
  case PlatformId::windows:
    switch (static_cast<WindowsEncoding>(encoding)) {
    case WindowsEncoding::unicode_full:
      return 5;
    case WindowsEncoding::unicode_bmp:
      return 4;
    case WindowsEncoding::symbol:
      return 2;
    }
    return 0;
  case PlatformId::unicode:
    if (static_cast<UnicodeEncoding>(encoding) ==
            UnicodeEncoding::unicode_2_0_full ||
        static_cast<UnicodeEncoding>(encoding) ==
            UnicodeEncoding::unicode_full) {
      return 5;
    }
    return 3;
  case PlatformId::macintosh:
    // Mac Roman is treated as Latin-1 — correct for ASCII.
    return static_cast<MacintoshEncoding>(encoding) == MacintoshEncoding::roman
               ? 1
               : 0;
  }
  return 0;
}

/// The tables `write()` keeps. One malformed table — routine in a PDF subset —
/// makes the OpenType Sanitizer reject the whole font, and the dropped ones buy
/// nothing: the caller positions every glyph, so layout never applies.
bool is_kept_table(const std::string_view tag) {
  constexpr std::array<std::string_view, 22> kept = {
      // required / metrics
      "head", "hhea", "hmtx", "maxp", "cmap", "name", "OS/2", "post",
      // outlines
      "glyf", "loca", "CFF ", "CFF2",
      // hinting
      "cvt ", "fpgm", "prep", "gasp",
      // color
      "COLR", "CPAL", "CBDT", "CBLC", "sbix", "SVG "};
  return std::ranges::find(kept, tag) != kept.end();
}

} // namespace

bool SfntFont::is_sfnt(const std::string_view data) {
  if (data.size() < 4) {
    return false;
  }
  const std::string_view tag = data.substr(0, 4);
  return tag == std::string_view("\x00\x01\x00\x00", 4) || tag == "OTTO" ||
         tag == "true" || tag == "ttcf" || tag == "typ1";
}

SfntFont::SfntFont(std::string data) : m_data{std::move(data)} { parse(); }

void SfntFont::parse() {
  const std::string_view d{m_data};

  std::uint32_t sfnt_offset = 0;
  if (d.substr(0, 4) == "ttcf") {
    const std::uint32_t count = bs::read_u32_be(d.substr(8));
    if (count == 0 || count > (d.size() - 12) / 4) {
      throw std::runtime_error("sfnt: invalid collection directory");
    }
    // TrueType Collection: read the first member's offset table.
    sfnt_offset = bs::read_u32_be(d.substr(12));
  }
  read_directory(d.substr(sfnt_offset));
  read_head();
  read_maxp();
  read_hhea();
  read_hmtx();
  read_cmap();
  read_name();
}

std::string_view SfntFont::table_data(const Table table) const {
  if (table.offset > m_data.size()) {
    throw std::runtime_error("sfnt: table offset exceeds the font");
  }
  // Like FreeType, clip a table that runs past the end of the font.
  return std::string_view{m_data}.substr(table.offset, table.length);
}

void SfntFont::read_directory(const std::string_view sfnt) {
  if (sfnt.size() < 12 || !is_sfnt(sfnt) || sfnt.substr(0, 4) == "ttcf") {
    throw std::runtime_error("sfnt: invalid offset table");
  }
  m_format = sfnt.substr(0, 4) == "OTTO" ? FontFormat::opentype_cff
                                         : FontFormat::truetype;
  const std::uint16_t num_tables = bs::read_u16_be(sfnt.substr(4));
  if (num_tables > (sfnt.size() - 12) / 16) {
    throw std::runtime_error("sfnt: truncated table directory");
  }

  // Past the 12 byte offset table, each directory entry is 16 bytes: tag(4),
  // checkSum(4), offset(4), length(4).
  for (std::uint16_t i = 0; i < num_tables; ++i) {
    const std::size_t entry = 12 + static_cast<std::size_t>(i) * 16;
    std::string tag{sfnt.substr(entry, 4)};
    const std::uint32_t offset = bs::read_u32_be(sfnt.substr(entry + 8));
    const std::uint32_t length = bs::read_u32_be(sfnt.substr(entry + 12));
    m_tables.emplace(std::move(tag), Table{offset, length});
  }
}

void SfntFont::read_head() {
  const auto head = table("head");
  if (!head.has_value()) {
    return; // tolerate; keep the unitsPerEm default
  }
  const std::string_view t = table_data(*head);
  m_units_per_em = bs::read_u16_be(t.substr(18));
  if (m_units_per_em == 0) {
    throw std::runtime_error("sfnt: zero units per em");
  }
  m_bbox = read_bbox(t.substr(36));
}

void SfntFont::read_maxp() {
  const auto maxp = table("maxp");
  if (!maxp.has_value()) {
    return;
  }
  m_glyph_count = bs::read_u16_be(table_data(*maxp).substr(4));
}

void SfntFont::read_hhea() {
  const auto hhea = table("hhea");
  if (!hhea.has_value()) {
    return;
  }
  m_number_of_h_metrics = bs::read_u16_be(table_data(*hhea).substr(34));
}

void SfntFont::read_hmtx() {
  const auto hmtx = table("hmtx");
  if (!hmtx.has_value()) {
    return;
  }
  const std::string_view t = table_data(*hmtx);
  m_advance_widths.reserve(m_number_of_h_metrics);
  for (std::uint16_t i = 0; i < m_number_of_h_metrics; ++i) {
    // Each longHorMetric is advanceWidth(2) + leftSideBearing(2).
    m_advance_widths.push_back(
        bs::read_u16_be(t.substr(static_cast<std::size_t>(i) * 4)));
  }
}

void SfntFont::read_cmap() {
  const auto cmap = table("cmap");
  if (!cmap.has_value()) {
    return;
  }
  const std::string_view t = table_data(*cmap);
  const std::uint16_t count = bs::read_u16_be(t.substr(2));

  std::vector<CmapEntry> entries;
  entries.reserve(count);
  for (std::uint16_t i = 0; i < count; ++i) {
    // The encoding records start at offset 4, 8 bytes each.
    entries.emplace_back(
        read_cmap_entry(t.substr(4 + static_cast<std::size_t>(i) * 8)));
  }

  m_symbolic = std::ranges::any_of(entries, [](const CmapEntry &entry) {
    return entry.platform == PlatformId::windows &&
           static_cast<WindowsEncoding>(entry.encoding) ==
               WindowsEncoding::symbol;
  });

  const auto score = [t](const CmapEntry &entry) -> std::uint32_t {
    if (t.size() < 2 || entry.offset > t.size() - 2) {
      return 0;
    }
    switch (static_cast<CmapFormat>(bs::read_u16_be(t.substr(entry.offset)))) {
    case CmapFormat::byte_encoding:
    case CmapFormat::segment_mapping:
    case CmapFormat::trimmed_mapping:
    case CmapFormat::segmented_coverage:
      return cmap_score(entry.platform, entry.encoding);
    default:
      return 0;
    }
  };
  std::ranges::stable_sort(entries, std::ranges::greater{}, score);

  for (const CmapEntry &entry : entries) {
    if (score(entry) == 0) {
      break;
    }
    // Like FreeType, a broken subtable drops only itself, because a PDF
    // addresses the glyphs of an embedded font by ID.
    try {
      // The encoding record's offset is relative to the start of the `cmap`
      // table.
      read_cmap_subtable(t.substr(entry.offset));
      break;
    } catch (const std::exception &) {
      m_cmap.clear();
    }
  }

  update_reverse();
}

void SfntFont::update_reverse() {
  // Lowest code point wins; m_cmap iterates code points ascending, so the
  // first time a glyph is seen is its lowest code point.
  m_reverse.clear();
  for (const auto &[code, glyph] : m_cmap) {
    m_reverse.emplace(glyph, code);
  }
}

void SfntFont::read_cmap_subtable(std::string_view s) {
  const auto format = static_cast<CmapFormat>(bs::read_u16_be(s));
  const std::size_t length = format == CmapFormat::segmented_coverage
                                 ? bs::read_u32_be(s.substr(4))
                                 : bs::read_u16_be(s.substr(2));
  s = s.substr(0, length);
  const auto map = [this](const char32_t code, const std::uint16_t glyph) {
    if (glyph == 0) {
      return;
    }
    m_cmap[code] = glyph;
  };

  const auto read_u16_vector = [](const std::string_view v,
                                  const std::size_t count) {
    std::vector<std::uint16_t> out;
    out.reserve(count);
    for (std::size_t i = 0; i < count; ++i) {
      out.push_back(bs::read_u16_be(v.substr(i * 2)));
    }
    return out;
  };

  switch (format) {
  case CmapFormat::byte_encoding: {
    // format(0), length(2), language(4), then a 256-byte glyphIdArray(6).
    for (std::uint32_t code = 0; code < 256; ++code) {
      map(code, bs::read_u8(s.substr(6 + code)));
    }
    break;
  }
  case CmapFormat::segment_mapping: {
    // format(0), length(2), language(4), segCountX2(6), 3 search hints(8..12),
    // then the parallel segs-sized arrays endCode(14), reservedPad, startCode,
    // idDelta, idRangeOffset.
    const std::uint16_t seg_count_x2 = bs::read_u16_be(s.substr(6));
    const std::size_t segs = seg_count_x2 / 2U;
    if (segs == 0 || seg_count_x2 % 2 != 0) {
      throw std::runtime_error("sfnt: invalid cmap segment count");
    }
    const std::vector<std::uint16_t> end_codes =
        read_u16_vector(s.substr(14), segs);
    const std::vector<std::uint16_t> start_codes =
        read_u16_vector(s.substr(16 + 2 * segs), segs);
    const std::vector<std::uint16_t> id_deltas =
        read_u16_vector(s.substr(16 + 4 * segs), segs);
    const std::vector<std::uint16_t> id_range_offsets =
        read_u16_vector(s.substr(16 + 6 * segs), segs);
    // What remains past the 16 + 8*segs byte header is the glyphIdArray that
    // non-zero idRangeOffsets index into.
    const std::size_t header = 16 + 8 * segs;
    if (length < header) {
      throw std::runtime_error("sfnt: cmap format 4 subtable too short");
    }
    const std::vector<std::uint16_t> glyph_ids =
        read_u16_vector(s.substr(header), (length - header) / 2);
    std::int32_t previous_end = -1;
    for (std::size_t seg = 0; seg < segs; ++seg) {
      const std::uint16_t start = start_codes.at(seg);
      const std::uint16_t end = end_codes.at(seg);
      const std::uint16_t delta = id_deltas.at(seg);
      const std::uint16_t range = id_range_offsets.at(seg);
      // Skip a bad segment and keep the rest. In ascending order, the
      // segments cover each code once.
      if (start > end || start <= previous_end ||
          (start != 0xFFFF && range % 2 != 0)) {
        continue;
      }
      previous_end = end;
      for (std::uint32_t code = start; code <= end && code != 0xffff; ++code) {
        std::uint16_t glyph = 0;
        if (range == 0) {
          glyph = static_cast<std::uint16_t>(code + delta);
        } else {
          // idRangeOffset is a self-relative byte offset from
          // &idRangeOffset[seg]; as an index into glyphIdArray it is range/2 +
          // (code-start) - (segs-seg).
          const std::size_t index = range / 2U + (code - start) - (segs - seg);
          glyph = glyph_ids.at(index);
          if (glyph != 0) {
            glyph = static_cast<std::uint16_t>(glyph + delta);
          }
        }
        map(code, glyph);
      }
    }
    break;
  }
  case CmapFormat::trimmed_mapping: {
    // format(0), length(2), language(4), firstCode(6), entryCount(8), then the
    // glyphIdArray(10).
    const std::uint16_t first = bs::read_u16_be(s.substr(6));
    const std::uint16_t entries = bs::read_u16_be(s.substr(8));
    if (std::uint32_t{first} + entries > 0x10000) {
      throw std::runtime_error("sfnt: cmap format 6 exceeds the BMP");
    }
    for (std::uint16_t i = 0; i < entries; ++i) {
      map(first + i,
          bs::read_u16_be(s.substr(10 + static_cast<std::size_t>(i) * 2)));
    }
    break;
  }
  case CmapFormat::segmented_coverage: {
    // format(0), reserved(2), length(4), language(8), numGroups(12), then the
    // groups(16), each a 12-byte startCharCode/endCharCode/startGlyphID.
    const std::uint32_t groups = bs::read_u32_be(s.substr(12));
    if (groups > (s.size() - 16) / 12) {
      throw std::runtime_error("sfnt: truncated cmap groups");
    }
    std::uint32_t previous_end = 0;
    for (std::uint32_t g = 0; g < groups; ++g) {
      const std::size_t base = 16 + static_cast<std::size_t>(g) * 12;
      const std::uint32_t start = bs::read_u32_be(s.substr(base));
      const std::uint32_t end = bs::read_u32_be(s.substr(base + 4));
      const std::uint32_t start_glyph = bs::read_u32_be(s.substr(base + 8));
      if (start > end || end > 0x10FFFF || (g > 0 && start <= previous_end) ||
          start_glyph > 0xFFFF || end - start > 0xFFFF - start_glyph) {
        throw std::runtime_error("sfnt: invalid cmap format 12 group");
      }
      previous_end = end;
      for (std::uint32_t code = start; code <= end; ++code) {
        map(code, static_cast<std::uint16_t>(start_glyph + (code - start)));
      }
    }
    break;
  }
  default:
    break; // unsupported subtable format: leave the map empty
  }
}

void SfntFont::read_name() {
  const auto name = table("name");
  if (!name.has_value()) {
    return;
  }
  const std::string_view t = table_data(*name);
  const std::uint16_t count = bs::read_u16_be(t.substr(2));
  const std::uint16_t string_offset = bs::read_u16_be(t.substr(4));

  std::vector<NameEntry> entries;
  entries.reserve(count);
  for (std::uint16_t i = 0; i < count; ++i) {
    // The name records start at offset 6, 12 bytes each.
    entries.emplace_back(
        read_name_entry(t.substr(6 + static_cast<std::size_t>(i) * 12)));
  }

  const auto score_entry = [](const NameEntry &entry) -> std::uint32_t {
    // Only the full (4) and PostScript (6) names are usable; everything else
    // scores below the empty default so it is never selected.
    if (entry.name_id != NameId::full && entry.name_id != NameId::postscript) {
      return 0;
    }
    const std::uint32_t score = (entry.name_id == NameId::postscript ? 10 : 0) +
                                (entry.utf16() ? 2 : 1);
    return score;
  };

  const auto best_entry = std::ranges::max_element(entries, {}, score_entry);

  if (best_entry != entries.end() && score_entry(*best_entry) > 0) {
    // name_local_offset is relative to the string storage (string_offset).
    const std::size_t offset =
        static_cast<std::size_t>(string_offset) + best_entry->name_local_offset;
    if (offset <= t.size()) {
      const std::string_view value = t.substr(offset, best_entry->name_length);
      m_name = best_entry->utf16() ? read_utf16be(value) : read_latin1(value);
    }
  }
}

FontFormat SfntFont::format() const noexcept { return m_format; }

std::string SfntFont::name() const { return m_name; }

std::uint16_t SfntFont::glyph_count() const noexcept { return m_glyph_count; }

std::uint16_t SfntFont::units_per_em() const noexcept { return m_units_per_em; }

bool SfntFont::symbolic() const noexcept { return m_symbolic; }

FontBBox SfntFont::bounding_box() const noexcept { return m_bbox; }

std::uint16_t SfntFont::advance_width(const std::uint16_t glyph) const {
  if (m_advance_widths.empty()) {
    return 0;
  }
  // Glyphs beyond `numberOfHMetrics` share the last advance (monospace tail).
  if (glyph >= m_advance_widths.size()) {
    return m_advance_widths.back();
  }
  return m_advance_widths[glyph];
}

std::uint16_t SfntFont::glyph_for_code_point(const char32_t code_point) const {
  const auto it = m_cmap.find(code_point);
  return it == m_cmap.end() ? 0 : it->second;
}

std::optional<char32_t>
SfntFont::code_point_for_glyph(const std::uint16_t glyph) const {
  const auto it = m_reverse.find(glyph);
  if (it == m_reverse.end()) {
    return std::nullopt;
  }
  return it->second;
}

const std::map<char32_t, std::uint16_t> &SfntFont::cmap() const noexcept {
  return m_cmap;
}

void SfntFont::set_cmap(std::map<char32_t, std::uint16_t> cmap) {
  m_cmap = std::move(cmap);
  update_reverse();
}

std::string SfntFont::write() const {
  std::vector<std::pair<std::string, std::string>> tables;
  tables.reserve(m_tables.size() + 1);
  for (const auto &[tag, location] : m_tables) {
    // `cmap` is rebuilt from the cmap() model below.
    if (tag == "cmap" || !is_kept_table(tag)) {
      continue;
    }
    std::string data = std::string(table_data(location));
    if (tag == "hmtx") {
      // OTS rejects an `hmtx` shorter than `hhea` and `maxp` say.
      const std::size_t side_bearings =
          std::max(m_glyph_count, m_number_of_h_metrics) -
          m_number_of_h_metrics;
      const std::size_t length =
          4 * std::size_t{m_number_of_h_metrics} + 2 * side_bearings;
      if (data.size() < length) {
        data.resize(length, '\0');
      }
    }
    tables.emplace_back(tag, std::move(data));
  }
  tables.emplace_back("cmap", serialize_cmap(m_cmap));

  // OTS rejects a font missing `post` / `name` / `OS/2`, and PDF-embedded
  // TrueType routinely omits all three; synthesize the missing ones so the
  // browser accepts the `@font-face`. build_sfnt sorts the directory, so the
  // insertion order here does not matter.
  if (!m_tables.contains("post")) {
    tables.emplace_back("post", serialize_post());
  }
  if (!m_tables.contains("name")) {
    tables.emplace_back("name", serialize_name(m_name));
  }
  if (!m_tables.contains("OS/2")) {
    std::uint16_t first_char = 0;
    std::uint16_t last_char = 0;
    if (!m_cmap.empty()) {
      first_char = static_cast<std::uint16_t>(
          std::min<char32_t>(m_cmap.begin()->first, 0xffff));
      last_char = static_cast<std::uint16_t>(
          std::min<char32_t>(m_cmap.rbegin()->first, 0xffff));
    }
    tables.emplace_back("OS/2",
                        serialize_os2(m_units_per_em, m_bbox.y_min,
                                      m_bbox.y_max, first_char, last_char));
  }

  const std::uint32_t version = m_format == FontFormat::opentype_cff
                                    ? 0x4f54544fU /* 'OTTO' */
                                    : 0x00010000U;
  return build_sfnt(version, std::move(tables));
}

std::optional<SfntFont::Table>
SfntFont::table(const std::string_view tag) const {
  const auto it = m_tables.find(tag);
  if (it == m_tables.end()) {
    return std::nullopt;
  }
  return it->second;
}

} // namespace odr::internal::font::sfnt
