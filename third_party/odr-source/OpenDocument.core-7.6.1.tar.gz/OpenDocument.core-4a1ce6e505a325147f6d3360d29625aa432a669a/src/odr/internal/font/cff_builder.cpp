#include <odr/internal/font/cff_builder.hpp>

#include <odr/internal/font/cff_standard_strings.hpp>
#include <odr/internal/util/byte_string.hpp>
#include <odr/internal/util/number_util.hpp>

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <limits>
#include <optional>
#include <ranges>
#include <stdexcept>
#include <string>
#include <unordered_set>
#include <utility>
#include <vector>

#include <fmt/format.h>

namespace odr::internal::font::cff {

namespace {

/// A CFF DICT integer in the compact encoding (used for widths / bbox).
void dict_int(std::string &s, const std::int32_t v) {
  if (v >= -107 && v <= 107) {
    s += static_cast<char>(v + 139);
  } else if (v >= 108 && v <= 1131) {
    const std::int32_t u = v - 108;
    s += static_cast<char>((u >> 8) + 247);
    s += static_cast<char>(u & 0xff);
  } else if (v >= -1131 && v <= -108) {
    const std::int32_t u = -v - 108;
    s += static_cast<char>((u >> 8) + 251);
    s += static_cast<char>(u & 0xff);
  } else if (v >= -32768 && v <= 32767) {
    s += static_cast<char>(28);
    util::byte_string::put_u16_be(s, static_cast<std::uint16_t>(v));
  } else {
    s += static_cast<char>(29);
    s += static_cast<char>((v >> 24) & 0xff);
    s += static_cast<char>((v >> 16) & 0xff);
    s += static_cast<char>((v >> 8) & 0xff);
    s += static_cast<char>(v & 0xff);
  }
}

void dict_number(std::string &out, const double value) {
  if (!std::isfinite(value)) {
    throw std::runtime_error("cff: non-finite DICT operand");
  }
  if (const std::optional<std::int32_t> integer =
          util::number::to_integer<std::int32_t>(value);
      integer.has_value()) {
    dict_int(out, *integer);
    return;
  }
  const std::string text = fmt::format("{:.17g}", value);
  std::vector<std::uint8_t> nibbles;
  for (std::size_t i = 0; i < text.size(); ++i) {
    const char c = text[i];
    if (c == '.') {
      nibbles.push_back(0xA);
    } else if (c == '-') {
      nibbles.push_back(0xE);
    } else if (c == 'e') {
      const bool negative = text[i + 1] == '-';
      nibbles.push_back(negative ? 0xC : 0xB);
      if (negative || text[i + 1] == '+') {
        ++i;
      }
    } else {
      nibbles.push_back(static_cast<std::uint8_t>(c - '0'));
    }
  }
  nibbles.push_back(0xF);
  if (nibbles.size() % 2 != 0) {
    nibbles.push_back(0xF);
  }
  out += static_cast<char>(30);
  for (std::size_t i = 0; i < nibbles.size(); i += 2) {
    out += static_cast<char>((nibbles[i] << 4) | nibbles[i + 1]);
  }
}

/// A CFF DICT integer in the fixed 5-byte form (`29 + int32`), so an operand
/// whose value (an offset) is not yet known can be sized before it is filled.
void dict_int_fixed(std::string &s, const std::int32_t v) {
  s += static_cast<char>(29);
  s += static_cast<char>((v >> 24) & 0xff);
  s += static_cast<char>((v >> 16) & 0xff);
  s += static_cast<char>((v >> 8) & 0xff);
  s += static_cast<char>(v & 0xff);
}

void dict_operator(std::string &s, const std::int32_t op) {
  if (op >= 1200) {
    s += static_cast<char>(12);
    s += static_cast<char>(op - 1200);
  } else {
    s += static_cast<char>(op);
  }
}

/// Serialize a CFF INDEX from its members.
std::string build_index(const std::vector<std::string> &members) {
  if (!std::in_range<std::uint16_t>(members.size())) {
    throw std::runtime_error("cff: too many INDEX members");
  }
  std::string out;
  util::byte_string::put_u16_be(out,
                                static_cast<std::uint16_t>(members.size()));
  if (members.empty()) {
    return out; // count 0: no offSize/offsets
  }
  std::uint32_t total = 1;
  for (const std::string &m : members) {
    if (m.size() > std::numeric_limits<std::uint32_t>::max() - total) {
      throw std::runtime_error("cff: INDEX exceeds 32-bit offsets");
    }
    total += static_cast<std::uint32_t>(m.size());
  }
  const std::uint8_t off_size = total <= 0xff       ? 1
                                : total <= 0xffff   ? 2
                                : total <= 0xffffff ? 3
                                                    : 4;
  out += static_cast<char>(off_size);
  const auto put_off = [&](const std::uint32_t off) {
    for (std::int32_t i = off_size - 1; i >= 0; --i) {
      out += static_cast<char>((off >> (8 * i)) & 0xff);
    }
  };
  std::uint32_t offset = 1;
  put_off(offset);
  for (const std::string &m : members) {
    offset += static_cast<std::uint32_t>(m.size());
    put_off(offset);
  }
  for (const std::string &m : members) {
    out += m;
  }
  return out;
}

} // namespace

} // namespace odr::internal::font::cff

namespace odr::internal::font {

std::string cff::build_cff(const std::string_view name,
                           const std::span<const BuilderGlyph> glyphs,
                           const double default_width,
                           const double nominal_width, const FontBBox bbox) {
  if (glyphs.empty() || glyphs.size() > 65000 ||
      glyphs.front().name != ".notdef") {
    throw std::runtime_error("cff: invalid name-keyed glyph set");
  }
  // CharStrings INDEX (one Type2 charstring per glyph).
  std::vector<std::string> charstrings;
  charstrings.reserve(glyphs.size());
  for (const BuilderGlyph &glyph : glyphs) {
    charstrings.push_back(glyph.charstring);
  }
  const std::string charstrings_index = build_index(charstrings);

  std::vector<std::string> strings;
  std::unordered_set<std::string_view> names{".notdef"};
  std::string charset(1, '\0'); // format 0, with implicit .notdef
  for (const BuilderGlyph &glyph : glyphs | std::views::drop(1)) {
    if (!names.insert(glyph.name).second) {
      throw std::runtime_error("cff: duplicate glyph name");
    }
    const auto standard = std::ranges::find(cff_standard_strings, glyph.name);
    std::size_t sid =
        static_cast<std::size_t>(standard - cff_standard_strings.begin());
    if (standard == cff_standard_strings.end()) {
      sid = cff_standard_strings_size + strings.size();
      if (sid >= 65000) {
        throw std::runtime_error("cff: too many custom strings");
      }
      strings.push_back(glyph.name);
    }
    util::byte_string::put_u16_be(charset, static_cast<std::uint16_t>(sid));
  }
  const std::string string_index = build_index(strings);

  // Private DICT: defaultWidthX (20), nominalWidthX (21).
  std::string private_dict;
  dict_number(private_dict, default_width);
  dict_operator(private_dict, 20);
  dict_number(private_dict, nominal_width);
  dict_operator(private_dict, 21);

  const std::string name_index =
      build_index({std::string(name.empty() ? "ODRType1" : name)});
  const std::string global_subrs = build_index({});

  // Top DICT, with the offsets to charset / CharStrings / Private filled once
  // the layout is known. Fixed-width offset integers keep the size constant.
  const auto top_dict = [&](const std::uint32_t charset_off,
                            const std::uint32_t charstrings_off,
                            const std::uint32_t private_off) {
    std::string d;
    dict_int(d, bbox.x_min);
    dict_int(d, bbox.y_min);
    dict_int(d, bbox.x_max);
    dict_int(d, bbox.y_max);
    dict_operator(d, 5); // FontBBox
    dict_int_fixed(d, static_cast<std::int32_t>(charset_off));
    dict_operator(d, 15); // charset
    dict_int_fixed(d, static_cast<std::int32_t>(charstrings_off));
    dict_operator(d, 17); // CharStrings
    dict_int_fixed(d, static_cast<std::int32_t>(private_dict.size()));
    dict_int_fixed(d, static_cast<std::int32_t>(private_off));
    dict_operator(d, 18); // Private [size offset]
    return d;
  };

  const std::string top_dict_probe = build_index({top_dict(0, 0, 0)});
  constexpr std::uint64_t header_size = 4;
  const std::uint64_t prefix = header_size + name_index.size() +
                               top_dict_probe.size() + string_index.size() +
                               global_subrs.size();
  const std::uint64_t charset_start = prefix + charstrings_index.size();
  const std::uint64_t private_start = charset_start + charset.size();
  if (private_start + private_dict.size() >
      std::numeric_limits<std::int32_t>::max()) {
    throw std::runtime_error("cff: output exceeds signed DICT offsets");
  }
  const auto charstrings_off = static_cast<std::uint32_t>(prefix);
  const auto charset_off = static_cast<std::uint32_t>(charset_start);
  const auto private_off = static_cast<std::uint32_t>(private_start);

  const std::string top_dict_index =
      build_index({top_dict(charset_off, charstrings_off, private_off)});

  std::string out;
  out += static_cast<char>(1); // major
  out += static_cast<char>(0); // minor
  out += static_cast<char>(4); // hdrSize
  out += static_cast<char>(4); // offSize (absolute offsets; legacy/unused)
  out += name_index;
  out += top_dict_index;
  out += string_index;
  out += global_subrs;
  out += charstrings_index;
  out += charset;
  out += private_dict;
  return out;
}

} // namespace odr::internal::font
