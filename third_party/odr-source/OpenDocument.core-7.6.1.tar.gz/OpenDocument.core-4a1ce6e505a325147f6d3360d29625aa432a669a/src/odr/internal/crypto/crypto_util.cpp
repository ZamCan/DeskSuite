#include <odr/internal/crypto/crypto_util.hpp>

#include <odr/internal/crypto/crypto_argon2.hpp>

#include <array>
#include <cstdint>
#include <cstring>
#include <limits>
#include <stdexcept>

// RC4 and MD5 are retained in Crypto++ only for legacy formats (here: the PDF
// standard security handler, R 2-4); opt in to the Weak:: namespace.
#define CRYPTOPP_ENABLE_NAMESPACE_WEAK 1

#include <cryptopp/aes.h>
#include <cryptopp/arc4.h>
#include <cryptopp/base64.h>
#include <cryptopp/blowfish.h>
#include <cryptopp/crc.h>
#include <cryptopp/des.h>
#include <cryptopp/filters.h>
#include <cryptopp/gcm.h>
#include <cryptopp/hex.h>
#include <cryptopp/md5.h>
#include <cryptopp/modes.h>
#include <cryptopp/pwdbased.h>
#include <cryptopp/sha.h>
#include <cryptopp/zinflate.h>
#include <cryptopp/zlib.h>

namespace odr::internal::crypto {

using byte = std::uint8_t;

namespace {

std::string process(CryptoPP::StreamTransformation &cipher,
                    const std::string_view input) {
  if (input.size() % cipher.MandatoryBlockSize() != 0) {
    throw std::invalid_argument("cipher input is not a whole number of blocks");
  }
  std::string result(input.size(), '\0');
  cipher.ProcessData(reinterpret_cast<byte *>(result.data()),
                     reinterpret_cast<const byte *>(input.data()),
                     input.size());
  return result;
}

} // namespace

std::string util::base64_encode(const std::string_view in) {
  std::string out;
  CryptoPP::Base64Encoder b(new CryptoPP::StringSink(out), false);
  b.Put(reinterpret_cast<const byte *>(in.data()), in.size());
  b.MessageEnd();
  return out;
}

std::string util::base64_decode(const std::string_view in) {
  std::string out;
  CryptoPP::Base64Decoder b(new CryptoPP::StringSink(out));
  b.Put(reinterpret_cast<const byte *>(in.data()), in.size());
  b.MessageEnd();
  return out;
}

std::string util::hex_encode(const std::string_view in) {
  std::string out;
  CryptoPP::HexEncoder e(new CryptoPP::StringSink(out), false);
  e.Put(reinterpret_cast<const byte *>(in.data()), in.size());
  e.MessageEnd();
  return out;
}

std::string util::hex_decode(const std::string_view in) {
  if (in.size() % 2 != 0) {
    throw std::invalid_argument("hex_decode: odd number of digits");
  }
  std::string out;
  CryptoPP::HexDecoder d(new CryptoPP::StringSink(out));
  d.Put(reinterpret_cast<const byte *>(in.data()), in.size());
  d.MessageEnd();
  // HexDecoder silently drops anything outside [0-9A-Fa-f] (including
  // whitespace), so a short result is the only signal of a bad digit.
  if (out.size() * 2 != in.size()) {
    throw std::invalid_argument("hex_decode: invalid hex digit");
  }
  return out;
}

std::uint32_t util::crc32(const std::string_view in) {
  std::array<byte, CryptoPP::CRC32::DIGESTSIZE> out;
  CryptoPP::CRC32().CalculateDigest(
      out.data(), reinterpret_cast<const byte *>(in.data()), in.size());
  // Crypto++ emits the checksum in host byte order, so copying the bytes back
  // into a word reproduces the value portably.
  std::uint32_t value;
  std::memcpy(&value, out.data(), out.size());
  return value;
}

std::string util::md5(const std::string_view in) {
  std::array<byte, CryptoPP::Weak::MD5::DIGESTSIZE> out;
  CryptoPP::Weak::MD5().CalculateDigest(
      out.data(), reinterpret_cast<const byte *>(in.data()), in.size());
  return {reinterpret_cast<char *>(out.data()), out.size()};
}

std::string util::sha1(const std::string_view in) {
  std::array<byte, CryptoPP::SHA1::DIGESTSIZE> out;
  CryptoPP::SHA1().CalculateDigest(
      out.data(), reinterpret_cast<const byte *>(in.data()), in.size());
  return {reinterpret_cast<char *>(out.data()), out.size()};
}

std::string util::sha256(const std::string_view in) {
  std::array<byte, CryptoPP::SHA256::DIGESTSIZE> out;
  CryptoPP::SHA256().CalculateDigest(
      out.data(), reinterpret_cast<const byte *>(in.data()), in.size());
  return {reinterpret_cast<char *>(out.data()), out.size()};
}

std::string util::sha384(const std::string_view in) {
  std::array<byte, CryptoPP::SHA384::DIGESTSIZE> out;
  CryptoPP::SHA384().CalculateDigest(
      out.data(), reinterpret_cast<const byte *>(in.data()), in.size());
  return {reinterpret_cast<char *>(out.data()), out.size()};
}

std::string util::sha512(const std::string_view in) {
  std::array<byte, CryptoPP::SHA512::DIGESTSIZE> out;
  CryptoPP::SHA512().CalculateDigest(
      out.data(), reinterpret_cast<const byte *>(in.data()), in.size());
  return {reinterpret_cast<char *>(out.data()), out.size()};
}

std::string util::rc4(const std::string_view key,
                      const std::string_view input) {
  CryptoPP::Weak::ARC4 rc4(reinterpret_cast<const byte *>(key.data()),
                           key.size());
  return process(rc4, input);
}

std::string util::pbkdf2(const std::size_t key_size,
                         const std::string_view start_key,
                         const std::string_view salt,
                         const std::size_t iteration_count) {
  if (iteration_count == 0 ||
      iteration_count > std::numeric_limits<unsigned int>::max()) {
    throw std::invalid_argument("PBKDF2 iteration count out of range");
  }
  std::string result(key_size, '\0');
  const CryptoPP::PKCS5_PBKDF2_HMAC<CryptoPP::SHA1> pbkdf2;
  pbkdf2.DeriveKey(reinterpret_cast<byte *>(result.data()), result.size(),
                   false, reinterpret_cast<const byte *>(start_key.data()),
                   start_key.size(),
                   reinterpret_cast<const byte *>(salt.data()), salt.size(),
                   static_cast<unsigned int>(iteration_count));
  return result;
}

std::string util::argon2id(const std::size_t key_size,
                           const std::string_view start_key,
                           const std::string_view salt,
                           const std::size_t iteration_count,
                           const std::size_t memory, const std::size_t lanes) {
  return argon2::id(key_size, start_key, salt, iteration_count, memory, lanes);
}

std::string util::decrypt_aes_ecb(const std::string_view key,
                                  const std::string_view input) {
  CryptoPP::ECB_Mode<CryptoPP::AES>::Decryption decryption;
  decryption.SetKey(reinterpret_cast<const byte *>(key.data()), key.size());
  return process(decryption, input);
}

std::string util::decrypt_aes_cbc(const std::string_view key,
                                  const std::string_view iv,
                                  const std::string_view input) {
  CryptoPP::CBC_Mode<CryptoPP::AES>::Decryption decryption;
  decryption.SetKeyWithIV(reinterpret_cast<const byte *>(key.data()),
                          key.size(), reinterpret_cast<const byte *>(iv.data()),
                          iv.size());
  return process(decryption, input);
}

std::string util::encrypt_aes_cbc(const std::string_view key,
                                  const std::string_view iv,
                                  const std::string_view input) {
  CryptoPP::CBC_Mode<CryptoPP::AES>::Encryption encryption;
  encryption.SetKeyWithIV(reinterpret_cast<const byte *>(key.data()),
                          key.size(), reinterpret_cast<const byte *>(iv.data()),
                          iv.size());
  return process(encryption, input);
}

std::string util::decrypt_aes_gcm(const std::string_view key,
                                  const std::string_view iv,
                                  const std::string_view input) {
  // follows https://www.w3.org/TR/xmlenc-core1/#sec-AES-GCM

  const std::size_t iv_size = iv.size();
  constexpr std::size_t mac_size = 16;

  // The input is IV || ciphertext || tag; anything shorter would wrap
  // `cipher_size`. `memcmp`, not `strncmp` — both operands are binary.
  if (input.size() < iv_size + mac_size) {
    throw std::runtime_error("GCM input too short");
  }
  if (std::memcmp(iv.data(), input.data(), iv_size) != 0) {
    throw std::runtime_error("IV mismatch");
  }

  const std::size_t cipher_size = input.size() - iv_size - mac_size;
  std::string result(cipher_size, '\0');
  auto *message = reinterpret_cast<byte *>(result.data());
  const auto *mac =
      reinterpret_cast<const byte *>(input.data() + input.size() - mac_size);
  const auto *iv_ = reinterpret_cast<const byte *>(input.data());
  const auto *cipher = reinterpret_cast<const byte *>(input.data() + iv_size);

  CryptoPP::GCM<CryptoPP::AES>::Decryption decryption;
  decryption.SetKeyWithIV(reinterpret_cast<const byte *>(key.data()),
                          key.size(), reinterpret_cast<const byte *>(iv.data()),
                          iv.size());
  const bool check = decryption.DecryptAndVerify(
      message, mac, mac_size, iv_, static_cast<int>(iv_size), nullptr, 0,
      cipher, cipher_size);

  if (!check) {
    throw std::runtime_error("GCM decryption failed");
  }

  return result;
}

std::string util::decrypt_triple_des(const std::string_view key,
                                     const std::string_view iv,
                                     const std::string_view input) {
  CryptoPP::CBC_Mode<CryptoPP::DES_EDE3>::Decryption decryption;
  decryption.SetKeyWithIV(reinterpret_cast<const byte *>(key.data()),
                          key.size(), reinterpret_cast<const byte *>(iv.data()),
                          iv.size());
  return process(decryption, input);
}

std::string util::decrypt_blowfish(const std::string_view key,
                                   const std::string_view iv,
                                   const std::string_view input) {
  CryptoPP::CFB_Mode<CryptoPP::Blowfish>::Decryption decryption;
  decryption.SetKeyWithIV(reinterpret_cast<const byte *>(key.data()),
                          key.size(), reinterpret_cast<const byte *>(iv.data()),
                          iv.size());
  return process(decryption, input);
}

namespace {
/// discard non deflated content caused by padding
class MyInflator final : public CryptoPP::Inflator {
public:
  explicit MyInflator(BufferedTransformation *attachment = nullptr)
      : Inflator(attachment, false, -1) {}

  std::size_t GetPadding() const { return m_padding; }

protected:
  void ProcessPoststreamTail() override {
    m_padding = m_inQueue.CurrentSize();
    m_inQueue.Clear();
  }

private:
  std::size_t m_padding{0};
};
} // namespace

std::string util::inflate(const std::string_view input) {
  std::string result;
  MyInflator inflator(new CryptoPP::StringSink(result));
  inflator.Put(reinterpret_cast<const byte *>(input.data()), input.size());
  inflator.MessageEnd();
  return result;
}

std::size_t util::padding(const std::string_view input) {
  MyInflator inflator;
  inflator.Put(reinterpret_cast<const byte *>(input.data()), input.size());
  inflator.MessageEnd();
  return inflator.GetPadding();
}

namespace {
/// Drops the ADLER32 check (RFC 1950 2.2), which real producers truncate, and
/// clears the queue so trailing bytes stay out of the output.
class UncheckedZlibDecompressor final : public CryptoPP::ZlibDecompressor {
public:
  explicit UncheckedZlibDecompressor(BufferedTransformation *attachment)
      : ZlibDecompressor(attachment) {}

  /// The full 32 KiB window, as zlib keeps it: producers declare a smaller
  /// `CINFO` in the header than the distances they use.
  [[nodiscard]] unsigned int GetLog2WindowSize() const override { return 15; }

protected:
  void ProcessPoststreamTail() override { m_inQueue.Clear(); }
};
} // namespace

std::string util::zlib_inflate(const std::string_view input) {
  std::string result;
  UncheckedZlibDecompressor inflator(new CryptoPP::StringSink(result));
  inflator.Put(reinterpret_cast<const byte *>(input.data()), input.size());
  inflator.MessageEnd();
  return result;
}

std::string util::zlib_deflate(const std::string_view input) {
  std::string out;
  CryptoPP::ZlibCompressor compressor(new CryptoPP::StringSink(out));
  compressor.Put(reinterpret_cast<const CryptoPP::byte *>(input.data()),
                 input.size());
  compressor.MessageEnd();
  return out;
}

} // namespace odr::internal::crypto
