#include <odr/internal/html/image_file.hpp>

#include <odr/exceptions.hpp>
#include <odr/file.hpp>
#include <odr/html.hpp>
#include <odr/logger.hpp>
#include <odr/odr.hpp>

#include <odr/internal/common/file.hpp>
#include <odr/internal/html/common.hpp>
#include <odr/internal/html/frontend.hpp>
#include <odr/internal/html/html_service.hpp>
#include <odr/internal/html/html_writer.hpp>
#include <odr/internal/svm/svm_file.hpp>
#include <odr/internal/svm/svm_to_svg.hpp>

#include <span>
#include <sstream>
#include <string_view>

namespace odr::internal::html {
namespace {

/// A starview metafile is converted to svg; anything else goes out as its own
/// bytes labelled @p mime_type.
void write_image_src(const ImageFile &image_file, std::ostream &out,
                     const std::string &mime_type, const Logger &logger) {
  if (image_file.file_type() == FileType::starview_metafile) {
    try {
      // TODO `image_file` is already an `SvmFile`
      // TODO `impl()` might be a bit dirty
      const std::shared_ptr<abstract::File> image_file_impl =
          image_file.file().impl();
      // TODO memory file might not be necessary; other istreams didn't support
      // `tellg`
      const svm::SvmFile svm_file(
          std::make_shared<MemoryFile>(*image_file_impl));
      std::ostringstream svg_out;
      svm::translate_to_svg(svm_file, svg_out, logger);
      // TODO use stream
      out << file_to_url(svg_out.str(), "image/svg+xml");
      return;
    } catch (const std::exception &e) {
      ODR_WARNING(logger, "svm translation failed: " << e.what());
    } catch (...) {
      ODR_WARNING(logger, "svm translation failed");
    }
  }

  // TODO use stream
  out << file_to_url(*image_file.stream(), mime_type);
}

/// An SVM image as the SVG a browser shows, converted when it is written.
class SvgImageResource final : public abstract::HtmlResource {
public:
  SvgImageResource(File file, std::string path, const Logger &logger)
      : m_file{std::move(file)}, m_path{std::move(path)}, m_logger{logger} {}

  [[nodiscard]] HtmlResourceType type() const override {
    return HtmlResourceType::image;
  }
  [[nodiscard]] const std::string &mime_type() const override {
    static const std::string mime_type = "image/svg+xml";
    return mime_type;
  }
  [[nodiscard]] const std::string &name() const override { return m_path; }
  [[nodiscard]] const std::string &path() const override { return m_path; }
  /// None: the file is the SVM, and what this writes is SVG.
  [[nodiscard]] const std::optional<File> &file() const override {
    static const std::optional<File> none;
    return none;
  }
  [[nodiscard]] bool is_shipped() const override { return false; }
  [[nodiscard]] bool is_external() const override { return false; }
  [[nodiscard]] bool is_accessible() const override { return true; }

  /// Nothing where the conversion fails, so a broken image does not stop
  /// `bring_offline` or the server.
  void write_resource(std::ostream &os) const override {
    if (!m_file.has_value()) {
      return;
    }
    try {
      const svm::SvmFile svm_file(
          std::make_shared<MemoryFile>(*m_file->impl()));
      std::ostringstream svg;
      svm::translate_to_svg(svm_file, svg, m_logger);
      os << std::move(svg).str();
    } catch (const std::exception &e) {
      ODR_WARNING(m_logger, "svm translation failed: " << e.what());
    } catch (...) {
      ODR_WARNING(m_logger, "svm translation failed");
    }
  }

private:
  std::optional<File> m_file;
  std::string m_path;
  Logger m_logger;
};

/// An image file knows exactly which format it is holding, so the data url
/// says so. The table's first mime type is the canonical one.
std::string image_mime_type(const ImageFile &image_file) {
  const std::span<const std::string_view> mimetypes =
      mimetypes_by_file_type(image_file.file_type());
  return mimetypes.empty() ? "image/jpg" : std::string(mimetypes.front());
}

class HtmlServiceImpl final : public HtmlService {
public:
  HtmlServiceImpl(ImageFile image_file, HtmlConfig config, const Logger &logger)
      : HtmlService(std::move(config), logger),
        m_image_file{std::move(image_file)},
        m_resources{locate_viewport_resources(this->config())} {
    m_views.emplace_back(
        std::make_shared<HtmlView>(*this, "image", 0, "image.html"));
  }

  void warmup() const override {}

  [[nodiscard]] const HtmlViews &list_views() const override { return m_views; }

  [[nodiscard]] bool exists(const std::string &path) const override {
    return path == "image.html" || resource_at(m_resources, path) != nullptr;
  }

  [[nodiscard]] std::string mimetype(const std::string &path) const override {
    if (path == "image.html") {
      return "text/html";
    }

    if (const odr::HtmlResource *resource = resource_at(m_resources, path);
        resource != nullptr) {
      return resource->mime_type();
    }

    throw FileNotFound("Unknown path: " + path);
  }

  void write(const std::string &path, std::ostream &out) const override {
    if (path == "image.html") {
      HtmlWriter writer(out, config());
      write_image(writer);
      return;
    }

    if (const odr::HtmlResource *resource = resource_at(m_resources, path);
        resource != nullptr) {
      resource->write_resource(out);
      return;
    }

    throw FileNotFound("Unknown path: " + path);
  }

  HtmlResources write_html(const std::string &path,
                           HtmlWriter &out) const override {
    if (path == "image.html") {
      return write_image(out);
    }

    throw FileNotFound("Unknown path: " + path);
  }

  HtmlResources write_image(HtmlWriter &out) const {
    HtmlResources resources;
    const WritingState state(out, config(), resources, logger());

    out.write_begin();
    out.write_header_begin();
    out.write_header_charset("UTF-8");
    out.write_header_title("odr");
    write_viewport_meta(out, config(), true);
    // An image has no layout width to preserve, so css alone fits it, framed
    // or not - no measuring and no `viewport_width`.
    write_zoom_style(out, config(), WidthFit::none, {});
    write_content_margin_style(out, config());
    out.write_header_style_begin();
    // The picture runs to the border unless the config puts a floor under it.
    out.out() << "body{margin:0;padding:var(--odr-min-margin-top,0px) "
                 "var(--odr-min-margin-right,0px) "
                 "var(--odr-min-margin-bottom,0px) "
                 "var(--odr-min-margin-left,0px);background:#fff}";
    if (width_fit(config(), true) != WidthFit::none) {
      // `100%` of a zoomed body is the viewport again, so the factor has to
      // be put back for the image to grow with it
      out.out() << "img{max-width:calc(100% * var(--odr-zoom, 1));"
                   "height:auto}";
    }
    out.write_header_style_end();
    if (writes_dark_style(config())) {
      out.write_header_style_begin(dark_style_media(config()));
      out.out() << ":root{color-scheme:dark}body{background:#0d1117}";
      out.write_header_style_end();
    }
    out.write_header_end();

    out.write_body_begin();

    {
      out.write_new_line();
      out.out() << "<img";
      out.out() << " alt=\"Error: image not found or unsupported\"";
      out.out() << " src=\"";

      write_image_src(m_image_file, out.out(), image_mime_type(m_image_file),
                      logger());

      out.out() << "\">";
    }

    write_viewport_script(state);
    write_host_bridge_script(state);

    out.write_body_end();
    out.write_end();

    return resources;
  }

protected:
  ImageFile m_image_file;
  /// The script this view links; empty of locations when the config embeds it.
  HtmlResources m_resources;

  HtmlViews m_views;
};

} // namespace
} // namespace odr::internal::html

namespace odr::internal {

void html::translate_image_src(const File &file, std::ostream &out,
                               const HtmlConfig &config, const Logger &logger) {
  try {
    translate_image_src(odr::open(file).as_image_file(), out, config, logger);
  } catch (...) {
    // nothing named it, so the label is a guess - browsers sniff `<img>` and
    // `image/jpg` is what they have been handed here for years
    // TODO use stream
    out << file_to_url(*file.stream(), "image/jpg");
  }
}

void html::translate_image_src(const ImageFile &image_file, std::ostream &out,
                               const HtmlConfig & /*config*/,
                               const Logger &logger) {
  write_image_src(image_file, out, image_mime_type(image_file), logger);
}

odr::HtmlResource html::linked_image_resource(const File &file,
                                              std::string path,
                                              const Logger &logger) {
  std::string mime_type;
  try {
    const ImageFile image_file = odr::open(file).as_image_file();
    if (image_file.file_type() == FileType::starview_metafile) {
      path += ".svg";
      return odr::HtmlResource(
          std::make_shared<SvgImageResource>(file, std::move(path), logger));
    }
    mime_type = image_mime_type(image_file);
  } catch (...) {
    // what nothing names goes out as the data url labels it
    mime_type = "image/jpg";
  }
  return HtmlResource::create(HtmlResourceType::image, std::move(mime_type),
                              path, path, file, false, false, true);
}

HtmlService html::create_image_service(const ImageFile &image_file,
                                       HtmlConfig config,
                                       const Logger &logger) {
  return odr::HtmlService(
      std::make_unique<HtmlServiceImpl>(image_file, std::move(config), logger));
}

} // namespace odr::internal
