#pragma once

#include <odr/html.hpp>

#include <functional>
#include <iosfwd>
#include <string>
#include <string_view>
#include <variant>
#include <vector>

namespace odr::internal::html {

class StyleRegistry;

enum class HtmlCloseType {
  standard,
  trailing,
  none,
};

using HtmlWriteCallback = std::function<void(std::ostream &)>;
using HtmlWritable = std::variant<const char *, std::string, HtmlWriteCallback>;
using HtmlAttributesVector = std::vector<std::pair<HtmlWritable, HtmlWritable>>;
using HtmlAttributeWriterCallback =
    std::function<void(const HtmlWritable &, const HtmlWritable &)>;
using HtmlAttributeCallback =
    std::function<void(const HtmlAttributeWriterCallback &)>;
using HtmlAttributes =
    std::variant<HtmlAttributesVector, HtmlAttributeCallback>;

struct HtmlElementOptions {
  bool inline_element{false};
  HtmlCloseType close_type{HtmlCloseType::standard};

  std::optional<HtmlAttributes> attributes{};

  std::optional<HtmlWritable> style{};
  std::optional<HtmlWritable> clazz{};
  /// The class a deduplicated style block resolved to, written after `clazz`.
  std::optional<std::string> style_class{};

  std::optional<HtmlWritable> extra{};

  HtmlElementOptions &set_inline(bool is_inline);
  HtmlElementOptions &set_close_type(HtmlCloseType _close_type);
  HtmlElementOptions &set_attributes(std::optional<HtmlAttributes> _attributes);
  HtmlElementOptions &set_style(std::optional<HtmlWritable> _style);
  /// Either an inline `style` attribute or, where @p registry names the block,
  /// a class beside whatever `set_class` says. A null @p registry — every view
  /// but a spreadsheet's — keeps it inline.
  HtmlElementOptions &set_style(std::string _style, StyleRegistry *registry);
  HtmlElementOptions &set_class(std::optional<HtmlWritable> _class);
  HtmlElementOptions &set_extra(std::optional<HtmlWritable> _extra);
};

class HtmlWriter {
public:
  HtmlWriter(std::ostream &out, bool format, std::string indent,
             std::uint32_t current_indent = 0);
  HtmlWriter(std::ostream &out, const HtmlConfig &config);

  void write_begin(const HtmlElementOptions &options = {});
  void write_end();

  void write_header_begin();
  void write_header_end();
  void write_header_title(const std::string &title);
  void write_header_meta(const std::string &name, const std::string &content);
  void write_header_viewport(const std::string &viewport);
  void write_header_charset(const std::string &charset);
  /// @p media, when given, gates the stylesheet on that media query.
  void write_header_style(const std::string &href, std::string_view media = {});
  void write_header_style_begin(std::string_view media = {});
  void write_header_style_end();

  void write_script(const std::string &src);
  void write_script_begin();
  void write_script_end();

  void write_body_begin(const HtmlElementOptions &options = {});
  void write_body_end();

  void write_element_begin(const std::string &name,
                           const HtmlElementOptions &options = {});
  void write_element_end(const std::string &name);

  [[nodiscard]] bool is_inline_mode() const;
  void write_new_line();
  void write_raw(const HtmlWritable &writable, bool new_line = true);

  std::ostream &out();

private:
  struct StackElement {
    std::string name;
    bool inline_element{false};
  };

  std::ostream *m_out{nullptr};
  bool m_format{false};
  std::string m_indent;
  std::uint32_t m_current_indent{0};
  std::vector<StackElement> m_stack;
};

} // namespace odr::internal::html
