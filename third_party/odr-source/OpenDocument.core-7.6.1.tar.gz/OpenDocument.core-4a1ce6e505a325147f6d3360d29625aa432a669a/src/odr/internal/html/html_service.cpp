#include <odr/internal/html/html_service.hpp>

#include <odr/internal/util/stream_util.hpp>
#include <odr/internal/util/string_util.hpp>

#include <odr/exceptions.hpp>

#include <algorithm>

namespace odr::internal::html {

HtmlService::HtmlService(HtmlConfig config, const Logger &logger)
    : m_config{std::move(config)}, m_logger{logger} {}

const HtmlConfig &HtmlService::config() const { return m_config; }

const Logger &HtmlService::logger() const { return m_logger; }

HtmlView::HtmlView(const abstract::HtmlService &service, std::string name,
                   std::size_t index, std::string path)
    : m_service{&service}, m_name{std::move(name)}, m_index{index},
      m_path{std::move(path)} {}

const std::string &HtmlView::name() const { return m_name; }

std::size_t HtmlView::index() const { return m_index; }

const std::string &HtmlView::path() const { return m_path; }

const HtmlConfig &HtmlView::config() const { return m_service->config(); }

/// Only a sheet cuts anything, and only `html/document.cpp` renders one.
const std::optional<HtmlSheetCut> &HtmlView::sheet_cut() const {
  static const std::optional<HtmlSheetCut> none;
  return none;
}

const abstract::HtmlService &HtmlView::service() const { return *m_service; }

const Logger &HtmlView::logger() const { return m_service->logger(); }

HtmlResources HtmlView::write_html(HtmlWriter &out) const {
  return m_service->write_html(path(), out);
}

odr::HtmlResource HtmlResource::create(HtmlResourceType type,
                                       std::string mime_type, std::string name,
                                       std::string path,
                                       std::optional<File> file,
                                       bool is_shipped, bool is_external,
                                       bool is_accessible) {
  return odr::HtmlResource(std::make_shared<HtmlResource>(
      type, std::move(mime_type), std::move(name), std::move(path),
      std::move(file), is_shipped, is_external, is_accessible));
}

HtmlResource::HtmlResource(HtmlResourceType type, std::string mime_type,
                           std::string name, std::string path,
                           std::optional<File> file, bool is_shipped,
                           bool is_external, bool is_accessible)
    : m_type{type}, m_mime_type{std::move(mime_type)}, m_name{std::move(name)},
      m_path{std::move(path)}, m_file{std::move(file)},
      m_is_shipped{is_shipped}, m_is_external{is_external},
      m_is_accessible{is_accessible} {}

HtmlResourceType HtmlResource::type() const { return m_type; }

const std::string &HtmlResource::mime_type() const { return m_mime_type; }

const std::string &HtmlResource::name() const { return m_name; }

const std::string &HtmlResource::path() const { return m_path; }

const std::optional<File> &HtmlResource::file() const { return m_file; }

bool HtmlResource::is_shipped() const { return m_is_shipped; }

bool HtmlResource::is_external() const { return m_is_external; }

bool HtmlResource::is_accessible() const { return m_is_accessible; }

void HtmlResource::write_resource(std::ostream &os) const {
  const std::optional<File> &resource_file = file();
  if (!is_accessible() || !resource_file.has_value()) {
    throw ResourceNotAccessible(name(), path());
  }

  util::stream::pipe(*resource_file->stream(), os);
}

} // namespace odr::internal::html

namespace odr::internal {

bool html::resource_location_taken(const HtmlResources &resources,
                                   const std::string_view location) {
  return std::ranges::any_of(resources, [&](const auto &entry) {
    return entry.second.has_value() &&
           util::string::equals_ignore_case(*entry.second, location);
  });
}

const odr::HtmlResource *html::resource_at(const HtmlResources &resources,
                                           const std::string &path) {
  for (const auto &[resource, location] : resources) {
    if (location.has_value() && *location == path) {
      return &resource;
    }
  }

  return nullptr;
}

} // namespace odr::internal
