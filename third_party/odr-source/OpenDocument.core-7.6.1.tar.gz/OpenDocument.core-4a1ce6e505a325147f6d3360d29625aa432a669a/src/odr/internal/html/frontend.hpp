#pragma once

#include <odr/html.hpp>

#include <cstdint>
#include <string_view>

namespace odr::internal::html {

struct WritingState;

/// Each of these writes one complete `<style>`/`<script>` element, or links it
/// as a shipped @ref odr::HtmlResource when the config asks for that.

/// Each `write_*_dark_style` follows the style it restates and writes nothing
/// for @ref odr::HtmlColorScheme::light.

void write_document_style(const WritingState &state);
void write_document_dark_style(const WritingState &state);
/// Written in addition to the document style.
void write_spreadsheet_style(const WritingState &state);
void write_spreadsheet_dark_style(const WritingState &state);
void write_text_style(const WritingState &state);
void write_text_dark_style(const WritingState &state);
void write_xml_style(const WritingState &state);
void write_xml_dark_style(const WritingState &state);
void write_filesystem_style(const WritingState &state);
void write_filesystem_dark_style(const WritingState &state);
/// Black in every scheme, so no dark style.
void write_media_style(const WritingState &state);
/// Written by every view that writes the search script.
void write_search_style(const WritingState &state);
void write_search_dark_style(const WritingState &state);
/// The browser lays out an `odr-chunk` only where `viewport.js` marks it near
/// the viewport. Inline, because a chunk must start hidden on the first frame.
/// Nothing where `HtmlConfig::lazy_layout` is off.
void write_chunk_style(const WritingState &state);
/// The classes that make an element a chunk, each with a space before it, and
/// @p near where it is near the viewport before the script runs. Empty where
/// `HtmlConfig::lazy_layout` is off.
[[nodiscard]] std::string chunk_classes(const HtmlConfig &config, bool near);
/// The chunks that one script of a search index holds the text of, in every
/// view (`lazy-loading.md` decision 4).
constexpr std::uint32_t chunks_per_index = 64;
/// A json string that cannot end the `<script>` it sits in.
[[nodiscard]] std::string script_string(const std::string &value);

/// For a view writing its style inline: whether to write a dark one, and the
/// `media` gating it. A print stays light, so the query names `screen`.
bool writes_dark_style(const HtmlConfig &config);
std::string_view dark_style_media(const HtmlConfig &config);

/// `odr.editing`, `odr.onError`, `odr.takesKeys` and `odr.generateDiff`.
/// Written by every document view, and **first**: the scripts below read
/// `odr.takesKeys`.
void write_editing_script(const WritingState &state);
/// The text editor, attached to the mode. Written where the config edits.
void write_document_script(const WritingState &state);
/// Written in addition to the editing script.
void write_spreadsheet_script(const WritingState &state);
/// The sheet's editor, attached to the mode. Written where the config edits.
void write_sheet_editing_script(const WritingState &state);
/// Whether the build embeds the evaluator of `wasm/formula`, so a sheet's
/// editor takes formula input.
bool carries_formula_module();
/// `createOdrFormula`, the evaluator of `wasm/formula`, for a sheet's editor to
/// compute its formula cells and take formula input with. Written ahead of
/// the editor, and nothing where the build has no module.
void write_formula_script(const WritingState &state);
void write_text_script(const WritingState &state);
/// `odr.search()`, `searchNext()`, `searchPrevious()`, `resetSearch()`,
/// `searchDone()` and the `onSearchChange` callback — the rest of that object,
/// for every view rendering text, whatever the format.
void write_search_script(const WritingState &state);

/// `odr.annotation`: the pending markup a viewer draws on a pdf page, and
/// `getAnnotations()`, the payload @ref odr::PdfFile::annotate takes.
void write_pdf_annotation_style(const WritingState &state);
void write_pdf_annotation_script(const WritingState &state);

/// `odr.getZoom()`, `setZoom(value, focus)`, `adjustZoom(factor, focus)`,
/// `resetZoom(focus)`, `isZoomFitted()`, `getViewportRect(element)`,
/// `onZoomChange`, plus the fit @ref write_zoom_style left to be measured.
/// Holds the reading position.
void write_viewport_script(const WritingState &state);
/// Last in the body, after every script that sets an `odr.on*` default.
/// Nothing unless `HtmlConfig::host_message_handler` names a function.
void write_host_bridge_script(const WritingState &state);

/// What the corresponding `write_*` calls would link, without writing anything:
/// a service has to answer for these paths as well as for its views. Every
/// entry is located `nullopt` when the config embeds them.
HtmlResources locate_document_resources(const HtmlConfig &config,
                                        bool spreadsheet);
HtmlResources locate_filesystem_resources(const HtmlConfig &config);
HtmlResources locate_text_resources(const HtmlConfig &config);
HtmlResources locate_xml_resources(const HtmlConfig &config);
HtmlResources locate_media_resources(const HtmlConfig &config);
HtmlResources locate_search_resources(const HtmlConfig &config);
HtmlResources locate_viewport_resources(const HtmlConfig &config);
HtmlResources locate_pdf_annotation_resources(const HtmlConfig &config);

} // namespace odr::internal::html
