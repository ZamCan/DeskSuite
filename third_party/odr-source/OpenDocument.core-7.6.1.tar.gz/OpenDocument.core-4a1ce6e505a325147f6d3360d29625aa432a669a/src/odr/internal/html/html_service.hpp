#pragma once

#include <odr/file.hpp>
#include <odr/html.hpp>

#include <odr/internal/abstract/html_service.hpp>

#include <string_view>

namespace odr::internal::html {

class HtmlService : public abstract::HtmlService {
public:
  HtmlService(HtmlConfig config, const Logger &logger);

  [[nodiscard]] const HtmlConfig &config() const override;
  [[nodiscard]] const Logger &logger() const override;

private:
  HtmlConfig m_config;

protected:
  Logger m_logger;
};

class HtmlView : public abstract::HtmlView {
public:
  HtmlView(const abstract::HtmlService &service, std::string name,
           std::size_t index, std::string path);

  [[nodiscard]] const std::string &name() const override;
  [[nodiscard]] std::size_t index() const override;
  [[nodiscard]] const std::string &path() const override;
  [[nodiscard]] const HtmlConfig &config() const override;
  [[nodiscard]] const std::optional<HtmlSheetCut> &sheet_cut() const override;
  [[nodiscard]] const abstract::HtmlService &service() const;
  [[nodiscard]] const Logger &logger() const;

  HtmlResources write_html(HtmlWriter &out) const override;

private:
  const abstract::HtmlService *m_service{};
  std::string m_name;
  std::size_t m_index{};
  std::string m_path;
};

/// The resource a service serves at @p path, or `nullptr`. An embedded resource
/// has no location and so is never served.
const odr::HtmlResource *resource_at(const HtmlResources &resources,
                                     const std::string &path);

/// Whether a location is already used, including case-insensitive filesystems.
bool resource_location_taken(const HtmlResources &resources,
                             std::string_view location);

class HtmlResource : public abstract::HtmlResource {
public:
  static odr::HtmlResource create(HtmlResourceType type, std::string mime_type,
                                  std::string name, std::string path,
                                  std::optional<File> file, bool is_shipped,
                                  bool is_external, bool is_accessible);

  HtmlResource(HtmlResourceType type, std::string mime_type, std::string name,
               std::string path, std::optional<File> file, bool is_shipped,
               bool is_external, bool is_accessible);

  [[nodiscard]] HtmlResourceType type() const override;
  [[nodiscard]] const std::string &mime_type() const override;
  [[nodiscard]] const std::string &name() const override;
  [[nodiscard]] const std::string &path() const override;
  [[nodiscard]] const std::optional<File> &file() const override;
  [[nodiscard]] bool is_shipped() const override;
  [[nodiscard]] bool is_external() const override;
  [[nodiscard]] bool is_accessible() const override;

  void write_resource(std::ostream &os) const override;

private:
  HtmlResourceType m_type{};
  std::string m_mime_type;
  std::string m_name;
  std::string m_path;
  std::optional<File> m_file;
  bool m_is_shipped{};
  bool m_is_external{};
  bool m_is_accessible{};
};

} // namespace odr::internal::html
