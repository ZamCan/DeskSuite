#include <odr/internal/html/document_style.hpp>

#include <odr/document_element.hpp>
#include <odr/style.hpp>

#include <odr/internal/html/common.hpp>
#include <odr/internal/util/number_util.hpp>
#include <odr/internal/util/string_util.hpp>
#include <odr/internal/xml/xml_util.hpp>

#include <array>

#include <fmt/format.h>

namespace odr::internal {

namespace {

/// Whether @p word is in @p family and no letter follows it: "Liberation Mono"
/// and "RobotoMono-Regular", not "Monotype Corsiva".
bool contains_word(const std::string_view family, const std::string_view word) {
  for (std::size_t at = util::string::find_ignore_case(family, word);
       at != std::string_view::npos;
       at = util::string::find_ignore_case(family, word, at + 1)) {
    const std::size_t after = at + word.size();
    if (after == family.size() ||
        !util::string::is_ascii_letter(family[after])) {
      return true;
    }
  }
  return false;
}

const char *generic_font_family(const std::string_view family) {
  static constexpr std::array monospace{
      "mono",   "courier", "consolas",    "lucida console", "menlo",
      "monaco", "cousine", "inconsolata", "source code"};
  static constexpr std::array serif{
      "times",        "georgia",     "cambria",   "garamond",
      "book antiqua", "palatino",    "bookman",   "century schoolbook",
      "constantia",   "baskerville", "thorndale", "tinos",
      "caladea",      "minion",      "didot",     "bodoni"};
  for (const char *name : monospace) {
    if (contains_word(family, name)) {
      return "monospace";
    }
  }
  if (util::string::find_ignore_case(family, "sans") ==
          std::string_view::npos &&
      contains_word(family, "serif")) {
    return "serif";
  }
  for (const char *name : serif) {
    if (util::string::starts_with_ignore_case(family, name)) {
      return "serif";
    }
  }
  return "sans-serif";
}

bool is_generic_font_family(const std::string_view family) {
  static constexpr std::array generic{"serif",   "sans-serif", "monospace",
                                      "cursive", "fantasy",    "system-ui",
                                      "math",    "emoji",      "fangsong"};
  for (const char *name : generic) {
    if (util::string::equals_ignore_case(family, name)) {
      return true;
    }
  }
  return false;
}

/// An ODF `svg:font-family` is a CSS list already: each entry a whole quoted
/// string or a name of letters, digits, spaces, `-` and `_`.
bool is_font_family_list(const std::string_view value) {
  std::size_t begin = 0;
  while (begin <= value.size()) {
    const std::size_t comma = value.find(',', begin);
    const std::string_view entry = util::string::trim_view(value.substr(
        begin, comma == std::string_view::npos ? std::string_view::npos
                                               : comma - begin));
    if (entry.empty()) {
      return false;
    }
    if (entry.front() == '\'' || entry.front() == '"') {
      if (entry.size() < 2 || entry.back() != entry.front() ||
          entry.substr(1, entry.size() - 2).find_first_of("'\"\\") !=
              std::string_view::npos) {
        return false;
      }
    } else {
      for (const char c : entry) {
        if (!util::string::is_ascii_letter_or_digit(c) && c != ' ' &&
            c != '-' && c != '_' && static_cast<unsigned char>(c) < 0x80) {
          return false;
        }
      }
    }
    if (comma == std::string_view::npos) {
      return true;
    }
    begin = comma + 1;
  }
  return false;
}

} // namespace

std::string html::translate_font_family(const std::string_view font_name) {
  const std::string_view value = util::string::trim_view(font_name);
  // a keyword, which quotes would turn into the name of a font no one has
  if (is_generic_font_family(value)) {
    return std::string(value);
  }
  if (value.find_first_of("'\",") == std::string_view::npos ||
      !is_font_family_list(value)) {
    std::string result = "'";
    for (const char c : value) {
      if (static_cast<unsigned char>(c) < 0x20) {
        // a raw line break ends a CSS string
        result += fmt::format("\\{:x} ", static_cast<unsigned char>(c));
        continue;
      }
      if (c == '\\' || c == '\'') {
        result += '\\';
      }
      result += c;
    }
    return result.append("',").append(generic_font_family(value));
  }

  const std::size_t comma = value.find(',');
  const std::string_view first =
      util::string::trim_view(value.substr(0, comma), [](const char c) {
        return util::string::is_ascii_whitespace(c) || c == '\'' || c == '"';
      });
  const std::string_view last = util::string::trim_view(
      comma == std::string_view::npos ? value
                                      : value.substr(value.rfind(',') + 1));
  if (is_generic_font_family(last)) {
    return std::string(value);
  }
  return std::string(value).append(",").append(generic_font_family(first));
}

const char *html::translate_text_align(const TextAlign text_align) {
  switch (text_align) {
  case TextAlign::left:
    return "left";
  case TextAlign::right:
    return "right";
  case TextAlign::center:
    return "center";
  case TextAlign::justify:
    return "justify";
  case TextAlign::start:
    return "start";
  case TextAlign::end:
    return "end";
  default:
    return ""; // TODO log
  }
}

const char *html::translate_text_direction(const TextDirection direction) {
  switch (direction) {
  case TextDirection::left_to_right:
    return "ltr";
  case TextDirection::right_to_left:
    return "rtl";
  default:
    return ""; // TODO log
  }
}

const char *
html::translate_horizontal_align(const HorizontalAlign horizontal_align) {
  switch (horizontal_align) {
  case HorizontalAlign::left:
    return "left";
  case HorizontalAlign::center:
    return "center";
  case HorizontalAlign::right:
    return "right";
  default:
    return ""; // TODO log
  }
}

const char *html::translate_vertical_align(const VerticalAlign vertical_align) {
  switch (vertical_align) {
  case VerticalAlign::top:
    return "top";
  case VerticalAlign::middle:
    return "middle";
  case VerticalAlign::bottom:
    return "bottom";
  default:
    return ""; // TODO log
  }
}

const char *html::translate_break(const BreakType break_type) {
  switch (break_type) {
  case BreakType::page:
    return "page";
  case BreakType::column:
    return "column";
  case BreakType::none:
    // The css initial value; the model needs it only for style inheritance.
    return nullptr;
  }
  return nullptr;
}

const char *html::translate_font_weight(const FontWeight font_weight) {
  switch (font_weight) {
  case FontWeight::normal:
    return "normal";
  case FontWeight::bold:
    return "bold";
  default:
    return ""; // TODO log
  }
}

const char *html::translate_font_style(const FontStyle font_style) {
  switch (font_style) {
  case FontStyle::normal:
    return "normal";
  case FontStyle::italic:
    return "italic";
  default:
    return ""; // TODO log
  }
}

const char *html::translate_font_position(const FontPosition font_position) {
  switch (font_position) {
  case FontPosition::normal:
    return "baseline";
  case FontPosition::super:
    return "super";
  case FontPosition::sub:
    return "sub";
  default:
    return ""; // TODO log
  }
}

std::string html::translate_outer_page_style(const PageLayout &page_layout) {
  std::string result;
  if (const std::optional<Measure> width = page_layout.width;
      width.has_value()) {
    result.append("width:").append(css_length(*width)).append(";");
  }
  if (const std::optional<Measure> height = page_layout.height;
      height.has_value()) {
    result.append("height:").append(css_length(*height)).append(";");
  }
  if (const std::optional<Color> background_color =
          page_layout.background_color;
      background_color.has_value()) {
    result.append("background-color:")
        .append(color(*background_color))
        .append(";");
  }
  return result;
}

std::string
html::translate_outer_flowing_page_style(const PageLayout &page_layout) {
  PageLayout flowing_page_layout = page_layout;
  flowing_page_layout.height = {};

  std::string result = translate_outer_page_style(flowing_page_layout);
  if (const std::optional<Measure> height = page_layout.height;
      height.has_value()) {
    result.append("min-height:").append(css_length(*height)).append(";");
  }
  return result;
}

std::string html::translate_inner_page_style(const PageLayout &page_layout) {
  std::string result;
  if (const std::optional<Quantity<double>> margin_right =
          page_layout.margin.right;
      margin_right.has_value()) {
    result.append("margin-right:")
        .append(css_length(*margin_right))
        .append(";");
  }
  if (const std::optional<Quantity<double>> margin_top = page_layout.margin.top;
      margin_top.has_value()) {
    result.append("margin-top:").append(css_length(*margin_top)).append(";");
  }
  if (const std::optional<Quantity<double>> margin_left =
          page_layout.margin.left;
      margin_left.has_value()) {
    result.append("margin-left:").append(css_length(*margin_left)).append(";");
  }
  if (const std::optional<Quantity<double>> margin_bottom =
          page_layout.margin.bottom;
      margin_bottom.has_value()) {
    result.append("margin-bottom:")
        .append(css_length(*margin_bottom))
        .append(";");
  }
  return result;
}

std::string html::translate_text_style(const TextStyle &text_style) {
  std::string result;
  if (const std::optional<std::string> &font_name = text_style.font_name;
      font_name.has_value() && !font_name->empty()) {
    result.append("font-family:")
        .append(xml::escape_attribute(translate_font_family(*font_name)))
        .append(";");
  }
  if (const std::optional<Measure> font_size = text_style.font_size;
      font_size.has_value()) {
    result.append("font-size:").append(css_length(*font_size)).append(";");
  }
  if (const std::optional<FontWeight> font_weight = text_style.font_weight;
      font_weight.has_value()) {
    result.append("font-weight:")
        .append(translate_font_weight(*font_weight))
        .append(";");
  }
  if (const std::optional<FontStyle> font_style = text_style.font_style;
      font_style.has_value()) {
    result.append("font-style:")
        .append(translate_font_style(*font_style))
        .append(";");
  }
  // one declaration: a second `text-decoration` replaces the first
  const bool underline =
      text_style.font_underline.has_value() && *text_style.font_underline;
  const bool line_through =
      text_style.font_line_through.has_value() && *text_style.font_line_through;
  if (underline || line_through) {
    result += "text-decoration:";
    if (underline) {
      result += "underline";
    }
    if (underline && line_through) {
      result += " ";
    }
    if (line_through) {
      result += "line-through";
    }
    result += ";";
  }
  if (const std::optional<std::string> font_shadow = text_style.font_shadow;
      font_shadow.has_value()) {
    result.append("text-shadow:")
        .append(xml::escape_attribute(*font_shadow))
        .append(";");
  }
  if (const std::optional<Color> font_color = text_style.font_color;
      font_color.has_value()) {
    result.append("color:").append(color(*font_color)).append(";");
  }
  if (const std::optional<Color> background_color = text_style.background_color;
      background_color.has_value()) {
    result.append("background-color:")
        .append(color(*background_color))
        .append(";");
  }
  if (const std::optional<FontPosition> font_position =
          text_style.font_position;
      font_position.has_value()) {
    result.append("vertical-align:")
        .append(translate_font_position(*font_position))
        .append(";");
  }
  return result;
}

std::string html::translate_block_font_style(const TextStyle &text_style) {
  std::string result;
  if (const std::optional<std::string> &font_name = text_style.font_name;
      font_name.has_value() && !font_name->empty()) {
    result.append("font-family:")
        .append(xml::escape_attribute(translate_font_family(*font_name)))
        .append(";");
  }
  if (const std::optional<Measure> font_size = text_style.font_size;
      font_size.has_value()) {
    result.append("font-size:").append(css_length(*font_size)).append(";");
  }
  return result;
}

std::string
html::translate_paragraph_style(const ParagraphStyle &paragraph_style,
                                const TextDirection base) {
  std::string result;
  if (const std::optional<TextDirection> direction = paragraph_style.direction;
      direction.has_value() && *direction != base) {
    result.append("direction:")
        .append(translate_text_direction(*direction))
        .append(";");
  }
  if (const std::optional<TextAlign> text_align = paragraph_style.text_align;
      text_align.has_value()) {
    result.append("text-align:")
        .append(translate_text_align(*text_align))
        .append(";");
  }
  if (const std::optional<Quantity<double>> margin_right =
          paragraph_style.margin.right;
      margin_right.has_value()) {
    result.append("margin-right:")
        .append(css_length(*margin_right))
        .append(";");
  }
  if (const std::optional<Quantity<double>> margin_top =
          paragraph_style.margin.top;
      margin_top.has_value()) {
    result.append("margin-top:").append(css_length(*margin_top)).append(";");
  }
  if (const std::optional<Quantity<double>> margin_left =
          paragraph_style.margin.left;
      margin_left.has_value()) {
    result.append("margin-left:").append(css_length(*margin_left)).append(";");
  }
  if (const std::optional<Quantity<double>> margin_bottom =
          paragraph_style.margin.bottom;
      margin_bottom.has_value()) {
    result.append("margin-bottom:")
        .append(css_length(*margin_bottom))
        .append(";");
  }
  if (const std::optional<Measure> line_height = paragraph_style.line_height;
      line_height.has_value()) {
    // a percent line height is relative to the text font size, which is
    // emitted on nested text spans; a CSS percentage would resolve against
    // this block's font size, while a unitless ratio inherits per element
    if (line_height->unit().name() == "%") {
      const Measure ratio(line_height->magnitude() * 1e-2, DynamicUnit(""));
      result.append("line-height:").append(ratio.to_string()).append(";");
    } else {
      result.append("line-height:")
          .append(css_length(*line_height))
          .append(";");
    }
  }
  if (const std::optional<Measure> text_indent = paragraph_style.text_indent;
      text_indent.has_value()) {
    result.append("text-indent:").append(css_length(*text_indent)).append(";");
  }
  // Paged media only; the sheet it starts is `TextHtmlFragment`'s business.
  if (const std::optional<BreakType> break_before =
          paragraph_style.break_before;
      break_before.has_value()) {
    if (const char *value = translate_break(*break_before); value != nullptr) {
      result.append("break-before:").append(value).append(";");
    }
  }
  if (const std::optional<BreakType> break_after = paragraph_style.break_after;
      break_after.has_value()) {
    if (const char *value = translate_break(*break_after); value != nullptr) {
      result.append("break-after:").append(value).append(";");
    }
  }
  return result;
}

std::string html::translate_table_style(const TableStyle &table_style) {
  std::string result;
  if (const std::optional<Measure> width = table_style.width;
      width.has_value()) {
    result.append("width:").append(css_length(*width)).append(";");
  }
  return result;
}

std::string
html::translate_table_column_style(const TableColumnStyle &table_column_style) {
  std::string result;
  if (const std::optional<Measure> width = table_column_style.width;
      width.has_value()) {
    result.append("width:").append(css_length(*width)).append(";");
    result.append("min-width:").append(css_length(*width)).append(";");
  }
  return result;
}

std::string
html::translate_table_row_style(const TableRowStyle &table_row_style) {
  std::string result;
  // html takes a row height as a minimum; capping one would have to go on the
  // cells
  if (const std::optional<Measure> height = table_row_style.height;
      height.has_value()) {
    result.append("height:").append(css_length(*height)).append(";");
  }
  return result;
}

std::string
html::translate_table_cell_style(const TableCellStyle &table_cell_style,
                                 const bool dark_fill) {
  std::string result;
  if (const std::optional<HorizontalAlign> horizontal_align =
          table_cell_style.horizontal_align;
      horizontal_align.has_value() &&
      *horizontal_align != HorizontalAlign::general) {
    result.append("text-align:")
        .append(translate_horizontal_align(*horizontal_align))
        .append(";");
  }
  if (const std::optional<VerticalAlign> vertical_align =
          table_cell_style.vertical_align;
      vertical_align.has_value()) {
    result.append("vertical-align:")
        .append(translate_vertical_align(*vertical_align))
        .append(";");
  }
  if (const std::optional<Color> background_color =
          table_cell_style.background_color;
      background_color.has_value()) {
    result.append("background-color:")
        .append(color(*background_color))
        .append(";");
    if (dark_fill) {
      result.append("--odr-dark-fill:")
          .append(color(html::dark_fill(*background_color)))
          .append(";--odr-fill:")
          .append(color(*background_color))
          .append(";");
    }
  }
  if (const std::optional<Quantity<double>> padding_right =
          table_cell_style.padding.right;
      padding_right.has_value()) {
    result.append("padding-right:")
        .append(css_length(*padding_right))
        .append(";");
  }
  if (const std::optional<Quantity<double>> padding_top =
          table_cell_style.padding.top;
      padding_top.has_value()) {
    result.append("padding-top:").append(css_length(*padding_top)).append(";");
  }
  if (const std::optional<Quantity<double>> padding_left =
          table_cell_style.padding.left;
      padding_left.has_value()) {
    result.append("padding-left:")
        .append(css_length(*padding_left))
        .append(";");
  }
  if (const std::optional<Quantity<double>> padding_bottom =
          table_cell_style.padding.bottom;
      padding_bottom.has_value()) {
    result.append("padding-bottom:")
        .append(css_length(*padding_bottom))
        .append(";");
  }
  if (const std::optional<std::string> border_right =
          table_cell_style.border.right;
      border_right.has_value()) {
    result.append("border-right:")
        .append(xml::escape_attribute(*border_right))
        .append(";");
  }
  if (const std::optional<std::string> border_top = table_cell_style.border.top;
      border_top.has_value()) {
    result.append("border-top:")
        .append(xml::escape_attribute(*border_top))
        .append(";");
  }
  if (const std::optional<std::string> border_left =
          table_cell_style.border.left;
      border_left.has_value()) {
    result.append("border-left:")
        .append(xml::escape_attribute(*border_left))
        .append(";");
  }
  if (const std::optional<std::string> border_bottom =
          table_cell_style.border.bottom;
      border_bottom.has_value()) {
    result.append("border-bottom:")
        .append(xml::escape_attribute(*border_bottom))
        .append(";");
  }
  if (const std::optional<double> text_rotation =
          table_cell_style.text_rotation;
      text_rotation.has_value() && *text_rotation != 0) {
    // TODO covers only the -90° case
    result.append("writing-mode:vertical-lr;");
  }
  return result;
}

std::string html::translate_drawing_style(const GraphicStyle &graphic_style) {
  std::string result;
  if (const std::optional<Measure> stroke_width = graphic_style.stroke_width;
      stroke_width.has_value()) {
    result.append("stroke-width:")
        .append(css_length(*stroke_width))
        .append(";");
  }
  if (const std::optional<Color> stroke_color = graphic_style.stroke_color;
      stroke_color.has_value()) {
    result.append("stroke:").append(color(*stroke_color)).append(";");
  }
  if (const std::optional<Color> fill_color = graphic_style.fill_color;
      fill_color.has_value()) {
    result.append("fill:").append(color(*fill_color)).append(";");
  }
  if (const std::optional<VerticalAlign> vertical_align =
          graphic_style.vertical_align;
      vertical_align.has_value()) {
    if (vertical_align == VerticalAlign::middle) {
      result += "display:flex;justify-content:center;flex-direction:column;";
    }
    // TODO else log
  }
  return result;
}

std::string html::translate_drawing_transform(
    const std::optional<DrawingTransform> &transform) {
  if (!transform.has_value()) {
    return "";
  }

  const auto number = [](const double value) {
    return util::number::to_string_significant(value, 7);
  };

  // Css applies the list right to left, so the linear part goes last.
  std::string result;
  if (transform->e.magnitude() != 0 || transform->f.magnitude() != 0) {
    result.append("translate(")
        .append(css_length(transform->e))
        .append(",")
        .append(css_length(transform->f))
        .append(")");
  }
  if (transform->a != 1 || transform->b != 0 || transform->c != 0 ||
      transform->d != 1) {
    result.append(result.empty() ? "" : " ")
        .append("matrix(")
        .append(number(transform->a))
        .append(",")
        .append(number(transform->b))
        .append(",")
        .append(number(transform->c))
        .append(",")
        .append(number(transform->d))
        .append(",0,0)");
  }
  if (result.empty()) {
    return "";
  }
  // Css would otherwise turn the box about its centre.
  return "transform:" + result + ";transform-origin:0 0;";
}

std::string html::translate_frame_properties(const Frame &frame) {
  const GraphicStyle style = frame.style();

  auto text_wrap = TextWrap::run_through;
  if (style.text_wrap.has_value()) {
    text_wrap = *style.text_wrap;
  }

  // a side, but only where no offset already places the frame
  auto horizontal_position = HorizontalAlign::left;
  if (!frame.x().has_value() && style.horizontal_position.has_value()) {
    horizontal_position = *style.horizontal_position;
  }

  // Only a frame anchored in the text takes its place from the wrap. Text does
  // not flow around a page-anchored one: css cannot place a box away from where
  // it sits in the flow and still have the flow react to it.
  const AnchorType anchor_type = frame.anchor_type();
  const bool in_text = anchor_type != AnchorType::at_page;

  // The frame is what its image sizes against.
  std::string result;
  if (anchor_type == AnchorType::as_char) {
    result += "position:relative;";
    result += "display:inline-block;";
  } else if (in_text && text_wrap == TextWrap::before) {
    result += "position:relative;";
    result += "display:block;";
    result += "float:right;clear:both;";
    result += "shape-outside:content-box;";
    const std::optional<Measure> x = frame.x();
    if (x.has_value()) {
      result += "margin-left:" + css_length(*x) + ";";
    }
    if (const std::optional<Measure> y = frame.y(); y.has_value()) {
      result += "margin-top:" + css_length(*y) + ";";
    }
    // holds the frame at its offset; with no offset it would pin it left
    if (const std::optional<Measure> width = frame.width();
        width.has_value() && x.has_value()) {
      result += "margin-right:calc(100% - ";
      result += css_length(*x);
      result += " - ";
      result += css_length(*width);
      result += ");";
    }
  } else if (in_text && text_wrap == TextWrap::after) {
    result += "position:relative;";
    result += "display:block;";
    result += "float:left;clear:both;";
    result += "shape-outside:content-box;";
    if (const std::optional<Measure> x = frame.x(); x.has_value()) {
      result += "margin-left:" + css_length(*x) + ";";
    }
    if (const std::optional<Measure> y = frame.y(); y.has_value()) {
      result += "margin-top:" + css_length(*y) + ";";
    }
  } else if (in_text && text_wrap == TextWrap::none) {
    result += "position:relative;";
    result += "display:block;";
    if (const std::optional<Measure> x = frame.x(); x.has_value()) {
      result += "margin-left:" + css_length(*x) + ";";
    }
    if (horizontal_position == HorizontalAlign::center) {
      result += "margin-left:auto;margin-right:auto;";
    } else if (horizontal_position == HorizontalAlign::right) {
      result += "margin-left:auto;";
    }
    if (const std::optional<Measure> y = frame.y(); y.has_value()) {
      result += "margin-top:" + css_length(*y) + ";";
    }
  } else {
    result += "display:block;";
    result += "position:absolute;";
    if (const std::optional<Measure> x = frame.x(); x.has_value()) {
      result += "left:" + css_length(*x) + ";";
    }
    if (horizontal_position == HorizontalAlign::center) {
      result += "left:0;right:0;margin-left:auto;margin-right:auto;";
    } else if (horizontal_position == HorizontalAlign::right) {
      result += "right:0;";
    }
    if (const std::optional<Measure> y = frame.y(); y.has_value()) {
      result += "top:" + css_length(*y) + ";";
    }
  }
  if (const std::optional<Measure> width = frame.width(); width.has_value()) {
    result += "width:" + css_length(*width) + ";";
  }
  if (const std::optional<Measure> height = frame.height();
      height.has_value()) {
    result += "height:" + css_length(*height) + ";";
  }
  if (const std::optional<std::int32_t> z_index = frame.z_index();
      z_index.has_value()) {
    result += "z-index:" + std::to_string(*z_index) + ";";
  }
  result += translate_drawing_transform(frame.transform());
  return result;
}

std::string html::translate_shape_properties(const Frame &frame) {
  std::string result;
  result += "position:absolute;";
  if (const std::optional<Measure> x = frame.x(); x.has_value()) {
    result += "left:" + css_length(*x) + ";";
  } else {
    result += "left:0;";
  }
  if (const std::optional<Measure> y = frame.y(); y.has_value()) {
    result += "top:" + css_length(*y) + ";";
  } else {
    result += "top:0;";
  }
  if (const std::optional<Measure> width = frame.width(); width.has_value()) {
    result += "width:" + css_length(*width) + ";";
  } else {
    result += "width:0;";
  }
  if (const std::optional<Measure> height = frame.height();
      height.has_value()) {
    result += "height:" + css_length(*height) + ";";
  } else {
    result += "height:0;";
  }
  result += translate_drawing_transform(frame.transform());
  return result;
}

} // namespace odr::internal
