(function () {
  "use strict";

  // The sheet: the ruler, and a table for each chunk of rows
  // (`lazy-loading.md` decision 3).
  var table = document.querySelector(".odr-sheet");
  if (table === null) {
    return;
  }

  var odr = (window.odr = window.odr || {});

  var merged = table.querySelector("td[colspan],td[rowspan]") !== null;

  // the position map is built off the rows the page has, and a chunk that
  // loads later may bring a merge
  table.addEventListener("odr-chunk-filled", function (event) {
    index = null;
    merged = merged || event.target.querySelector("td[colspan],td[rowspan]") !== null;
  });
  var head = table.querySelector(".odr-sheet-head");
  var headerRow = head.tHead.rows[0];
  var chunks = table.getElementsByClassName("odr-sheet-rows");

  // Every row of every chunk, in the order the page shows them.
  function bodyRows() {
    return table.querySelectorAll(".odr-sheet-rows>tbody>tr");
  }

  // The `tbody` a row goes into past the last one, a new chunk where every
  // chunk went with the rows it held.
  function lastBody() {
    if (chunks.length > 0) {
      return chunks[chunks.length - 1].tBodies[0];
    }
    var chunk = document.createElement("table");
    chunk.className = "odr-sheet-rows odr-chunk odr-chunk-near";
    chunk.appendChild(cloneColumns());
    chunk.appendChild(document.createElement("tbody"));
    table.appendChild(chunk);
    if (odr.chunks !== undefined) {
      odr.chunks.observe(chunk);
    }
    return chunk.tBodies[0];
  }

  // The `col`s of the ruler, for a table that has none.
  function cloneColumns() {
    var fragment = document.createDocumentFragment();
    head.querySelectorAll("col").forEach(function (col) {
      fragment.appendChild(col.cloneNode(false));
    });
    return fragment;
  }

  // Every table states the sheet's width, so a column that goes in or out
  // changes it by @p pixels.
  function widen(pixels) {
    var width = parseFloat(table.style.getPropertyValue("--odr-sheet-width"));
    if (!isNaN(width)) {
      table.style.setProperty("--odr-sheet-width", width + pixels + "px");
    }
  }

  // Takes a chunk with no row left away, because it would keep its height.
  // One that has not loaded its rows yet keeps them to come.
  function dropEmptyChunks() {
    for (var i = chunks.length - 1; i >= 0; --i) {
      if (
        chunks[i].tBodies[0].rows.length === 0 &&
        !chunks[i].hasAttribute("data-odr-chunk-src")
      ) {
        chunks[i].remove();
      }
    }
  }

  var style = document.createElement("style");
  document.head.appendChild(style);

  var hovered = -1;
  var pinnedColumn = -1;
  var pinnedRow = null;
  var pinnedCell = null;

  // Column 0 is the gutter, which labels no column.
  function columnRule(index, wash, scope) {
    if (index < 1) {
      return "";
    }
    return (
      ".odr-sheet " +
      scope +
      "tr>:nth-child(" +
      (index + 1) +
      "){background-image:linear-gradient(" +
      wash +
      "," +
      wash +
      ")}"
    );
  }

  // The ruler reacts harder than the cells: it is the label being followed.
  function paint() {
    style.textContent =
      columnRule(hovered, "var(--odr-sheet-wash)", "") +
      columnRule(pinnedColumn, "var(--odr-sheet-wash-pinned)", "") +
      columnRule(hovered, "var(--odr-sheet-wash-ruler)", "thead ") +
      columnRule(pinnedColumn, "var(--odr-sheet-wash-ruler)", "thead ");
  }

  // What the wash paints: the cell's place among the ones written beside it,
  // gutter included, which is what `nth-child` counts. Not a position - a
  // merge writes nothing for a covered one, and gets no wash either.
  function rulerColumn(cell) {
    return cell !== null && !merged ? cell.cellIndex : -1;
  }

  // The gutter's label, which names the row wherever a sort has put it.
  function rowOf(tr) {
    return Number(tr.cells[0].textContent) - 1;
  }

  var index = null;

  // Whether a cell above still reaches into @p row.
  function holds(above, row) {
    return above !== undefined && above.last >= row;
  }

  // A row by its label and, where the sheet merges, its cells by position.
  // Walked once: a merged sheet is offered no sort control, so the rows are
  // still in the file's order here and one pass can carry the rowspans down.
  function build() {
    var index = { rows: new Map(), positions: new Map() };
    var covered = [];
    var rows = bodyRows();
    for (var i = 0; i < rows.length; ++i) {
      var tr = rows[i];
      var row = rowOf(tr);
      var line = [];
      index.rows.set(row, { tr: tr, cells: line });
      if (!merged) {
        continue;
      }
      var column = 0;
      for (var j = 1; j < tr.cells.length; ++j) {
        var td = tr.cells[j];
        while (holds(covered[column], row)) {
          line[column] = covered[column].cell;
          ++column;
        }
        var columns = Number(td.getAttribute("colspan") || 1);
        var last = row + Number(td.getAttribute("rowspan") || 1) - 1;
        for (var k = 0; k < columns; ++k) {
          line[column + k] = td;
          covered[column + k] = { last: last, cell: td };
        }
        index.positions.set(td, { column: column, row: row });
        column += columns;
      }
      // A rowspan reaching past the row's last cell covers the rest of it.
      for (; column < covered.length; ++column) {
        if (holds(covered[column], row)) {
          line[column] = covered[column].cell;
        }
      }
    }
    return index;
  }

  function indexed() {
    if (index === null) {
      index = build();
    }
    return index;
  }

  // The `td` at a position, or null past the sheet's extent. A position a
  // merge covers answers with the cell covering it, which is the one the file
  // states and an op names.
  function cellAt(column, row) {
    var entry = indexed().rows.get(row);
    if (entry === undefined || column < 0) {
      return null;
    }
    var cell = merged ? entry.cells[column] : entry.tr.cells[column + 1];
    return cell === undefined ? null : cell;
  }

  // Where a `td` sits, the way an op names it. Null for anything else - a
  // header, a cell of another table.
  function positionOf(cell) {
    if (cell === null || cell.tagName !== "TD") {
      return null;
    }
    if (merged) {
      var position = indexed().positions.get(cell);
      return position === undefined
        ? null
        : { column: position.column, row: position.row };
    }
    return { column: cell.cellIndex - 1, row: rowOf(cell.parentElement) };
  }

  var raisedCell = null;
  var raisedWrapper = null;
  var raisedContent = null;

  // The block the cell writes, or the cell where it writes none. `null` for
  // anything else — a shape, several blocks — which is not raised.
  function boxOf(cell) {
    if (cell.childElementCount === 0) {
      return cell;
    }
    var only = cell.firstElementChild;
    return cell.childElementCount === 1 && only.tagName === "X-P" ? only : null;
  }

  // Past the cell's edge by the spill `translate_sheet` measured, at the edge
  // where it clips, unbounded where it does neither.
  function visibleRight(cell) {
    var style = getComputedStyle(cell);
    var right = cell.getBoundingClientRect().right;
    var inset = /inset\(([^)]*)\)/.exec(style.clipPath || "");
    if (inset !== null) {
      var sides = inset[1].trim().split(/\s+/);
      return sides.length > 1 ? right - parseFloat(sides[1]) : right;
    }
    return style.overflow === "visible" ? Infinity : right;
  }

  // On the text, not the box: what is cut off is the string running past where
  // the cell still paints.
  function cutOff(cell, box) {
    var range = document.createRange();
    range.selectNodeContents(box);
    var ink = range.getBoundingClientRect();
    var rect = cell.getBoundingClientRect();
    return (
      ink.width > 0 &&
      (ink.right > visibleRight(cell) + 1 ||
        (getComputedStyle(cell).overflow !== "visible" &&
          ink.bottom > rect.bottom + 1))
    );
  }

  function lower() {
    if (raisedCell === null) {
      return;
    }
    raisedCell.classList.remove("odr-sheet-raised");
    if (raisedWrapper !== null) {
      while (raisedWrapper.firstChild) {
        raisedCell.insertBefore(raisedWrapper.firstChild, raisedWrapper);
      }
      raisedWrapper.remove();
      raisedWrapper = null;
    }
    raisedContent = null;
    raisedCell = null;
  }

  // Over its neighbours rather than pushing them aside.
  function raise(cell) {
    lower();
    if (cell === null || cell.tagName !== "TD") {
      return;
    }
    var box = boxOf(cell);
    if (box === null || !cutOff(cell, box)) {
      return;
    }
    if (box === cell) {
      raisedWrapper = document.createElement("span");
      raisedWrapper.className = "odr-sheet-raised-box";
      while (cell.firstChild) {
        raisedWrapper.appendChild(cell.firstChild);
      }
      cell.appendChild(raisedWrapper);
      box = raisedWrapper;
    }
    cell.classList.add("odr-sheet-raised");
    raisedCell = cell;
    raisedContent = box;
  }

  function pin(column, row, cell) {
    lower();
    focus = null;
    if (pinnedRow !== null) {
      pinnedRow.classList.remove("odr-sheet-pinned");
    }
    if (pinnedCell !== null) {
      pinnedCell.classList.remove("odr-sheet-pinned-cell");
    }

    pinnedColumn = column;
    pinnedRow = row;
    pinnedCell = cell;

    if (pinnedRow !== null) {
      pinnedRow.classList.add("odr-sheet-pinned");
    }
    if (pinnedCell !== null) {
      pinnedCell.classList.add("odr-sheet-pinned-cell");
      raise(pinnedCell);
    }
    paint();
    paintSelection();
  }

  // The corner a gesture moved, the pin being the other; null while the
  // selection is the pin alone.
  var focus = null;
  var selected = [];

  function lastRow() {
    var last = -1;
    indexed().rows.forEach(function (entry, row) {
      last = Math.max(last, row);
    });
    return last;
  }

  function lastColumn() {
    return headerRow.children.length - 2;
  }

  // The rectangle the pin and the focus span, a header's row or column across
  // the rendered extent, null where nothing is pinned.
  function selectionOf() {
    var at = pinnedPosition();
    if (at === null) {
      return null;
    }
    if (at.column === null && at.row === null) {
      return null;
    }
    if (at.row === null) {
      return {
        columns: [at.column, at.column],
        rows: [0, lastRow()],
        focus: null,
      };
    }
    if (at.column === null) {
      return { columns: [0, lastColumn()], rows: [at.row, at.row], focus: null };
    }
    var to = focus === null ? at : focus;
    return {
      columns: [Math.min(at.column, to.column), Math.max(at.column, to.column)],
      rows: [Math.min(at.row, to.row), Math.max(at.row, to.row)],
      focus: { column: to.column, row: to.row },
    };
  }

  // Every cell of the selection once, at the position an op names it by: a
  // merge answers with its anchor.
  function selectedCells() {
    var range = selectionOf();
    var result = [];
    if (range === null) {
      return result;
    }
    var seen = new Set();
    for (var row = range.rows[0]; row <= range.rows[1]; ++row) {
      for (var column = range.columns[0]; column <= range.columns[1]; ++column) {
        var cell = cellAt(column, row);
        if (cell === null || seen.has(cell)) {
          continue;
        }
        seen.add(cell);
        var position = positionOf(cell);
        result.push({ cell: cell, column: position.column, row: position.row });
      }
    }
    return result;
  }

  // The pin's outline marks a single cell, so only a wider selection is washed.
  function paintSelection() {
    for (var i = 0; i < selected.length; ++i) {
      selected[i].classList.remove("odr-sheet-selected");
    }
    selected = [];
    var cells = selectedCells();
    if (cells.length > 1) {
      for (var j = 0; j < cells.length; ++j) {
        cells[j].cell.classList.add("odr-sheet-selected");
        selected.push(cells[j].cell);
      }
    }
    table.dispatchEvent(new CustomEvent("odr-sheet-select"));
  }

  // Moves the focus to @p position, the pin staying where it is. False where
  // no cell is pinned or the sheet holds none there.
  function select(position) {
    var at = pinnedPosition();
    if (at === null || at.column === null || at.row === null) {
      return false;
    }
    if (cellAt(position.column, position.row) === null) {
      return false;
    }
    if (
      focus !== null &&
      focus.column === position.column &&
      focus.row === position.row
    ) {
      return true;
    }
    focus = { column: position.column, row: position.row };
    paintSelection();
    return true;
  }

  // What is pinned: a cell, or a whole column or row where a header is, the
  // axis that header does not name being null. Null where nothing is pinned.
  function pinnedPosition() {
    if (pinnedCell === null) {
      return null;
    }
    var position = positionOf(pinnedCell);
    if (position !== null) {
      return { column: position.column, row: position.row, cell: pinnedCell };
    }
    return {
      column: pinnedCell.classList.contains("odr-sheet-column-header")
        ? pinnedCell.cellIndex - 1
        : null,
      row: pinnedRow === null ? null : rowOf(pinnedRow),
      cell: pinnedCell,
    };
  }

  // Pins the cell at a position, as a click on it does; null clears the pin.
  // False where the sheet holds no such cell.
  function pinAt(position) {
    if (position === null) {
      pin(-1, null, null);
      return true;
    }
    var cell = cellAt(position.column, position.row);
    if (cell === null) {
      return false;
    }
    pin(rulerColumn(cell), cell.parentElement, cell);
    return true;
  }

  // Nothing a reader would see, so the cell beside it may spill over it.
  function isBlank(cell) {
    return (
      cell.textContent.trim() === "" &&
      cell.querySelector(":not(x-p):not(x-s)") === null
    );
  }

  // A row's cells by position, a covered one answering with the cell covering
  // it. Null past the sheet's last row.
  function rowCells(row) {
    var entry = indexed().rows.get(row);
    if (entry === undefined) {
      return null;
    }
    if (merged) {
      return entry.cells;
    }
    return Array.prototype.slice.call(entry.tr.cells, 1);
  }

  // The row's cells once each, with what `translate_sheet` states about them:
  // `max-width:0` where the column states a width, which is where it also
  // clips, and `nowrap` where the string may run past the cell.
  function rowState(row) {
    var cells = rowCells(row);
    if (cells === null) {
      return null;
    }
    var line = [];
    for (var i = 0; i < cells.length; ++i) {
      if (cells[i] === cells[i - 1]) {
        continue;
      }
      var style = getComputedStyle(cells[i]);
      line.push({
        cell: cells[i],
        blank: isBlank(cells[i]),
        sized: style.maxWidth === "0px",
        // a cell preserves its white space, so the shorthand reads `pre`
        nowrap: (style.textWrapMode || style.whiteSpace) === "nowrap",
      });
    }
    return line;
  }

  // The rows a `reflow` waits on, by label.
  var waiting = new Set();

  table.addEventListener("odr-chunk-near", function (event) {
    waiting.forEach(function (row) {
      var entry = indexed().rows.get(row);
      if (entry === undefined || event.target.contains(entry.tr)) {
        waiting.delete(row);
        if (entry !== undefined) {
          reflow(row);
        }
      }
    });
  });

  // The spill `translate_sheet` measured goes stale the moment a cell fills or
  // empties: its rule again, off the geometry the browser has. Offsets, not
  // rects: blink scales a rect by the body zoom, a `clip-path` is stated under
  // it.
  function reflow(row) {
    // a far chunk has no geometry: its rows wait until it is near
    var at = indexed().rows.get(row);
    var chunk = at === undefined ? null : at.tr.closest(".odr-chunk");
    // without lazy layout, the rows are in no chunk
    if (chunk !== null && !chunk.classList.contains("odr-chunk-near")) {
      waiting.add(row);
      return true;
    }
    var line = rowState(row);
    if (line === null) {
      return false;
    }

    // What each cell sees to its right: the next one showing something, or
    // the column stating no width that stops the spill before one.
    var bound = null;
    var stopped = false;
    for (var i = line.length - 1; i >= 0; --i) {
      line[i].bound = bound;
      line[i].stopped = stopped;
      if (!line[i].blank) {
        bound = line[i].cell;
        stopped = false;
      } else if (!line[i].sized) {
        bound = null;
        stopped = true;
      }
    }

    for (var j = 0; j < line.length; ++j) {
      var entry = line[j];
      if (!entry.sized || !entry.nowrap) {
        continue;
      }
      var spill =
        entry.bound === null
          ? 0
          : entry.bound.offsetLeft -
            entry.cell.offsetLeft -
            entry.cell.offsetWidth;
      entry.cell.style.overflow =
        spill > 0.5 || (entry.bound === null && !entry.stopped)
          ? "visible"
          : "hidden";
      entry.cell.style.clipPath =
        spill > 0.5 ? "inset(0 " + -spill + "px 0 0)" : "none";
    }
    return true;
  }

  // The run a write goes through, so its style survives; the cell itself
  // where it writes its string without one.
  function runOf(cell) {
    var box = boxOf(cell);
    while (
      box !== null &&
      box.childElementCount === 1 &&
      box.firstElementChild.tagName === "X-S"
    ) {
      box = box.firstElementChild;
    }
    return box;
  }

  // The text of a cell as an op states it: a line per block and per break.
  function textOf(node) {
    var text = "";
    var blocks = 0;
    for (var child = node.firstChild; child !== null; child = child.nextSibling) {
      if (child.nodeType === Node.TEXT_NODE) {
        text += child.nodeValue;
      } else if (child.tagName === "BR") {
        text += "\n";
      } else if (child.nodeType === Node.ELEMENT_NODE) {
        if (child.tagName === "X-P" && blocks++ > 0) {
          text += "\n";
        }
        text += textOf(child);
      }
    }
    return text;
  }

  // What the page shows at a position, shaped the way an op states a value.
  function valueAt(column, row) {
    var cell = cellAt(column, row);
    if (cell === null) {
      return null;
    }
    var text = textOf(cell);
    var kind = cell.classList.contains("odr-value-type-float")
      ? "number"
      : cell.classList.contains("odr-value-type-date")
        ? "date"
        : cell.classList.contains("odr-value-type-time")
          ? "time"
          : null;
    if (kind !== null) {
      // a formatted number, a date and a time state their value, a plain
      // number is its text
      var stated = cell.getAttribute("data-odr-value");
      var number =
        stated !== null ? Number(stated) : kind === "number" ? toNumber(text) : NaN;
      if (Number.isFinite(number)) {
        return { type: kind, number: number, text: text };
      }
    }
    return text === "" ? { type: "empty" } : { type: "string", text: text };
  }

  // The expression a formula cell computes, as the file spells it. Null for a
  // cell holding none, and for a read-only render, which writes no scaffolding.
  function formulaAt(column, row) {
    var cell = cellAt(column, row);
    return cell === null ? null : cell.getAttribute("data-odr-formula");
  }

  // Shows @p value at a position, as a write leaves the cell, and reflows
  // the row around it.
  function showValue(column, row, value) {
    var cell = cellAt(column, row);
    if (cell === null) {
      return false;
    }
    lower();
    var run = runOf(cell);
    var blocks = cell.querySelectorAll(":scope > x-p");
    if (run === null && blocks.length === cell.childElementCount) {
      // the lines go into the first block, as the file writes them
      for (var i = 1; i < blocks.length; ++i) {
        blocks[i].remove();
      }
      run = runOf(cell);
    }
    if (run === null) {
      return false;
    }
    run.textContent = value.type === "empty" ? "" : value.text;
    cell.classList.toggle("odr-value-type-float", value.type === "number");
    cell.classList.toggle("odr-value-type-date", value.type === "date");
    cell.classList.toggle("odr-value-type-time", value.type === "time");
    if (value.number !== undefined) {
      cell.setAttribute("data-odr-value", String(value.number));
    } else {
      cell.removeAttribute("data-odr-value");
    }
    // a boolean and an error, which a formula reads as what they are
    if (value.type === "boolean" || value.type === "error") {
      cell.setAttribute("data-odr-type", value.type);
    } else {
      cell.removeAttribute("data-odr-type");
    }
    reflow(row);
    return true;
  }

  // Whether a `rowspan` starting above @p row reaches it, so an edge there
  // would cut a merge.
  function spanReaches(row) {
    var cells = table.querySelectorAll("td[rowspan]");
    for (var i = 0; i < cells.length; ++i) {
      var top = rowOf(cells[i].parentElement);
      if (top < row && top + Number(cells[i].getAttribute("rowspan")) > row) {
        return true;
      }
    }
    return false;
  }

  // Labels every row from @p row on again, @p by further down.
  function relabel(row, by) {
    var rows = bodyRows();
    for (var i = 0; i < rows.length; ++i) {
      var label = rowOf(rows[i]);
      if (label >= row) {
        rows[i].cells[0].textContent = String(label + by + 1);
      }
    }
  }

  function changed() {
    index = null;
    if (pinnedRow !== null && !table.contains(pinnedRow)) {
      pin(-1, null, null);
    } else {
      paintSelection();
    }
  }

  // Puts @p rows in at @p row, where the row the label names is shown, or
  // after the one before it, and labels them and the rows below.
  function restoreRows(row, rows) {
    lower();
    var at = indexed().rows.get(row);
    var before = indexed().rows.get(row - 1);
    relabel(row, rows.length);
    for (var i = 0; i < rows.length; ++i) {
      rows[i].cells[0].textContent = String(row + i + 1);
      if (at !== undefined) {
        at.tr.parentNode.insertBefore(rows[i], at.tr);
      } else if (before !== undefined) {
        before.tr.parentNode.insertBefore(rows[i], before.tr.nextSibling);
        before = { tr: rows[i] };
      } else {
        lastBody().appendChild(rows[i]);
      }
    }
    changed();
  }

  // Inserts @p count unstyled rows at @p row. Returns null if the edit cuts a
  // merge or lies past the rendered rows.
  function insertRows(row, count) {
    if (row > lastRow() + 1 || spanReaches(row)) {
      return null;
    }
    var cols = head.querySelectorAll("col");
    var rows = [];
    for (var i = 0; i < count; ++i) {
      var tr = document.createElement("tr");
      var th = document.createElement("th");
      th.className = "odr-sheet-row-header";
      tr.appendChild(th);
      for (var column = 0; column <= lastColumn(); ++column) {
        var td = document.createElement("td");
        var width = cols[column + 1];
        td.style.cssText =
          (width !== undefined && width.style.width !== "" ? "max-width:0;" : "") +
          "white-space:nowrap";
        tr.appendChild(td);
      }
      rows.push(tr);
    }
    restoreRows(row, rows);
    return rows;
  }

  // Takes the rows from @p row on away, @p count of them at most, and moves
  // the rows below up. The rows taken, for `restoreRows`; null where an edge
  // would cut a merge.
  function deleteRows(row, count) {
    if (spanReaches(row) || spanReaches(row + count)) {
      return null;
    }
    lower();
    var rows = [];
    for (var at = row; at < row + count; ++at) {
      var entry = indexed().rows.get(at);
      if (entry !== undefined) {
        rows.push(entry.tr);
      }
    }
    rows.forEach(function (tr) {
      tr.remove();
    });
    dropEmptyChunks();
    relabel(row + count, -count);
    changed();
    return rows;
  }

  // The letters naming the column @p index, `A` for 0.
  function columnName(index) {
    var name = "";
    for (var n = index + 1; n > 0; n = Math.floor((n - 1) / 26)) {
      name = String.fromCharCode(65 + ((n - 1) % 26)) + name;
    }
    return name;
  }

  // The headers of the columns, the corner left out.
  function columnHeaders() {
    return Array.prototype.slice.call(headerRow.cells, 1);
  }

  function addSortControl(header) {
    var control = document.createElement("span");
    control.className = "odr-sheet-sort";
    header.appendChild(control);
  }

  // Whether a `colspan` starting left of @p column reaches it, so an edge
  // there would cut a merge.
  function colspanReaches(column) {
    var cells = table.querySelectorAll("td[colspan]");
    for (var i = 0; i < cells.length; ++i) {
      var left = positionOf(cells[i]).column;
      if (left < column && left + Number(cells[i].getAttribute("colspan")) > column) {
        return true;
      }
    }
    return false;
  }

  // States every column's letters again, and moves what a sort and the pin
  // hold by the place of a header, after @p count columns from @p column on
  // went in or out.
  function columnsChanged(column, count, inserted) {
    index = null;
    columnHeaders().forEach(function (header, at) {
      var letters = header.firstChild;
      if (letters === null || letters.nodeType !== Node.TEXT_NODE) {
        letters = header.insertBefore(document.createTextNode(""), header.firstChild);
      }
      letters.nodeValue = columnName(at);
      var control = header.querySelector(".odr-sheet-sort");
      if (control !== null) {
        control.setAttribute("title", "sort by column " + columnName(at));
      }
    });
    // `sortedColumn` is the header's place, the corner being 0
    var sorted = sortedColumn - 1;
    if (sorted >= column + (inserted ? 0 : count)) {
      sortedColumn += inserted ? count : -count;
    } else if (sorted >= column && !inserted) {
      sortedColumn = -1;
      sortedDirection = 0;
    }
    if (pinnedCell !== null && !table.contains(pinnedCell)) {
      pin(-1, null, null);
      return;
    }
    if (pinnedColumn >= 0) {
      pinnedColumn = rulerColumn(pinnedCell);
    }
    paint();
    paintSelection();
  }

  // Puts a `<col>` of each of the widths of @p slice into every table, and
  // its headers and cells in at @p column: a cell goes before the first one
  // of its row at or right of the column.
  function restoreColumns(column, slice) {
    lower();
    [head].concat(Array.prototype.slice.call(chunks)).forEach(function (part) {
      var cols = part.querySelectorAll("col");
      var nextCol = cols[column + 1] || null;
      slice.widths.forEach(function (width) {
        var col = document.createElement("col");
        col.style.width = width;
        cols[0].parentNode.insertBefore(
          col,
          nextCol === null ? cols[cols.length - 1].nextSibling : nextCol
        );
      });
    });
    slice.widths.forEach(function (width) {
      widen(parseFloat(width));
    });
    var nextHeader = columnHeaders()[column] || null;
    var places = slice.cells.map(function (entry) {
      var next = null;
      for (var i = 1; i < entry.tr.cells.length && next === null; ++i) {
        var at = positionOf(entry.tr.cells[i]);
        if (at !== null && at.column >= column) {
          next = entry.tr.cells[i];
        }
      }
      return next;
    });
    slice.headers.forEach(function (header) {
      headerRow.insertBefore(header, nextHeader);
    });
    slice.cells.forEach(function (entry, i) {
      entry.tds.forEach(function (td) {
        entry.tr.insertBefore(td, places[i]);
      });
    });
    columnsChanged(column, slice.headers.length, true);
  }

  // @p count empty columns from @p column on, the columns right of it moved
  // on. A new column is as wide as Excel's default one, because every table
  // of the sheet has to state it, and its cells have no style. Null where the
  // edge would cut a merge, or lies past the rendered columns.
  function insertColumns(column, count) {
    if (column > lastColumn() + 1 || colspanReaches(column)) {
      return null;
    }
    var slice = { widths: [], headers: [], cells: [] };
    for (var i = 0; i < count; ++i) {
      slice.widths.push("64px");
      var header = document.createElement("th");
      header.className = "odr-sheet-column-header";
      if (!merged) {
        addSortControl(header);
      }
      slice.headers.push(header);
    }
    var rows = bodyRows();
    for (var r = 0; r < rows.length; ++r) {
      var tds = [];
      for (var j = 0; j < count; ++j) {
        var td = document.createElement("td");
        td.style.cssText = "max-width:0;white-space:nowrap";
        tds.push(td);
      }
      slice.cells.push({ tr: rows[r], tds: tds });
    }
    restoreColumns(column, slice);
    return slice;
  }

  // Takes the columns from @p column on away, @p count of them at most, and
  // moves the columns right of them back. What was taken, for
  // `restoreColumns`; null where an edge would cut a merge.
  function deleteColumns(column, count) {
    if (colspanReaches(column) || colspanReaches(column + count)) {
      return null;
    }
    lower();
    var end = Math.min(column + count, lastColumn() + 1);
    var headers = columnHeaders();
    var slice = { widths: [], headers: [], cells: [] };
    var headCols = head.querySelectorAll("col");
    for (var at = column; at < end; ++at) {
      slice.widths.push(getComputedStyle(headCols[at + 1]).width);
      slice.headers.push(headers[at]);
    }
    [head].concat(Array.prototype.slice.call(chunks)).forEach(function (part) {
      var cols = part.querySelectorAll("col");
      for (var c = end; c > column; --c) {
        cols[c].remove();
      }
    });
    slice.widths.forEach(function (width) {
      widen(-parseFloat(width));
    });
    var rows = bodyRows();
    for (var r = 0; r < rows.length; ++r) {
      var tr = rows[r];
      var tds = [];
      for (var i = 1; i < tr.cells.length; ++i) {
        var position = positionOf(tr.cells[i]);
        if (position !== null && position.column >= column && position.column < end) {
          tds.push(tr.cells[i]);
        }
      }
      slice.cells.push({ tr: tr, tds: tds });
    }
    slice.headers.forEach(function (node) {
      node.remove();
    });
    slice.cells.forEach(function (entry) {
      entry.tds.forEach(function (td) {
        td.remove();
      });
    });
    columnsChanged(column, end - column, false);
    return slice;
  }

  // What the script beside this one, and a host, ask of the sheet: positions
  // the way an op names them, and the pin. `spreadsheet-editing.md` decision 8.
  odr.sheet = {
    cellAt: cellAt,
    positionOf: positionOf,
    pinned: pinnedPosition,
    pin: pinAt,
    lower: lower,
    valueAt: valueAt,
    formulaAt: formulaAt,
    showValue: showValue,
    reflow: reflow,
    selection: selectionOf,
    select: select,
    selectedCells: selectedCells,
    insertRows: insertRows,
    deleteRows: deleteRows,
    restoreRows: restoreRows,
    insertColumns: insertColumns,
    deleteColumns: deleteColumns,
    restoreColumns: restoreColumns,
  };

  table.addEventListener("mouseover", function (event) {
    var column = rulerColumn(event.target.closest("td,th"));
    if (column !== hovered) {
      hovered = column;
      paint();
    }
  });

  table.addEventListener("mouseleave", function () {
    hovered = -1;
    paint();
  });

  /// Whether the sheet is in the mode that writes cells. The editor is a
  /// script of its own, and a read-only view carries none of it.
  function editingEnabled() {
    return (
      odr.editing !== undefined &&
      typeof odr.editing.isEnabled === "function" &&
      odr.editing.isEnabled()
    );
  }

  table.addEventListener("click", function (event) {
    // Selecting inside what is raised must not put the cell back.
    if (raisedContent !== null && raisedContent.contains(event.target)) {
      return;
    }

    var cell = event.target.closest("td,th");
    if (cell === null) {
      return;
    }

    if (event.shiftKey && cell.tagName === "TD" && select(positionOf(cell))) {
      return;
    }

    // Clicking what is pinned clears it - but `detail` counts the clicks, and
    // the second of a double click is the reader selecting a word. Clearing
    // the pin under that flickers the border off again. A cell in an edited
    // sheet holds its pin too, because the editor opens over that cell and
    // reads it. A header opens none, so it still clears.
    if (cell === pinnedCell) {
      var takenByEditor = editingEnabled() && cell.tagName === "TD";
      if (event.detail <= 1 && !takenByEditor) {
        pin(-1, null, null);
      }
      return;
    }

    if (cell.classList.contains("odr-sheet-column-header")) {
      pin(rulerColumn(cell), null, cell);
    } else if (cell.classList.contains("odr-sheet-row-header")) {
      pin(-1, cell.parentElement, cell);
    } else if (cell.classList.contains("odr-sheet-corner")) {
      pin(-1, null, null);
    } else {
      pin(rulerColumn(cell), cell.parentElement, cell);
    }
  });

  // A mouse drawn over the cells in the editing mode spans a selection; a
  // touch scrolls, and a read-only sheet leaves the text to select.
  var dragFrom = null;
  table.addEventListener("pointerdown", function (event) {
    var cell = event.target.closest("td");
    dragFrom =
      event.pointerType === "mouse" &&
      event.button === 0 &&
      !event.shiftKey &&
      cell !== null &&
      editingEnabled()
        ? cell
        : null;
  });
  table.addEventListener("pointermove", function (event) {
    if (dragFrom === null || (event.buttons & 1) === 0) {
      dragFrom = null;
      return;
    }
    var cell = event.target.closest("td");
    if (cell === null || (cell === dragFrom && focus === null)) {
      return;
    }
    if (pinnedCell !== dragFrom) {
      pin(rulerColumn(dragFrom), dragFrom.parentElement, dragFrom);
    }
    event.preventDefault();
    select(positionOf(cell));
  });
  document.addEventListener("pointerup", function () {
    dragFrom = null;
  });

  // The canvas around the sheet included.
  document.addEventListener("click", function (event) {
    if (event.target.closest(".odr-sheet") === null) {
      pin(-1, null, null);
    }
  });

  // Navigation, not editing: a read-only sheet has a pin to clear.
  if (odr.takesKeys("navigation")) {
    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape") {
        pin(-1, null, null);
      }
    });
  }


  var sortedColumn = -1;
  var sortedDirection = 0;

  // A plain number states no value, only its rendered text. The last
  // separator is the decimal one, which settles 1,234.56 against 1.234,56.
  function toNumber(text) {
    var cleaned = text.replace(/[^0-9,.eE+-]/g, "");
    if (cleaned.lastIndexOf(",") > cleaned.lastIndexOf(".")) {
      cleaned = cleaned.replace(/\./g, "").replace(",", ".");
    } else {
      cleaned = cleaned.replace(/,/g, "");
    }
    var value = parseFloat(cleaned);
    return isFinite(value) ? value : NaN;
  }

  // Numbers, then text, then blanks: no column is forced into one kind.
  var NUMBER = 0;
  var TEXT = 1;
  var BLANK = 2;

  function keyOf(row, index) {
    var cell = row.children[index];
    var text = cell === undefined ? "" : cell.textContent.trim();
    if (cell === undefined) {
      return { rank: BLANK, value: 0 };
    }
    // a date, a time and a formatted number state their value
    var stated = cell.getAttribute("data-odr-value");
    var value =
      stated !== null
        ? Number(stated)
        : cell.classList.contains("odr-value-type-float")
          ? toNumber(text)
          : NaN;
    return Number.isFinite(value)
      ? { rank: NUMBER, value: value }
      : { rank: text === "" ? BLANK : TEXT, value: text };
  }

  // Puts @p rows back into the chunks in their order, each chunk holding as
  // many as it did. A merged sheet has no sort, so no `rowspan` moves.
  function reorder(rows) {
    var counts = Array.prototype.map.call(chunks, function (chunk) {
      return chunk.tBodies[0].rows.length;
    });
    var at = 0;
    for (var c = 0; c < chunks.length; ++c) {
      var fragment = document.createDocumentFragment();
      for (var i = 0; i < counts[c]; ++i) {
        fragment.appendChild(rows[at++]);
      }
      chunks[c].tBodies[0].appendChild(fragment);
    }
  }

  function sortBy(index, direction) {
    var rows = Array.prototype.slice.call(bodyRows());
    // the labels state the file's order, whatever an edit added or took
    if (direction === 0) {
      reorder(
        rows.sort(function (a, b) {
          return rowOf(a) - rowOf(b);
        })
      );
      return;
    }

    var keys = new Map();
    for (var i = 0; i < rows.length; ++i) {
      keys.set(rows[i], keyOf(rows[i], index));
    }

    // A blank is an absent value, not the smallest one, so it stays last either
    // way round. The stable sort keeps the document's order for ties.
    rows.sort(function (a, b) {
      var x = keys.get(a);
      var y = keys.get(b);
      if (x.rank === BLANK || y.rank === BLANK) {
        return x.rank === y.rank ? 0 : x.rank === BLANK ? 1 : -1;
      }
      if (x.rank !== y.rank) {
        return (x.rank - y.rank) * direction;
      }
      var result =
        x.rank === NUMBER
          ? x.value - y.value
          : x.value.localeCompare(y.value, undefined, { numeric: true });
      return result * direction;
    });
    reorder(rows);
  }

  // A `rowspan` would reach into a row no longer beneath it and a `colspan`
  // breaks the column index, so a merged sheet gets no sort control. Nor does
  // one whose rows load as the reader comes near: a sort needs them all.
  if (!merged && table.querySelector("[data-odr-chunk-src]") === null) {
    columnHeaders().forEach(function (header) {
      var letters = header.textContent;
      addSortControl(header);
      header.lastChild.setAttribute("title", "sort by column " + letters);
    });

    table.addEventListener(
      "click",
      function (event) {
        var control = event.target.closest(".odr-sheet-sort");
        if (control === null) {
          return;
        }
        // The header itself pins the column; only this control sorts it.
        event.stopPropagation();

        var index = control.parentElement.cellIndex;
        var direction =
          index !== sortedColumn ? 1 : sortedDirection === 1 ? -1 : 0;

        sortBy(index, direction);

        control.classList.remove("odr-sheet-sort-asc", "odr-sheet-sort-desc");
        if (direction === 1) {
          control.classList.add("odr-sheet-sort-asc");
        } else if (direction === -1) {
          control.classList.add("odr-sheet-sort-desc");
        }
        if (sortedColumn !== index && sortedColumn >= 0) {
          headerRow.children[sortedColumn]
            .querySelector(".odr-sheet-sort")
            .classList.remove("odr-sheet-sort-asc", "odr-sheet-sort-desc");
        }

        sortedColumn = direction === 0 ? -1 : index;
        sortedDirection = direction;
      },
      true
    );
  }
})();
