#pragma once

#include <cstdint>
#include <iosfwd>
#include <optional>
#include <string>
#include <string_view>
#include <vector>

#include <odr/html.hpp>
#include <odr/internal/abstract/html_service.hpp>
#include <odr/internal/formula/formula_parser.hpp>
#include <odr/internal/formula/formula_value.hpp>
#include <odr/quantity.hpp>
#include <odr/style.hpp>

namespace odr {
struct Color;
struct HtmlConfig;
class Html;
class Logger;
} // namespace odr

namespace odr::internal::abstract {
class File;
}

namespace odr::internal::html {

class StyleRegistry;

struct WritingState {
  WritingState(HtmlWriter &out, const HtmlConfig &config,
               HtmlResources &resources, const Logger &logger,
               StyleRegistry *styles = nullptr)
      : m_out{&out}, m_config{&config}, m_resources(&resources),
        m_logger{&logger}, m_styles{styles} {}

  [[nodiscard]] HtmlWriter &out() const { return *m_out; }
  [[nodiscard]] const HtmlConfig &config() const { return *m_config; }
  [[nodiscard]] HtmlResources &resources() const { return *m_resources; }
  [[nodiscard]] const Logger &logger() const { return *m_logger; }
  /// Where repeated style blocks are deduplicated, or null where they are not.
  [[nodiscard]] StyleRegistry *styles() const { return m_styles; }

  /// The view's base direction, stated on its root.
  [[nodiscard]] TextDirection direction() const { return m_direction; }
  void set_direction(const TextDirection direction) { m_direction = direction; }

  /// Whether an editable run says so in the markup - false under a sheet,
  /// whose editing is an overlay.
  [[nodiscard]] bool editable_markup() const { return m_editable_markup; }
  void set_editable_markup(const bool editable) {
    m_editable_markup = editable;
  }

  /// Whether the document can be edited at all, which a sheet states so its
  /// editor can refuse before the user clicks anything.
  [[nodiscard]] bool document_editable() const { return m_document_editable; }
  void set_document_editable(const bool editable) {
    m_document_editable = editable;
  }

  /// The syntax a formula of this document is written in, or nothing where
  /// the engine states none.
  [[nodiscard]] std::optional<formula::Syntax> formula_syntax() const {
    return m_formula_syntax;
  }
  void set_formula_syntax(const std::optional<formula::Syntax> syntax) {
    m_formula_syntax = syntax;
  }
  /// The names a formula of this document reads, null where none is known.
  [[nodiscard]] const std::vector<formula::Name> *formula_names() const {
    return m_formula_names;
  }
  void set_formula_names(const std::vector<formula::Name> *names) {
    m_formula_names = names;
  }

  /// Whether the page box of a slide or a drawing page is a chunk, and if so,
  /// whether it is near the viewport in the markup; nothing in a view of one
  /// page, which has nothing to skip (`lazy-loading.md` decision 3).
  [[nodiscard]] std::optional<bool> page_chunk_near() const {
    return m_page_chunk_near;
  }
  void set_page_chunk_near(const std::optional<bool> near) {
    m_page_chunk_near = near;
  }

private:
  HtmlWriter *m_out;
  const HtmlConfig *m_config;
  HtmlResources *m_resources;
  const Logger *m_logger;
  StyleRegistry *m_styles;
  TextDirection m_direction{TextDirection::left_to_right};
  bool m_editable_markup{true};
  bool m_document_editable{false};
  std::optional<formula::Syntax> m_formula_syntax;
  const std::vector<formula::Name> *m_formula_names{nullptr};
  std::optional<bool> m_page_chunk_near;
};

/// Writes viewport metadata: explicit content, then mode override, then config.
/// The default resolves automatic mode; content width sets the minimum scale.
void write_viewport_meta(HtmlWriter &out, const HtmlConfig &config,
                         bool fit_width_by_default,
                         std::optional<HtmlViewportMode> mode_override = {},
                         std::optional<double> content_pixels = {});

/// Who fits the output's width to the viewport.
enum class WidthFit {
  none,    ///< nobody: it is shown at its size
  browser, ///< the browser, steered by the viewport meta tag
  view,    ///< the view itself, measured and kept current
};

[[nodiscard]] WidthFit
width_fit(const HtmlConfig &config, bool fit_width_by_default,
          std::optional<HtmlViewportMode> mode_override = {});

/// A finite CSS length, or zero for an unsupported unit or magnitude.
[[nodiscard]] std::string css_length(const Measure &measure);

/// @p measure in css pixels, or nothing without an absolute unit.
[[nodiscard]] std::optional<double>
css_pixels(const std::optional<Measure> &measure);

/// Both side gutters the page column puts around its pages, in css pixels,
/// raised where `config.min_content_margin` asks for more. A side the css
/// resolves but this cannot — `em`, `%` — keeps the built-in gutter here.
[[nodiscard]] double page_column_gutter_pixels(const HtmlConfig &config);

/// The zoom the view opens at: `--odr-fit` fits @p content_pixels into
/// `config.viewport_width`, or names who measures it instead, `--odr-zoom` pins
/// it, `body{zoom}` applies the winner.
void write_zoom_style(HtmlWriter &out, const HtmlConfig &config, WidthFit fits,
                      std::optional<double> content_pixels);

/// `config.min_content_margin` as the `--odr-min-margin-*` the stylesheets
/// floor their insets against; nothing at all where no side states a css
/// length, which leaves those insets as shipped.
void write_content_margin_style(HtmlWriter &out, const HtmlConfig &config);

/// Escapes text and preserves whitespace with entities. Editable runs use
/// `xml::escape_text`; attributes use `xml::escape_attribute`.
std::string escape_text(std::string text);

/// What a target is, as an `href` would be dispatched. Whitespace and control
/// bytes are skipped while reading the scheme, as browsers strip them first.
enum class UriKind {
  relative, ///< no scheme
  external, ///< a navigable scheme
  refused,  ///< `javascript:` and kin
};

[[nodiscard]] UriKind uri_kind(std::string_view uri);

/// Safe to emit as an `href`.
[[nodiscard]] inline bool is_safe_uri(const std::string_view uri) {
  return uri_kind(uri) != UriKind::refused;
}

/// The `<a>` attributes for @p kind, unprefixed; empty but for
/// @ref UriKind::external.
[[nodiscard]] std::string_view link_target_attributes(UriKind kind);

/// What an `<a>` from a document writes: its `href`, if the config lets it
/// navigate, and the attributes of @ref link_target_attributes.
struct LinkTarget {
  std::optional<std::string> href;
  std::string_view attributes;
};

/// A fragment stays in the view, so only @ref allow_external_content keeps
/// any other relative target.
[[nodiscard]] LinkTarget link_target(std::string_view href,
                                     const HtmlConfig &config);

/// Whether an `<img>` may load @p source, which a document names outside
/// itself. An image `data:` url is inline, so it always loads.
[[nodiscard]] bool loads_external_source(std::string_view source,
                                         const HtmlConfig &config);

std::string color(const Color &color);
/// @p color for a dark page: its lightness mirrored into the band between the
/// page and the lightest ground light text still reads on, its hue kept.
Color dark_fill(const Color &color);

/// Substitute `{index}` in an output file name pattern (e.g.
/// `page{index}.html`) with `index`, or with "" when absent.
std::string fill_path_variables(const std::string &path,
                                std::optional<std::uint32_t> index = {});

std::string file_to_url(const std::string &file, const std::string &mime_type);
std::string file_to_url(std::istream &file, const std::string &mime_type);
std::string file_to_url(const abstract::File &file,
                        const std::string &mime_type);

/// The key classes a view's scripts may take; `editing.md` decision 12.
[[nodiscard]] std::string keyboard_classes(const HtmlConfig &config);

/// The scope as the page states it; `editing.md` decision 14.
[[nodiscard]] std::string_view editing_scope_name(HtmlEditingScope scope);

} // namespace odr::internal::html
