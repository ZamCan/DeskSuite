#include <odr/internal/html/pdf_file.hpp>

#include <odr/exceptions.hpp>
#include <odr/file.hpp>
#include <odr/html.hpp>
#include <odr/odr.hpp>

#include <odr/internal/abstract/file.hpp>
#include <odr/internal/abstract/font.hpp>
#include <odr/internal/common/file.hpp>
#include <odr/internal/common/null_stream.hpp>
#include <odr/internal/common/path.hpp>
#include <odr/internal/crypto/crypto_util.hpp>
#include <odr/internal/font/cff_font.hpp>
#include <odr/internal/font/cff_transform.hpp>
#include <odr/internal/font/sfnt_font.hpp>
#include <odr/internal/font/sfnt_transform.hpp>
#include <odr/internal/html/common.hpp>
#include <odr/internal/html/frontend.hpp>
#include <odr/internal/html/html_service.hpp>
#include <odr/internal/html/html_writer.hpp>
#include <odr/internal/html/style_registry.hpp>
#include <odr/internal/pdf/pdf_color.hpp>
#include <odr/internal/pdf/pdf_document.hpp>
#include <odr/internal/pdf/pdf_document_element.hpp>
#include <odr/internal/pdf/pdf_document_parser.hpp>
#include <odr/internal/pdf/pdf_file.hpp>
#include <odr/internal/pdf/pdf_page_extractor.hpp>
#include <odr/internal/util/color_util.hpp>
#include <odr/internal/util/number_util.hpp>
#include <odr/internal/util/string_util.hpp>
#include <odr/internal/xml/xml_util.hpp>

#include <algorithm>
#include <array>
#include <cctype>
#include <cmath>
#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <set>
#include <span>
#include <sstream>
#include <string>
#include <string_view>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

namespace odr::internal::html {

namespace {

/// Round to 0.01 units; finer precision is invisible and the extra digits add
/// up across a page full of path data.
double round2(const double v) { return std::round(v * 100.0) / 100.0; }

constexpr double pt_to_in = 1.0 / 72.0;

/// A transform as an SVG `matrix(...)`. Only the translation is rounded; the
/// linear part keeps full precision so small scale/skew factors aren't
/// quantized to zero.
std::string svg_matrix(const util::math::Transform2D &m) {
  std::ostringstream f;
  f << "matrix(" << m.a << ',' << m.b << ',' << m.c << ',' << m.d << ','
    << round2(m.e) << ',' << round2(m.f) << ')';
  return std::move(f).str();
}

/// The page's index and the map back from its box to pdf user space, for the
/// annotator to place what the user draws. Empty when the transform is
/// singular and nothing can be placed.
std::string page_attributes(const std::size_t index,
                            const util::math::Transform2D &to_box) {
  const std::optional<util::math::Transform2D> from_box = to_box.inverse();
  if (!from_box.has_value()) {
    return {};
  }
  const auto n = [](const double v) {
    // a negative zero would render as `-0`, which is only noise in the output
    return util::number::to_string_significant(v == 0 ? 0.0 : v, 10);
  };
  return R"( data-odr-page=")" + std::to_string(index) +
         R"(" data-odr-space=")" + n(from_box->a) + ',' + n(from_box->b) + ',' +
         n(from_box->c) + ',' + n(from_box->d) + ',' + n(from_box->e) + ',' +
         n(from_box->f) + '"';
}

/// One resolved link annotation, positioned in page-box points (y-down).
struct LinkOut {
  double left{0};
  double top{0};
  double width{0};
  double height{0};
  std::string href; ///< external URI or an internal target (a "#pN" anchor
                    ///< or a "pageN.html" page view); already attr-escaped
  std::string_view target_attributes; ///< see @ref link_target
};

/// A link's 0-based target page index to the href navigating to it. Returns ""
/// to drop the link (target page not rendered).
using PageHref = std::function<std::string(std::size_t)>;

/// Resolves a link annotation's destination to a page index, via the catalog's
/// named-destination tables (ISO 32000-1 12.3.2.3).
struct LinkResolver {
  pdf::DocumentParser &parser;
  std::map<pdf::ObjectReference, std::size_t> page_index;
  std::map<std::string, pdf::Object> named_dests; ///< name -> raw dest value

  /// A destination (a name/string, a `[page …]` array, or a dict with `/D`)
  /// to its target page index, if it resolves to a known page.
  [[nodiscard]] std::optional<std::size_t> resolve_dest_page(pdf::Object dest) {
    dest = parser.resolve_object_copy(std::move(dest));
    if (dest.is_string() || dest.is_name()) {
      const std::string name =
          dest.is_string() ? dest.as_string() : dest.as_name();
      const auto it = named_dests.find(name);
      if (it == named_dests.end()) {
        return std::nullopt;
      }
      dest = parser.resolve_object_copy(it->second);
    }
    if (dest.is_dictionary() && dest.as_dictionary().has_value("D")) {
      dest = parser.resolve_object_copy(dest.as_dictionary().get("D"));
    }
    if (!dest.is_array() || dest.as_array().empty()) {
      return std::nullopt;
    }
    const pdf::Object &target = dest.as_array()[0];
    if (!target.is_reference()) {
      return std::nullopt;
    }
    const auto it = page_index.find(target.as_reference());
    return it != page_index.end() ? std::optional<std::size_t>(it->second)
                                  : std::nullopt;
  }
};

/// Walk a destination name tree (`Names` leaf pairs, `Kids` intermediates),
/// depth-guarded, collecting `name -> dest` into `out`.
void collect_dest_name_tree(pdf::DocumentParser &parser,
                            const pdf::Object &node_ref,
                            std::map<std::string, pdf::Object> &out,
                            const int depth) {
  if (depth > 50) {
    return;
  }
  const pdf::Object node = parser.resolve_object_copy(node_ref);
  if (!node.is_dictionary()) {
    return;
  }
  const pdf::Dictionary &dictionary = node.as_dictionary();
  if (dictionary.has_value("Names")) {
    const pdf::Array names =
        parser.resolve_object_copy(dictionary.get("Names")).as_array();
    for (std::size_t i = 0; i + 1 < names.size(); i += 2) {
      const pdf::Object key = parser.resolve_object_copy(names[i]);
      if (key.is_string()) {
        out.emplace(key.as_string(), names[i + 1]);
      }
    }
  }
  if (dictionary.has_value("Kids")) {
    const pdf::Array kids =
        parser.resolve_object_copy(dictionary.get("Kids")).as_array();
    for (const pdf::Object &kid : kids) {
      collect_dest_name_tree(parser, kid, out, depth + 1);
    }
  }
}

/// Build the link resolver once per document: the page-index map and the
/// catalog's named destinations.
LinkResolver build_link_resolver(pdf::DocumentParser &parser,
                                 const pdf::Document &document,
                                 const std::span<pdf::Page *const> pages) {
  LinkResolver resolver{parser, {}, {}};
  for (std::size_t i = 0; i < pages.size(); ++i) {
    resolver.page_index.emplace(pages[i]->object_reference, i);
  }
  if (document.catalog != nullptr && document.catalog->object.is_dictionary()) {
    const pdf::Dictionary &catalog = document.catalog->object.as_dictionary();
    if (catalog.has_value("Dests")) {
      const pdf::Object dests =
          parser.resolve_object_copy(catalog.get("Dests"));
      if (dests.is_dictionary()) {
        for (const auto &[key, value] : dests.as_dictionary()) {
          resolver.named_dests.emplace(key, value);
        }
      }
    }
    if (catalog.has_value("Names")) {
      const pdf::Object names =
          parser.resolve_object_copy(catalog.get("Names"));
      if (names.is_dictionary() && names.as_dictionary().has_value("Dests")) {
        collect_dest_name_tree(parser, names.as_dictionary().get("Dests"),
                               resolver.named_dests, 0);
      }
    }
  }
  return resolver;
}

void write_pdf_body_begin(HtmlWriter &out, const HtmlConfig &config) {
  out.write_body_begin(HtmlElementOptions().set_attributes(
      [&](const HtmlAttributeWriterCallback &clb) {
        if (config.pdf_annotation_mark_on_selection) {
          clb("data-odr-annotation-mark-on-selection", "true");
        }
      }));
}

/// A page's `/Link` annotations (ISO 32000-1 12.5.6.5) as positioned overlays.
/// `to_box` maps PDF user space to the page box (points, y-down).
std::vector<LinkOut> collect_page_links(const pdf::Page &page,
                                        const util::math::Transform2D &to_box,
                                        LinkResolver &resolver,
                                        const PageHref &page_href,
                                        const HtmlConfig &config) {
  std::vector<LinkOut> links;
  pdf::DocumentParser &parser = resolver.parser;
  for (const pdf::Annotation *annotation : page.annotations) {
    if (annotation == nullptr || !annotation->object.is_dictionary()) {
      continue;
    }
    const pdf::Dictionary &dictionary = annotation->object.as_dictionary();
    const pdf::Object subtype =
        parser.resolve_object_copy(dictionary.get("Subtype"));
    if (!subtype.is_name() || subtype.as_name() != "Link") {
      continue;
    }
    const pdf::Object rect = parser.resolve_object_copy(dictionary.get("Rect"));
    if (!rect.is_array() || rect.as_array().size() < 4) {
      continue;
    }
    const std::vector<double> r = rect.as_reals();

    std::string href;
    std::string_view target_attributes;
    if (dictionary.has_value("A")) {
      const pdf::Object action =
          parser.resolve_object_copy(dictionary.get("A"));
      if (action.is_dictionary()) {
        const pdf::Dictionary &a = action.as_dictionary();
        const pdf::Object s = parser.resolve_object_copy(a.get("S"));
        const std::string kind = s.is_name() ? s.as_name() : "";
        if (kind == "URI" && a.has_value("URI")) {
          const pdf::Object uri = parser.resolve_object_copy(a.get("URI"));
          if (uri.is_string()) {
            const LinkTarget target = link_target(uri.as_string(), config);
            href = target.href.value_or("");
            target_attributes = target.attributes;
          }
        } else if (kind == "GoTo" && a.has_value("D")) {
          if (const auto index = resolver.resolve_dest_page(a.get("D"));
              index.has_value()) {
            href = page_href(*index);
          }
        }
      }
    }
    if (href.empty() && dictionary.has_value("Dest")) {
      if (const auto index = resolver.resolve_dest_page(dictionary.get("Dest"));
          index.has_value()) {
        href = page_href(*index);
      }
    }
    if (href.empty()) {
      continue;
    }

    const std::array<double, 2> p0 = to_box.apply(r[0], r[1]);
    const std::array<double, 2> p1 = to_box.apply(r[2], r[3]);
    LinkOut link;
    link.left = std::min(p0[0], p1[0]);
    link.top = std::min(p0[1], p1[1]);
    link.width = std::abs(p1[0] - p0[0]);
    link.height = std::abs(p1[1] - p0[1]);
    link.href = xml::escape_attribute(std::move(href));
    link.target_attributes = target_attributes;
    links.push_back(std::move(link));
  }
  return links;
}

/// Write a page's link overlays as absolutely-positioned `<a>` elements (in
/// page-box points, matching the text layer's unit).
void write_page_links(HtmlWriter &out, const std::vector<LinkOut> &links) {
  for (const LinkOut &link : links) {
    std::ostringstream a;
    // A `#pN` link scrolls this page; a `/URI` action leaves it.
    a << "<a class=\"lk\" href=\"" << link.href << '"';
    if (!link.target_attributes.empty()) {
      a << ' ' << link.target_attributes;
    }
    a << " style=\"left:" << round2(link.left) << "pt;top:" << round2(link.top)
      << "pt;width:" << round2(link.width)
      << "pt;height:" << round2(link.height) << "pt\"></a>";
    out.write_raw(std::move(a).str());
  }
}

/// A PDF device color as CSS `rgb(...)`. Other spaces are already converted at
/// extract time; only `unknown` reaches here, falling back to black.
std::string device_color_to_css(const pdf::GraphicsState::Color &color) {
  std::int32_t r = 0;
  std::int32_t g = 0;
  std::int32_t b = 0;
  switch (color.space) {
  case pdf::ColorSpace::device_grey:
    r = g = b = util::color::to_byte(color.grey);
    break;
  case pdf::ColorSpace::device_rgb:
    r = util::color::to_byte(color.rgb[0]);
    g = util::color::to_byte(color.rgb[1]);
    b = util::color::to_byte(color.rgb[2]);
    break;
  case pdf::ColorSpace::device_cmyk: {
    const std::array<double, 3> rgb = pdf::cmyk_to_rgb(
        color.cmyk[0], color.cmyk[1], color.cmyk[2], color.cmyk[3]);
    r = util::color::to_byte(rgb[0]);
    g = util::color::to_byte(rgb[1]);
    b = util::color::to_byte(rgb[2]);
    break;
  }
  case pdf::ColorSpace::unknown:
    break;
  }
  std::ostringstream s;
  s << "rgb(" << r << ',' << g << ',' << b << ')';
  return std::move(s).str();
}

/// Convert an sRGB triple in [0, 1] (a shading colour stop) to a CSS
/// `rgb(...)`.
std::string rgb_to_css(const std::array<double, 3> &rgb) {
  std::ostringstream s;
  s << "rgb(" << +util::color::to_byte(rgb[0]) << ','
    << +util::color::to_byte(rgb[1]) << ',' << +util::color::to_byte(rgb[2])
    << ')';
  return std::move(s).str();
}

/// A PDF blend-mode name (`/BM`, ISO 32000-1 11.3.5) as its CSS
/// `mix-blend-mode` keyword — CSS took its blend modes from PDF, so they map
/// 1:1. "" for `Normal` and for anything unrecognized, so callers can skip the
/// property entirely.
std::string blend_mode_to_css(const std::string &blend_mode) {
  static const std::unordered_map<std::string, std::string> map = {
      {"Multiply", "multiply"},     {"Screen", "screen"},
      {"Overlay", "overlay"},       {"Darken", "darken"},
      {"Lighten", "lighten"},       {"ColorDodge", "color-dodge"},
      {"ColorBurn", "color-burn"},  {"HardLight", "hard-light"},
      {"SoftLight", "soft-light"},  {"Difference", "difference"},
      {"Exclusion", "exclusion"},   {"Hue", "hue"},
      {"Saturation", "saturation"}, {"Color", "color"},
      {"Luminosity", "luminosity"}};
  const auto it = map.find(blend_mode);
  return it != map.end() ? it->second : std::string{};
}

/// The CSS declaration a non-embedded font renders through: its substitute
/// family stack plus the weight/style implied by `/BaseFont` and the
/// `/FontDescriptor` flags.
std::string font_substitute_declaration(const pdf::FontSubstitute &substitute) {
  std::string declaration = "font-family:" + substitute.css_family;
  if (substitute.bold) {
    declaration += ";font-weight:bold";
  }
  if (substitute.italic) {
    declaration += ";font-style:italic";
  }
  return declaration;
}

/// The suffixes naming a family's styled cut, most specific first. `local()`
/// matches a face name, not a family plus a weight, so bold must be asked for.
std::vector<std::string_view> style_suffixes(const bool bold,
                                             const bool italic) {
  if (bold && italic) {
    return {"-BoldItalic", " Bold Italic", "-BoldOblique", " Bold Oblique"};
  }
  if (bold) {
    return {"-Bold", " Bold"};
  }
  if (italic) {
    return {"-Italic", " Italic", "-Oblique", " Oblique"};
  }
  return {};
}

/// The `local(...)` sources of a `font-family` stack, dropping the generic
/// keywords an `@font-face src` cannot name, each family styled-cut-first so a
/// system without the cut still resolves. "" when the stack is generic-only.
std::string local_font_sources(const std::string_view css_family,
                               const bool bold, const bool italic) {
  static constexpr std::array<std::string_view, 6> generics = {
      "serif", "sans-serif", "monospace", "cursive", "fantasy", "system-ui"};
  const std::vector<std::string_view> suffixes = style_suffixes(bold, italic);
  std::string src;
  const auto add = [&src](const std::string_view name,
                          const std::string_view suffix) {
    if (!src.empty()) {
      src += ',';
    }
    src += "local(\"";
    src += name;
    src += suffix;
    src += "\")";
  };
  std::size_t start = 0;
  while (start <= css_family.size()) {
    const std::size_t comma = css_family.find(',', start);
    std::string_view name = css_family.substr(
        start, comma == std::string_view::npos ? css_family.size() - start
                                               : comma - start);
    while (!name.empty() && name.front() == ' ') {
      name.remove_prefix(1);
    }
    while (!name.empty() && name.back() == ' ') {
      name.remove_suffix(1);
    }
    // The stack quotes a name that needs it ('Times New Roman'); `add` quotes
    // again, and a doubly quoted name matches no installed face.
    if (name.size() > 1 && (name.front() == '\'' || name.front() == '"') &&
        name.back() == name.front()) {
      name.remove_prefix(1);
      name.remove_suffix(1);
    }
    const bool generic = std::ranges::find(generics, name) != generics.end();
    if (!name.empty() && !generic) {
      for (const std::string_view suffix : suffixes) {
        add(name, suffix);
      }
      add(name, "");
    }
    if (comma == std::string_view::npos) {
      break;
    }
    start = comma + 1;
  }
  return src;
}

/// One `@font-face` per (substitute family, style, ascent) overriding the
/// face's ascent/descent, so a glyph's baseline lands at the `top`
/// `add_position_classes` derived from `ascent_em` rather than wherever
/// whichever local font resolves would put it.
class SubstituteFontFaces {
public:
  /// @p suffix ends every face name, as `StyleRegistry::set_suffix` does.
  explicit SubstituteFontFaces(std::string suffix = {})
      : m_suffix{std::move(suffix)} {}

  /// The `font-family:...` (plus weight/style) declaration for `substitute`,
  /// routed through a generated metric-overriding face `'odr-sN'`. Falls back
  /// to the plain family stack when the stack names no concrete font.
  std::string declaration(const pdf::FontSubstitute &substitute,
                          const double ascent_em) {
    const std::string src = local_font_sources(
        substitute.css_family, substitute.bold, substitute.italic);
    if (src.empty()) {
      return font_substitute_declaration(substitute);
    }
    // The two overrides sum to one em, so `line-height:1` leaves no leading and
    // the baseline sits at exactly `ascent_em`. `max` keeps descent
    // non-negative for the rare clamped ascent > 1.
    const double ascent = ascent_em;
    const double descent = std::max(0.0, 1.0 - ascent_em);
    std::ostringstream key;
    key << src << '|' << substitute.bold << '|' << substitute.italic << '|'
        << std::llround(ascent * 1000.0);
    const auto [it, inserted] = m_index_by_key.try_emplace(
        std::move(key).str(), static_cast<int>(m_faces.size()) + 1);
    if (inserted) {
      std::ostringstream face;
      face << "@font-face{font-family:'odr-s" << it->second << m_suffix
           << "';src:" << src;
      // Declared, so the browser does not synthesise them a second time.
      if (substitute.bold) {
        face << ";font-weight:bold";
      }
      if (substitute.italic) {
        face << ";font-style:italic";
      }
      face << ";ascent-override:" << round2(ascent * 100.0)
           << "%;descent-override:" << round2(descent * 100.0)
           << "%;line-gap-override:0%}";
      m_faces.push_back(std::move(face).str());
    }
    std::string declaration = "font-family:'odr-s" +
                              std::to_string(it->second) + m_suffix + "'," +
                              substitute.css_family;
    if (substitute.bold) {
      declaration += ";font-weight:bold";
    }
    if (substitute.italic) {
      declaration += ";font-style:italic";
    }
    return declaration;
  }

  /// Appends the collected `@font-face` rules to `out`.
  void append_faces(std::string &out) const {
    for (const std::string &face : m_faces) {
      out += face;
    }
  }

private:
  std::map<std::string, int> m_index_by_key;
  std::vector<std::string> m_faces;
  std::string m_suffix;
};

/// An SVG `d` attribute for a path's subpaths, each point mapped through
/// `to_box` (PDF user space -> the page box, y-down).
std::string svg_path_d(const std::vector<pdf::Subpath> &subpaths,
                       const util::math::Transform2D &to_box) {
  std::ostringstream d;
  const auto point = [&](const std::array<double, 2> &p) {
    const std::array<double, 2> q = to_box.apply(p[0], p[1]);
    d << ' ' << round2(q[0]) << ' ' << round2(q[1]);
  };
  bool first = true;
  for (const pdf::Subpath &sub : subpaths) {
    d << (first ? "M" : " M");
    first = false;
    point(sub.start);
    for (const pdf::PathSegment &seg : sub.segments) {
      if (seg.kind == pdf::PathSegment::Kind::line) {
        d << " L";
        point(seg.end);
      } else {
        d << " C";
        point(seg.c1);
        point(seg.c2);
        point(seg.end);
      }
    }
    if (sub.closed) {
      d << " Z";
    }
  }
  return std::move(d).str();
}

/// A painted path as an SVG `<path .../>` fragment in the page viewBox, or ""
/// when it paints nothing. `clip_id` and `fill_url_id`, when non-empty, name a
/// `<clipPath>` and a paint server (gradient or tiling pattern) to reference.
std::string svg_path_fragment(const pdf::PathElement &path,
                              const util::math::Transform2D &to_box,
                              const std::string &clip_id,
                              const std::string &fill_url_id) {
  if ((!path.fill && !path.stroke) || path.subpaths.empty()) {
    return {};
  }
  std::ostringstream f;
  f << "<path d=\"" << svg_path_d(path.subpaths, to_box) << '"';
  if (!clip_id.empty()) {
    f << " clip-path=\"url(#" << clip_id << ")\"";
  }

  if (path.fill) {
    if (!fill_url_id.empty()) {
      f << " fill=\"url(#" << fill_url_id << ")\"";
    } else {
      f << " fill=\"" << device_color_to_css(path.fill_color) << '"';
    }
    if (path.even_odd) {
      f << " fill-rule=\"evenodd\"";
    }
    if (path.fill_alpha < 1) {
      f << " fill-opacity=\"" << round2(path.fill_alpha) << '"';
    }
  } else {
    f << " fill=\"none\"";
  }

  if (path.stroke) {
    f << " stroke=\"" << device_color_to_css(path.stroke_color) << '"';
    if (path.stroke_alpha < 1) {
      f << " stroke-opacity=\"" << round2(path.stroke_alpha) << '"';
    }
    // A 0 width is "device-thinnest" in PDF; SVG would draw nothing.
    const double width = path.line_width > 0 ? path.line_width : 0.5;
    f << " stroke-width=\"" << round2(width) << '"';
    if (path.line_cap == 1) {
      f << " stroke-linecap=\"round\"";
    } else if (path.line_cap == 2) {
      f << " stroke-linecap=\"square\"";
    }
    if (path.line_join == 1) {
      f << " stroke-linejoin=\"round\"";
    } else if (path.line_join == 2) {
      f << " stroke-linejoin=\"bevel\"";
    } else {
      // miter join: SVG defaults the limit to 4, PDF to 10 — state it.
      f << " stroke-miterlimit=\"" << round2(path.miter_limit) << '"';
    }
    const bool dashed = std::ranges::any_of(
        path.dash_array, [](const double v) { return v > 0; });
    if (dashed) {
      f << " stroke-dasharray=\"";
      for (std::size_t i = 0; i < path.dash_array.size(); ++i) {
        f << (i == 0 ? "" : ",") << round2(path.dash_array[i]);
      }
      f << '"';
      if (path.dash_phase != 0) {
        f << " stroke-dashoffset=\"" << round2(path.dash_phase) << '"';
      }
    }
  }

  if (const std::string blend = blend_mode_to_css(path.blend_mode);
      !blend.empty()) {
    f << " style=\"mix-blend-mode:" << blend << '"';
  }

  f << "/>";
  return std::move(f).str();
}

/// One resource per distinct image: every placement of it gets the same url.
/// The name is a digest of the bytes, so the views of one document agree on it
/// and a host may render them into one directory.
class ImageRegistry {
public:
  /// @p drops for a render that keeps only its text: no image is read.
  ImageRegistry(const HtmlConfig &config, HtmlResources &resources,
                const bool drops = false)
      : m_config{&config}, m_resources{&resources}, m_drops{drops} {}

  std::string url(const pdf::ImageElement &image) {
    if (m_drops) {
      return {};
    }
    if (image.source != nullptr) {
      if (const auto it = m_url_by_source.find(image.source);
          it != std::end(m_url_by_source)) {
        return it->second;
      }
    }
    std::string result = url(image.data, image.mime);
    if (image.source != nullptr) {
      m_url_by_source.emplace(image.source, result);
    }
    return result;
  }

  /// Keyed on the bytes: a stencil, an inline image and an alpha mask carry no
  /// object to key on, so identical bytes reach us as separate elements.
  std::string url(const std::string &data, const std::string &mime) {
    if (m_drops) {
      return {};
    }
    const std::string name =
        "image" +
        crypto::util::hex_encode(crypto::util::sha256(data)).substr(0, 16) +
        extension(mime);
    const auto [it, fresh] = m_url_by_name.try_emplace(name);
    if (fresh) {
      odr::HtmlResource resource = HtmlResource::create(
          HtmlResourceType::image, mime, name, name,
          File(std::make_shared<MemoryFile>(data)), false, false, true);
      HtmlResourceLocation location =
          m_config->resource_locator(resource, *m_config);
      it->second = location.value_or(file_to_url(data, mime));
      m_resources->emplace_back(std::move(resource), std::move(location));
    }
    return it->second;
  }

private:
  static std::string extension(const std::string &mime) {
    const FileType type = file_type_by_mimetype(mime);
    if (type == FileType::unknown) {
      return {};
    }
    return "." + std::string(file_extension_by_file_type(type));
  }

  const HtmlConfig *m_config{nullptr};
  HtmlResources *m_resources{nullptr};
  bool m_drops{false};
  std::unordered_map<const pdf::XObject *, std::string> m_url_by_source;
  std::unordered_map<std::string, std::string> m_url_by_name;
};

/// Emits an image in the flipped unit square (ISO 32000-1 8.10.5), or empty.
/// Apply clip_id to a wrapper so clipping stays in page coordinates.
/// @p mask_id names the `<mask>` holding a JPEG's alpha; empty for none.
std::string svg_image_fragment(const pdf::ImageElement &image,
                               const util::math::Transform2D &to_box,
                               const std::string &clip_id,
                               const std::string &mask_id,
                               ImageRegistry &images) {
  if (image.data.empty()) {
    return {};
  }
  constexpr util::math::Transform2D flip =
      util::math::Transform2D::scaling_translation(1, -1, 0, 1);
  const util::math::Transform2D m = flip * image.transform * to_box;

  std::ostringstream f;
  if (!clip_id.empty()) {
    f << "<g clip-path=\"url(#" << clip_id << ")\">";
  }
  f << R"(<image width="1" height="1" preserveAspectRatio="none" transform=")"
    << svg_matrix(m) << '"';
  if (image.alpha < 1) {
    f << " opacity=\"" << round2(image.alpha) << '"';
  }
  if (!mask_id.empty()) {
    f << " mask=\"url(#" << mask_id << ")\"";
  }
  if (const std::string blend = blend_mode_to_css(image.blend_mode);
      !blend.empty()) {
    f << " style=\"mix-blend-mode:" << blend << '"';
  }
  f << " href=\"" << xml::escape_attribute(images.url(image)) << "\"/>";
  if (!clip_id.empty()) {
    f << "</g>";
  }
  return std::move(f).str();
}

/// Shared bookkeeping for the per-page `<defs>` registries below: a
/// signature->id cache deduplicating repeated definitions plus the accumulated
/// `<defs>` markup. Ids are namespaced per page as `<prefix><page>_<n>`.
class DefsRegistry {
public:
  explicit DefsRegistry(const std::uint32_t page) : m_page{page} {}

  [[nodiscard]] std::string defs() const { return m_defs.str(); }

protected:
  /// The id for `signature`. `inserted` is true only on first sight, when the
  /// caller still has to emit the definition into `m_defs`.
  struct Entry {
    std::string id;
    bool inserted;
  };
  Entry intern(const std::string &signature, const char *prefix) {
    const auto [it, inserted] = m_id_by_signature.try_emplace(signature);
    if (inserted) {
      it->second = std::string(prefix) + std::to_string(m_page) + "_" +
                   std::to_string(++m_count);
    }
    return {it->second, inserted};
  }

  std::ostringstream m_defs;

private:
  std::uint32_t m_page;
  std::uint32_t m_count{0};
  std::unordered_map<std::string, std::string> m_id_by_signature;
};

/// A page's clip regions as nested `<clipPath>` defs (`c<page>_<n>`). PDF's
/// current clip is the *intersection* of an ordered region list; SVG expresses
/// intersection by chaining `clip-path`, so region i references region i-1 and
/// the painted element references the last.
class ClipRegistry : public DefsRegistry {
public:
  /// The `@font-face` family a font's glyphs are drawn in, "" for none.
  using FontFamily = std::function<std::string(const pdf::Font &)>;

  ClipRegistry(const std::uint32_t page, FontFamily font_family)
      : DefsRegistry(page), m_font_family{std::move(font_family)} {}

  /// The clipPath id to reference on a path painted under `clip`, registering
  /// any not-yet-seen regions. Empty when `clip` is empty (unclipped).
  std::string register_clip(const std::vector<pdf::ClipPath> &clip,
                            const util::math::Transform2D &to_box) {
    std::string signature;
    std::string parent;
    for (const pdf::ClipPath &region : clip) {
      std::string shape;
      if (region.text.empty()) {
        shape = "<path d=\"" + svg_path_d(region.subpaths, to_box) + '"';
        if (region.even_odd) {
          shape += " clip-rule=\"evenodd\"";
        }
        shape += "/>";
      } else {
        shape = text_shape(region.text, to_box);
        if (shape.empty()) {
          continue; // no face to draw the glyphs in: left unclipped
        }
      }
      signature += shape;
      signature += ';';
      const auto [id, inserted] = intern(signature, "c");
      if (inserted) {
        m_defs << "<clipPath id=\"" << id << '"';
        if (!parent.empty()) {
          m_defs << " clip-path=\"url(#" << parent << ")\"";
        }
        m_defs << '>' << shape << "</clipPath>";
      }
      parent = id;
    }
    return parent;
  }

private:
  FontFamily m_font_family;

  /// One `<text>` a run in the glyph layer's `@font-face` and PUA code points,
  /// each glyph at its own `x`. "" when a run's font has no face.
  std::string text_shape(const std::vector<pdf::TextClipRun> &runs,
                         const util::math::Transform2D &to_box) const {
    // SVG text is y-down in its own space, text space y-up.
    static constexpr util::math::Transform2D flip =
        util::math::Transform2D::scaling(1, -1);
    std::ostringstream out;
    for (const pdf::TextClipRun &run : runs) {
      const std::string family =
          run.font != nullptr ? m_font_family(*run.font) : std::string();
      if (family.empty() || run.horizontal_scaling == 0) {
        return {};
      }
      // `advances` carry the horizontal scaling, which `transform` applies
      // again.
      const double scaling = run.horizontal_scaling / 100.0;
      std::string glyphs;
      std::ostringstream x;
      double pen = 0;
      std::size_t i = 0;
      for (const std::uint32_t code : run.font->codes(run.codes)) {
        util::string::append_c32(
            font::pua_code_point(run.font->glyph_for_code(code)), glyphs);
        x << (i == 0 ? "" : " ") << pen / scaling;
        pen += i < run.advances.size() ? run.advances[i] : 0;
        ++i;
      }
      if (glyphs.empty()) {
        continue;
      }
      out << "<text transform=\"" << svg_matrix(flip * run.transform * to_box)
          << "\" font-family=\"" << family << "\" font-size=\"" << run.size
          << "\" x=\"" << std::move(x).str() << "\">" << glyphs << "</text>";
    }
    return std::move(out).str();
  }
};

/// Emits axial/radial SVG gradients in userSpaceOnUse with gradientTransform.
/// Extend uses pad; background and bbox remain unsupported.
class GradientRegistry : public DefsRegistry {
public:
  using DefsRegistry::DefsRegistry;

  /// The gradient id to reference via `fill="url(#id)"` for `shading` placed by
  /// `m` (shading space -> page box). Empty for an unrepresentable shading.
  std::string register_gradient(const pdf::Shading &shading,
                                const util::math::Transform2D &m) {
    if ((shading.type != 2 && shading.type != 3) || shading.stops.empty()) {
      return {};
    }
    std::ostringstream sig;
    sig << shading.type << ':' << static_cast<const void *>(&shading) << ':'
        << m.a << ',' << m.b << ',' << m.c << ',' << m.d << ',' << m.e << ','
        << m.f;
    const auto [id, inserted] = intern(sig.str(), "g");
    if (!inserted) {
      return id;
    }

    const std::array<double, 6> &c = shading.coords;
    if (shading.type == 2) {
      m_defs << "<linearGradient id=\"" << id << "\" x1=\"" << c[0]
             << "\" y1=\"" << c[1] << "\" x2=\"" << c[2] << "\" y2=\"" << c[3]
             << '"';
    } else {
      // Radial: the outer circle (x1,y1,r1) is SVG's (cx,cy,r); the inner
      // circle (x0,y0,r0) is the focal point and radius (fr is SVG2).
      m_defs << "<radialGradient id=\"" << id << "\" cx=\"" << c[3]
             << "\" cy=\"" << c[4] << "\" r=\"" << c[5] << "\" fx=\"" << c[0]
             << "\" fy=\"" << c[1] << "\" fr=\"" << c[2] << '"';
    }
    m_defs << " gradientUnits=\"userSpaceOnUse\" gradientTransform=\""
           << svg_matrix(m) << "\">";
    for (const pdf::GradientStop &stop : shading.stops) {
      m_defs << "<stop offset=\"" << round2(stop.offset) << "\" stop-color=\""
             << rgb_to_css(stop.rgb) << "\"/>";
    }
    m_defs << (shading.type == 2 ? "</linearGradient>" : "</radialGradient>");
    return id;
  }
};

/// An `sh` shading flood as an SVG `<rect>` spanning the page box, filled with
/// `gradient_id`; `clip_id` (and the gradient's own extent) bound the paint.
/// "" when the shading produced no gradient.
std::string svg_shading_fragment(const std::string &gradient_id,
                                 const std::string &clip_id, const double width,
                                 const double height, const double alpha,
                                 const std::string &blend_mode) {
  if (gradient_id.empty()) {
    return {};
  }
  std::ostringstream f;
  f << "<rect x=\"0\" y=\"0\" width=\"" << round2(width) << "\" height=\""
    << round2(height) << "\" fill=\"url(#" << gradient_id << ")\"";
  if (!clip_id.empty()) {
    f << " clip-path=\"url(#" << clip_id << ")\"";
  }
  if (alpha < 1) {
    f << " opacity=\"" << round2(alpha) << '"';
  }
  if (const std::string blend = blend_mode_to_css(blend_mode); !blend.empty()) {
    f << " style=\"mix-blend-mode:" << blend << '"';
  }
  f << "/>";
  return std::move(f).str();
}

/// Emits tiling-pattern paths and images; returns empty for unsupported
/// patterns. PaintType 2 includes the fill colour in its cache key.
class PatternRegistry : public DefsRegistry {
public:
  using DefsRegistry::DefsRegistry;

  std::string register_pattern(const pdf::Pattern &pattern,
                               const util::math::Transform2D &m,
                               const pdf::GraphicsState::Color &fill_color,
                               ImageRegistry &images, const Logger &logger) {
    if (pattern.resources == nullptr || pattern.content.empty() ||
        pattern.x_step == 0 || pattern.y_step == 0) {
      return {};
    }
    const bool uncoloured = pattern.paint_type == 2;
    std::ostringstream sig;
    sig << static_cast<const void *>(&pattern) << ':' << m.a << ',' << m.b
        << ',' << m.c << ',' << m.d << ',' << m.e << ',' << m.f;
    if (uncoloured) {
      sig << ':' << device_color_to_css(fill_color);
    }
    const auto [id, inserted] = intern(sig.str(), "pat");
    if (!inserted) {
      return id;
    }

    // Tile content is laid out in pattern space (identity page transform); the
    // y-flip and placement live in `patternTransform`.
    std::ostringstream tile;
    for (const pdf::PageElement &element :
         pdf::extract_page(pattern.content, *pattern.resources, logger)) {
      if (const auto *path = std::get_if<pdf::PathElement>(&element)) {
        pdf::PathElement painted = *path;
        if (uncoloured) {
          painted.fill_color = fill_color;
          painted.stroke_color = fill_color;
        }
        tile << svg_path_fragment(painted, util::math::Transform2D(), "", "");
      } else if (const auto *image = std::get_if<pdf::ImageElement>(&element)) {
        tile << svg_image_fragment(*image, util::math::Transform2D(), "", "",
                                   images);
      }
    }

    m_defs << "<pattern id=\"" << id
           << "\" patternUnits=\"userSpaceOnUse\" x=\""
           << round2(pattern.bbox[0]) << "\" y=\"" << round2(pattern.bbox[1])
           << "\" width=\"" << round2(std::abs(pattern.x_step))
           << "\" height=\"" << round2(std::abs(pattern.y_step))
           << "\" patternTransform=\"" << svg_matrix(m) << "\">";
    // Clip each cell to its `/BBox` (ISO 32000-1 8.7.3.1). An overlapping
    // lattice (step < BBox) has no single-`<pattern>` equivalent and is lost.
    const double bbox_w = pattern.bbox[2] - pattern.bbox[0];
    const double bbox_h = pattern.bbox[3] - pattern.bbox[1];
    if (bbox_w > 0 && bbox_h > 0) {
      m_defs << "<clipPath id=\"" << id << "c\"><rect x=\""
             << round2(pattern.bbox[0]) << "\" y=\"" << round2(pattern.bbox[1])
             << "\" width=\"" << round2(bbox_w) << "\" height=\""
             << round2(bbox_h) << "\"/></clipPath><g clip-path=\"url(#" << id
             << "c)\">" << std::move(tile).str() << "</g>";
    } else {
      m_defs << std::move(tile).str();
    }
    m_defs << "</pattern>";
    return id;
  }
};

class MaskRegistry;

/// One graphic page element as an SVG fragment in the page viewBox,
/// registering any clip, gradient, pattern or soft mask it needs. "" for a text
/// element or one that paints nothing. A `GroupElement`'s children are wrapped
/// in a single `<g>` so the group composites as a unit before its
/// opacity/blend/mask apply.
std::string render_graphic_fragment(
    const pdf::PageElement &element, const util::math::Transform2D &to_box,
    double width, double height, ClipRegistry &clips,
    GradientRegistry &gradients, PatternRegistry &patterns, MaskRegistry &masks,
    ImageRegistry &images, const Logger &logger);

/// A page's soft masks (`/SMask`, ISO 32000-1 11.6.5.2) as `<mask>` defs
/// (`m<page>_<n>`). The extractor has already rendered each mask's transparency
/// group to graphic elements; those are serialized through the page's own
/// clip/gradient/pattern registries so their ids stay unique within the page.
class MaskRegistry : public DefsRegistry {
public:
  using DefsRegistry::DefsRegistry;

  std::string register_mask(const pdf::SoftMask &mask,
                            const util::math::Transform2D &to_box,
                            const double width, const double height,
                            ClipRegistry &clips, GradientRegistry &gradients,
                            PatternRegistry &patterns, ImageRegistry &images,
                            const Logger &logger) {
    // A fresh `SoftMask` is built for every `gs`, but many are identical (one
    // drop-shadow across a run of glyphs); dedupe on the rendered body.
    std::ostringstream body;
    for (const pdf::PageElement &element : mask.group) {
      body << render_graphic_fragment(element, to_box, width, height, clips,
                                      gradients, patterns, *this, images,
                                      logger);
    }
    std::string signature = mask.type == pdf::SoftMask::Type::alpha ? "A" : "L";
    if (mask.backdrop.has_value()) {
      signature += rgb_to_css(*mask.backdrop);
    }
    signature += ';';
    signature += body.str();
    const auto [id, inserted] = intern(signature, "m");
    if (!inserted) {
      return id;
    }
    m_defs << "<mask id=\"" << id
           << "\" maskUnits=\"userSpaceOnUse\" x=\"0\" y=\"0\" width=\""
           << round2(width) << "\" height=\"" << round2(height) << '"';
    if (mask.type == pdf::SoftMask::Type::alpha) {
      m_defs << " mask-type=\"alpha\"";
    }
    m_defs << '>';
    // Black — SVG's mask background already — needs no backdrop rect.
    if (mask.backdrop.has_value() &&
        ((*mask.backdrop)[0] + (*mask.backdrop)[1] + (*mask.backdrop)[2] > 0)) {
      m_defs << "<rect x=\"0\" y=\"0\" width=\"" << round2(width)
             << "\" height=\"" << round2(height) << "\" fill=\""
             << rgb_to_css(*mask.backdrop) << "\"/>";
    }
    m_defs << std::move(body).str() << "</mask>";
    return id;
  }

  /// The alpha of a JPEG image as a `<mask>` in the image's own unit square.
  std::string register_image_mask(const std::string &url) {
    const auto [id, inserted] = intern("I;" + url, "m");
    if (inserted) {
      m_defs
          << "<mask id=\"" << id
          << R"(" mask-type="alpha" maskContentUnits="userSpaceOnUse">)"
          << R"(<image width="1" height="1" preserveAspectRatio="none" href=")"
          << xml::escape_attribute(url) << "\"/></mask>";
    }
    return id;
  }
};

/// Wrap an SVG fragment in a `<g>` carrying an opacity, a soft mask and/or a
/// blend mode, registering the mask. Returns `fragment` unchanged when none
/// apply (and "" for an empty fragment).
std::string wrap_effects(std::string fragment, const double alpha,
                         const std::shared_ptr<const pdf::SoftMask> &soft_mask,
                         const std::string &blend_mode,
                         const util::math::Transform2D &to_box,
                         const double width, const double height,
                         ClipRegistry &clips, GradientRegistry &gradients,
                         PatternRegistry &patterns, MaskRegistry &masks,
                         ImageRegistry &images, const Logger &logger) {
  if (fragment.empty()) {
    return fragment;
  }
  std::string mask_id;
  if (soft_mask != nullptr) {
    mask_id = masks.register_mask(*soft_mask, to_box, width, height, clips,
                                  gradients, patterns, images, logger);
  }
  const std::string blend = blend_mode_to_css(blend_mode);
  if (alpha >= 1 && mask_id.empty() && blend.empty()) {
    return fragment;
  }
  std::ostringstream g;
  g << "<g";
  if (alpha < 1) {
    g << " opacity=\"" << round2(alpha) << '"';
  }
  if (!mask_id.empty()) {
    g << " mask=\"url(#" << mask_id << ")\"";
  }
  if (!blend.empty()) {
    g << " style=\"mix-blend-mode:" << blend << '"';
  }
  g << '>' << fragment << "</g>";
  return std::move(g).str();
}

std::string render_graphic_fragment(
    const pdf::PageElement &element, const util::math::Transform2D &to_box,
    const double width, const double height, ClipRegistry &clips,
    GradientRegistry &gradients, PatternRegistry &patterns, MaskRegistry &masks,
    ImageRegistry &images, const Logger &logger) {
  const auto wrap_mask =
      [&](std::string fragment,
          const std::shared_ptr<const pdf::SoftMask> &soft_mask) {
        return wrap_effects(std::move(fragment), 1.0, soft_mask, "", to_box,
                            width, height, clips, gradients, patterns, masks,
                            images, logger);
      };
  if (const auto *path = std::get_if<pdf::PathElement>(&element)) {
    const std::string clip_id = clips.register_clip(path->clip, to_box);
    std::string fill_url_id;
    if (path->fill_shading != nullptr) {
      fill_url_id = gradients.register_gradient(
          *path->fill_shading, path->shading_transform * to_box);
    } else if (path->fill_pattern != nullptr) {
      fill_url_id = patterns.register_pattern(*path->fill_pattern,
                                              path->pattern_transform * to_box,
                                              path->fill_color, images, logger);
    }
    return wrap_mask(svg_path_fragment(*path, to_box, clip_id, fill_url_id),
                     path->soft_mask);
  }
  if (const auto *shading = std::get_if<pdf::ShadingElement>(&element)) {
    if (shading->shading == nullptr) {
      return {};
    }
    const std::string clip_id = clips.register_clip(shading->clip, to_box);
    const std::string gradient_id = gradients.register_gradient(
        *shading->shading, shading->transform * to_box);
    return wrap_mask(svg_shading_fragment(gradient_id, clip_id, width, height,
                                          shading->alpha, shading->blend_mode),
                     shading->soft_mask);
  }
  if (const auto *image = std::get_if<pdf::ImageElement>(&element)) {
    const std::string clip_id = clips.register_clip(image->clip, to_box);
    const std::string mask_id = image->alpha_mask.empty()
                                    ? ""
                                    : masks.register_image_mask(images.url(
                                          image->alpha_mask, "image/png"));
    return wrap_mask(
        svg_image_fragment(*image, to_box, clip_id, mask_id, images),
        image->soft_mask);
  }
  if (const auto *group = std::get_if<pdf::GroupElement>(&element)) {
    if (group->children == nullptr) {
      return {};
    }
    std::string inner;
    for (const pdf::PageElement &child : group->children->elements) {
      inner +=
          render_graphic_fragment(child, to_box, width, height, clips,
                                  gradients, patterns, masks, images, logger);
    }
    return wrap_effects(std::move(inner), group->alpha, group->soft_mask,
                        group->blend_mode, to_box, width, height, clips,
                        gradients, patterns, masks, images, logger);
  }
  return {};
}

/// Hoists text out of SVG transparency groups into the HTML layers.
/// Text loses group effects; graphics retain them. Drops emptied groups.
std::vector<pdf::PageElement>
lift_group_text(std::vector<pdf::PageElement> elements) {
  std::vector<pdf::PageElement> result;
  result.reserve(elements.size());
  for (pdf::PageElement &element : elements) {
    auto *group = std::get_if<pdf::GroupElement>(&element);
    if (group == nullptr || group->children == nullptr) {
      result.push_back(std::move(element));
      continue;
    }
    // Flatten nested groups first, so all interior text sits at this level.
    std::vector<pdf::PageElement> inner =
        lift_group_text(group->children->elements);
    std::vector<pdf::PageElement> graphics;
    graphics.reserve(inner.size());
    for (pdf::PageElement &child : inner) {
      if (std::holds_alternative<pdf::TextElement>(child)) {
        result.push_back(std::move(child)); // hoisted ahead of the group
      } else {
        graphics.push_back(std::move(child));
      }
    }
    if (graphics.empty()) {
      continue; // the group carried only text; nothing left to composite
    }
    auto children = std::make_shared<pdf::GroupChildren>();
    children->elements = std::move(graphics);
    pdf::GroupElement lifted;
    lifted.children = std::move(children);
    lifted.alpha = group->alpha;
    lifted.blend_mode = group->blend_mode;
    lifted.soft_mask = group->soft_mask;
    result.push_back(std::move(lifted));
  }
  return result;
}

/// A page's content stream, then the annotation appearances painting on top of
/// it (ISO 32000-1 12.5.5).
std::vector<pdf::PageElement> page_elements(const pdf::Page &page,
                                            const std::string &content,
                                            const Logger &logger) {
  std::vector<pdf::PageElement> elements =
      lift_group_text(pdf::extract_page(content, *page.resources, logger));
  for (const pdf::Annotation *annotation : page.annotations) {
    std::vector<pdf::PageElement> appearance =
        lift_group_text(pdf::extract_annotation(*annotation, logger));
    elements.insert(elements.end(), std::make_move_iterator(appearance.begin()),
                    std::make_move_iterator(appearance.end()));
  }
  return elements;
}

class HtmlServiceImpl;

/// Where page @p number loads from (`lazy-loading.md` decision 3).
std::string page_script_path(const std::size_t number) {
  return "pdf-pages/" + std::to_string(number) + ".js";
}

/// Where the text of index group @p group loads from.
std::string index_script_path(const std::size_t group) {
  return "pdf-search/" + std::to_string(group) + ".js";
}

/// A resource the service renders when it is asked for.
class RenderedResource : public abstract::HtmlResource {
public:
  RenderedResource(const HtmlServiceImpl &service, std::string path,
                   std::string mime_type)
      : m_service{&service}, m_path{std::move(path)},
        m_mime_type{std::move(mime_type)} {}

  [[nodiscard]] HtmlResourceType type() const override {
    return m_mime_type == "font/ttf" ? HtmlResourceType::font
                                     : HtmlResourceType::js;
  }
  [[nodiscard]] const std::string &mime_type() const override {
    return m_mime_type;
  }
  [[nodiscard]] const std::string &name() const override { return m_path; }
  [[nodiscard]] const std::string &path() const override { return m_path; }
  [[nodiscard]] const std::optional<File> &file() const override {
    static const std::optional<File> none;
    return none;
  }
  [[nodiscard]] bool is_shipped() const override { return false; }
  [[nodiscard]] bool is_external() const override { return false; }
  [[nodiscard]] bool is_accessible() const override { return true; }

protected:
  const HtmlServiceImpl *m_service{nullptr};

private:
  std::string m_path;
  std::string m_mime_type;
};

/// A page after the first as the script that puts it into its empty page.
class PageScriptResource final : public RenderedResource {
public:
  PageScriptResource(const HtmlServiceImpl &service, const std::size_t number)
      : RenderedResource(service, page_script_path(number), "text/javascript"),
        m_number{number} {}

  void write_resource(std::ostream &os) const override;

private:
  std::size_t m_number{0};
};

/// A script of the search index: the text of the pages of a group that load.
class PageIndexResource final : public RenderedResource {
public:
  PageIndexResource(const HtmlServiceImpl &service, std::string path,
                    const std::size_t group)
      : RenderedResource(service, std::move(path), "text/javascript"),
        m_group{group} {}

  void write_resource(std::ostream &os) const override;

private:
  std::size_t m_group{0};
};

/// A font that every page links, rather than each page carrying it.
class FontFileResource final : public RenderedResource {
public:
  FontFileResource(const HtmlServiceImpl &service, const pdf::Font &font,
                   std::string path)
      : RenderedResource(service, std::move(path), "font/ttf"), m_font{&font} {}

  void write_resource(std::ostream &os) const override;

private:
  const pdf::Font *m_font{nullptr};
};

class HtmlServiceImpl final : public HtmlService {
public:
  HtmlServiceImpl(PdfFile pdf_file, HtmlConfig config, const Logger &logger)
      : HtmlService(std::move(config), logger), m_pdf_file{std::move(pdf_file)},
        m_resources{locate_search_resources(this->config())} {
    for (auto &&resource : locate_pdf_annotation_resources(this->config())) {
      m_resources.emplace_back(std::move(resource));
    }
    // declared before any page is parsed, so before the views are known
    for (auto &&resource : locate_viewport_resources(this->config())) {
      m_resources.push_back(std::move(resource));
    }
  }

  /// Parses once, applies the `[page_range_begin, page_range_end)` range and
  /// builds the views: the combined document plus one per rendered page. The
  /// parser and its object cache live for the service's lifetime so every view
  /// renders off that one parse.
  void warmup() const override {
    std::lock_guard lock(m_mutex);

    if (m_document != nullptr) {
      return;
    }

    const auto &pdf_file =
        dynamic_cast<const pdf::PdfFile &>(*m_pdf_file.impl());
    m_parser =
        std::make_unique<pdf::DocumentParser>(pdf_file.create_parser(m_logger));
    m_document = m_parser->parse_document();

    const std::vector<pdf::Page *> pages = m_document->collect_pages();
    m_link_resolver = std::make_unique<LinkResolver>(
        build_link_resolver(*m_parser, *m_document, pages));
    const std::size_t begin =
        std::min<std::size_t>(config().page_range_begin, pages.size());
    const std::size_t end = std::clamp<std::size_t>(
        config().page_range_end.value_or(pages.size()), begin, pages.size());
    m_first_page = begin;
    m_pages.assign(pages.begin() + static_cast<std::ptrdiff_t>(begin),
                   pages.begin() + static_cast<std::ptrdiff_t>(end));

    m_views.emplace_back(std::make_shared<HtmlView>(
        *this, "document", 0, config().document_output_file_name));
    for (std::size_t i = 0; i < m_pages.size(); ++i) {
      const std::size_t page = m_first_page + i;
      m_views.emplace_back(std::make_shared<HtmlView>(
          *this, "page" + std::to_string(page + 1), page + 1,
          fill_path_variables(config().page_output_file_name, page)));
    }
  }

  [[nodiscard]] const HtmlViews &list_views() const override {
    warmup();
    return m_views;
  }

  [[nodiscard]] bool is_view(const std::string &path) const {
    warmup();
    return std::ranges::any_of(
        m_views, [&path](const auto &view) { return view.path() == path; });
  }

  /// The resource at @p path, copied: a render on another thread may add to
  /// the list meanwhile.
  [[nodiscard]] std::optional<odr::HtmlResource>
  linked_resource(const std::string &path) const {
    std::lock_guard lock(m_resources_mutex);
    if (const odr::HtmlResource *resource = resource_at(m_resources, path);
        resource != nullptr) {
      return *resource;
    }
    return std::nullopt;
  }

  [[nodiscard]] bool exists(const std::string &path) const override {
    return is_view(path) || linked_resource(path).has_value();
  }

  [[nodiscard]] std::string mimetype(const std::string &path) const override {
    if (is_view(path)) {
      return "text/html";
    }
    if (const std::optional<odr::HtmlResource> resource = linked_resource(path);
        resource.has_value()) {
      return resource->mime_type();
    }
    throw FileNotFound("Unknown path: " + path);
  }

  void write(const std::string &path, std::ostream &out) const override {
    // written without the lock, which a page script takes itself
    if (const std::optional<odr::HtmlResource> resource = linked_resource(path);
        !is_view(path) && resource.has_value()) {
      resource->write_resource(out);
      return;
    }
    HtmlWriter writer(out, config());
    write_html(path, writer);
  }

  HtmlResources write_html(const std::string &path,
                           HtmlWriter &out) const override {
    warmup();
    // The parser's object cache is shared mutable state; renders are
    // serialized.
    std::lock_guard lock(m_mutex);
    if (path == config().document_output_file_name) {
      return remember_linked(write_document(out));
    }
    for (std::size_t i = 0; i < m_pages.size(); ++i) {
      if (path == m_views[i + 1].path()) {
        return remember_linked(write_page(i, out));
      }
    }
    throw FileNotFound("Unknown path: " + path);
  }

  /// Keeps a render's linked resources so `exists`/`mimetype`/`write` can serve
  /// what the markup points at. A view has to be rendered before its images can
  /// be asked for, so collecting them here is enough; pre-rendering every view
  /// to fill the list up front is not worth what it costs on a pdf.
  HtmlResources remember_linked(HtmlResources resources) const {
    std::lock_guard lock(m_resources_mutex);
    for (const auto &entry : resources) {
      if (entry.second.has_value() &&
          resource_at(m_resources, *entry.second) == nullptr) {
        m_resources.push_back(entry);
      }
    }
    return resources;
  }

  /// Whether the 0-based page index falls inside the rendered page range.
  [[nodiscard]] bool page_rendered(const std::size_t index) const {
    return index >= m_first_page && index < m_first_page + m_pages.size();
  }

  /// The combined document: every rendered page, internal links as `#pN`
  /// anchors (dropped when the target page is outside the page range).
  HtmlResources write_document(HtmlWriter &out) const {
    if (loads_pages()) {
      // before the first page, so its faces read the files too
      const std::vector<const pdf::Font *> &fonts = document_fonts();
      HtmlResources resources =
          write_pages_dual_layer(out, std::span(m_pages).first(1),
                                 m_first_page + 1, document_page_href(),
                                 std::span(m_pages).subspan(1))
              .resources;
      for (const pdf::Font *font : fonts) {
        if (const std::optional<std::string> file = shared_font_file(font);
            file.has_value()) {
          resources.emplace_back(
              odr::HtmlResource(
                  std::make_shared<FontFileResource>(*this, *font, *file)),
              *file);
        }
      }
      return resources;
    }
    return write_pages(out, m_pages, m_first_page + 1, document_page_href());
  }

  [[nodiscard]] PageHref document_page_href() const {
    return [this](const std::size_t index) {
      return page_rendered(index) ? "#p" + std::to_string(index + 1)
                                  : std::string();
    };
  }

  /// Whether the combined document loads its pages after the first as the
  /// reader comes near, which it does where it is laid out lazily, in two
  /// layers. The single layer re-encodes a font for the pages it meets, so a
  /// page rendered alone would need a font of its own.
  [[nodiscard]] bool loads_pages() const {
    return config().lazy_loading && config().lazy_layout &&
           config().pdf_text_mode == PdfTextMode::dual_layer &&
           m_pages.size() > 1;
  }

  /// Page @p number rendered alone, as the script that puts it into the page.
  void write_page_script(const std::size_t number, std::ostream &os) const {
    std::lock_guard lock(m_mutex);
    std::ostringstream html;
    HtmlWriter out(html, false, "");
    const std::size_t index = number - 1 - m_first_page;
    DualLayerPages page = write_pages_dual_layer(
        out, std::span(m_pages).subspan(index, 1), number, document_page_href(),
        {}, DualRender::fragment);
    // a search index asked for later need not render it again
    m_page_texts.resize(m_pages.size());
    m_page_texts[index] = std::move(page.texts.front());
    os << "odr.chunks.fill(" << script_string("p" + std::to_string(number))
       << "," << script_string(html.str()) << ");\n";
  }

  /// The text of the pages of index group @p group that load, as the script
  /// that hands it to the page. Each page renders once for it, alone and to
  /// nothing; the service keeps the text.
  void write_index_script(const std::size_t group, std::ostream &os) const {
    std::lock_guard lock(m_mutex);
    m_page_texts.resize(m_pages.size());
    const std::size_t first =
        std::max<std::size_t>(group * chunks_per_index, 1);
    const std::size_t end =
        std::min<std::size_t>(m_pages.size(), (group + 1) * chunks_per_index);
    os << "odr.chunks.text({";
    for (std::size_t index = first; index < end; ++index) {
      const std::size_t number = m_first_page + index + 1;
      std::optional<std::string> &text = m_page_texts[index];
      if (!text.has_value()) {
        NullStream null;
        HtmlWriter out(null, false, "");
        text = std::move(write_pages_dual_layer(
                             out, std::span(m_pages).subspan(index, 1), number,
                             document_page_href(), {}, DualRender::text)
                             .texts.front());
      }
      os << (index > first ? "," : "")
         << script_string("p" + std::to_string(number)) << ":"
         << script_string(*text);
    }
    os << "});\n";
  }

  void write_font_file(const pdf::Font &font, std::ostream &os) const {
    std::lock_guard lock(m_mutex);
    os << reencoded_font(font, {});
  }

  /// Whether a font re-encodes, which the service asks once for each font:
  /// the test re-encodes it, and every page rendered apart would ask again.
  [[nodiscard]] bool shared_font_is_usable(const pdf::Font *font) const {
    const auto [it, inserted] = m_font_usable.try_emplace(font, false);
    if (inserted) {
      it->second = font_is_usable(*font, m_logger);
    }
    return it->second;
  }

  /// The number a font has in every page rendered apart.
  [[nodiscard]] std::uint32_t shared_font_id(const pdf::Font *font) const {
    const auto [it, inserted] = m_font_ids.try_emplace(
        font, static_cast<std::uint32_t>(m_font_ids.size() + 1));
    return it->second;
  }

  /// The file a font's face reads, nothing where it has none: one that no
  /// page states in its resources, which a page then carries itself.
  [[nodiscard]] std::optional<std::string>
  shared_font_file(const pdf::Font *font) const {
    if (!m_font_files.contains(font)) {
      return std::nullopt;
    }
    return "pdf-fonts/" + std::to_string(shared_font_id(font)) + ".ttf";
  }

  /// The usable fonts the rendered pages state in their resources and in the
  /// resources of their forms, each with a file. Found once.
  [[nodiscard]] const std::vector<const pdf::Font *> &document_fonts() const {
    if (m_document_fonts.has_value()) {
      return *m_document_fonts;
    }
    std::vector<const pdf::Font *> &result = m_document_fonts.emplace();
    std::unordered_set<const pdf::Resources *> seen;
    const auto visit = [&](const auto &self,
                           const pdf::Resources *resources) -> void {
      if (resources == nullptr || !seen.insert(resources).second) {
        return;
      }
      for (const auto &[name, font] : resources->font) {
        if (font != nullptr && !m_font_files.contains(font) &&
            shared_font_is_usable(font)) {
          m_font_files.insert(font);
          static_cast<void>(shared_font_id(font));
          result.push_back(font);
        }
      }
      for (const auto &[name, x_object] : resources->x_object) {
        if (x_object != nullptr) {
          self(self, x_object->resources);
        }
      }
    };
    for (const pdf::Page *page : m_pages) {
      visit(visit, page->resources);
    }
    return result;
  }

  /// One standalone page (the `page{index}.html` view). Internal links are
  /// rebased onto this page's own directory: the browser resolves an href
  /// against the current document, not the output root.
  HtmlResources write_page(const std::size_t page_index,
                           HtmlWriter &out) const {
    const RelPath from_dir = RelPath(m_views[page_index + 1].path()).parent();
    const PageHref page_href = [this, &from_dir](const std::size_t index) {
      return page_rendered(index)
                 ? RelPath(fill_path_variables(config().page_output_file_name,
                                               index))
                       .rebase(from_dir)
                       .string()
                 : std::string();
    };
    const std::array<pdf::Page *, 1> pages{m_pages[page_index]};
    return write_pages(out, pages, m_first_page + page_index + 1, page_href);
  }

  HtmlResources write_pages(HtmlWriter &out,
                            const std::span<pdf::Page *const> pages,
                            const std::size_t first_page_number,
                            const PageHref &page_href) const {
    if (config().pdf_text_mode == PdfTextMode::single_layer) {
      return write_pages_single_layer(out, pages, first_page_number, page_href);
    }
    return write_pages_dual_layer(out, pages, first_page_number, page_href)
        .resources;
  }

  // `.vis` paints PUA glyphs; `.sel` carries transparent Unicode in stream
  // order. Selection runs use PDF advance widths; invisible text is not
  // painted.

  /// One run inside a visual line block: margin-left, font size,
  /// font-family+colour. The line block holds placement only.
  struct VisRunOut {
    std::string classes;
    std::string text; ///< PUA glyph string (or real unicode for fallback path)
  };
  /// One visual line block, absolutely positioned at its first run's origin.
  struct VisLineOut {
    std::string classes; ///< "t lN tN [mN]" (or matrix transform)
    std::vector<VisRunOut> runs;
  };
  struct PathOut {
    std::string svg;
  };
  /// Visual-layer paint-order item: a glyph line block, or an SVG fragment.
  using VisItem = std::variant<VisLineOut, PathOut>;

  /// One selection-layer run: an inline-block span of fixed width (for CSS
  /// justify). Empty `text` means a spacer-only span.
  struct SelRunOut {
    std::string classes; ///< "sr wN [mlN]"
    std::string text;    ///< real unicode, may be empty for spacer
  };
  /// One selection-layer line block: absolutely positioned, transparent.
  struct SelLineOut {
    std::string classes; ///< "t lN tN i"
    std::vector<SelRunOut> runs;
  };

  struct DualPageOut {
    std::string classes;
    std::string attributes;
    double width{0};
    double height{0};
    std::vector<VisItem> vis_items;
    std::vector<SelLineOut> sel_lines;
    std::string clip_defs;
    std::vector<LinkOut> links;
  };

  /// What the dual layer writes: the resources, and for a fragment the text of
  /// its page as `search.js` reads it, a `\n` between two lines of its `.sel`
  /// layer (`lazy-loading.md` decision 4).
  struct DualLayerPages {
    HtmlResources resources;
    std::vector<std::string> texts;
  };

  /// The text of each page as a search reads it.
  static std::vector<std::string>
  sel_texts(const std::span<const DualPageOut> pages) {
    std::vector<std::string> texts;
    texts.reserve(pages.size());
    for (const DualPageOut &page : pages) {
      std::string text;
      for (const SelLineOut &line : page.sel_lines) {
        if (&line != page.sel_lines.data()) {
          text += '\n';
        }
        for (const SelRunOut &run : line.runs) {
          // `search.js` folds it to a space; only a new line writes a `\n`
          std::string run_text = run.text;
          std::ranges::replace(run_text, '\n', ' ');
          text += run_text;
        }
      }
      texts.push_back(std::move(text));
    }
    return texts;
  }

  /// What a render of the dual layer is for.
  enum class DualRender {
    document, ///< pages, and the pages that load as empty ones
    fragment, ///< the one page of a page script
    text,     ///< a fragment for its text alone, with no image read
  };

  /// @p pages rendered, and @p later as empty pages that load as scripts
  /// (`lazy-loading.md` decision 3). A fragment is the one page of such a
  /// script: the rules it needs and what its page box holds, which the script
  /// puts into the empty page.
  DualLayerPages write_pages_dual_layer(
      HtmlWriter &out, const std::span<pdf::Page *const> pages,
      const std::size_t first_page_number, const PageHref &page_href,
      const std::span<pdf::Page *const> later = {},
      const DualRender render = DualRender::document) const {
    const bool fragment = render != DualRender::document;
    // pages rendered apart share one page, so their names must not clash: a
    // fragment suffixes its classes with its page, and a font has one number
    // and one file for the whole service
    const bool loads = !later.empty() || fragment;
    const std::string suffix =
        fragment ? "_" + std::to_string(first_page_number) : std::string();
    // a fragment's resources are written by nobody, so it carries its images
    HtmlConfig fragment_config = config();
    fragment_config.resource_locator = [](const odr::HtmlResource &,
                                          const HtmlConfig &) {
      return HtmlResourceLocation();
    };

    HtmlResources resources;
    ImageRegistry images(fragment ? fragment_config : config(), resources,
                         render == DualRender::text);
    const WritingState state(out, config(), resources, logger());

    pdf::DocumentParser &parser = *m_parser;
    LinkResolver &link_resolver = *m_link_resolver;

    // every page that loads states the `.fvN` rule of its fonts again, which
    // would beat the colour a page before it states, so its own rules rank
    // above a single class
    StyleRegistry styles(loads ? StyleRegistry::Rank::replaces_inline
                               : StyleRegistry::Rank::plain);
    styles.set_suffix(suffix);
    std::vector<DualPageOut> pages_out;
    pages_out.reserve(pages.size());

    // Font management — visual layer only needs PUA glyphs.
    std::uint32_t family_count = 0;
    std::string font_faces;
    std::string font_styles; // per-font `.fvN` (visible) / `.fnN` (invisible)
    // metric-overriding `.odr-sN` faces
    SubstituteFontFaces substitute_faces(suffix);
    std::vector<const pdf::Font *> accepted_fonts;
    // Which classes are used: [0]=fv (visible), [1]=fn (invisible).
    std::vector<std::array<bool, 2>> font_class_used;
    std::unordered_map<const pdf::Font *, std::uint32_t> family_index;

    const auto font_family = [&](const pdf::Font *font) -> std::uint32_t {
      if (!loads) {
        return intern_font(family_index, family_count, font, m_logger,
                           [&](std::uint32_t) {
                             accepted_fonts.push_back(font);
                             font_class_used.push_back({false, false});
                           });
      }
      const auto [it, inserted] = family_index.try_emplace(font, 0);
      if (!inserted || !shared_font_is_usable(font)) {
        return it->second;
      }
      const std::uint32_t index = shared_font_id(font);
      it->second = index;
      if (accepted_fonts.size() < index) {
        accepted_fonts.resize(index, nullptr);
        font_class_used.resize(index, {false, false});
      }
      accepted_fonts[index - 1] = font;
      return index;
    };
    const ClipRegistry::FontFamily clip_font_family =
        [&](const pdf::Font &font) { return face_name(font_family(&font)); };

    const auto add_class = [&styles](std::string &classes,
                                     const std::string &prefix,
                                     std::string declaration) {
      classes += ' ';
      classes += styles.intern(prefix, std::move(declaration));
    };

    // Strips a trailing `wN` (width) token so a merged selection run's width
    // can be re-declared. At most one is ever attached.
    const auto strip_width_class = [](std::string &classes) {
      const std::size_t pos = classes.rfind(' ');
      if (pos == std::string::npos) {
        return;
      }
      const std::string_view tail(classes.data() + pos + 1,
                                  classes.size() - pos - 1);
      if (tail.size() > 1 && tail.front() == 'w' &&
          std::ranges::all_of(tail.substr(1), [](const char c) {
            return std::isdigit(static_cast<unsigned char>(c)) != 0 || c == '_';
          })) {
        classes.resize(pos);
      }
    };

    for (pdf::Page *page : pages) {
      const PageBox pb = begin_page(*page, add_class);
      const double width = pb.width;
      const double height = pb.height;
      const util::math::Transform2D &to_box = pb.to_box;

      // page numbers are 1-based, `data-odr-page` is the 0-based index
      const std::size_t page_index = first_page_number - 1 + pages_out.size();

      DualPageOut &page_out = pages_out.emplace_back();
      page_out.classes = pb.classes;
      page_out.attributes = page_attributes(page_index, to_box);
      page_out.width = width;
      page_out.height = height;
      page_out.links =
          collect_page_links(*page, to_box, link_resolver, page_href, config());

      std::string stream;
      for (const auto &ref : page->contents_reference) {
        stream += parser.read_decoded_stream(ref);
        stream += '\n';
      }

      // the ids of a page's defs name it, by its place here or, where pages
      // are rendered apart, by its number
      const auto defs_page =
          static_cast<std::uint32_t>(loads ? page_index + 1 : pages_out.size());
      ClipRegistry clips(defs_page, clip_font_family);
      GradientRegistry gradients(defs_page);
      PatternRegistry patterns(defs_page);
      MaskRegistry masks(defs_page);

      /// index of the open VisLineOut in vis_items, -1 = none
      std::int32_t vis_cur_line = -1;
      double vis_prev_end = 0;
      double vis_prev_baseline = 0;
      double vis_prev_font_pt = 0;
      bool vis_prev_was_matrix = false;
      std::string vis_cur_flow_key;
      const auto vis_close_line = [&] { vis_cur_line = -1; };

      // Selection layer state: reading-order grouping, in the open block's
      // frame.
      bool sel_have_prev = false;
      double sel_prev_baseline = 0;
      double sel_prev_end = 0;
      /// previous run's advance height, for `starts_new_line`
      double sel_prev_font_pt = 0;
      bool sel_prev_ends_space = false;
      bool sel_prev_was_matrix = false;
      std::int32_t sel_cur_line = -1;
      /// origin the open `.sr` run starts at, to recompute its width on merge
      double sel_cur_run_start_ox = 0;
      /// font-size of the previous element, for its line's trailing space
      double sel_prev_font_size_pt = 0;
      /// the open block's transform: its linear part identifies runs one CSS
      /// matrix can place, its origin anchors the frame they flow in
      util::math::Transform2D sel_block;
      /// the open block's `local_scale`, which every run in it is measured in
      double sel_cur_local = 1;
      /// advance owed to the next run: whitespace no span could carry, plus a
      /// gap no spacer took
      double sel_pending_space = 0;
      /// width of the open line's last span, which a gap after a space widens:
      /// a `margin-left` there is a hole in the selection highlight
      double sel_tail_width_pt = 0;
      /// the font size of the last span, if it is a `.sg`
      std::optional<double> sel_tail_gap_font_size_pt;

      const auto gap_classes = [&](const double font_size_pt,
                                   const double width_pt) {
        std::string result = "sg";
        add_class(result, "f", pt_decl("font-size", font_size_pt));
        // Always a width: an unsized spacer takes the space advance of the
        // fallback font, and that adds up at every word break.
        add_class(result, "w", pt_decl("width", width_pt));
        // Only a gap that still reads as a word space: a column of white
        // painted solid is worse than the sliver.
        if (width_pt > 0 && width_pt <= font_size_pt) {
          result += " sw";
        }
        return result;
      };

      for (const pdf::PageElement &element :
           page_elements(*page, stream, m_logger)) {
        if (handle_graphic_element(
                element, to_box, width, height, clips, gradients, patterns,
                masks, images, m_logger, [&] { vis_close_line(); },
                [&](std::string frag) {
                  page_out.vis_items.push_back(PathOut{std::move(frag)});
                })) {
          continue;
        }

        const pdf::TextElement &text = std::get<pdf::TextElement>(element);
        // TODO(clip text): clip not applied to text (see pdf/AGENTS.md gaps).
        const std::uint32_t font =
            text.font != nullptr ? font_family(text.font) : 0;
        if (text.text.empty() && font == 0) {
          continue;
        }

        const auto [m, invisible, is_matrix, asc, scale, ox, baseline, extent,
                    font_pt, font_size_pt] = run_geometry(text, to_box);
        const double ascent_pt = asc * text.size;
        const std::string color_suffix = color_class(text, invisible, styles);

        // --- Visual layer ---------------------------------------------------
        // Invisible runs paint nothing and Type3 runs are painted by their char
        // procs, so both contribute to the selection layer only.
        if (!invisible && !text.render_as_graphics) {
          // A block carries its first run's placement and the rest flow off it,
          // so another font, size or ascent needs a block of its own — size is
          // in the key, so `vis_local` is the block's.
          const double vis_local = local_scale(font_size_pt);
          std::ostringstream key;
          key << font << '|' << font_size_pt << '|' << round2(asc * text.size);
          if (font == 0 && text.font != nullptr &&
              text.font->substitute.has_value()) {
            key << '|' << font_substitute_declaration(*text.font->substitute);
          }
          const std::string vis_flow_key = std::move(key).str();

          bool new_vis_line = is_matrix || vis_prev_was_matrix ||
                              vis_cur_line < 0 ||
                              vis_flow_key != vis_cur_flow_key;
          double vis_margin_pt = 0;
          if (!new_vis_line && vis_prev_font_pt > 0) {
            if (starts_new_line(baseline, vis_prev_baseline, ox, vis_prev_end,
                                vis_prev_font_pt)) {
              new_vis_line = true;
            } else {
              vis_margin_pt = round2((ox - vis_prev_end) * vis_local);
            }
          }

          if (new_vis_line) {
            std::string line_base = "t";
            add_position_classes(line_base, add_class, m, is_matrix, vis_local,
                                 ox, baseline, ascent_pt);
            VisLineOut line_out;
            line_out.classes = std::move(line_base);
            page_out.vis_items.push_back(std::move(line_out));
            vis_cur_line = static_cast<int>(page_out.vis_items.size()) - 1;
            vis_cur_flow_key = vis_flow_key;
          }

          std::string run_classes = "g"; // user-select:none
          add_class(run_classes, "f",
                    pt_decl("font-size", round2(font_size_pt * vis_local)));
          if (font != 0) {
            run_classes += ' ';
            run_classes += font_class(font_class_used, font, invisible);
          } else if (text.font != nullptr &&
                     text.font->substitute.has_value()) {
            // Non-embedded: real Unicode in the substitute family, whose
            // metric-overriding face pins the baseline to `asc`.
            add_class(
                run_classes, "ff",
                substitute_faces.declaration(*text.font->substitute, asc));
          }
          if (vis_margin_pt != 0) {
            add_class(run_classes, "ml", pt_decl("margin-left", vis_margin_pt));
          }
          run_classes += color_suffix;

          std::string run_text;
          if (font != 0) {
            // Not `escape_text`: its `&nbsp;` is a different character, which
            // `word-spacing` does not move.
            run_text = escape_markup(glyph_run_str(*text.font, text.codes));
          } else {
            // `margin-left` already spans the word break; rendering it too
            // shifts the glyphs by a space, once per run.
            run_text = escape_text(core_text(text));
          }

          if (const double cs_pt =
                  round2(text.char_spacing * scale * vis_local);
              cs_pt != 0) {
            add_class(run_classes, "s", pt_decl("letter-spacing", cs_pt));
          }
          // Tw applies to single-byte code 32 alone (9.3.3), which only a
          // simple font's run keeps as a real U+0020 (`space_glyph`).
          if (!(text.font != nullptr && text.font->composite)) {
            if (const double ws_pt =
                    round2(text.word_spacing * scale * vis_local);
                ws_pt != 0) {
              add_class(run_classes, "ws", pt_decl("word-spacing", ws_pt));
            }
          }

          std::get<VisLineOut>(page_out.vis_items[vis_cur_line])
              .runs.push_back(
                  VisRunOut{std::move(run_classes), std::move(run_text)});

          vis_prev_end = ox + extent;
          vis_prev_baseline = baseline;
          vis_prev_font_pt = font_pt;
          vis_prev_was_matrix = is_matrix;
        }

        // --- Selection layer -----------------------------------------------
        // A run is measured in the frame its block lays out in: page space for
        // an axis-aligned block, the block's own space for a matrix one. Both
        // put x along the writing line, so one set of tests serves both.
        if (!text.text.empty()) {
          const bool starts_space = text.text.front() == ' ';
          // A leading inferred space is dropped: the gap between runs is
          // covered by the spacer span, not by the run text.
          std::string core = starts_space ? text.text.substr(1) : text.text;

          // Settled before the run is measured: it is measured in the scale of
          // the block it joins.
          bool sel_frame_kept =
              sel_have_prev && !is_matrix && !sel_prev_was_matrix;
          std::optional<std::array<double, 2>> sel_matrix_origin;
          if (is_matrix && sel_cur_line >= 0 && sel_prev_was_matrix &&
              same_linear(sel_block, m)) {
            sel_matrix_origin = local_origin(sel_block, m);
            sel_frame_kept = sel_frame_kept || sel_matrix_origin.has_value();
          }
          const double tz = text.horizontal_scaling / 100.0;
          // at scale 1, and linear in the block's; `text.width` carries the
          // horizontal scaling the CSS matrix applies again
          const double unit_extent =
              is_matrix ? (tz != 0 ? text.width * scale / tz : 0) : extent;
          const double unit_font_pt = is_matrix ? text.size * scale : font_pt;
          double unit_ox = is_matrix ? 0 : ox;
          double unit_baseline = is_matrix ? 0 : baseline;
          if (sel_matrix_origin.has_value()) {
            unit_ox = (*sel_matrix_origin)[0];
            unit_baseline = (*sel_matrix_origin)[1];
          }
          // A block keeps the scale it opened with: splitting would break a
          // copied line at every superscript, and this layer is transparent.
          double sel_local =
              sel_frame_kept ? sel_cur_local : local_scale(font_size_pt);
          double sel_font_size_pt = round2(font_size_pt * sel_local);
          double sel_ox = unit_ox * sel_local;
          double sel_baseline = unit_baseline * sel_local;
          double sel_extent = unit_extent * sel_local;
          double sel_font_pt = unit_font_pt * sel_local;
          double width_pt = round2(sel_extent);
          // Signed: a run that starts inside the previous one pulls back.
          const double gap_pt = sel_ox - sel_prev_end;

          bool new_sel_line = !sel_frame_kept;
          bool sel_gap = false;
          if (sel_frame_kept && sel_prev_font_pt > 0) {
            new_sel_line =
                starts_new_line(sel_baseline, sel_prev_baseline, sel_ox,
                                sel_prev_end, sel_prev_font_pt);
            sel_gap = sel_ox - sel_prev_end > 0.25 * sel_prev_font_pt;
          }
          // A block anchors its runs to one baseline, so a run a rise lifts
          // off it — a superscript — needs its own, though it breaks nothing.
          const bool baseline_shift =
              is_matrix && sel_frame_kept && !new_sel_line &&
              sel_prev_font_pt > 0 &&
              std::abs(sel_baseline - sel_prev_baseline) >
                  0.02 * sel_prev_font_pt;
          new_sel_line = new_sel_line || baseline_shift;
          // The extractor's leading space is the break; a block opened because
          // the frames are not comparable is not.
          const bool break_space =
              (sel_frame_kept && !baseline_shift) || starts_space;

          if (new_sel_line) {
            // A block starting here has its own scale, and this run sits at
            // its origin.
            sel_local = local_scale(font_size_pt);
            sel_font_size_pt = round2(font_size_pt * sel_local);
            sel_extent = unit_extent * sel_local;
            sel_font_pt = unit_font_pt * sel_local;
            width_pt = round2(sel_extent);
            sel_ox = is_matrix ? 0 : ox * sel_local;
            sel_baseline = is_matrix ? 0 : baseline * sel_local;
            sel_block = m;
            sel_cur_local = sel_local;
            // Close the previous line with a trailing space. `sg`, not `sr`:
            // it carries no PDF-derived width, just the space.
            if (sel_cur_line >= 0 && sel_have_prev && !sel_prev_ends_space &&
                break_space) {
              std::string space_cls = "sg";
              add_class(space_cls, "f",
                        pt_decl("font-size", sel_prev_font_size_pt));
              page_out.sel_lines[sel_cur_line].runs.push_back(
                  SelRunOut{std::move(space_cls), " "});
            }
            std::string sel_base = "t";
            add_position_classes(sel_base, add_class, m, is_matrix, sel_local,
                                 ox, baseline, ascent_pt);
            sel_base += " i"; // transparent
            page_out.sel_lines.push_back(SelLineOut{std::move(sel_base), {}});
            sel_cur_line = static_cast<int>(page_out.sel_lines.size()) - 1;
            // Nothing is owed at the origin — unless this run is whitespace,
            // which emits no span to carry its advance.
            sel_pending_space = core.empty() ? sel_extent : 0;
            if (!core.empty()) {
              std::string cls = "sr";
              add_class(cls, "f", pt_decl("font-size", sel_font_size_pt));
              if (width_pt > 0) {
                add_class(cls, "w", pt_decl("width", width_pt));
              }
              page_out.sel_lines[sel_cur_line].runs.push_back(
                  SelRunOut{std::move(cls), std::move(core)});
              sel_cur_run_start_ox = sel_ox;
              sel_tail_width_pt = width_pt;
              sel_tail_gap_font_size_pt.reset();
            }
          } else if (sel_gap || sel_prev_ends_space || starts_space) {
            std::vector<SelRunOut> &runs =
                page_out.sel_lines[sel_cur_line].runs;
            // A real leading space is dropped from the text, so its advance
            // belongs to the gap: left in the run, one letter cannot be
            // justified over it and the space shows as a hole.
            const double lead =
                starts_space && !text.leading_space_inferred && !core.empty() &&
                        text.width > 0 && !text.advances.empty()
                    ? std::max(0.0,
                               sel_extent * text.advances.front() / text.width)
                    : 0;
            // The gap before this run, plus its own advance when it is only
            // whitespace and emits no `.sr`. Dropping either shortens the line.
            sel_pending_space +=
                gap_pt + lead + (core.empty() ? sel_extent : 0);
            // One space character per run of whitespace; a second would be
            // copied as one. The advance waits for the next `.sr` instead.
            if (!sel_prev_ends_space && !runs.empty()) {
              const double rounded_gap =
                  std::max(0.0, round2(sel_pending_space));
              runs.push_back(
                  SelRunOut{gap_classes(sel_font_size_pt, rounded_gap), " "});
              sel_pending_space -= rounded_gap;
              sel_tail_width_pt = rounded_gap;
              sel_tail_gap_font_size_pt = sel_font_size_pt;
            }
            if (!core.empty()) {
              // The last span ends in a space, so it takes the gap.
              if (const double owed = round2(sel_pending_space);
                  owed > 0 && sel_prev_ends_space && !runs.empty()) {
                sel_tail_width_pt = round2(sel_tail_width_pt + owed);
                if (sel_tail_gap_font_size_pt.has_value()) {
                  runs.back().classes = gap_classes(*sel_tail_gap_font_size_pt,
                                                    sel_tail_width_pt);
                } else {
                  strip_width_class(runs.back().classes);
                  add_class(runs.back().classes, "w",
                            pt_decl("width", sel_tail_width_pt));
                }
                sel_pending_space = 0;
              }
              std::string cls = "sr";
              add_class(cls, "f", pt_decl("font-size", sel_font_size_pt));
              if (const double owed = round2(sel_pending_space); owed != 0) {
                add_class(cls, "ml", pt_decl("margin-left", owed));
              }
              sel_pending_space = 0;
              width_pt = round2(sel_extent - lead);
              if (width_pt > 0) {
                add_class(cls, "w", pt_decl("width", width_pt));
              }
              runs.push_back(SelRunOut{std::move(cls), std::move(core)});
              sel_cur_run_start_ox = sel_ox + lead;
              sel_tail_width_pt = width_pt;
              sel_tail_gap_font_size_pt.reset();
            }
          } else {
            // Tight continuation on the same baseline: merge into the previous
            // run so the browser reads the sequence as one word, and widen that
            // run to the full merged extent so CSS justify still spreads across
            // the true PDF advance.
            std::vector<SelRunOut> &runs =
                page_out.sel_lines[sel_cur_line].runs;
            if (!runs.empty()) {
              runs.back().text += text.text;
              strip_width_class(runs.back().classes);
              const double merged_width_pt =
                  round2(sel_ox + sel_extent - sel_cur_run_start_ox);
              if (merged_width_pt > 0) {
                add_class(runs.back().classes, "w",
                          pt_decl("width", merged_width_pt));
              }
              sel_tail_width_pt = merged_width_pt;
            }
          }

          sel_prev_baseline = sel_baseline;
          sel_prev_end = sel_ox + sel_extent;
          sel_prev_font_pt = sel_font_pt;
          sel_prev_ends_space = !text.text.empty() && text.text.back() == ' ';
          sel_prev_was_matrix = is_matrix;
          sel_prev_font_size_pt = sel_font_size_pt;
          sel_have_prev = true;
        }
      }

      // Selection lines stay in content-stream order: sorting by baseline y
      // would interleave multi-column layouts, which the stream keeps
      // contiguous. The fix is page segmentation (XY-cut), not a scalar sort.
      page_out.clip_defs =
          clips.defs() + gradients.defs() + patterns.defs() + masks.defs();
    }

    // Post-pass: re-encode accepted fonts PUA-only.
    for (std::uint32_t i = 0; i < accepted_fonts.size(); ++i) {
      if (accepted_fonts[i] != nullptr) {
        write_font_face(*accepted_fonts[i], i, {}, font_class_used[i],
                        font_faces, font_styles,
                        loads ? shared_font_file(accepted_fonts[i])
                              : std::nullopt);
      }
    }
    substitute_faces.append_faces(font_faces);

    const auto write_vis_line = [&](const VisLineOut &line) {
      out.write_element_begin(
          "div", HtmlElementOptions().set_inline(true).set_class(line.classes));
      for (const VisRunOut &run : line.runs) {
        out.write_element_begin(
            "span",
            HtmlElementOptions().set_inline(true).set_class(run.classes));
        out.write_raw(run.text);
        out.write_element_end("span");
      }
      out.write_element_end("div");
    };

    const auto write_sel_line = [&](const SelLineOut &line) {
      out.write_element_begin(
          "div", HtmlElementOptions().set_inline(true).set_class(line.classes));
      for (const SelRunOut &run : line.runs) {
        out.write_element_begin(
            "span",
            HtmlElementOptions().set_inline(true).set_class(run.classes));
        if (!run.text.empty()) {
          out.write_raw(escape_markup(run.text));
        }
        out.write_element_end("span");
      }
      out.write_element_end("div");
    };

    // What the page box holds: the visual layer, the selection layer, and the
    // link overlays on top so they stay clickable.
    const auto write_page_content = [&](const DualPageOut &page) {
      // Visual layer: paint-order graphics and unselectable glyphs.
      out.write_element_begin("div",
                              HtmlElementOptions().set_class("vis").set_extra(
                                  R"(aria-hidden="true")"));
      write_page_items(out, page.clip_defs, page.vis_items, page.width,
                       page.height, write_vis_line);
      out.write_element_end("div"); // .vis

      // Selection layer: transparent, selectable Unicode in reading order.
      out.write_element_begin("div", HtmlElementOptions().set_class("sel"));
      for (const SelLineOut &line : page.sel_lines) {
        write_sel_line(line);
      }
      out.write_element_end("div"); // .sel

      write_page_links(out, page.links);
    };

    if (fragment) {
      out.out() << "<style>" << font_faces << font_styles;
      styles.write_rules(out.out());
      out.out() << "</style>";
      for (const DualPageOut &page : pages_out) {
        write_page_content(page);
      }
      return {std::move(resources), sel_texts(pages_out)};
    }

    // a page that loads later states its size, so the column and the print
    // know it before it is rendered
    struct PageSize {
      double width{0};
      double height{0};
    };
    std::vector<PageSize> sizes;
    sizes.reserve(pages_out.size() + later.size());
    std::vector<PageBox> later_boxes;
    later_boxes.reserve(later.size());
    for (const DualPageOut &page : pages_out) {
      sizes.push_back({page.width, page.height});
    }
    for (pdf::Page *page : later) {
      later_boxes.push_back(
          begin_page(*page, [](std::string &, const std::string &,
                               const std::string &) {}));
      sizes.push_back({later_boxes.back().width, later_boxes.back().height});
    }

    write_header_common(state, font_faces, font_styles, styles, sizes, [&] {
      // Visual layer glyph spans: not selectable (selection rides the `.sel`
      // layer).
      out.out() << ".g{user-select:none}";
      // Blank page resolves into `.sel`, not to `.vis` ahead of all the text.
      out.out() << ".vis{pointer-events:none}.sel{position:absolute;inset:0}";
      // Selection-layer fallback font: `size-adjust` shrinks a local system
      // font under the PDF-derived `.sr`/`.sg` widths. CSS justify only ever
      // *adds* spacing, so undershooting is free while overshooting spills out
      // of the run — hence the deliberately low config default. With no
      // fonts configured `.i` falls through to plain `sans-serif`.
      if (const std::vector<std::string> &fonts =
              config().pdf_dual_layer_fallback_fonts;
          !fonts.empty()) {
        std::ostringstream ff;
        ff << "@font-face{font-family:sf;src:";
        for (std::size_t i = 0; i < fonts.size(); ++i) {
          if (i != 0) {
            ff << ',';
          }
          ff << "local(\"";
          for (const char c : fonts[i]) {
            if (c == '"' || c == '\\') {
              ff << '\\';
            }
            ff << c;
          }
          ff << "\")";
        }
        const double adjust_pct =
            round2(std::clamp(config().pdf_dual_layer_fallback_font_size_adjust,
                              0.0, 1.0) *
                   100.0);
        ff << ";size-adjust:" << adjust_pct << "%}";
        out.out() << std::move(ff).str();
      }
      // Transparent text for the selection layer line blocks.
      out.out() << ".i{color:transparent;font-family:sf,sans-serif}";
      // A selection paints text in the highlight's own colour, which beats
      // `transparent` and shows this layer over the glyphs it stands for. An
      // author `::selection` drops the UA background, so state that too - and
      // state it see-through, because this layer paints over the glyph one.
      out.out()
          << ".i::selection,.i *::selection"
             "{color:transparent;background-color:rgba(70,130,220,.32);"
             "background-color:color-mix(in srgb,Highlight 45%,transparent)}";
      // Leave selection runs unclipped for WebView handles. The zero-height
      // strut aligns the baseline; inherited pre preserves spaces and prevents
      // wrapping.
      out.out() << ".sr{display:inline-block;vertical-align:bottom;"
                   "text-align:justify;text-align-last:justify;"
                   "text-justify:inter-character}";
      // A justification opportunity after the last letter, which is not
      // copied: else a one-letter run keeps its fallback advance and the rest
      // of the run is a hole in the highlight.
      out.out() << ".sr::after{content:\"\";display:inline-block}";
      // Selection-layer gap spacer. It holds only a space, so no handle can
      // land in it and the clip is free, along with the y alignment it gives.
      out.out() << ".sg{display:inline-block;overflow:hidden}";
      // A lone space cannot be justified to its box, so pad the advance and let
      // the width clip it: else every word break shows a sliver of white.
      out.out() << ".sw{letter-spacing:1000pt}";
    });

    write_pdf_body_begin(out, config());
    out.write_element_begin("div", HtmlElementOptions().set_class("d"));
    std::size_t page_number = first_page_number;
    for (const DualPageOut &page : pages_out) {
      // the first page is near the viewport before the script says so
      std::string classes =
          page.classes +
          chunk_classes(config(), page_number == first_page_number);
      out.write_element_begin(
          "div", HtmlElementOptions()
                     .set_class(std::move(classes))
                     .set_extra(R"(id="p)" + std::to_string(page_number++) +
                                R"(")" + page.attributes));

      write_page_content(page);
      out.write_element_end("div"); // .p
    }
    for (std::size_t i = 0; i < later.size(); ++i) {
      const PageBox &box = later_boxes[i];
      const std::size_t number = page_number++;
      // the first page of a group that loads names the script of its text;
      // `later` starts at the second page
      const std::size_t group = (i + 1) / chunks_per_index;
      const std::string text_attribute =
          i == 0 || (i + 1) % chunks_per_index == 0
              ? R"( data-odr-chunk-text=")" + index_script_path(group) + '"'
              : std::string();
      std::ostringstream size;
      size << "width:" << box.width * pt_to_in
           << "in;height:" << box.height * pt_to_in
           << "in;page:" << print_page_name(box.width, box.height);
      out.write_element_begin(
          "div",
          HtmlElementOptions()
              .set_class("p" + chunk_classes(config(), false))
              .set_style(std::move(size).str())
              .set_extra(R"(id="p)" + std::to_string(number) +
                         R"(" data-odr-chunk="p)" + std::to_string(number) +
                         R"(" data-odr-chunk-src=")" +
                         page_script_path(number) + '"' + text_attribute +
                         page_attributes(number - 1, box.to_box)));
      out.write_element_end("div");
      resources.emplace_back(
          odr::HtmlResource(
              std::make_shared<PageScriptResource>(*this, number)),
          page_script_path(number));
      if (!text_attribute.empty()) {
        resources.emplace_back(
            odr::HtmlResource(std::make_shared<PageIndexResource>(
                *this, index_script_path(group), group)),
            index_script_path(group));
      }
    }
    out.write_element_end("div"); // .d
    write_search_script(state);
    write_viewport_script(state);
    write_pdf_annotation_script(state);
    write_host_bridge_script(state);
    out.write_body_end();
    out.write_end();

    return {std::move(resources), {}};
  }

  // Frequency-selected cmap entries render clean runs as Unicode. Other runs
  // paint glyphs through `::before` and expose Unicode in a zero-width overlay.

  struct SingleRunOut {
    std::string margin;     ///< "" or a `margin-left` class
    std::string color;      ///< "" or a colour class name (no leading space)
    std::string text;       ///< real Unicode (HTML-escaped), may be empty
    std::string glyph_data; ///< PUA glyph string (non-empty → unclean)
    bool lead_space{false}; ///< clean run: emit a selectable space before
                            ///< `text` (a recovered inferred word break)
    std::string lead_space_width; ///< "" (zero-width `.ov`) or a width class:
                                  ///< the pdf2htmlEX-style width-bearing space
                                  ///< that also carries the gap (no run margin)
  };
  struct SingleLineOut {
    std::string classes;    ///< "t lN tN [mN] [fvN|fnN] [iN]..."
    std::string font_class; ///< per-font family+colour class on the block
    std::vector<SingleRunOut> runs;
  };
  struct SinglePathOut {
    std::string svg;
  };
  using SingleItem = std::variant<SingleLineOut, SinglePathOut>;

  struct SinglePageOut {
    std::string classes;
    std::string attributes;
    double width{0};
    double height{0};
    std::vector<SingleItem> items;
    std::string clip_defs;
    std::vector<LinkOut> links;
  };

  HtmlResources write_pages_single_layer(
      HtmlWriter &out, const std::span<pdf::Page *const> pages,
      const std::size_t first_page_number, const PageHref &page_href) const {
    HtmlResources resources;
    ImageRegistry images(config(), resources);
    const WritingState state(out, config(), resources, logger());

    pdf::DocumentParser &parser = *m_parser;
    LinkResolver &link_resolver = *m_link_resolver;

    // A real-Unicode scalar gets a cmap entry only inside the BMP and outside
    // the PUA, so the glyph-deterministic PUA code points are never shadowed.
    const auto collapsible_unicode = [](const char32_t c) {
      return c <= 0xFFFF && !(c >= 0xE000 && c <= 0xF8FF);
    };

    // A leading inferred space carries no character code or advance, so the 1:1
    // codes-to-text alignment starts after it — as `core_text_view` views it.
    const auto core_char_count = [](const pdf::TextElement &t) {
      return util::string::utf8_length(t.text) -
             (t.leading_space_inferred ? 1u : 0u);
    };

    std::uint32_t family_count = 0;
    std::string font_faces;
    std::string font_styles;              // ".fvN{...}" / ".fnN{...}"
    SubstituteFontFaces substitute_faces; // metric-overriding `.odr-sN` faces
    std::vector<const pdf::Font *> accepted_fonts;
    // Per-font, per-uchar, per-glyph occurrence count (pre-pass).
    // Indexed by font_index - 1.
    std::vector<std::map<char32_t, std::map<std::uint16_t, std::uint32_t>>>
        glyph_freq;
    // Per-font winning uchar→glyph mapping (derived from glyph_freq).
    std::vector<std::map<char32_t, std::uint16_t>> used_unicode;
    // Which per-font classes are used: [0]=fv (visible), [1]=fn (invisible).
    std::vector<std::array<bool, 2>> font_class_used;
    std::unordered_map<const pdf::Font *, std::uint32_t> family_index;

    const auto font_family = [&](const pdf::Font *font) {
      return intern_font(family_index, family_count, font, m_logger,
                         [&](std::uint32_t) {
                           accepted_fonts.push_back(font);
                           glyph_freq.emplace_back();
                           used_unicode.emplace_back();
                           font_class_used.push_back({false, false});
                         });
    };
    const ClipRegistry::FontFamily clip_font_family =
        [&](const pdf::Font &font) { return face_name(font_family(&font)); };

    StyleRegistry styles(StyleRegistry::Rank::plain);
    const auto add_class = [&styles](std::string &classes,
                                     const std::string &prefix,
                                     std::string declaration) {
      classes += ' ';
      classes += styles.intern(prefix, std::move(declaration));
    };

    // Build the page streams once (reused for both the pre-pass and main pass).
    std::vector<std::string> page_streams;
    page_streams.reserve(pages.size());
    for (pdf::Page *page : pages) {
      std::string stream;
      for (const auto &ref : page->contents_reference) {
        stream += parser.read_decoded_stream(ref);
        stream += '\n';
      }
      page_streams.push_back(std::move(stream));
    }

    // ---- Pre-pass: frequency analysis ------------------------------------
    // Every page is extracted twice (here and in the main pass): re-parsing an
    // already-decoded stream is cheaper than buffering every page's elements.
    for (std::size_t pi = 0; pi < pages.size(); ++pi) {
      const pdf::Page &page = *pages[pi];
      for (const pdf::PageElement &element :
           page_elements(page, page_streams[pi], m_logger)) {
        const auto *text = std::get_if<pdf::TextElement>(&element);
        if (text == nullptr || text->text.empty() || text->font == nullptr) {
          continue;
        }
        const std::uint32_t font = font_family(text->font);
        if (font == 0) {
          continue;
        }
        // Only collapsible-candidate runs vote; the leading inferred space is
        // skipped so a run carrying one still does.
        if (core_char_count(*text) != text->advances.size()) {
          continue;
        }
        auto remaining = core_text_view(*text);
        for (const std::uint32_t code : text->font->codes(text->codes)) {
          const char32_t uchar = util::string::next_utf8(remaining);
          if (!collapsible_unicode(uchar)) {
            continue;
          }
          const std::uint16_t glyph = text->font->glyph_for_code(code);
          ++glyph_freq[font - 1][uchar][glyph];
        }
      }
    }

    // The winning glyph per (font, uchar) takes the cmap entry; the map's
    // ascending glyph order makes strict `>` break ties by lower glyph id.
    for (std::uint32_t fi = 0; fi < family_count; ++fi) {
      for (const auto &[uchar, counts] : glyph_freq[fi]) {
        std::uint16_t best_glyph = 0;
        std::uint32_t best_count = 0;
        for (const auto &[glyph, count] : counts) {
          if (count > best_count ||
              (count == best_count && glyph < best_glyph)) {
            best_glyph = glyph;
            best_count = count;
          }
        }
        used_unicode[fi][uchar] = best_glyph;
      }
    }

    // ---- Main pass (pass 1): build page structures -----------------------
    std::vector<SinglePageOut> pages_out;
    pages_out.reserve(pages.size());

    for (std::size_t pi = 0; pi < pages.size(); ++pi) {
      const pdf::Page &page = *pages[pi];
      const PageBox pb = begin_page(page, add_class);
      const double width = pb.width;
      const double height = pb.height;
      const util::math::Transform2D &to_box = pb.to_box;

      // page numbers are 1-based, `data-odr-page` is the 0-based index
      const std::size_t page_index = first_page_number - 1 + pages_out.size();

      SinglePageOut &page_out = pages_out.emplace_back();
      page_out.classes = pb.classes;
      page_out.attributes = page_attributes(page_index, to_box);
      page_out.width = width;
      page_out.height = height;
      page_out.links =
          collect_page_links(page, to_box, link_resolver, page_href, config());

      ClipRegistry clips(static_cast<std::uint32_t>(pages_out.size()),
                         clip_font_family);
      GradientRegistry gradients(static_cast<std::uint32_t>(pages_out.size()));
      PatternRegistry patterns(static_cast<std::uint32_t>(pages_out.size()));
      MaskRegistry masks(static_cast<std::uint32_t>(pages_out.size()));

      std::int32_t cur_line = -1;
      std::string cur_flow_key;
      bool prev_was_matrix = false;
      double prev_end = 0;
      double prev_baseline = 0;
      double prev_font_pt = 0;
      const auto close_line = [&] { cur_line = -1; };

      for (const pdf::PageElement &element :
           page_elements(page, page_streams[pi], m_logger)) {
        if (handle_graphic_element(
                element, to_box, width, height, clips, gradients, patterns,
                masks, images, m_logger, [&] { close_line(); },
                [&](std::string frag) {
                  page_out.items.push_back(SinglePathOut{std::move(frag)});
                })) {
          continue;
        }

        const pdf::TextElement &text = std::get<pdf::TextElement>(element);
        // TODO(clip text): clip not applied to text (see pdf/AGENTS.md gaps).
        const std::uint32_t font =
            text.font != nullptr ? font_family(text.font) : 0;
        if (text.text.empty() && font == 0) {
          continue;
        }

        const auto [m, invisible, is_matrix, asc, scale, ox, baseline, extent,
                    font_pt, font_size_pt] = run_geometry(text, to_box);
        const double ascent_pt = asc * text.size;
        const double cs_pt = round2(text.char_spacing * scale);
        const double ws_pt = round2(text.word_spacing * scale);
        // Size is in the flow key below, so this is the block's.
        const double line_local = local_scale(font_size_pt);
        const std::string color_suffix = color_class(text, invisible, styles);

        SingleRunOut run;
        // `color_suffix` leads with a space for the dual-layer paths that
        // concatenate it; a single-layer run stores the bare class name.
        run.color =
            color_suffix.empty() ? std::string() : color_suffix.substr(1);

        if (font == 0 || invisible) {
          // Fallback / invisible: real unicode directly. The word break rides
          // its own span as below, else it is margined *and* advanced over.
          run.lead_space = text.leading_space_inferred;
          run.text = escape_markup(core_text(text));
        } else {
          // Collapse needs 1:1 codes-to-core-text and every (uchar, glyph) to
          // match the frequency winner. The leading inferred space is metadata,
          // not a coded char, so excluding it keeps a recovered word break from
          // forcing the whole run onto the PUA path.
          bool collapse = core_char_count(text) > 0 &&
                          core_char_count(text) == text.advances.size();
          if (collapse) {
            const std::map<char32_t, std::uint16_t> &won =
                used_unicode[font - 1];
            auto remaining = core_text_view(text);
            for (const std::uint32_t code : text.font->codes(text.codes)) {
              const char32_t uchar = util::string::next_utf8(remaining);
              const std::uint16_t glyph = text.font->glyph_for_code(code);
              const auto it = won.find(uchar);
              if (!collapsible_unicode(uchar) || it == won.end() ||
                  it->second != glyph) {
                collapse = false;
                break;
              }
            }
          }
          if (collapse) {
            // A leading inferred space becomes its own span, never a literal
            // space in `text`, so `white-space:pre` cannot shift the glyphs off
            // their placement origin. Over a positive gap that span carries the
            // gap as its width (pdf2htmlEX's model: one real space that is both
            // the copyable character and the advance), else it is zero-width.
            run.lead_space = text.leading_space_inferred;
            run.text = escape_markup(core_text(text));
          } else {
            run.glyph_data = glyph_run_str(*text.font, text.codes);
            run.text = escape_markup(text.text); // overlay (empty=no_unicode)
          }
        }
        if (run.text.empty() && run.glyph_data.empty()) {
          continue; // invisible no_unicode
        }

        // ---- Flow grouping -----------------------------------------------
        // The substitute family is part of the flow key, so a Helvetica run and
        // a Times run never share one line block's `font_class`.
        const std::string substitute_declaration =
            (font == 0 && !invisible && text.font != nullptr &&
             text.font->substitute.has_value())
                ? substitute_faces.declaration(*text.font->substitute, asc)
                : std::string();
        std::ostringstream fk;
        fk << font << '|' << invisible << '|' << font_size_pt << '|' << cs_pt
           << '|' << ws_pt << '|' << substitute_declaration;
        const std::string flow_key = std::move(fk).str();
        bool new_line = is_matrix || prev_was_matrix || cur_line < 0 ||
                        flow_key != cur_flow_key;
        double margin_pt = 0;
        if (!new_line && prev_font_pt > 0) {
          if (starts_new_line(baseline, prev_baseline, ox, prev_end,
                              prev_font_pt)) {
            new_line = true;
          } else {
            margin_pt = round2((ox - prev_end) * line_local);
          }
        }

        if (new_line) {
          std::string base = "t";
          add_position_classes(base, add_class, m, is_matrix, line_local, ox,
                               baseline, ascent_pt);
          add_class(base, "f",
                    pt_decl("font-size", round2(font_size_pt * line_local)));
          const bool spacing_one_to_one =
              font != 0 ||
              (text.font != nullptr &&
               util::string::utf8_length(text.text) == text.advances.size());
          if (text.char_spacing != 0 && spacing_one_to_one) {
            add_class(base, "s",
                      pt_decl("letter-spacing", round2(cs_pt * line_local)));
          }
          if (text.word_spacing != 0 && spacing_one_to_one &&
              !(text.font != nullptr && text.font->composite)) {
            // `ws` = word-spacing everywhere (`w` is width in the dual layer).
            add_class(base, "ws",
                      pt_decl("word-spacing", round2(ws_pt * line_local)));
          }
          // Invisible (Tr 3/7) and Type3 (painted by char procs) runs stay in
          // the DOM for selection but render transparent.
          if (font == 0 && (invisible || text.render_as_graphics)) {
            base += " i";
          }

          SingleLineOut line;
          line.classes = std::move(base);
          if (font != 0) {
            line.font_class = font_class(font_class_used, font, invisible);
          } else if (!substitute_declaration.empty()) {
            line.font_class = styles.intern("ff", substitute_declaration);
          }
          line.runs.push_back(std::move(run));
          page_out.items.push_back(std::move(line));
          cur_line = static_cast<int>(page_out.items.size()) - 1;
          cur_flow_key = flow_key;
        } else {
          if (run.lead_space && margin_pt > 0) {
            // Recovered word break over a positive gap: fold the advance into
            // the space span rather than a `margin-left` on the run.
            run.lead_space_width =
                styles.intern("w", pt_decl("width", margin_pt));
          } else if (margin_pt != 0) {
            run.margin = styles.intern("ml", pt_decl("margin-left", margin_pt));
          }
          std::get<SingleLineOut>(page_out.items[cur_line])
              .runs.push_back(std::move(run));
        }

        prev_end = ox + extent;
        prev_baseline = baseline;
        prev_font_pt = font_pt;
        prev_was_matrix = is_matrix;
      }

      page_out.clip_defs =
          clips.defs() + gradients.defs() + patterns.defs() + masks.defs();
    }

    // ---- Post-pass: re-encode fonts with frequency-winner cmap entries ---
    for (std::uint32_t i = 0; i < family_count; ++i) {
      write_font_face(*accepted_fonts[i], i, used_unicode[i],
                      font_class_used[i], font_faces, font_styles);
    }
    substitute_faces.append_faces(font_faces);

    // ---- Pass 2: write HTML ---------------------------------------------
    write_header_common(state, font_faces, font_styles, styles, pages_out, [&] {
      // Invisible text render modes (Tr 3/7).
      out.out() << ".i{color:transparent}";
      // Unclean glyphs via generated content, out of the DOM text stream.
      out.out() << ".gl::before{content:attr(data-g)}";
      // The real Unicode of an unclean run: invisible and zero-width, but still
      // found and selected in reading order. `inline-block` is what lets
      // `width:0` apply at all.
      out.out() << ".ov{display:inline-block;width:0;overflow:hidden;"
                   "color:transparent;vertical-align:baseline}";
      // Width-bearing selectable space for a recovered word break: a real `" "`
      // sized to the gap by a `wN` class, copyable *and* carrying the advance.
      // Deliberately no `overflow:hidden`: it would move the inline-block's
      // baseline to its bottom margin edge and highlight the space at the wrong
      // height, while clipping nothing (the space is transparent).
      out.out() << ".sp{display:inline-block;"
                   "color:transparent;vertical-align:baseline}";
      // As `.i` in the dual layer above, with `*` reaching a run's own span
      // and a search `mark`.
      out.out()
          << ".i::selection,.i *::selection,"
             ".ov::selection,.ov *::selection,"
             ".sp::selection,.sp *::selection"
             "{color:transparent;background-color:rgba(70,130,220,.32);"
             "background-color:color-mix(in srgb,Highlight 45%,transparent)}";
      // A hit in the overlay is clipped away with it, so the glyphs it belongs
      // to carry the highlight instead - the whole run of them, which is as
      // narrow as the overlay can say.
      out.out() << ".gl:has(+.ov mark){background:#ff0;"
                   "mix-blend-mode:multiply}";
      out.out() << ".gl:has(+.ov mark.current){background:orange}";
    });

    // A run's span class: `head` plus its optional margin-left and colour.
    const auto run_class = [](const SingleRunOut &run, const char *head) {
      std::string cls = head;
      const auto add = [&](const std::string &t) {
        if (t.empty()) {
          return;
        }
        if (!cls.empty()) {
          cls += ' ';
        }
        cls += t;
      };
      add(run.margin);
      add(run.color);
      return cls;
    };

    const auto write_line = [&](const SingleLineOut &line) {
      std::string classes = line.classes;
      if (!line.font_class.empty()) {
        classes += ' ';
        classes += line.font_class;
      }
      out.write_element_begin(
          "div", HtmlElementOptions().set_inline(true).set_class(classes));
      for (const SingleRunOut &run : line.runs) {
        if (run.glyph_data.empty()) {
          // Clean / invisible / fallback: real Unicode renders directly.
          if (run.lead_space) {
            // With a `wN` width the space carries the gap; without one it is a
            // zero-width `.ov` (line-leading or negative gap) that cannot shift
            // the glyphs under `white-space:pre`.
            const std::string space_cls = run.lead_space_width.empty()
                                              ? std::string("ov")
                                              : "sp " + run.lead_space_width;
            out.write_element_begin(
                "span",
                HtmlElementOptions().set_inline(true).set_class(space_cls));
            out.write_raw(" ");
            out.write_element_end("span");
          }
          const std::string cls = run_class(run, "");
          if (cls.empty()) {
            out.write_raw(run.text);
          } else {
            out.write_element_begin(
                "span", HtmlElementOptions().set_inline(true).set_class(cls));
            out.write_raw(run.text);
            out.write_element_end("span");
          }
        } else {
          // Unclean: glyph via generated content, real-unicode overlay.
          out.write_element_begin(
              "span", HtmlElementOptions()
                          .set_inline(true)
                          .set_class(run_class(run, "gl"))
                          .set_attributes(HtmlAttributesVector{
                              {std::string("data-g"), run.glyph_data}}));
          out.write_element_end("span");
          if (!run.text.empty()) {
            out.write_element_begin(
                "span", HtmlElementOptions().set_inline(true).set_class("ov"));
            out.write_raw(run.text);
            out.write_element_end("span");
          }
        }
      }
      out.write_element_end("div");
    };

    write_pdf_body_begin(out, config());
    out.write_element_begin("div", HtmlElementOptions().set_class("d"));
    std::size_t page_number = first_page_number;
    for (const SinglePageOut &page : pages_out) {
      // the first page is near the viewport before the script says so
      std::string classes =
          page.classes +
          chunk_classes(config(), page_number == first_page_number);
      out.write_element_begin(
          "div", HtmlElementOptions()
                     .set_class(std::move(classes))
                     .set_extra(R"(id="p)" + std::to_string(page_number++) +
                                R"(")" + page.attributes));
      write_page_items(out, page.clip_defs, page.items, page.width, page.height,
                       write_line);
      write_page_links(out, page.links);
      out.write_element_end("div"); // .p
    }
    out.write_element_end("div"); // .d
    write_search_script(state);
    write_viewport_script(state);
    write_pdf_annotation_script(state);
    write_host_bridge_script(state);
    out.write_body_end();
    out.write_end();

    return resources;
  }

  static std::string pt_decl(const char *property, double value) {
    std::ostringstream s;
    s << property << ':' << value << "pt";
    return std::move(s).str();
  }

  /// Whether a run at (`ox`, `baseline`) starts a new visual line: its baseline
  /// jumped by more than 0.6× the previous run's advance height, or its origin
  /// sits left of that run's right edge — a carriage return. Shared by all
  /// three layers so the heuristic cannot drift between them; callers gate on
  /// `prev_font_pt > 0`.
  static bool starts_new_line(const double baseline, const double prev_baseline,
                              const double ox, const double prev_end,
                              const double prev_font_pt) {
    return std::abs(baseline - prev_baseline) > 0.6 * prev_font_pt ||
           ox < prev_end - 0.5 * prev_font_pt;
  }

  /// Whether two runs share a linear part, so one line block's CSS matrix
  /// places both.
  static bool same_linear(const util::math::Transform2D &l,
                          const util::math::Transform2D &r) {
    return l.a == r.a && l.b == r.b && l.c == r.c && l.d == r.d;
  }

  /// `m`'s origin along `block`'s own axes, x along the writing line. Empty
  /// for a singular linear part, which spans no frame.
  static std::optional<std::array<double, 2>>
  local_origin(const util::math::Transform2D &block,
               const util::math::Transform2D &m) {
    const double det = block.a * block.d - block.b * block.c;
    if (det == 0) {
      return std::nullopt;
    }
    const double dx = m.e - block.e;
    const double dy = m.f - block.f;
    return std::array<double, 2>{(dx * block.d - dy * block.c) / det,
                                 (-dx * block.b + dy * block.a) / det};
  }

  /// Per-run geometry from a `TextElement` and the page's `to_box`. Identical
  /// in every text mode, and kept in one place so no call site can drift.
  struct RunGeometry {
    util::math::Transform2D m; ///< glyph space -> page box (y-down, pt later)
    bool invisible;            ///< Tr 3/7 — paints nothing, selectable only
    bool is_matrix;            ///< rotated/skewed/flipped -> CSS matrix path
    double asc;                ///< ascent in em (clamped)
    double scale;              ///< uniform axis scale (1 on the matrix path)
    double ox;                 ///< origin x (baseline left) in pt
    double baseline;           ///< origin y (baseline) in pt
    double extent;             ///< advance width in pt
    double font_pt;            ///< font size along the advance axis in pt
    double font_size_pt;       ///< the CSS font-size the run asks for, in pt
  };

  /// 24px, the largest minimum font size a chrome user can set; an android
  /// webview defaults to 8px.
  static constexpr double text_floor_pt = 18;

  /// How much larger a block holding `font_size_pt` lays out to clear a
  /// browser's minimum font size; the block scales it back out. The clamp reads
  /// the specified size, so zoom does not move the floor.
  static double local_scale(const double font_size_pt) {
    return font_size_pt > 0 && font_size_pt < text_floor_pt
               ? text_floor_pt / font_size_pt
               : 1.0;
  }

  static RunGeometry run_geometry(const pdf::TextElement &text,
                                  const util::math::Transform2D &to_box) {
    constexpr util::math::Transform2D flip_glyph =
        util::math::Transform2D::scaling(1, -1);
    const util::math::Transform2D m = flip_glyph * text.transform * to_box;
    const bool invisible =
        text.rendering_mode == pdf::TextRenderingMode::invisible ||
        text.rendering_mode == pdf::TextRenderingMode::clip;
    // `m.a > 0` keeps a pure 180° rotation (a = d = -1) off the axis-aligned
    // fast path, where it would feed a negative `m.a` into the placement math.
    const bool is_matrix = !(m.b == 0 && m.c == 0 && m.a == m.d && m.a > 0);
    const double tz = text.horizontal_scaling / 100.0;
    const double axis = tz != 0 ? std::hypot(m.a, m.b) / tz : 0;
    const double scale = is_matrix ? 1.0 : m.a;
    return RunGeometry{
        .m = m,
        .invisible = invisible,
        .is_matrix = is_matrix,
        .asc = ascent_em(text.font),
        .scale = scale,
        .ox = m.e,
        .baseline = m.f,
        .extent = text.width * axis,
        .font_pt = text.size * axis,
        .font_size_pt = round2(text.size * scale),
    };
  }

  /// The colour class suffix (with a leading space) for a run's paint colour,
  /// or "" for black / invisible.
  static std::string color_class(const pdf::TextElement &text,
                                 const bool invisible, StyleRegistry &styles) {
    if (invisible) {
      return {};
    }
    const bool stroked =
        text.rendering_mode == pdf::TextRenderingMode::stroke ||
        text.rendering_mode == pdf::TextRenderingMode::stroke_clip;
    const bool fill_and_stroke =
        text.rendering_mode == pdf::TextRenderingMode::fill_stroke ||
        text.rendering_mode == pdf::TextRenderingMode::fill_stroke_clip;
    const pdf::GraphicsState::Color &paint =
        stroked ? text.stroke_color : text.fill_color;
    // The span carries one opacity, so a fill-and-stroke glyph takes the more
    // opaque of the two: a transparent fill must not drop an opaque outline.
    const double alpha = stroked ? text.stroke_alpha
                         : fill_and_stroke
                             ? std::max(text.fill_alpha, text.stroke_alpha)
                             : text.fill_alpha;
    const std::string blend = blend_mode_to_css(text.blend_mode);
    std::string css = device_color_to_css(paint);
    // Fast path: default black, fully opaque, no blend — no class needed.
    if (css == "rgb(0,0,0)" && alpha >= 1 && blend.empty()) {
      return {};
    }
    std::ostringstream declaration;
    declaration << "color:" << css;
    if (alpha < 1) {
      declaration << ";opacity:" << round2(alpha);
    }
    if (!blend.empty()) {
      declaration << ";mix-blend-mode:" << blend;
    }
    return ' ' + styles.intern("k", std::move(declaration).str());
  }

  /// The page-box geometry shared by both modes' page setup; `add_class`
  /// interns the width/height declarations.
  struct PageBox {
    double width;
    double height;
    util::math::Transform2D to_box;
    std::string classes;
  };

  template <typename AddClass>
  static PageBox begin_page(const pdf::Page &page, AddClass &&add_class) {
    // The crop box is what a viewer shows (14.11.2); it falls back to the media
    // box. Its corners may be given in either order (7.9.5).
    const pdf::Array &page_box = page.crop_box.as_array();
    const double box_x0 =
        std::min(page_box[0].as_real(), page_box[2].as_real());
    const double box_y0 =
        std::min(page_box[1].as_real(), page_box[3].as_real());
    const double box_width =
        std::max(page_box[0].as_real(), page_box[2].as_real()) - box_x0;
    const double box_height =
        std::max(page_box[1].as_real(), page_box[3].as_real()) - box_y0;

    // `/Rotate` turns the page clockwise as displayed (7.7.3.3), so a quarter
    // turn swaps what the reader sees as its width and height.
    const bool quarter_turn = page.rotate == 90 || page.rotate == 270;
    const double width = quarter_turn ? box_height : box_width;
    const double height = quarter_turn ? box_width : box_height;

    std::string classes = "p";
    {
      std::ostringstream w;
      w << "width:" << width * pt_to_in << "in";
      add_class(classes, "x", std::move(w).str());
      std::ostringstream h;
      h << "height:" << height * pt_to_in << "in";
      add_class(classes, "y", std::move(h).str());
      add_class(classes, "q", "page:" + print_page_name(width, height));
    }

    // Onto the displayed box: 90° sends the top-left corner to the top-right,
    // 270° to the bottom-left.
    const util::math::Transform2D rotation = [&]() -> util::math::Transform2D {
      switch (page.rotate) {
      case 90:
        return {0, 1, -1, 0, box_height, 0};
      case 180:
        return {-1, 0, 0, -1, box_width, box_height};
      case 270:
        return {0, -1, 1, 0, 0, box_width};
      default:
        return {};
      }
    }();

    const util::math::Transform2D to_box =
        util::math::Transform2D::translation(-box_x0, -box_y0) *
        util::math::Transform2D::scaling_translation(1, -1, 0, box_height) *
        rotation;

    return {width, height, to_box, std::move(classes)};
  }

  /// The 1-based font family index for `font`, or 0 when it is unusable. Runs
  /// `on_accept(index)` on first acceptance so the caller can grow its parallel
  /// per-font arrays.
  template <typename OnAccept>
  static std::uint32_t intern_font(
      std::unordered_map<const pdf::Font *, std::uint32_t> &family_index,
      std::uint32_t &family_count, const pdf::Font *font, const Logger &logger,
      OnAccept &&on_accept) {
    const auto [it, inserted] = family_index.try_emplace(font, 0);
    if (!inserted) {
      return it->second;
    }
    if (!font_is_usable(*font, logger)) {
      return 0;
    }
    const std::uint32_t index = ++family_count;
    it->second = index;
    on_accept(index);
    return index;
  }

  /// A page's `<defs>` and its paint-order body: an SVG open/close dance around
  /// the item list, identical in both modes bar the line and path types.
  template <typename LineT, typename PathT, typename WriteLine>
  static void
  write_page_items(HtmlWriter &out, const std::string &clip_defs,
                   const std::vector<std::variant<LineT, PathT>> &items,
                   const double width, const double height,
                   WriteLine &&write_line) {
    if (!clip_defs.empty()) {
      out.write_raw("<svg width=\"0\" height=\"0\" style=\"position:absolute\">"
                    "<defs>");
      out.write_raw(clip_defs);
      out.write_raw("</defs></svg>");
    }
    bool svg_open = false;
    const auto close_svg = [&] {
      if (svg_open) {
        out.write_raw("</svg>");
        svg_open = false;
      }
    };
    for (const std::variant<LineT, PathT> &item : items) {
      if (const auto *path = std::get_if<PathT>(&item)) {
        if (!svg_open) {
          std::ostringstream open;
          open << "<svg class=\"s\" viewBox=\"0 0 " << round2(width) << ' '
               << round2(height) << "\" preserveAspectRatio=\"none\">";
          out.write_raw(std::move(open).str());
          svg_open = true;
        }
        out.write_raw(path->svg);
      } else {
        close_svg();
        write_line(std::get<LineT>(item));
      }
    }
    close_svg();
  }

  /// The widest page a view holds, in css pixels, with `.d`'s side gutters.
  template <typename PageOut>
  static std::optional<double> content_pixels(const std::vector<PageOut> &pages,
                                              const HtmlConfig &config) {
    double widest = 0;
    for (const PageOut &page : pages) {
      widest = std::max(widest, page.width);
    }
    if (widest <= 0) {
      return {};
    }
    return widest * pt_to_in * 96.0 + page_column_gutter_pixels(config);
  }

  /// The named `@page` a page box prints on, one per distinct size.
  static std::string print_page_name(const double width, const double height) {
    return "odr-" + std::to_string(std::lround(width * 100)) + "x" +
           std::to_string(std::lround(height * 100));
  }

  /// The document/head prologue shared by both modes, with `write_mode_css()`
  /// slotted between the constant rules. Leaves the writer after `</head>`.
  template <typename PageOut, typename WriteModeCss>
  void write_header_common(const WritingState &state,
                           const std::string &font_faces,
                           const std::string &font_styles,
                           const StyleRegistry &styles,
                           const std::vector<PageOut> &pages,
                           WriteModeCss &&write_mode_css) const {
    HtmlWriter &out = state.out();
    const std::optional<double> content = content_pixels(pages, config());

    out.write_begin();
    out.write_header_begin();
    out.write_header_charset("UTF-8");
    out.write_header_title("odr");
    write_viewport_meta(out, config(), true, {}, content);
    write_zoom_style(out, config(), width_fit(config(), true), content);
    write_content_margin_style(out, config());
    out.write_header_style_begin();
    out.out() << "body{margin:0;background:#525659}";
    // `.d`: the page column, sized to the widest page so pages of differing
    // width centre against each other rather than against the viewport. Their
    // side margin is part of that width, so a phone screen keeps a gutter.
    out.out() << ".d{display:flex;flex-direction:column;align-items:center;"
                 "gap:16px;padding:max(16px,var(--odr-min-margin-top,0px)) 0 "
                 "max(16px,var(--odr-min-margin-bottom,0px));"
                 "width:max-content;min-width:100%}";
    // `overflow:hidden` clips to the crop box, as a viewer does: content may
    // sit outside it (a bleed, or an InDesign spread's other page).
    // A page is a chunk (`write_chunk_style`). The box states its own size,
    // so a page that is not laid out needs no `contain-intrinsic-size`.
    out.out() << ".p{position:relative;"
                 "margin:0 max(16px,var(--odr-min-margin-right,0px)) 0 "
                 "max(16px,var(--odr-min-margin-left,0px));background:#fff;"
                 "overflow:hidden;box-shadow:0 1px 4px rgba(0,0,0,.5)}";
    // One page to a sheet.
    out.out() << "@media print{body{background:none}"
                 ".d{display:block;padding:0;width:auto;min-width:0}"
                 ".p{margin:0;box-shadow:none;"
                 "break-after:page}.p:last-child{break-after:auto}}"
                 "@page{margin:0}";
    std::set<std::string> print_pages;
    for (const PageOut &page : pages) {
      if (std::string name = print_page_name(page.width, page.height);
          print_pages.insert(name).second) {
        out.out() << "@page " << name << "{size:" << page.width * pt_to_in
                  << "in " << page.height * pt_to_in << "in}";
      }
    }
    // `.t`: shared base for all absolutely-positioned line blocks.
    // `font-size:0` collapses its strut, which outranks the run it holds and
    // would take the line box's baseline.
    out.out() << ".t{position:absolute;left:0;top:0;transform-origin:0 0;"
                 "white-space:pre;line-height:1;font-size:0;font-kerning:none;"
                 "font-variant-ligatures:none}";
    write_mode_css();
    // SVG overlay covering the page box (visual graphics layer).
    out.out() << ".s{position:absolute;left:0;top:0;width:100%;height:100%;"
                 "overflow:hidden;pointer-events:none}";
    // Link annotation overlays (absolutely positioned in page-box points).
    out.out() << ".lk{position:absolute;transform-origin:0 0}";
    // A search hit marks the text layer over the page: the browser's own `mark`
    // colour would paint invisible text, an opaque highlight hide the glyphs.
    out.out() << "mark{color:inherit;mix-blend-mode:multiply}";
    out.out() << font_faces;
    out.out() << font_styles;
    styles.write_rules(out.out());
    out.write_header_style_end();
    write_chunk_style(state);
    write_search_style(state);
    write_pdf_annotation_style(state);
    write_permissions(out);
    out.write_header_end();
  }

  /// pdf.js `enablePermissions`: the text stays selectable, but a copy puts
  /// nothing on the clipboard, and a print shows nothing.
  void write_permissions(HtmlWriter &out) const {
    if (!config().pdf_enforce_permissions || !m_pdf_file.has_permissions()) {
      return;
    }
    const PdfPermissions permissions = m_pdf_file.permissions();
    if (!permissions.print && !permissions.print_high_quality) {
      out.write_header_style_begin();
      out.out() << "@media print{body{display:none!important}}";
      out.write_header_style_end();
    }
    if (!permissions.copy) {
      out.write_script_begin();
      out.out() << R"(document.addEventListener("copy",function(e){)"
                   R"(e.preventDefault();e.stopPropagation()},true);)";
      out.write_script_end();
    }
  }

  /// Appends a line block's placement classes: `l`/`t` plus `z` taking `local`
  /// back out for an axis-aligned run, `m` carrying it for a rotated one.
  /// `ox`/`baseline`/`ascent_pt` are page space: `local` grows what the box
  /// holds, not where it sits.
  template <typename AddClass>
  static void add_position_classes(std::string &classes, AddClass &&add_class,
                                   const util::math::Transform2D &m,
                                   const bool is_matrix, const double local,
                                   const double ox, const double baseline,
                                   const double ascent_pt) {
    if (!is_matrix) {
      add_class(classes, "l", pt_decl("left", round2(ox)));
      add_class(classes, "t",
                pt_decl("top", round2(baseline - ascent_pt * m.a)));
      if (local != 1) {
        std::ostringstream z;
        z << "transform:scale(" << 1 / local << ')';
        add_class(classes, "z", std::move(z).str());
      }
      return;
    }
    // A CSS `matrix()` translation is intrinsically px; `translate()` takes pt
    // and applies outside it, so the whole text layer stays in pt.
    const double tx = m.e - m.c * ascent_pt;
    const double ty = m.f - m.d * ascent_pt;
    std::ostringstream t;
    t << "transform:translate(" << round2(tx) << "pt," << round2(ty)
      << "pt) matrix(" << m.a / local << ',' << m.b / local << ','
      << m.c / local << ',' << m.d / local << ",0,0)";
    add_class(classes, "m", std::move(t).str());
  }

  /// Serializes `sfnt` re-encoded to the PUA, restoring the cmap
  /// `reencode_to_pua` overwrites — the `SfntFont` is shared by every page, and
  /// a left-behind PUA cmap makes the next `glyph_for_code` miss.
  static std::string
  write_sfnt_pua(font::sfnt::SfntFont &sfnt,
                 const std::map<char32_t, std::uint16_t> &extra_unicode) {
    std::map<char32_t, std::uint16_t> original_cmap = sfnt.cmap();
    try {
      font::reencode_to_pua(sfnt, extra_unicode);
      std::string reencoded = sfnt.write();
      sfnt.set_cmap(std::move(original_cmap));
      return reencoded;
    } catch (...) {
      sfnt.set_cmap(std::move(original_cmap));
      throw;
    }
  }

  /// Whether `font`'s embedded program re-encodes without throwing. Probes the
  /// real encode path so failures surface here, not in the post-pass. Failing
  /// swaps in a substitute, which the page shows, so say so.
  static bool font_is_usable(const pdf::Font &font, const Logger &logger) {
    const auto dropped = [&](const std::string &why) {
      ODR_WARNING(logger, "pdf: rendering '"
                              << font.embedded_font->name()
                              << "' with a substitute, its embedded program "
                                 "does not re-encode: "
                              << why);
      return false;
    };
    if (const auto sfnt = std::dynamic_pointer_cast<font::sfnt::SfntFont>(
            font.embedded_font)) {
      try {
        (void)write_sfnt_pua(*sfnt, {});
        return true;
      } catch (const std::exception &e) {
        return dropped(e.what());
      } catch (...) {
        return dropped("sfnt re-encode failed");
      }
    }
    if (const auto cff =
            std::dynamic_pointer_cast<font::cff::CffFont>(font.embedded_font)) {
      try {
        (void)font::cff::wrap_to_otf(*cff);
        return true;
      } catch (const std::exception &e) {
        return dropped(e.what());
      } catch (...) {
        return dropped("cff wrap failed");
      }
    }
    return false;
  }

  /// The `fvN`/`fnN` class for `font` (visible/invisible), marking it used in
  /// `font_class_used` so the post-pass emits the corresponding rule.
  static std::string
  font_class(std::vector<std::array<bool, 2>> &font_class_used,
             const std::uint32_t font, const bool inv) {
    font_class_used[font - 1][inv ? 1 : 0] = true;
    return (inv ? "fn" : "fv") + std::to_string(font);
  }

  /// The `@font-face` family of the 1-based font `index`, "" for 0.
  static std::string face_name(const std::uint32_t index) {
    return index == 0 ? std::string() : "odr-f" + std::to_string(index);
  }

  /// `font`'s embedded program re-encoded, with `extra_unicode`'s cmap
  /// entries folded in alongside the PUA range.
  static std::string
  reencoded_font(const pdf::Font &font,
                 std::map<char32_t, std::uint16_t> extra_unicode) {
    if (const std::uint16_t space = space_glyph(font); space != 0) {
      extra_unicode.emplace(U' ', space);
    }
    if (const auto sfnt = std::dynamic_pointer_cast<font::sfnt::SfntFont>(
            font.embedded_font)) {
      return write_sfnt_pua(*sfnt, extra_unicode);
    }
    if (const auto cff =
            std::dynamic_pointer_cast<font::cff::CffFont>(font.embedded_font)) {
      return font::cff::wrap_to_otf(*cff, extra_unicode);
    }
    return {};
  }

  /// Appends `font`'s `@font-face` plus the `.fvN`/`.fnN` rules `class_used`
  /// says are needed. The face reads its program from @p file where that is
  /// given, and carries it inline else.
  static void write_font_face(const pdf::Font &font, const std::uint32_t index,
                              std::map<char32_t, std::uint16_t> extra_unicode,
                              const std::array<bool, 2> &class_used,
                              std::string &font_faces, std::string &font_styles,
                              const std::optional<std::string> &file = {}) {
    const std::string url =
        file.has_value()
            ? *file
            : file_to_url(reencoded_font(font, std::move(extra_unicode)),
                          "font/ttf");
    const std::string n = std::to_string(index + 1);
    // The overrides sum to one em, so `line-height:1` puts the baseline at
    // exactly the `ascent_em` a run's `top` is derived from.
    const double ascent = ascent_em(&font);
    std::ostringstream face;
    face << "@font-face{font-family:'odr-f" << n << "';src:url(" << url
         << ");ascent-override:" << round2(ascent * 100.0)
         << "%;descent-override:" << round2((1.0 - ascent) * 100.0)
         << "%;line-gap-override:0%}";
    font_faces += std::move(face).str();
    const auto rule = [&](const char *cls, const char *color) {
      font_styles += '.';
      font_styles += cls;
      font_styles += n;
      font_styles += '{';
      font_styles += color;
      font_styles += "font-family:'odr-f";
      font_styles += n;
      font_styles += "'}";
    };
    if (class_used[0]) {
      rule("fv", "color:#000;");
    }
    if (class_used[1]) {
      rule("fn", "color:transparent;");
      // The same guard for a line the embedded font makes invisible; the dual
      // layer's `fnN` rides a `user-select:none` run and needs none.
      font_styles +=
          ".fn" + n + "::selection,.fn" + n +
          " *::selection"
          "{color:transparent;background-color:rgba(70,130,220,.32);"
          "background-color:color-mix(in srgb,Highlight 45%,transparent)}";
    }
  }

  /// Baseline offset below a line block's `top`, in em. Capped at one em so
  /// the `@font-face` descent can make the two sum to it.
  static double ascent_em(const pdf::Font *font) {
    double em = 0.8;
    if (font != nullptr && font->descriptor_ascent.has_value()) {
      em = *font->descriptor_ascent;
    } else if (font != nullptr && font->embedded_font != nullptr) {
      const std::uint16_t units = font->embedded_font->units_per_em();
      if (units != 0) {
        em = static_cast<double>(font->embedded_font->bounding_box().y_max) /
             units;
      }
    }
    return std::clamp(em, 0.5, 1.0);
  }

  /// The glyph a simple font paints for byte 32, 0 when it has none. That byte
  /// keeps a real U+0020 for CSS `word-spacing` to move, and `write_font_face`
  /// maps U+0020 onto this glyph so the painted shape is unchanged.
  static std::uint16_t space_glyph(const pdf::Font &font) {
    if (font.composite || font.embedded_font == nullptr) {
      return 0;
    }
    const std::uint16_t glyph = font.glyph_for_code(' ');
    return glyph < font.embedded_font->glyph_count() ? glyph : 0;
  }

  static std::string glyph_run_str(const pdf::Font &font,
                                   const std::string &codes) {
    const std::uint16_t space = space_glyph(font);
    std::string s;
    for (const std::uint32_t code : font.codes(codes)) {
      if (code == ' ' && space != 0) {
        s += ' ';
        continue;
      }
      util::string::append_c32(font::pua_code_point(font.glyph_for_code(code)),
                               s);
    }
    return s;
  }

  /// `text.text` past an inferred leading space, which backs no advance.
  static std::string_view core_text_view(const pdf::TextElement &text) {
    return std::string_view(text.text).substr(text.leading_space_inferred ? 1
                                                                          : 0);
  }

  static std::string core_text(const pdf::TextElement &text) {
    return std::string(core_text_view(text));
  }

  /// Escapes only the three markup-significant characters. Deliberately *not*
  /// `html::escape_text`: its `&nbsp;` substitution is a distinct character
  /// from U+0020 and breaks the find and word selection these layers exist for.
  static std::string escape_markup(std::string s) {
    util::string::replace_all(s, "&", "&amp;");
    util::string::replace_all(s, "<", "&lt;");
    util::string::replace_all(s, ">", "&gt;");
    return s;
  }

  /// Handles the non-text elements common to both modes, calling `close_line`
  /// and `push_svg` for a non-empty fragment. Returns false for a text element.
  template <typename CloseLine, typename PushSvg>
  static bool handle_graphic_element(
      const pdf::PageElement &element, const util::math::Transform2D &to_box,
      double width, double height, ClipRegistry &clips,
      GradientRegistry &gradients, PatternRegistry &patterns,
      MaskRegistry &masks, ImageRegistry &images, const Logger &logger,
      CloseLine &&close_line, PushSvg &&push_svg) {
    // Text is handled by the caller; every other element kind is a graphic.
    if (std::holds_alternative<pdf::TextElement>(element)) {
      return false;
    }
    std::string frag =
        render_graphic_fragment(element, to_box, width, height, clips,
                                gradients, patterns, masks, images, logger);
    if (!frag.empty()) {
      close_line();
      push_svg(std::move(frag));
    }
    return true;
  }

protected:
  PdfFile m_pdf_file;
  /// The search css and js every view links; empty of locations when the config
  /// embeds them.
  mutable HtmlResources m_resources;
  /// Guards `m_resources`, apart from `m_mutex`: a resource is looked up while
  /// a render holds that one, and a page script takes it to render.
  mutable std::mutex m_resources_mutex;

  // Lazily initialized by `warmup()` (all guarded by `m_mutex`): one parse
  // shared by the combined-document and per-page renders.
  mutable std::mutex m_mutex;
  mutable std::unique_ptr<pdf::DocumentParser> m_parser;
  mutable std::unique_ptr<pdf::Document> m_document;
  mutable std::unique_ptr<LinkResolver> m_link_resolver;
  /// The rendered pages (`[page_range_begin, page_range_end)`) and the 0-based
  /// document-global index of the first one.
  mutable std::vector<pdf::Page *> m_pages;
  mutable std::size_t m_first_page{0};
  mutable HtmlViews m_views;
  /// What pages rendered apart share: the number of each font, and the fonts
  /// that have a file of their own.
  mutable std::unordered_map<const pdf::Font *, std::uint32_t> m_font_ids;
  mutable std::unordered_set<const pdf::Font *> m_font_files;
  mutable std::unordered_map<const pdf::Font *, bool> m_font_usable;
  mutable std::optional<std::vector<const pdf::Font *>> m_document_fonts;
  /// The text of each page a search index has asked for.
  mutable std::vector<std::optional<std::string>> m_page_texts;
};

void PageScriptResource::write_resource(std::ostream &os) const {
  m_service->write_page_script(m_number, os);
}

void PageIndexResource::write_resource(std::ostream &os) const {
  m_service->write_index_script(m_group, os);
}

void FontFileResource::write_resource(std::ostream &os) const {
  m_service->write_font_file(*m_font, os);
}

} // namespace

} // namespace odr::internal::html

namespace odr::internal {

HtmlService html::create_pdf_service(const PdfFile &pdf_file, HtmlConfig config,
                                     const Logger &logger) {
  return odr::HtmlService(
      std::make_unique<HtmlServiceImpl>(pdf_file, std::move(config), logger));
}

} // namespace odr::internal
