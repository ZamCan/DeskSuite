#pragma once

#include <odr/file.hpp>

#include <odr/internal/text/text_file.hpp>

#include <memory>

namespace odr::internal::json {

class JsonFile final : public abstract::TextFile {
public:
  explicit JsonFile(std::shared_ptr<text::TextFile> file);

  [[nodiscard]] std::shared_ptr<abstract::File> file() const noexcept override;

  [[nodiscard]] FileType file_type() const noexcept override;
  [[nodiscard]] std::string_view mimetype() const noexcept override;
  [[nodiscard]] FileMeta file_meta() const override;

  [[nodiscard]] bool is_decodable() const noexcept override;

  [[nodiscard]] TextEncoding encoding() const noexcept override;

private:
  std::shared_ptr<text::TextFile> m_file;
};

} // namespace odr::internal::json
