# Legacy MS implementation

## References

- [Technical Documents](https://docs.microsoft.com/en-us/openspecs/office_file_formats/MS-OFFFFLP/6ae2fd93-51fc-4e75-a54a-1b175c627b51)
- [[MS-DOC]: Word (.doc) Binary File Format](https://docs.microsoft.com/en-us/openspecs/office_file_formats/ms-doc)
- [[MS-PPT]: PowerPoint (.ppt) Binary File Format](https://docs.microsoft.com/en-us/openspecs/office_file_formats/ms-ppt)
- [[MS-XLS]: Excel Binary File Format (.xls) Structure](https://docs.microsoft.com/en-us/openspecs/office_file_formats/ms-xls)
- [[MS-ODRAW]: Office Drawing Binary File Format](https://learn.microsoft.com/en-us/openspecs/office_file_formats/ms-odraw)
- [[MS-CFB]: Compound File Binary File Format](https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-cfb)
- [[MS-OFFCRYPTO]: Office Document Cryptography Structure](https://learn.microsoft.com/en-us/openspecs/office_file_formats/ms-offcrypto)
- https://github.com/microsoft/compoundfilereader
