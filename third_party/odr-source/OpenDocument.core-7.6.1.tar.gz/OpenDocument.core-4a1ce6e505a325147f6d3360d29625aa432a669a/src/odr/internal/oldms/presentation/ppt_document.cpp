#include <odr/internal/oldms/presentation/ppt_document.hpp>

#include <odr/file.hpp>
#include <odr/style.hpp>

#include <odr/internal/abstract/filesystem.hpp>
#include <odr/internal/common/element_adapter.hpp>
#include <odr/internal/common/file.hpp>
#include <odr/internal/oldms/presentation/ppt_parser.hpp>

#include <memory>
#include <optional>
#include <string>

namespace odr::internal::oldms::presentation {

namespace {
std::unique_ptr<abstract::ElementAdapter>
create_element_adapter(ElementRegistry &registry,
                       const StyleRegistry &style_registry);
}

Document::Document(std::shared_ptr<abstract::ReadableFilesystem> files)
    : internal::Document(FileType::legacy_powerpoint_presentation,
                         DocumentType::presentation, std::move(files)) {
  m_root_element = parse_tree(m_element_registry, m_style_registry, *m_files);

  m_element_adapter =
      create_element_adapter(m_element_registry, m_style_registry);
}

ElementRegistry &Document::element_registry() { return m_element_registry; }

const ElementRegistry &Document::element_registry() const {
  return m_element_registry;
}

const StyleRegistry &Document::style_registry() const {
  return m_style_registry;
}

namespace {

using AdapterBase = internal::RegistryElementAdapter<
    ElementRegistry, abstract::SlideAdapter, abstract::FrameAdapter,
    abstract::LineBreakAdapter, abstract::ParagraphAdapter,
    abstract::SpanAdapter, abstract::TextAdapter, abstract::ImageAdapter>;

class ElementAdapter final : public AdapterBase {
public:
  ElementAdapter(ElementRegistry &registry, const StyleRegistry &style_registry)
      : AdapterBase(registry), m_style_registry(&style_registry) {}

  [[nodiscard]] PageLayout slide_page_layout(
      [[maybe_unused]] const ElementIdentifier element_id) const override {
    // The DocumentAtom's slide size, with the default 4:3 slide as fallback
    // so the renderer has page dimensions.
    if (const auto size = m_registry->slide_size(); size.has_value()) {
      return {
          .width =
              Measure(size->first / master_units_per_inch, DynamicUnit("in")),
          .height =
              Measure(size->second / master_units_per_inch, DynamicUnit("in")),
          .print_orientation = {},
          .margin = {},
          .background_color = {},
          .direction = {},
      };
    }
    return {
        .width = Measure("10in"),
        .height = Measure("7.5in"),
        .print_orientation = {},
        .margin = {},
        .background_color = {},
        .direction = {},
    };
  }
  [[nodiscard]] ElementIdentifier slide_master_page(
      [[maybe_unused]] const ElementIdentifier element_id) const override {
    return null_element_id;
  }
  [[nodiscard]] std::string
  slide_name(const ElementIdentifier element_id) const override {
    // Slides carry no names in the file; number them in presentation order.
    std::size_t index = 1;
    for (ElementIdentifier id =
             m_registry->element_at(element_id).previous_sibling_id;
         id != null_element_id;
         id = m_registry->element_at(id).previous_sibling_id) {
      ++index;
    }
    return "Slide " + std::to_string(index);
  }

  [[nodiscard]] AnchorType frame_anchor_type(
      [[maybe_unused]] const ElementIdentifier element_id) const override {
    return AnchorType::at_page;
  }
  [[nodiscard]] std::optional<Measure>
  frame_x(const ElementIdentifier element_id) const override {
    return anchor_measure(element_id, [](const Anchor &a) { return a.left; });
  }
  [[nodiscard]] std::optional<Measure>
  frame_y(const ElementIdentifier element_id) const override {
    return anchor_measure(element_id, [](const Anchor &a) { return a.top; });
  }
  [[nodiscard]] std::optional<Measure>
  frame_width(const ElementIdentifier element_id) const override {
    return anchor_measure(element_id, [](const Anchor &a) {
      return std::int64_t{a.right} - a.left;
    });
  }
  [[nodiscard]] std::optional<Measure>
  frame_height(const ElementIdentifier element_id) const override {
    return anchor_measure(element_id, [](const Anchor &a) {
      return std::int64_t{a.bottom} - a.top;
    });
  }
  [[nodiscard]] std::optional<std::int32_t>
  frame_z_index(const ElementIdentifier /*element_id*/) const override {
    return std::nullopt;
  }
  [[nodiscard]] std::optional<DrawingTransform>
  frame_transform(const ElementIdentifier /*element_id*/) const override {
    return std::nullopt;
  }
  [[nodiscard]] GraphicStyle
  frame_style(const ElementIdentifier /*element_id*/) const override {
    return {};
  }

  /// TODO the character run of a line break is not read.
  [[nodiscard]] TextStyle line_break_style(
      [[maybe_unused]] const ElementIdentifier element_id) const override {
    return {};
  }

  /// TODO paragraph properties ([MS-PPT] `TextPFRun`) are not read: alignment,
  /// indent and spacing all render as the default.
  [[nodiscard]] ParagraphStyle paragraph_style(
      [[maybe_unused]] const ElementIdentifier element_id) const override {
    return {};
  }
  [[nodiscard]] TextStyle
  paragraph_text_style(const ElementIdentifier element_id) const override {
    return stored_style(element_id);
  }

  [[nodiscard]] TextStyle
  span_style(const ElementIdentifier element_id) const override {
    return stored_style(element_id);
  }

  [[nodiscard]] std::string
  text_content(const ElementIdentifier element_id) const override {
    return m_registry->text_element_at(element_id).text;
  }
  [[nodiscard]] TextStyle text_style(
      [[maybe_unused]] const ElementIdentifier element_id) const override {
    // The enclosing span carries the character style.
    return {};
  }

  [[nodiscard]] bool image_is_internal(
      [[maybe_unused]] const ElementIdentifier element_id) const override {
    return true;
  }
  [[nodiscard]] std::optional<odr::File>
  image_file(const ElementIdentifier element_id) const override {
    return odr::File(std::make_shared<MemoryFile>(
        m_registry->image_element_at(element_id).data));
  }
  [[nodiscard]] std::string
  image_href(const ElementIdentifier element_id) const override {
    return m_registry->image_element_at(element_id).href;
  }

private:
  /// The character style stored for a paragraph or span element.
  [[nodiscard]] TextStyle
  stored_style(const ElementIdentifier element_id) const {
    return m_style_registry->text_style(
        m_registry->element_style_index(element_id));
  }

  // Converts one field of a frame's anchor to a Measure, or nullopt when the
  // frame has no anchor.
  template <typename Selector>
  [[nodiscard]] std::optional<Measure>
  anchor_measure(const ElementIdentifier element_id,
                 const Selector &select) const {
    const std::optional<Anchor> &anchor =
        m_registry->frame_element_at(element_id).anchor;
    if (!anchor.has_value()) {
      return std::nullopt;
    }
    return Measure(select(*anchor) / master_units_per_inch, DynamicUnit("in"));
  }

  const StyleRegistry *m_style_registry{nullptr};
};

std::unique_ptr<abstract::ElementAdapter>
create_element_adapter(ElementRegistry &registry,
                       const StyleRegistry &style_registry) {
  return std::make_unique<ElementAdapter>(registry, style_registry);
}

} // namespace

} // namespace odr::internal::oldms::presentation
