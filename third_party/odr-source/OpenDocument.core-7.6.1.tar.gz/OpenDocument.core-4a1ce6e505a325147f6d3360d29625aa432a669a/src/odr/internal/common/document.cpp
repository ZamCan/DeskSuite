#include <odr/internal/common/document.hpp>

#include <odr/exceptions.hpp>

#include <odr/internal/abstract/filesystem.hpp>
#include <odr/internal/common/sheet_dependencies.hpp>
#include <odr/internal/formula/formula_value.hpp>
#include <odr/internal/zip/zip_util.hpp>

namespace odr::internal {

Document::Document(const FileType file_type, const DocumentType document_type,
                   std::shared_ptr<abstract::ReadableFilesystem> files,
                   const EncryptionState encryption_state,
                   std::shared_ptr<zip::util::Archive> archive)
    : m_file_type{file_type}, m_document_type{document_type},
      m_encryption_state{encryption_state}, m_files{std::move(files)},
      m_archive{std::move(archive)} {}

Document::~Document() = default;

bool Document::is_editable() const noexcept { return false; }

std::optional<std::string> Document::locale() const { return std::nullopt; }

bool Document::is_savable(const bool /*encrypted*/) const noexcept {
  return false;
}

void Document::release_source(const AbsPath &path) const {
  if (m_archive != nullptr) {
    m_archive->release_source(path);
  }
}

void Document::save(std::ostream & /*out*/) const {
  throw UnsupportedOperation();
}

void Document::save(std::ostream & /*out*/, const char * /*password*/) const {
  throw UnsupportedOperation();
}

FileType Document::file_type() const noexcept { return m_file_type; }

DocumentType Document::document_type() const noexcept {
  return m_document_type;
}

std::shared_ptr<abstract::ReadableFilesystem>
Document::as_filesystem() const noexcept {
  return m_files;
}

ElementIdentifier Document::root_element() const { return m_root_element; }

const abstract::ElementAdapter *Document::element_adapter() const {
  return m_element_adapter.get();
}

const SheetDependencies &Document::sheet_dependencies() const {
  if (!m_sheet_dependencies) {
    m_sheet_dependencies =
        std::make_unique<SheetDependencies>(SheetDependencies::of(*this));
  }
  return *m_sheet_dependencies;
}

formula::Settings Document::formula_settings() const { return {}; }

std::vector<formula::Name> Document::formula_names() const { return {}; }

std::vector<formula::ExternalSheet> Document::formula_external_sheets() const {
  return {};
}

void Document::drop_sheet_dependencies() const noexcept {
  m_sheet_dependencies.reset();
}

void Document::note_written(const ElementIdentifier sheet,
                            const TablePosition &position) const {
  m_written.emplace_back(sheet, position);
}

void Document::note_moved() const noexcept { m_moved = true; }

const std::vector<std::pair<ElementIdentifier, TablePosition>> &
Document::written() const noexcept {
  return m_written;
}

bool Document::moved() const noexcept { return m_moved; }

void Document::forget_edits() const noexcept {
  m_written.clear();
  m_moved = false;
}

bool Document::is_decrypted() const noexcept {
  return m_encryption_state == EncryptionState::decrypted;
}

} // namespace odr::internal
