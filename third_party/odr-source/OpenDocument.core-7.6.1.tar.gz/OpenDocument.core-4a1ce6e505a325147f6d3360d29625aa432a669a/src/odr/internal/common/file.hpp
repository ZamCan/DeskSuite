#pragma once

#include <odr/internal/abstract/file.hpp>
#include <odr/internal/common/path.hpp>

#include <iosfwd>
#include <memory>
#include <string>

namespace odr {
enum class FileLocation;
}

namespace odr::internal {

class DiskFile : public abstract::File {
public:
  explicit DiskFile(const char *path);
  explicit DiskFile(const std::string &path);
  explicit DiskFile(AbsPath path);

  [[nodiscard]] FileLocation location() const noexcept final;
  [[nodiscard]] std::size_t size() const final;

  [[nodiscard]] std::string name() const final;

  [[nodiscard]] std::optional<AbsPath> disk_path() const final;
  [[nodiscard]] std::optional<std::string_view> memory_data() const final;

  [[nodiscard]] std::unique_ptr<std::istream> stream() const final;

protected:
  [[nodiscard]] const AbsPath &path() const noexcept { return m_path; }

private:
  AbsPath m_path;
};

class MemoryFile final : public abstract::File {
public:
  explicit MemoryFile(std::string data, std::string name = {});
  /// Takes @p file's bytes into memory, name and all.
  explicit MemoryFile(const File &file);

  [[nodiscard]] FileLocation location() const noexcept override;
  [[nodiscard]] std::size_t size() const override;

  [[nodiscard]] std::string name() const override;

  [[nodiscard]] std::optional<AbsPath> disk_path() const override;
  [[nodiscard]] std::optional<std::string_view> memory_data() const override;

  [[nodiscard]] std::unique_ptr<std::istream> stream() const override;

  [[nodiscard]] const std::string &content() const;

private:
  std::string m_data;
  std::string m_name;
};

} // namespace odr::internal
