#pragma once

#include <odr/definitions.hpp>
#include <odr/document_element.hpp>

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <limits>
#include <stdexcept>
#include <tuple>
#include <unordered_map>
#include <utility>

namespace odr::internal {

/// The tree links every registry element carries, stored @p Id wide.
template <typename Id> struct ElementNode {
  Id parent_id{null_element_id};
  Id first_child_id{null_element_id};
  Id last_child_id{null_element_id};
  Id previous_sibling_id{null_element_id};
  Id next_sibling_id{null_element_id};
  ElementType type{ElementType::none};
};

/// A per-type payload keyed by element id, hashed, filled in any order.
/// Prefer @ref SortedSideTable for a payload written when its element is
/// created: it is a binary search over a narrow-keyed array instead.
template <typename T> class SideTable final {
public:
  T &emplace(const ElementIdentifier id, T value) {
    return m_entries.insert_or_assign(id, std::move(value)).first->second;
  }

  [[nodiscard]] auto *find(this auto &self, const ElementIdentifier id) {
    const auto it = self.m_entries.find(id);
    return it != std::end(self.m_entries) ? &it->second : nullptr;
  }

  [[nodiscard]] auto &at(this auto &self, const ElementIdentifier id) {
    auto *entry = self.find(id);
    if (entry == nullptr) {
      throw std::out_of_range("SideTable::at: identifier not found");
    }
    return *entry;
  }

private:
  std::unordered_map<ElementIdentifier, T> m_entries;
};

/// Ordered payloads with binary-search lookup and stable references.
/// `emplace` requires strictly increasing IDs.
template <typename T, typename Id = ElementIdentifier>
class SortedSideTable final {
public:
  T &emplace(const ElementIdentifier id, T value) {
    if (id > std::numeric_limits<Id>::max()) {
      throw std::out_of_range("SortedSideTable::emplace: identifier too wide");
    }
    if (!m_entries.empty() && m_entries.back().first >= id) {
      throw std::invalid_argument(
          "SortedSideTable::emplace: identifier out of order");
    }
    return m_entries.emplace_back(static_cast<Id>(id), std::move(value)).second;
  }

  [[nodiscard]] auto *find(this auto &self, const ElementIdentifier id) {
    const auto it =
        std::ranges::lower_bound(self.m_entries, id, {}, &Entry::first);
    return it != std::end(self.m_entries) && it->first == id ? &it->second
                                                             : nullptr;
  }

  [[nodiscard]] auto &at(this auto &self, const ElementIdentifier id) {
    auto *entry = self.find(id);
    if (entry == nullptr) {
      throw std::out_of_range("SortedSideTable::at: identifier not found");
    }
    return *entry;
  }

  [[nodiscard]] auto begin(this auto &self) noexcept {
    return self.m_entries.begin();
  }
  [[nodiscard]] auto end(this auto &self) noexcept {
    return self.m_entries.end();
  }

private:
  using Entry = std::pair<Id, T>;

  std::deque<Entry> m_entries;
};

/// Append-only element store with index-plus-one IDs and stable references.
/// @p ElementT derives from @ref ElementNode.
template <typename ElementT, typename Id = ElementIdentifier>
class ElementRegistry {
public:
  using Element = ElementT;

  [[nodiscard]] std::size_t size() const noexcept { return m_elements.size(); }

  /// The index @p id names; an engine whose ids are not all indices shadows it.
  [[nodiscard]] static ElementIdentifier
  resolve_id(const ElementIdentifier id) noexcept {
    return id;
  }

  [[nodiscard]] ElementIdentifier checked_id(this const auto &self,
                                             const ElementIdentifier id) {
    const ElementIdentifier index = self.resolve_id(id);
    self.check_element_id(index);
    return index;
  }

  [[nodiscard]] auto &element_at(this auto &self, const ElementIdentifier id) {
    return self.m_elements[self.checked_id(id) - 1];
  }

  /// Retires an element and its descendants without reusing their ids.
  void invalidate(this auto &self, const ElementIdentifier id) {
    self.element_at(id).type = ElementType::none;
    self.m_has_removed = true;
  }

  void invalidate_children(this auto &self, const ElementIdentifier id) {
    Element &parent = self.element_at(id);
    for (ElementIdentifier child = parent.first_child_id;
         child != null_element_id;) {
      const ElementIdentifier next = self.element_at(child).next_sibling_id;
      self.invalidate(child);
      child = next;
    }
    parent.first_child_id = parent.last_child_id = null_element_id;
  }

  void append_child(const ElementIdentifier parent_id,
                    const ElementIdentifier child_id) {
    Element &parent = element_at(parent_id);
    link_child(parent_id, child_id, parent.first_child_id,
               parent.last_child_id);
  }

  /// Links @p child_id beside @p anchor_id. Indices, as @ref link_child wants
  /// them, and the element's own chain rather than one a payload holds.
  void insert_sibling_after(const ElementIdentifier anchor_id,
                            const ElementIdentifier child_id) {
    insert_sibling_(anchor_id, child_id, Placement::after);
  }
  void insert_sibling_before(const ElementIdentifier anchor_id,
                             const ElementIdentifier child_id) {
    insert_sibling_(anchor_id, child_id, Placement::before);
  }

  /// Unlinks @p child_id from that same chain; it keeps its id and its
  /// payload and stops being reachable.
  void unlink_child(const ElementIdentifier child_id) {
    Element &child = element_at(child_id);
    const Id parent_id = child.parent_id;
    if (parent_id == null_element_id) {
      throw std::invalid_argument(
          "ElementRegistry::unlink_child: child has no parent");
    }
    const Id previous_id = child.previous_sibling_id;
    const Id next_id = child.next_sibling_id;

    if (previous_id != null_element_id) {
      element_at(previous_id).next_sibling_id = next_id;
    } else {
      element_at(parent_id).first_child_id = next_id;
    }
    if (next_id != null_element_id) {
      element_at(next_id).previous_sibling_id = previous_id;
    } else {
      element_at(parent_id).last_child_id = previous_id;
    }

    child.parent_id = null_element_id;
    child.previous_sibling_id = null_element_id;
    child.next_sibling_id = null_element_id;
  }

protected:
  ~ElementRegistry() = default;

  std::tuple<ElementIdentifier, Element &> create_element_(ElementType type) {
    if (m_elements.size() >= std::numeric_limits<Id>::max()) {
      throw std::overflow_error(
          "ElementRegistry::create_element: out of identifiers");
    }

    Element &element = m_elements.emplace_back();
    const ElementIdentifier element_id = m_elements.size();
    element.type = type;
    return {element_id, element};
  }

  /// Links @p child_id as the last child of the chain @p first_id / @p last_id
  /// - the element's own, or one of the secondary chains a payload holds.
  /// Both ids are indices, not whatever @ref resolve_id accepts.
  void link_child(const ElementIdentifier parent_id,
                  const ElementIdentifier child_id, Id &first_id, Id &last_id) {
    Element &child = element_at(child_id);
    if (child.parent_id != null_element_id) {
      throw std::invalid_argument(
          "ElementRegistry::link_child: child already has a parent");
    }

    child.parent_id = static_cast<Id>(parent_id);
    child.previous_sibling_id = last_id;

    if (first_id == null_element_id) {
      first_id = static_cast<Id>(child_id);
    } else {
      element_at(last_id).next_sibling_id = static_cast<Id>(child_id);
    }
    last_id = static_cast<Id>(child_id);
  }

  void insert_sibling_(const ElementIdentifier anchor_id,
                       const ElementIdentifier child_id,
                       const Placement where) {
    Element &anchor = element_at(anchor_id);
    const Id parent_id = anchor.parent_id;
    if (parent_id == null_element_id) {
      throw std::invalid_argument(
          "ElementRegistry::insert_sibling: anchor has no parent");
    }
    Element &child = element_at(child_id);
    if (child.parent_id != null_element_id) {
      throw std::invalid_argument(
          "ElementRegistry::insert_sibling: child already has a parent");
    }

    const Id previous_id = where == Placement::after
                               ? static_cast<Id>(anchor_id)
                               : anchor.previous_sibling_id;
    const Id next_id = where == Placement::after ? anchor.next_sibling_id
                                                 : static_cast<Id>(anchor_id);

    child.parent_id = parent_id;
    child.previous_sibling_id = previous_id;
    child.next_sibling_id = next_id;

    if (previous_id != null_element_id) {
      element_at(previous_id).next_sibling_id = static_cast<Id>(child_id);
    } else {
      element_at(parent_id).first_child_id = static_cast<Id>(child_id);
    }
    if (next_id != null_element_id) {
      element_at(next_id).previous_sibling_id = static_cast<Id>(child_id);
    } else {
      element_at(parent_id).last_child_id = static_cast<Id>(child_id);
    }
  }

  void check_element_id(const ElementIdentifier id) const {
    if (id == null_element_id) {
      throw std::out_of_range(
          "ElementRegistry::check_element_id: null identifier");
    }
    if (id - 1 >= m_elements.size()) {
      throw std::out_of_range(
          "ElementRegistry::check_element_id: identifier out of range");
    }
    if (m_has_removed) {
      for (ElementIdentifier at = id; at != null_element_id;
           at = m_elements[at - 1].parent_id) {
        if (m_elements[at - 1].type == ElementType::none) {
          throw std::out_of_range("element has been removed");
        }
      }
    }
  }

  std::deque<Element> m_elements;

private:
  bool m_has_removed{false};
};

} // namespace odr::internal
