#include <odr/internal/cfb/cfb_impl.hpp>

#include <odr/exceptions.hpp>
#include <odr/internal/util/byte_stream_util.hpp>
#include <odr/internal/util/string_util.hpp>

#include <algorithm>
#include <cstring>
#include <stdexcept>

namespace odr::internal::cfb {

namespace {

std::uint32_t parse_uint32(std::istream &in) {
  return util::byte_stream::read<std::uint32_t>(in);
}

} // namespace

void impl::parse_header(std::istream &in, CompoundFileHeader &hdr) {
  util::byte_stream::read(in, hdr);
  // TODO deal with endianess
}

void impl::parse_entry(std::istream &in, CompoundFileEntry &entry) {
  util::byte_stream::read(in, entry);
  // TODO deal with endianess
}

impl::CompoundFileEntry impl::parse_entry(std::istream &in) {
  CompoundFileEntry entry{};
  parse_entry(in, entry);
  return entry;
}

} // namespace odr::internal::cfb

namespace odr::internal::cfb::impl {

std::string CompoundFileEntry::get_name() const {
  // [MS-CFB] 2.6.1: `name_len` counts bytes including the terminating NUL and
  // never exceeds the 64-byte name field.
  if (name_len > sizeof(name) || name_len % 2 != 0 ||
      (name_len >= 2 && name[name_len / 2 - 1] != u'\0')) {
    throw CfbFileCorrupted();
  }
  if (name_len < 2) {
    return {};
  }
  return internal::util::string::c16str_to_string(name.data(), name_len - 2);
}

CompoundFileReader::CompoundFileReader(std::istream &in,
                                       const std::uint64_t file_size)
    : m_file_size{file_size} {
  parse_header(in, m_header);

  if (std::memcmp(m_header.signature.data(), MAGIC, 8) != 0) {
    throw NoCfbFile();
  }

  // [MS-CFB] 2.2: major version 3 or 4, pinned to sector shift 9 resp. 12; the
  // sector size is 1 << sector_shift.
  if (!(m_header.major_version == 3 && m_header.sector_shift == 9) &&
      !(m_header.major_version == 4 && m_header.sector_shift == 12)) {
    throw CfbFileCorrupted();
  }
  if (m_header.byte_order != 0xfffe || m_header.mini_sector_shift != 6 ||
      m_header.mini_stream_cutoff_size != 4096) {
    throw CfbFileCorrupted();
  }
  m_sector_size = std::uint64_t{1} << m_header.sector_shift;

  // The file must contain at least 3 sectors
  if (m_file_size < m_sector_size * 3) {
    throw CfbFileCorrupted();
  }

  parse_entry(in, RootId, m_root);
  if (m_root.type != 5) {
    throw CfbFileCorrupted();
  }

  m_mini_stream_start_sector = m_root.start_sector_location;
}

void CompoundFileReader::parse_entry(std::istream &in,
                                     const std::uint32_t entry_id,
                                     CompoundFileEntry &entry) const {
  const std::uint64_t offset =
      std::uint64_t{entry_id} * sizeof(CompoundFileEntry);

  if (offset >= m_file_size) {
    throw std::invalid_argument("");
  }

  const SectorOffset sector_offset = normalize_sector_offset(
      in, {m_header.first_directory_sector_location, offset});
  const std::uint64_t address = sector_offset_to_address(sector_offset);
  in.seekg(static_cast<std::streampos>(address));
  impl::parse_entry(in, entry);
  if (m_header.major_version == 3) {
    // [MS-CFB] 2.6.1: older writers leave the high DWORD uninitialized.
    entry.size = static_cast<std::uint32_t>(entry.size);
  }
}

CompoundFileEntry
CompoundFileReader::parse_entry(std::istream &in,
                                const std::uint32_t entry_id) const {
  CompoundFileEntry entry{};
  parse_entry(in, entry_id, entry);
  return entry;
}

void CompoundFileReader::read_file(std::istream &in,
                                   const CompoundFileEntry &entry,
                                   const std::uint64_t offset, char *buffer,
                                   const std::uint64_t len) const {
  if (offset > entry.size) {
    throw std::invalid_argument(
        "offset bigger than entry size: " + std::to_string(offset) + " > " +
        std::to_string(entry.size));
  }
  if (len > entry.size - offset) {
    throw std::invalid_argument(
        "length bigger than remaining entry size: " + std::to_string(len) +
        " > " + std::to_string(entry.size - offset));
  }

  if (len == 0) {
    return;
  }
  if (entry.size < m_header.mini_stream_cutoff_size) {
    read_mini_stream(in, {entry.start_sector_location, offset}, buffer, len);
  } else {
    read_stream(in, {entry.start_sector_location, offset}, buffer, len);
  }
}

void CompoundFileReader::read_stream(std::istream &in,
                                     const SectorOffset &sector_offset,
                                     char *buffer, std::uint64_t length) const {
  SectorOffset current_sector_offset =
      normalize_sector_offset(in, sector_offset);

  while (length > 0) {
    const std::uint64_t address =
        sector_offset_to_address(current_sector_offset);
    const std::size_t copy_length =
        std::min(length, m_sector_size - current_sector_offset.offset);
    if (address + copy_length > m_file_size) {
      throw CfbFileCorrupted();
    }

    in.seekg(static_cast<std::streampos>(address));
    util::byte_stream::read(in, buffer, copy_length);
    buffer += copy_length;
    length -= copy_length;

    if (length == 0) {
      break;
    }
    current_sector_offset.sector =
        resolve_next_sector(in, current_sector_offset.sector);
    current_sector_offset.offset = 0;
  }
}

void CompoundFileReader::read_mini_stream(std::istream &in,
                                          const SectorOffset &sector_offset,
                                          char *buffer,
                                          std::uint64_t length) const {
  SectorOffset current_sector_offset =
      normalize_mini_sector_offset(in, sector_offset);

  while (length > 0) {
    const std::uint64_t address =
        mini_sector_offset_to_address(in, current_sector_offset);
    const std::size_t copy_length =
        std::min(length, m_mini_sector_size - current_sector_offset.offset);
    const std::uint64_t mini_offset =
        current_sector_offset.offset +
        current_sector_offset.sector * m_mini_sector_size;
    if (copy_length > m_root.size - mini_offset ||
        address + copy_length > m_file_size) {
      throw CfbFileCorrupted();
    }

    in.seekg(static_cast<std::streampos>(address));
    util::byte_stream::read(in, buffer, copy_length);
    buffer += copy_length;
    length -= copy_length;

    if (length == 0) {
      break;
    }
    current_sector_offset.sector =
        resolve_next_mini_sector(in, current_sector_offset.sector);
    current_sector_offset.offset = 0;
  }
}

Sector CompoundFileReader::resolve_next_sector(std::istream &in,
                                               const Sector sector) const {
  // lookup FAT
  const std::uint32_t entriesPerSector = m_sector_size / 4;
  const std::uint32_t fatSectorNumber = sector / entriesPerSector;
  const std::uint32_t fatSectorLocation =
      resolve_fat_sector_location(in, fatSectorNumber);
  const std::uint64_t address = sector_offset_to_address(
      {fatSectorLocation,
       static_cast<std::uint64_t>(sector % entriesPerSector) * 4});
  in.seekg(static_cast<std::streampos>(address));
  return parse_uint32(in);
}

Sector CompoundFileReader::resolve_next_mini_sector(
    std::istream &in, const std::uint32_t mini_sector) const {
  const SectorOffset sector_offset = normalize_sector_offset(
      in, {m_header.first_mini_fat_sector_location,
           static_cast<std::uint64_t>(mini_sector) * 4});
  const std::uint64_t address = sector_offset_to_address(sector_offset);
  in.seekg(static_cast<std::streampos>(address));
  return parse_uint32(in);
}

std::uint64_t CompoundFileReader::sector_offset_to_address(
    const SectorOffset &sector_offset) const {
  const std::uint64_t address = sector_offset.offset + m_sector_size +
                                sector_offset.sector * m_sector_size;

  if (sector_offset.sector >= MaxSector ||
      sector_offset.offset >= m_sector_size || address >= m_file_size) {
    throw CfbFileCorrupted();
  }

  return address;
}

std::uint64_t CompoundFileReader::mini_sector_offset_to_address(
    std::istream &in, const SectorOffset &sector_offset) const {
  const std::uint64_t address =
      sector_offset.offset + sector_offset.sector * m_mini_sector_size;

  if (sector_offset.sector >= MaxSector ||
      sector_offset.offset >= m_mini_sector_size || address >= m_root.size) {
    throw CfbFileCorrupted();
  }

  return sector_offset_to_address(
      normalize_sector_offset(in, {m_mini_stream_start_sector, address}));
}

CompoundFileReader::SectorOffset
CompoundFileReader::normalize_sector_offset(std::istream &in,
                                            SectorOffset sector_offset) const {
  while (sector_offset.offset >= m_sector_size) {
    sector_offset.offset -= m_sector_size;
    sector_offset.sector = resolve_next_sector(in, sector_offset.sector);
  }
  return sector_offset;
}

CompoundFileReader::SectorOffset
CompoundFileReader::normalize_mini_sector_offset(
    std::istream &in, SectorOffset sector_offset) const {
  while (sector_offset.offset >= m_mini_sector_size) {
    sector_offset.offset -= m_mini_sector_size;
    sector_offset.sector = resolve_next_mini_sector(in, sector_offset.sector);
  }
  return sector_offset;
}

std::uint32_t CompoundFileReader::resolve_fat_sector_location(
    std::istream &in, std::uint32_t fat_sector_number) const {
  if (fat_sector_number < 109) {
    return m_header.header_difat[fat_sector_number];
  }

  fat_sector_number -= 109;
  const std::uint32_t entriesPerSector = m_sector_size / 4 - 1;
  std::uint32_t difatSectorLocation = m_header.first_difat_sector_location;
  while (fat_sector_number >= entriesPerSector) {
    fat_sector_number -= entriesPerSector;
    const std::uint64_t address =
        sector_offset_to_address({difatSectorLocation, m_sector_size - 4});
    in.seekg(static_cast<std::streampos>(address));
    difatSectorLocation = parse_uint32(in);
  }
  const std::uint64_t address = sector_offset_to_address(
      {difatSectorLocation, static_cast<std::uint64_t>(fat_sector_number) * 4});
  in.seekg(static_cast<std::streampos>(address));
  return parse_uint32(in);
}

} // namespace odr::internal::cfb::impl
