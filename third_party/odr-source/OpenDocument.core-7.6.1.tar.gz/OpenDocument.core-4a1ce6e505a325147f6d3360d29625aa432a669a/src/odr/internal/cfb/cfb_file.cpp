#include <odr/internal/cfb/cfb_file.hpp>

#include <odr/internal/cfb/cfb_archive.hpp>
#include <odr/internal/cfb/cfb_util.hpp>

namespace odr::internal::cfb {

CfbFile::CfbFile(std::shared_ptr<abstract::File> file)
    : m_cfb{std::make_shared<util::Archive>(std::move(file))} {}

std::shared_ptr<abstract::File> CfbFile::file() const noexcept {
  return m_cfb->file();
}

FileType CfbFile::file_type() const noexcept {
  return FileType::compound_file_binary_format;
}

std::string_view CfbFile::mimetype() const noexcept {
  return "application/x-cfb";
}

FileMeta CfbFile::file_meta() const {
  FileMeta result;
  result.type = file_type();
  result.mimetype = mimetype();
  return result;
}

bool CfbFile::is_decodable() const noexcept { return true; }

std::shared_ptr<abstract::Archive> CfbFile::archive() const {
  return std::make_shared<CfbArchive>(m_cfb);
}

} // namespace odr::internal::cfb
