#include <odr/internal/cfb/cfb_util.hpp>

#include <odr/exceptions.hpp>

#include <odr/internal/common/file.hpp>
#include <odr/internal/util/string_util.hpp>

#include <algorithm>
#include <iostream>
#include <limits>
#include <string>
#include <utility>

namespace odr::internal::cfb::util {

namespace {

class ReaderBuffer final : public std::streambuf {
public:
  ReaderBuffer(const impl::CompoundFileReader &reader,
               const impl::CompoundFileEntry &entry,
               std::unique_ptr<std::istream> stream,
               const std::size_t buffer_size = 4096)
      : m_reader{&reader}, m_entry{entry}, m_stream{std::move(stream)},
        m_buffer(buffer_size, '\0') {
    setg(m_buffer.data(), m_buffer.data(), m_buffer.data());
  }

protected:
  int underflow() override {
    if (m_offset >= m_entry.size) {
      return traits_type::eof();
    }

    const std::uint64_t remaining = m_entry.size - m_offset;
    const std::uint64_t amount =
        std::min<std::uint64_t>(remaining, m_buffer.size());
    m_reader->read_file(*m_stream, m_entry, m_offset, m_buffer.data(), amount);
    m_offset += amount;
    setg(m_buffer.data(), m_buffer.data(), m_buffer.data() + amount);

    return traits_type::to_int_type(*gptr());
  }

  std::streampos seekpos(const std::streampos sp,
                         const std::ios_base::openmode which) override {
    return seekoff(sp, std::ios_base::beg, which);
  }

  std::streampos seekoff(const std::streamoff off,
                         const std::ios_base::seekdir dir,
                         const std::ios_base::openmode which) override {
    if ((which & std::ios_base::in) == 0) {
      return -1;
    }

    if (m_entry.size > static_cast<std::uint64_t>(
                           std::numeric_limits<std::streamoff>::max())) {
      return -1;
    }
    const auto size = static_cast<std::streamoff>(m_entry.size);
    std::streamoff base = 0;
    if (dir == std::ios_base::cur) {
      base = static_cast<std::streamoff>(m_offset) - (egptr() - gptr());
    } else if (dir == std::ios_base::end) {
      base = size;
    } else if (dir != std::ios_base::beg) {
      return -1;
    }
    if (off < -base || off > size - base) {
      return -1;
    }
    const std::streamoff new_pos = base + off;
    m_offset = static_cast<std::uint64_t>(new_pos);

    // invalidate buffer
    setg(m_buffer.data(), m_buffer.data(), m_buffer.data());

    return new_pos;
  }

private:
  const impl::CompoundFileReader *m_reader{};
  const impl::CompoundFileEntry m_entry;
  std::unique_ptr<std::istream> m_stream;
  std::uint64_t m_offset{0};
  std::vector<char> m_buffer;
};

class FileInCfbIstream final : public std::istream {
public:
  FileInCfbIstream(std::shared_ptr<const Archive> archive,
                   std::unique_ptr<ReaderBuffer> sbuf)
      : std::istream(sbuf.get()), m_archive{std::move(archive)},
        m_sbuf{std::move(sbuf)} {}
  FileInCfbIstream(const std::shared_ptr<const Archive> &archive,
                   const impl::CompoundFileReader &reader,
                   const impl::CompoundFileEntry &entry)
      : FileInCfbIstream(archive,
                         std::make_unique<ReaderBuffer>(
                             reader, entry, archive->file()->stream())) {}

private:
  std::shared_ptr<const Archive> m_archive;
  std::unique_ptr<ReaderBuffer> m_sbuf;
};

class FileInCfb final : public abstract::File {
public:
  FileInCfb(std::shared_ptr<const Archive> archive,
            const impl::CompoundFileEntry &entry)
      : m_archive{std::move(archive)}, m_entry{entry} {}

  [[nodiscard]] FileLocation location() const noexcept override {
    return m_archive->file()->location();
  }
  [[nodiscard]] std::size_t size() const override {
    if (!std::in_range<std::size_t>(m_entry.size)) {
      throw FileReadError();
    }
    return static_cast<std::size_t>(m_entry.size);
  }

  [[nodiscard]] std::string name() const override { return m_entry.get_name(); }

  [[nodiscard]] std::optional<AbsPath> disk_path() const override {
    return std::nullopt;
  }
  [[nodiscard]] std::optional<std::string_view> memory_data() const override {
    return std::nullopt;
  }

  [[nodiscard]] std::unique_ptr<std::istream> stream() const override {
    return std::make_unique<FileInCfbIstream>(m_archive, m_archive->cfb(),
                                              m_entry);
  }

private:
  std::shared_ptr<const Archive> m_archive;
  impl::CompoundFileEntry m_entry;
};

} // namespace

Archive::Archive(std::shared_ptr<abstract::File> file)
    : m_file{std::move(file)}, m_cfb{*m_file->stream(), m_file->size()} {}

std::unique_ptr<abstract::File> Archive::Entry::file() const {
  if (!is_file()) {
    return {};
  }
  return std::make_unique<FileInCfb>(m_archive->shared_from_this(), m_entry);
}

std::optional<Archive::Entry> Archive::Entry::left() const {
  if (m_entry.left_sibling_id == impl::NullId) {
    return {};
  }
  const impl::CompoundFileEntry left = m_archive->m_cfb.parse_entry(
      *m_archive->m_file->stream(), m_entry.left_sibling_id);
  return Entry(*m_archive, m_entry.left_sibling_id, left,
               m_path.parent().join(RelPath(left.get_name())));
}

std::optional<Archive::Entry> Archive::Entry::right() const {
  if (m_entry.right_sibling_id == impl::NullId) {
    return {};
  }
  const impl::CompoundFileEntry right = m_archive->m_cfb.parse_entry(
      *m_archive->m_file->stream(), m_entry.right_sibling_id);
  return Entry(*m_archive, m_entry.right_sibling_id, right,
               m_path.parent().join(RelPath(right.get_name())));
}

std::optional<Archive::Entry> Archive::Entry::child() const {
  if (m_entry.child_id == impl::NullId) {
    return {};
  }
  const impl::CompoundFileEntry child = m_archive->m_cfb.parse_entry(
      *m_archive->m_file->stream(), m_entry.child_id);
  return Entry(*m_archive, m_entry.child_id, child,
               m_path.join(RelPath(child.get_name())));
}

void Archive::Iterator::enter_(Entry entry) {
  if (!m_visited.insert(entry.m_entry_id).second) {
    throw CfbFileCorrupted();
  }
  m_entry = std::move(entry);
}

void Archive::Iterator::dig_left_() {
  while (m_entry.has_value()) {
    const std::optional<Entry> left = m_entry->left();
    if (!left.has_value()) {
      break;
    }
    m_ancestors.push_back(*m_entry);
    enter_(*left);
  }
}

void Archive::Iterator::next_() {
  if (!m_entry.has_value()) {
    return;
  }

  if (const std::optional<Entry> child = m_entry->child(); child.has_value()) {
    m_directories.push_back({*m_entry, m_ancestors.size()});
    enter_(*child);
    dig_left_();
    return;
  }

  next_flat_();
}

void Archive::Iterator::next_flat_() {
  while (m_entry.has_value()) {
    if (const std::optional<Entry> right = m_entry->right();
        right.has_value()) {
      enter_(*right);
      dig_left_();
      return;
    }

    if (!m_ancestors.empty() &&
        (m_directories.empty() ||
         m_ancestors.size() > m_directories.back().ancestors)) {
      m_entry = m_ancestors.back();
      m_ancestors.pop_back();
      return;
    }

    if (m_directories.empty()) {
      m_entry.reset();
      return;
    }
    m_entry = m_directories.back().entry;
    m_directories.pop_back();
  }
}

const impl::CompoundFileReader &Archive::cfb() const { return m_cfb; }

std::shared_ptr<abstract::File> Archive::file() const { return m_file; }

Archive::Entry Archive::root() const {
  return {*this, impl::RootId, m_cfb.get_root_entry(), RelPath("")};
}

Archive::Iterator Archive::begin() const { return Iterator::begin(root()); }

Archive::Iterator Archive::end() const { return Iterator::end(); }

Archive::Iterator Archive::find(const RelPath &path) const {
  return std::find_if(begin(), end(), [&path](const Entry &entry) {
    return entry.path() == path;
  });
}

} // namespace odr::internal::cfb::util
