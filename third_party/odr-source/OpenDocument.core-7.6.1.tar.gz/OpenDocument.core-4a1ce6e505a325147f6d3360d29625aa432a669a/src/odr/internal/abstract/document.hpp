#pragma once

#include <odr/definitions.hpp>
// for the element model itself: `FrameAdapter` defaults its shape readers, and
// a default needs the complete type.
#include <odr/document_element.hpp>
#include <odr/exceptions.hpp>
#include <odr/quantity.hpp>

#include <cstdint>
#include <functional>
#include <iosfwd>
#include <memory>
#include <optional>
#include <string>
#include <vector>

namespace odr {
class File;
enum class FileType;
enum class DocumentType;
struct PageLayout;
struct TableDimensions;
struct TablePosition;
struct TableStyle;
struct TableColumnStyle;
struct TableRowStyle;
struct TableCellStyle;
struct TextStyle;
struct ParagraphStyle;
struct GraphicStyle;
} // namespace odr

namespace odr::internal {
class AbsPath;
class SheetDependencies;
} // namespace odr::internal

namespace odr::internal::formula {
struct Settings;
struct ExternalSheet;
struct Name;
} // namespace odr::internal::formula

namespace odr::internal::abstract {
class ReadableFilesystem;
class ElementAdapter;
class TextRootAdapter;
class SlideAdapter;
class PageAdapter;
class SheetAdapter;
class SheetCellAdapter;
class MasterPageAdapter;
class LineBreakAdapter;
class ParagraphAdapter;
class SpanAdapter;
class TextAdapter;
class LinkAdapter;
class BookmarkAdapter;
class ListAdapter;
class ListItemAdapter;
class TableAdapter;
class TableColumnAdapter;
class TableRowAdapter;
class TableCellAdapter;
class FrameAdapter;
class ImageAdapter;

class Document {
public:
  virtual ~Document() = default;

  /// Editable in any way.
  [[nodiscard]] virtual bool is_editable() const noexcept = 0;

  /// Savable, @p encrypted to ask for an encrypted save. A decrypted package
  /// is not: `save` would write it out in the clear.
  [[nodiscard]] virtual bool is_savable(bool encrypted) const noexcept = 0;

  virtual void save(std::ostream &out) const = 0;
  virtual void save(std::ostream &out, const char *password) const = 0;
  /// Called before a save replaces the file at @p path: whatever still reads
  /// from that file reads from a private copy from then on.
  virtual void release_source(const AbsPath & /*path*/) const {}

  [[nodiscard]] virtual FileType file_type() const noexcept = 0;
  [[nodiscard]] virtual DocumentType document_type() const noexcept = 0;
  /// A BCP 47 tag such as `de-DE`, or nothing where the file states none.
  [[nodiscard]] virtual std::optional<std::string> locale() const = 0;

  [[nodiscard]] virtual std::shared_ptr<ReadableFilesystem>
  as_filesystem() const noexcept = 0;

  [[nodiscard]] virtual ElementIdentifier root_element() const = 0;
  [[nodiscard]] virtual const ElementAdapter *element_adapter() const = 0;

  /// Built on the first question and kept: writing a formula is refused, so
  /// nothing a write does changes it.
  [[nodiscard]] virtual const SheetDependencies &sheet_dependencies() const = 0;

  /// How the formulas of the document compute: what an `.ods` states, and
  /// Excel's settings for every other format.
  [[nodiscard]] virtual formula::Settings formula_settings() const = 0;
  /// The names the document defines for its formulas. None for a format
  /// that states none.
  [[nodiscard]] virtual std::vector<formula::Name> formula_names() const = 0;
  /// The copies of other documents' sheets that the file caches apart from
  /// its own sheets (ECMA-376 18.14). An `.ods` holds them as sheets.
  [[nodiscard]] virtual std::vector<formula::ExternalSheet>
  formula_external_sheets() const = 0;
};

class ElementAdapter {
public:
  virtual ~ElementAdapter() = default;

  [[nodiscard]] virtual ElementType
  element_type(ElementIdentifier element_id) const = 0;

  [[nodiscard]] virtual ElementIdentifier
  element_parent(ElementIdentifier element_id) const = 0;
  [[nodiscard]] virtual ElementIdentifier
  element_first_child(ElementIdentifier element_id) const = 0;
  [[nodiscard]] virtual ElementIdentifier
  element_last_child(ElementIdentifier element_id) const = 0;
  [[nodiscard]] virtual ElementIdentifier
  element_previous_sibling(ElementIdentifier element_id) const = 0;
  [[nodiscard]] virtual ElementIdentifier
  element_next_sibling(ElementIdentifier element_id) const = 0;

  [[nodiscard]] virtual bool
  element_is_unique(ElementIdentifier element_id) const = 0;
  [[nodiscard]] virtual bool
  element_is_self_locatable(ElementIdentifier element_id) const = 0;
  [[nodiscard]] virtual bool
  element_is_editable(ElementIdentifier element_id) const = 0;

  /// Removes @p element_id and its subtree; it keeps its id and stops being
  /// reachable, so an id already handed out never names something else.
  virtual void
  element_remove([[maybe_unused]] const ElementIdentifier element_id) const {
    throw UnsupportedOperation();
  }

  /// A run holding @p text as the last child of @p element_id. What a
  /// paragraph holding no run at all is typed into.
  /// @throws UnsupportedOperation where the engine cannot write.
  virtual ElementIdentifier
  element_append_text([[maybe_unused]] const ElementIdentifier element_id,
                      [[maybe_unused]] const std::string &text) const {
    throw UnsupportedOperation();
  }

  [[nodiscard]] virtual const TextRootAdapter *
  text_root_adapter([[maybe_unused]] const ElementIdentifier element_id) const {
    return nullptr;
  }
  [[nodiscard]] virtual const SlideAdapter *
  slide_adapter([[maybe_unused]] const ElementIdentifier element_id) const {
    return nullptr;
  }
  [[nodiscard]] virtual const PageAdapter *
  page_adapter([[maybe_unused]] const ElementIdentifier element_id) const {
    return nullptr;
  }
  [[nodiscard]] virtual const SheetAdapter *
  sheet_adapter([[maybe_unused]] const ElementIdentifier element_id) const {
    return nullptr;
  }
  [[nodiscard]] virtual const SheetCellAdapter *sheet_cell_adapter(
      [[maybe_unused]] const ElementIdentifier element_id) const {
    return nullptr;
  }
  [[nodiscard]] virtual const MasterPageAdapter *master_page_adapter(
      [[maybe_unused]] const ElementIdentifier element_id) const {
    return nullptr;
  }
  [[nodiscard]] virtual const LineBreakAdapter *line_break_adapter(
      [[maybe_unused]] const ElementIdentifier element_id) const {
    return nullptr;
  }
  [[nodiscard]] virtual const ParagraphAdapter *
  paragraph_adapter([[maybe_unused]] const ElementIdentifier element_id) const {
    return nullptr;
  }
  [[nodiscard]] virtual const SpanAdapter *
  span_adapter([[maybe_unused]] const ElementIdentifier element_id) const {
    return nullptr;
  }
  [[nodiscard]] virtual const TextAdapter *
  text_adapter([[maybe_unused]] const ElementIdentifier element_id) const {
    return nullptr;
  }
  [[nodiscard]] virtual const LinkAdapter *
  link_adapter([[maybe_unused]] const ElementIdentifier element_id) const {
    return nullptr;
  }
  [[nodiscard]] virtual const BookmarkAdapter *
  bookmark_adapter([[maybe_unused]] const ElementIdentifier element_id) const {
    return nullptr;
  }
  [[nodiscard]] virtual const ListAdapter *
  list_adapter([[maybe_unused]] const ElementIdentifier element_id) const {
    return nullptr;
  }
  [[nodiscard]] virtual const ListItemAdapter *
  list_item_adapter([[maybe_unused]] const ElementIdentifier element_id) const {
    return nullptr;
  }
  [[nodiscard]] virtual const TableAdapter *
  table_adapter([[maybe_unused]] const ElementIdentifier element_id) const {
    return nullptr;
  }
  [[nodiscard]] virtual const TableColumnAdapter *table_column_adapter(
      [[maybe_unused]] const ElementIdentifier element_id) const {
    return nullptr;
  }
  [[nodiscard]] virtual const TableRowAdapter *
  table_row_adapter([[maybe_unused]] const ElementIdentifier element_id) const {
    return nullptr;
  }
  [[nodiscard]] virtual const TableCellAdapter *table_cell_adapter(
      [[maybe_unused]] const ElementIdentifier element_id) const {
    return nullptr;
  }
  [[nodiscard]] virtual const FrameAdapter *
  frame_adapter([[maybe_unused]] const ElementIdentifier element_id) const {
    return nullptr;
  }
  [[nodiscard]] virtual const ImageAdapter *
  image_adapter([[maybe_unused]] const ElementIdentifier element_id) const {
    return nullptr;
  }
};

class TextRootAdapter {
public:
  virtual ~TextRootAdapter() = default;

  [[nodiscard]] virtual PageLayout
  text_root_page_layout(ElementIdentifier element_id) const = 0;

  [[nodiscard]] virtual ElementIdentifier
  text_root_first_master_page(ElementIdentifier element_id) const = 0;
};

class SlideAdapter {
public:
  virtual ~SlideAdapter() = default;

  [[nodiscard]] virtual PageLayout
  slide_page_layout(ElementIdentifier element_id) const = 0;

  [[nodiscard]] virtual ElementIdentifier
  slide_master_page(ElementIdentifier element_id) const = 0;

  [[nodiscard]] virtual std::string
  slide_name(ElementIdentifier element_id) const = 0;
};

class PageAdapter {
public:
  virtual ~PageAdapter() = default;

  [[nodiscard]] virtual PageLayout
  page_layout(ElementIdentifier element_id) const = 0;

  [[nodiscard]] virtual ElementIdentifier
  page_master_page(ElementIdentifier element_id) const = 0;

  [[nodiscard]] virtual std::string
  page_name(ElementIdentifier element_id) const = 0;
};

/// A formula's position, repeated or array extent, array flag and expression
/// in the engine's syntax.
using SheetFormulaVisitor = std::function<void(
    std::uint32_t column, std::uint32_t row, const TableDimensions &span,
    bool array, const std::string &formula)>;

/// A cell the file states, as the parser indexed it: its position, the
/// columns and rows a repeat of it stands for, and its element.
using SheetCellVisitor = std::function<void(
    std::uint32_t column, std::uint32_t row, const TableDimensions &repeated,
    ElementIdentifier cell)>;

class SheetAdapter {
public:
  virtual ~SheetAdapter() = default;

  [[nodiscard]] virtual std::string
  sheet_name(ElementIdentifier element_id) const = 0;

  /// Empty where the file states no paper.
  [[nodiscard]] virtual PageLayout
  sheet_page_layout(ElementIdentifier element_id) const = 0;

  [[nodiscard]] virtual TableDimensions
  sheet_dimensions(ElementIdentifier element_id) const = 0;
  [[nodiscard]] virtual TableDimensions
  sheet_content(ElementIdentifier element_id,
                std::optional<TableDimensions> range) const = 0;

  [[nodiscard]] virtual ElementIdentifier
  sheet_cell(ElementIdentifier element_id, std::uint32_t column,
             std::uint32_t row) const = 0;
  [[nodiscard]] virtual ElementIdentifier
  sheet_first_shape(ElementIdentifier element_id) const = 0;

  /// Calls @p visitor for every cell of the sheet stating a formula, once per
  /// cell the file spells — a repeated run at its first position, so the grid
  /// a repeat stands for is never walked. Visits none by default.
  virtual void sheet_visit_formulas(
      [[maybe_unused]] const ElementIdentifier element_id,
      [[maybe_unused]] const SheetFormulaVisitor &visitor) const {}

  /// Calls @p visitor for every cell the file states, a repeat once, in no
  /// set order. False where the engine visits none.
  virtual bool
  sheet_visit_cells([[maybe_unused]] const ElementIdentifier element_id,
                    [[maybe_unused]] const SheetCellVisitor &visitor) const {
    return false;
  }

  /// Writes @p value into the cell at (@p column, @p row). A value stating
  /// nothing clears it.
  /// @throws UnsupportedOperation where the engine cannot write, the cell is
  ///         absent, repeated, covered, holding a formula or richer markup, or
  ///         @p value holds a formula.
  virtual void sheet_set_cell(ElementIdentifier element_id,
                              std::uint32_t column, std::uint32_t row,
                              const CellValue &value) const = 0;
  /// Writes a formatted result without replacing the formula. An unknown
  /// result invalidates the cache or requests recalculation on load.
  /// @throws UnsupportedOperation if writing is unsupported or the cell has
  /// no formula or is repeated.
  virtual void
  sheet_set_result([[maybe_unused]] ElementIdentifier element_id,
                   [[maybe_unused]] std::uint32_t column,
                   [[maybe_unused]] std::uint32_t row,
                   [[maybe_unused]] const CellValue &result) const {
    throw UnsupportedOperation();
  }
  /// @ref sheet_set_result for a cell an array formula fills, other than the
  /// one that states the formula. The caller knows the range it fills.
  /// @throws UnsupportedOperation if writing is unsupported, or the file
  /// states no such cell or a formula in it.
  virtual void
  sheet_set_array_result([[maybe_unused]] ElementIdentifier element_id,
                         [[maybe_unused]] std::uint32_t column,
                         [[maybe_unused]] std::uint32_t row,
                         [[maybe_unused]] const CellValue &result) const {
    throw UnsupportedOperation();
  }
  /// States the set fields of @p cell_style and @p text_style on the cell at
  /// (@p column, @p row) and leaves the rest. The cell's content is untouched.
  virtual void
  sheet_set_cell_style([[maybe_unused]] ElementIdentifier element_id,
                       [[maybe_unused]] std::uint32_t column,
                       [[maybe_unused]] std::uint32_t row,
                       [[maybe_unused]] const TableCellStyle &cell_style,
                       [[maybe_unused]] const TextStyle &text_style) const {
    throw UnsupportedOperation();
  }
  /// States the set fields on every cell of @p row, also the ones past what
  /// the file states, and on the cells of it that state their own style.
  virtual void
  sheet_set_row_style([[maybe_unused]] ElementIdentifier element_id,
                      [[maybe_unused]] std::uint32_t row,
                      [[maybe_unused]] const TableCellStyle &cell_style,
                      [[maybe_unused]] const TextStyle &text_style) const {
    throw UnsupportedOperation();
  }
  /// The same for every cell of @p column.
  virtual void
  sheet_set_column_style([[maybe_unused]] ElementIdentifier element_id,
                         [[maybe_unused]] std::uint32_t column,
                         [[maybe_unused]] const TableCellStyle &cell_style,
                         [[maybe_unused]] const TextStyle &text_style) const {
    throw UnsupportedOperation();
  }

  /// Inserts @p count empty rows at @p row, shifting cells and references.
  /// @throws UnsupportedOperation if unsupported, cutting a merge or pushing
  /// a cell off the grid.
  virtual void sheet_insert_rows([[maybe_unused]] ElementIdentifier element_id,
                                 [[maybe_unused]] std::uint32_t row,
                                 [[maybe_unused]] std::uint32_t count) const {
    throw UnsupportedOperation();
  }
  /// Deletes @p count rows at @p row, shifting cells and references up.
  /// References to deleted cells become `#REF!`.
  /// @throws UnsupportedOperation if unsupported or cutting a merge.
  virtual void sheet_delete_rows([[maybe_unused]] ElementIdentifier element_id,
                                 [[maybe_unused]] std::uint32_t row,
                                 [[maybe_unused]] std::uint32_t count) const {
    throw UnsupportedOperation();
  }

  /// Inserts @p count empty columns at @p column, shifting cells and
  /// references.
  /// @throws UnsupportedOperation if unsupported, cutting a merge or pushing
  /// a cell off the grid.
  virtual void
  sheet_insert_columns([[maybe_unused]] ElementIdentifier element_id,
                       [[maybe_unused]] std::uint32_t column,
                       [[maybe_unused]] std::uint32_t count) const {
    throw UnsupportedOperation();
  }
  /// Deletes @p count columns at @p column, shifting cells and references
  /// left. References to deleted cells become `#REF!`.
  /// @throws UnsupportedOperation if unsupported or cutting a merge.
  virtual void
  sheet_delete_columns([[maybe_unused]] ElementIdentifier element_id,
                       [[maybe_unused]] std::uint32_t column,
                       [[maybe_unused]] std::uint32_t count) const {
    throw UnsupportedOperation();
  }

  [[nodiscard]] virtual TableStyle
  sheet_style(ElementIdentifier element_id) const = 0;
  [[nodiscard]] virtual TableColumnStyle
  sheet_column_style(ElementIdentifier element_id,
                     std::uint32_t column) const = 0;
  [[nodiscard]] virtual TableRowStyle
  sheet_row_style(ElementIdentifier element_id, std::uint32_t row) const = 0;
  [[nodiscard]] virtual TableCellStyle
  sheet_cell_style(ElementIdentifier element_id, std::uint32_t column,
                   std::uint32_t row) const = 0;
  /// The format code the cell at the position shows a number in, an empty
  /// one too. Nothing for an engine that states none.
  [[nodiscard]] virtual std::optional<std::string>
  sheet_number_format([[maybe_unused]] ElementIdentifier element_id,
                      [[maybe_unused]] std::uint32_t column,
                      [[maybe_unused]] std::uint32_t row) const {
    return std::nullopt;
  }
};

class SheetCellAdapter {
public:
  virtual ~SheetCellAdapter() = default;

  [[nodiscard]] virtual TablePosition
  sheet_cell_position(ElementIdentifier element_id) const = 0;

  [[nodiscard]] virtual bool
  sheet_cell_is_covered(ElementIdentifier element_id) const = 0;
  [[nodiscard]] virtual TableDimensions
  sheet_cell_span(ElementIdentifier element_id) const = 0;
  [[nodiscard]] virtual ValueType
  sheet_cell_value_type(ElementIdentifier element_id) const = 0;
  [[nodiscard]] virtual CellValue
  sheet_cell_value(ElementIdentifier element_id) const = 0;
  /// The format code the cell shows a number in, nothing for an engine that
  /// states none.
  [[nodiscard]] virtual std::optional<std::string> sheet_cell_number_format(
      [[maybe_unused]] ElementIdentifier element_id) const {
    return std::nullopt;
  }
  /// The columns and rows an array formula fills, where the cell states one.
  [[nodiscard]] virtual std::optional<TableDimensions>
  sheet_cell_array_span([[maybe_unused]] ElementIdentifier element_id) const {
    return std::nullopt;
  }
};

class MasterPageAdapter {
public:
  virtual ~MasterPageAdapter() = default;

  [[nodiscard]] virtual PageLayout
  master_page_page_layout(ElementIdentifier element_id) const = 0;
};

class LineBreakAdapter {
public:
  virtual ~LineBreakAdapter() = default;

  [[nodiscard]] virtual TextStyle
  line_break_style(ElementIdentifier element_id) const = 0;
};

class ParagraphAdapter {
public:
  virtual ~ParagraphAdapter() = default;

  [[nodiscard]] virtual ParagraphStyle
  paragraph_style(ElementIdentifier element_id) const = 0;
  [[nodiscard]] virtual TextStyle
  paragraph_text_style(ElementIdentifier element_id) const = 0;
  /// Writes `text_align` of @p style, which is set, on the paragraph.
  virtual void
  paragraph_set_style([[maybe_unused]] const ElementIdentifier element_id,
                      [[maybe_unused]] const ParagraphStyle &style) const {
    throw UnsupportedOperation();
  }

  /// Splits @p element_id after @p after_id - one of its descendants, or null
  /// to move every child - into a new paragraph of the same style.
  virtual ElementIdentifier
  paragraph_split([[maybe_unused]] const ElementIdentifier element_id,
                  [[maybe_unused]] const ElementIdentifier after_id) const {
    throw UnsupportedOperation();
  }

  /// Takes the children of the paragraph after @p element_id and removes it.
  virtual void paragraph_merge_next(
      [[maybe_unused]] const ElementIdentifier element_id) const {
    throw UnsupportedOperation();
  }

  /// An empty paragraph after @p element_id, carrying the same style.
  virtual ElementIdentifier paragraph_insert_after(
      [[maybe_unused]] const ElementIdentifier element_id) const {
    throw UnsupportedOperation();
  }
};

class SpanAdapter {
public:
  virtual ~SpanAdapter() = default;

  [[nodiscard]] virtual TextStyle
  span_style(ElementIdentifier element_id) const = 0;
};

class TextAdapter {
public:
  virtual ~TextAdapter() = default;

  [[nodiscard]] virtual std::string
  text_content(ElementIdentifier element_id) const = 0;
  virtual void
  text_set_content([[maybe_unused]] const ElementIdentifier element_id,
                   [[maybe_unused]] const std::string &text) const {
    throw UnsupportedOperation();
  }

  /// A run beside @p element_id, in the same parent, so it takes the same
  /// style.
  virtual ElementIdentifier
  text_insert([[maybe_unused]] const ElementIdentifier element_id,
              [[maybe_unused]] const Placement where,
              [[maybe_unused]] const std::string &text) const {
    throw UnsupportedOperation();
  }

  [[nodiscard]] virtual TextStyle
  text_style(ElementIdentifier element_id) const = 0;
  /// States the set fields of @p style on the run and leaves the rest. A run
  /// sharing its style container with a sibling gets one of its own first.
  virtual void
  text_set_style([[maybe_unused]] const ElementIdentifier element_id,
                 [[maybe_unused]] const TextStyle &style) const {
    throw UnsupportedOperation();
  }
};

class LinkAdapter {
public:
  virtual ~LinkAdapter() = default;

  [[nodiscard]] virtual std::string
  link_href(ElementIdentifier element_id) const = 0;
};

class BookmarkAdapter {
public:
  virtual ~BookmarkAdapter() = default;

  [[nodiscard]] virtual std::string
  bookmark_name(ElementIdentifier element_id) const = 0;
};

class ListAdapter {
public:
  virtual ~ListAdapter() = default;

  [[nodiscard]] virtual ListType
  list_type(ElementIdentifier element_id) const = 0;
};

class ListItemAdapter {
public:
  virtual ~ListItemAdapter() = default;

  [[nodiscard]] virtual TextStyle
  list_item_style(ElementIdentifier element_id) const = 0;

  [[nodiscard]] virtual std::string
  list_item_marker(ElementIdentifier element_id) const = 0;

  [[nodiscard]] virtual std::optional<std::uint32_t>
  list_item_number(ElementIdentifier element_id) const = 0;
};

class TableAdapter {
public:
  virtual ~TableAdapter() = default;

  [[nodiscard]] virtual TableDimensions
  table_dimensions(ElementIdentifier element_id) const = 0;

  [[nodiscard]] virtual ElementIdentifier
  table_first_column(ElementIdentifier element_id) const = 0;
  [[nodiscard]] virtual ElementIdentifier
  table_first_row(ElementIdentifier element_id) const = 0;

  [[nodiscard]] virtual TableStyle
  table_style(ElementIdentifier element_id) const = 0;
};

class TableColumnAdapter {
public:
  virtual ~TableColumnAdapter() = default;

  [[nodiscard]] virtual TableColumnStyle
  table_column_style(ElementIdentifier element_id) const = 0;
};

class TableRowAdapter {
public:
  virtual ~TableRowAdapter() = default;

  [[nodiscard]] virtual TableRowStyle
  table_row_style(ElementIdentifier element_id) const = 0;
};

class TableCellAdapter {
public:
  virtual ~TableCellAdapter() = default;

  [[nodiscard]] virtual bool
  table_cell_is_covered(ElementIdentifier element_id) const = 0;
  [[nodiscard]] virtual TableDimensions
  table_cell_span(ElementIdentifier element_id) const = 0;
  [[nodiscard]] virtual ValueType
  table_cell_value_type(ElementIdentifier element_id) const = 0;

  [[nodiscard]] virtual TableCellStyle
  table_cell_style(ElementIdentifier element_id) const = 0;
};

class FrameAdapter {
public:
  virtual ~FrameAdapter() = default;

  /// The three shape readers default: an engine that only makes plain frames
  /// says nothing.
  [[nodiscard]] virtual ShapeType
  frame_shape_type([[maybe_unused]] const ElementIdentifier element_id) const {
    return ShapeType::none;
  }
  [[nodiscard]] virtual std::optional<DrawingPath>
  frame_path([[maybe_unused]] const ElementIdentifier element_id) const {
    return {};
  }
  [[nodiscard]] virtual std::optional<DrawingLine>
  frame_line([[maybe_unused]] const ElementIdentifier element_id) const {
    return {};
  }

  [[nodiscard]] virtual AnchorType
  frame_anchor_type(ElementIdentifier element_id) const = 0;
  [[nodiscard]] virtual std::optional<Measure>
  frame_x(ElementIdentifier element_id) const = 0;
  [[nodiscard]] virtual std::optional<Measure>
  frame_y(ElementIdentifier element_id) const = 0;
  [[nodiscard]] virtual std::optional<Measure>
  frame_width(ElementIdentifier element_id) const = 0;
  [[nodiscard]] virtual std::optional<Measure>
  frame_height(ElementIdentifier element_id) const = 0;
  [[nodiscard]] virtual std::optional<std::int32_t>
  frame_z_index(ElementIdentifier element_id) const = 0;
  [[nodiscard]] virtual std::optional<DrawingTransform>
  frame_transform(ElementIdentifier element_id) const = 0;

  [[nodiscard]] virtual GraphicStyle
  frame_style(ElementIdentifier element_id) const = 0;
};

class ImageAdapter {
public:
  virtual ~ImageAdapter() = default;

  [[nodiscard]] virtual bool
  image_is_internal(ElementIdentifier element_id) const = 0;
  [[nodiscard]] virtual std::optional<odr::File>
  image_file(ElementIdentifier element_id) const = 0;
  [[nodiscard]] virtual std::string
  image_href(ElementIdentifier element_id) const = 0;
};

} // namespace odr::internal::abstract
