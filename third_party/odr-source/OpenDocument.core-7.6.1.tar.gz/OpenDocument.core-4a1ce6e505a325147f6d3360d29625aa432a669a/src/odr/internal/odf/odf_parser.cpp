#include <odr/internal/odf/odf_parser.hpp>

#include <odr/internal/common/table_cursor.hpp>
#include <odr/internal/odf/odf_element_registry.hpp>
#include <odr/internal/odf/odf_table.hpp>

#include <string_view>
#include <unordered_map>

#include <pugixml.hpp>

namespace odr::internal::odf {

namespace {

using TreeParser = std::function<std::tuple<ElementIdentifier, pugi::xml_node>(
    ElementRegistry &registry, pugi::xml_node node)>;
using ChildrenParser =
    std::function<void(ElementRegistry &registry, ElementIdentifier parent_id,
                       pugi::xml_node node)>;

std::tuple<ElementIdentifier, pugi::xml_node>
parse_any_element_tree(ElementRegistry &registry, pugi::xml_node node);

void parse_any_element_children(ElementRegistry &registry,
                                const ElementIdentifier parent_id,
                                const pugi::xml_node node) {
  for (pugi::xml_node child_node = node.first_child(); child_node;) {
    if (auto [child_id, next_sibling] =
            parse_any_element_tree(registry, child_node);
        child_id == null_element_id) {
      child_node = child_node.next_sibling();
    } else {
      registry.append_child(parent_id, child_id);
      child_node = next_sibling;
    }
  }
}

std::tuple<ElementIdentifier, pugi::xml_node>
parse_element_tree(ElementRegistry &registry, const ElementType type,
                   const pugi::xml_node node,
                   const ChildrenParser &children_parser) {
  if (!node) {
    return {null_element_id, pugi::xml_node()};
  }

  const auto &[element_id, _] = registry.create_element(type, node);

  children_parser(registry, element_id, node);

  return {element_id, node.next_sibling()};
}

std::tuple<ElementIdentifier, pugi::xml_node>
parse_shape_tree(ElementRegistry &registry, const ShapeType shape_type,
                 const pugi::xml_node node,
                 const ChildrenParser &children_parser) {
  if (!node) {
    return {null_element_id, pugi::xml_node()};
  }

  const auto &[element_id, _] = registry.create_shape_element(shape_type, node);

  children_parser(registry, element_id, node);

  return {element_id, node.next_sibling()};
}

bool is_text_node(const pugi::xml_node node) {
  if (!node) {
    return false;
  }
  if (node.type() == pugi::node_pcdata) {
    return true;
  }

  const std::string name = node.name();

  if (name == "text:s") {
    return true;
  }
  if (name == "text:tab") {
    return true;
  }

  return false;
}

std::tuple<ElementIdentifier, pugi::xml_node>
parse_text_element(ElementRegistry &registry, const pugi::xml_node first) {
  if (!first) {
    return {null_element_id, pugi::xml_node()};
  }

  pugi::xml_node last = first;
  for (; is_text_node(last.next_sibling()); last = last.next_sibling()) {
  }

  const auto &[element_id, unused1, unused2] =
      registry.create_text_element(first, last);

  return {element_id, last.next_sibling()};
}

std::tuple<ElementIdentifier, pugi::xml_node>
parse_table_row(ElementRegistry &registry, const pugi::xml_node node) {
  if (!node) {
    return {null_element_id, pugi::xml_node()};
  }

  const auto &[element_id, _] =
      registry.create_element(ElementType::table_row, node);

  for (const pugi::xml_node cell_node : node.children()) {
    // TODO log warning if repeated
    if (auto [cell_id, _] = parse_any_element_tree(registry, cell_node);
        cell_id != null_element_id) {
      registry.append_child(element_id, cell_id);
    }
  }

  return {element_id, node.next_sibling()};
}

std::tuple<ElementIdentifier, pugi::xml_node>
parse_table(ElementRegistry &registry, const pugi::xml_node node) {
  if (!node) {
    return {null_element_id, pugi::xml_node()};
  }

  const auto &[element_id, _, table] = registry.create_table_element(node);

  // TODO inflate table first?

  for_each_table_column(node, [&](const pugi::xml_node column_node) {
    const std::uint32_t repeat =
        column_node.attribute("table:number-columns-repeated").as_uint(1);
    for (std::uint32_t i = 0; i < repeat; ++i) {
      // TODO mark as repeated
      auto [column_id, _] = parse_any_element_tree(registry, column_node);
      registry.append_column(element_id, column_id);
    }
  });

  for_each_table_row(node, [&](const pugi::xml_node row_node) {
    // TODO log warning if repeated
    auto [row_id, _] = parse_any_element_tree(registry, row_node);
    registry.append_child(element_id, row_id);
  });

  return {element_id, node.next_sibling()};
}

/// Empty: no content, no value, no formula and no span beyond the one cell.
/// A formula cell whose result an edit dropped states no content.
bool is_cell_empty(const pugi::xml_node cell_node) {
  return !cell_node.first_child() &&
         !cell_node.attribute("office:value-type") &&
         !cell_node.attribute("table:formula") &&
         cell_node.attribute("table:number-columns-spanned").as_uint(1) <= 1 &&
         cell_node.attribute("table:number-rows-spanned").as_uint(1) <= 1;
}

/// The element a cell node already carries, so a reindex keeps it.
using SheetCellElements = std::unordered_map<const void *, ElementIdentifier>;

/// Builds @p sheet's row and cell index off its dom. A cell node in
/// @p existing keeps that element; one that is not gets a fresh one.
void index_sheet_rows(ElementRegistry &registry,
                      const ElementIdentifier sheet_id,
                      ElementRegistry::Sheet &sheet, const pugi::xml_node node,
                      const SheetCellElements &existing) {
  TableCursor cursor;

  for_each_table_row(node, [&](const pugi::xml_node row_node) {
    const std::uint32_t rows_repeated =
        row_node.attribute("table:number-rows-repeated").as_uint(1);

    sheet.register_row(cursor.row(), rows_repeated, row_node);

    // the column a cell node starts at, counting every cell node of the row
    std::uint32_t stated_column = 0;
    for (const pugi::xml_node cell_node : row_node.children()) {
      const std::string_view kind = cell_node.name();
      const std::uint32_t columns_repeated =
          cell_node.attribute("table:number-columns-repeated").as_uint(1);
      if (kind == "table:covered-table-cell") {
        // a span accounts for the cell it covers, an array formula's range
        // does not ([ODF 1.2] 19.684)
        if (cursor.column() <= stated_column) {
          cursor.add_cell(1, 1, columns_repeated);
        }
        stated_column += columns_repeated;
        continue;
      }
      if (kind != "table:table-cell") {
        continue;
      }
      stated_column += columns_repeated;
      const std::uint32_t colspan =
          cell_node.attribute("table:number-columns-spanned").as_uint(1);
      const std::uint32_t rowspan =
          cell_node.attribute("table:number-rows-spanned").as_uint(1);
      const bool is_repeated = columns_repeated > 1 || rows_repeated > 1;

      ElementIdentifier cell_id = null_element_id;
      const auto kept = existing.find(cell_node.internal_object());
      if (kept != std::end(existing)) {
        cell_id = kept->second;
        ElementRegistry::SheetCell &cell =
            registry.sheet_cell_element_at(cell_id);
        cell.position = cursor.position();
        cell.is_repeated = is_repeated;
      } else if (!is_cell_empty(cell_node)) {
        const auto &[id, unused1, unused2] = registry.create_sheet_cell_element(
            cell_node, cursor.position(), is_repeated);
        cell_id = id;
        registry.append_sheet_cell(sheet_id, cell_id);
        parse_any_element_children(registry, cell_id, cell_node);
      }

      sheet.register_cell(cursor.column(), cursor.row(), columns_repeated,
                          rows_repeated, cell_node, cell_id);

      cursor.add_cell(colspan, rowspan, columns_repeated);
    }

    cursor.add_row(rows_repeated);
  });

  sheet.dimensions.rows = cursor.row();
}

/// One entry per row and per cell node at most - repeats collapse onto one.
void reserve_sheet(ElementRegistry::Sheet &sheet, const pugi::xml_node node) {
  std::size_t rows = 0;
  std::size_t cells = 0;
  for_each_table_row(node, [&](const pugi::xml_node row_node) {
    ++rows;
    for ([[maybe_unused]] const pugi::xml_node cell_node :
         row_node.children("table:table-cell")) {
      ++cells;
    }
  });

  sheet.rows.reserve(rows);
  sheet.cells.reserve(cells);
}

std::tuple<ElementIdentifier, pugi::xml_node>
parse_sheet(ElementRegistry &registry, const pugi::xml_node node) {
  if (!node) {
    return {null_element_id, pugi::xml_node()};
  }

  const auto &[element_id, _, sheet] = registry.create_sheet_element(node);

  reserve_sheet(sheet, node);

  TableCursor cursor;

  for_each_table_column(node, [&](const pugi::xml_node column_node) {
    const std::uint32_t columns_repeated =
        column_node.attribute("table:number-columns-repeated").as_uint(1);

    sheet.register_column(cursor.column(), columns_repeated, column_node);

    cursor.add_column(columns_repeated);
  });

  sheet.dimensions.columns = cursor.column();
  cursor = {};

  index_sheet_rows(registry, element_id, sheet, node, {});

  for (const pugi::xml_node shape_node :
       node.child("table:shapes").children()) {
    if (auto [shape_id, _] = parse_any_element_tree(registry, shape_node);
        shape_id != null_element_id) {
      registry.append_shape(element_id, shape_id);
    }
  }

  return {element_id, node.next_sibling()};
}

/// A `draw:image` beside a `draw:object` is the object's replacement
/// (10.4.6.2); the object draws itself, and the two would else stack.
std::tuple<ElementIdentifier, pugi::xml_node>
parse_replaceable_image(ElementRegistry &registry, const pugi::xml_node node) {
  if (node.parent().child("draw:object")) {
    return {null_element_id, pugi::xml_node()};
  }
  return parse_element_tree(registry, ElementType::image, node,
                            parse_any_element_children);
}

/// `draw:circle` / `draw:ellipse`: a full one is the box, one that
/// `draw:kind` (19.212) cuts needs the path its arc traces.
std::tuple<ElementIdentifier, pugi::xml_node>
parse_elliptical_element(ElementRegistry &registry, const pugi::xml_node node) {
  const std::string_view kind = node.attribute("draw:kind").value();
  const ShapeType shape_type =
      (kind == "arc" || kind == "cut" || kind == "section")
          ? ShapeType::custom
          : ShapeType::ellipse;
  return parse_shape_tree(registry, shape_type, node,
                          parse_any_element_children);
}

void parse_presentation_children(ElementRegistry &registry,
                                 const ElementIdentifier root_id,
                                 const pugi::xml_node node) {
  for (const pugi::xml_node child_node : node.children("draw:page")) {
    auto [child_id, _] = parse_element_tree(
        registry, ElementType::slide, child_node, parse_any_element_children);
    registry.append_child(root_id, child_id);
  }
}

void parse_spreadsheet_children(ElementRegistry &registry,
                                const ElementIdentifier root_id,
                                const pugi::xml_node node) {
  for (const pugi::xml_node child_node : node.children("table:table")) {
    auto [child_id, _] = parse_sheet(registry, child_node);
    registry.append_child(root_id, child_id);
  }
}

void parse_drawing_children(ElementRegistry &registry,
                            const ElementIdentifier root_id,
                            const pugi::xml_node node) {
  for (const pugi::xml_node child_node : node.children("draw:page")) {
    auto [child_id, _] = parse_element_tree(
        registry, ElementType::page, child_node, parse_any_element_children);
    registry.append_child(root_id, child_id);
  }
}

std::tuple<ElementIdentifier, pugi::xml_node>
parse_any_element_tree(ElementRegistry &registry, const pugi::xml_node node) {
  const auto create_default_tree_parser =
      [](const ElementType type,
         const ChildrenParser &children_parser = parse_any_element_children) {
        return [type, children_parser](ElementRegistry &r,
                                       const pugi::xml_node n) {
          return parse_element_tree(r, type, n, children_parser);
        };
      };
  const auto create_shape_tree_parser = [](const ShapeType shape_type) {
    return [shape_type](ElementRegistry &r, const pugi::xml_node n) {
      return parse_shape_tree(r, shape_type, n, parse_any_element_children);
    };
  };

  static std::unordered_map<std::string, TreeParser> parser_table{
      {"office:text", create_default_tree_parser(ElementType::root)},
      {"office:presentation",
       create_default_tree_parser(ElementType::root,
                                  parse_presentation_children)},
      {"office:spreadsheet",
       create_default_tree_parser(ElementType::root,
                                  parse_spreadsheet_children)},
      {"office:drawing",
       create_default_tree_parser(ElementType::root, parse_drawing_children)},
      {"text:p", create_default_tree_parser(ElementType::paragraph)},
      {"text:h", create_default_tree_parser(ElementType::paragraph)},
      {"text:span", create_default_tree_parser(ElementType::span)},
      {"text:s", parse_text_element},
      {"text:tab", parse_text_element},
      {"text:line-break", create_default_tree_parser(ElementType::line_break)},
      {"text:a", create_default_tree_parser(ElementType::link)},
      {"text:bookmark", create_default_tree_parser(ElementType::bookmark)},
      {"text:bookmark-start",
       create_default_tree_parser(ElementType::bookmark)},
      {"text:list", create_default_tree_parser(ElementType::list)},
      {"text:list-header", create_default_tree_parser(ElementType::list_item)},
      {"text:list-item", create_default_tree_parser(ElementType::list_item)},
      {"text:index-title", create_default_tree_parser(ElementType::group)},
      {"text:table-of-content", create_default_tree_parser(ElementType::group)},
      {"text:illustration-index",
       create_default_tree_parser(ElementType::group)},
      {"text:index-body", create_default_tree_parser(ElementType::group)},
      // A `draw:measure` writes its label as `text:measure` runs.
      {"text:measure", create_default_tree_parser(ElementType::group)},
      // No `text:soft-page-break`: [OpenDocument] 5.1.1 records the
      // producer's own layout there, not an authored break, which is
      // `fo:break-before` on the paragraph style.
      {"text:date", create_default_tree_parser(ElementType::group)},
      {"text:time", create_default_tree_parser(ElementType::group)},
      {"text:section", create_default_tree_parser(ElementType::group)},
      //{"text:page-number", create_tree_parser(ElementType::group)},
      //{"text:page-continuation", create_tree_parser(ElementType::group)},
      {"table:table", parse_table},
      {"table:table-column",
       create_default_tree_parser(ElementType::table_column)},
      {"table:table-row", parse_table_row},
      {"table:table-cell", create_default_tree_parser(ElementType::table_cell)},
      {"table:covered-table-cell",
       create_default_tree_parser(ElementType::table_cell)},
      {"draw:frame", create_default_tree_parser(ElementType::frame)},
      {"draw:image", parse_replaceable_image},
      // An embedded object renders as the image its own part is drawn to.
      {"draw:object", create_default_tree_parser(ElementType::image)},
      {"draw:rect", create_shape_tree_parser(ShapeType::rect)},
      {"draw:line", create_shape_tree_parser(ShapeType::line)},
      {"draw:circle", parse_elliptical_element},
      {"draw:custom-shape", create_shape_tree_parser(ShapeType::custom)},
      // A shape whose geometry is given rather than named is a custom shape.
      {"draw:path", create_shape_tree_parser(ShapeType::custom)},
      {"draw:polygon", create_shape_tree_parser(ShapeType::custom)},
      {"draw:polyline", create_shape_tree_parser(ShapeType::custom)},
      {"draw:regular-polygon", create_shape_tree_parser(ShapeType::custom)},
      {"draw:connector", create_shape_tree_parser(ShapeType::custom)},
      {"draw:caption", create_shape_tree_parser(ShapeType::rect)},
      {"draw:measure", create_shape_tree_parser(ShapeType::line)},
      {"draw:ellipse", parse_elliptical_element},
      {"draw:text-box", create_default_tree_parser(ElementType::group)},
      {"draw:g", create_default_tree_parser(ElementType::frame)},
      {"draw:a", create_default_tree_parser(ElementType::link)},
      {"style:master-page",
       create_default_tree_parser(ElementType::master_page)}};

  if (node.type() == pugi::xml_node_type::node_pcdata) {
    return parse_text_element(registry, node);
  }

  if (const auto constructor_it = parser_table.find(node.name());
      constructor_it != std::end(parser_table)) {
    return constructor_it->second(registry, node);
  }

  return {null_element_id, pugi::xml_node()};
}

} // namespace

} // namespace odr::internal::odf

namespace odr::internal {

ElementIdentifier odf::parse_tree(ElementRegistry &registry,
                                  const pugi::xml_node node) {
  auto [root, _] = parse_any_element_tree(registry, node);
  return root;
}

void odf::reindex_sheet(ElementRegistry &registry,
                        const ElementIdentifier sheet_id) {
  ElementRegistry::Sheet &sheet = registry.sheet_element_at(sheet_id);

  SheetCellElements existing;
  existing.reserve(sheet.cells.size());
  for (const ElementRegistry::Sheet::Cell &cell : sheet.cells) {
    if (cell.element_id != null_element_id) {
      existing.emplace(cell.node.internal_object(), cell.element_id);
    }
  }

  const pugi::xml_node node = registry.element_at(sheet_id).node;

  sheet.columns.clear();
  std::uint32_t column = 0;
  for_each_table_column(node, [&](const pugi::xml_node column_node) {
    const std::uint32_t repeated =
        column_node.attribute("table:number-columns-repeated").as_uint(1);
    sheet.register_column(column, repeated, column_node);
    column += repeated;
  });
  sheet.dimensions.columns = column;

  sheet.rows.clear();
  sheet.cells.clear();
  index_sheet_rows(registry, sheet_id, sheet, node, existing);
}

} // namespace odr::internal
