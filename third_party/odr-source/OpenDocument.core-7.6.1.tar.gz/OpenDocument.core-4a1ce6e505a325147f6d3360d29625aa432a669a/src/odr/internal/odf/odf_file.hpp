#pragma once

#include <odr/file.hpp>

#include <odr/internal/abstract/file.hpp>
#include <odr/internal/odf/odf_manifest.hpp>

#include <memory>
#include <string>

namespace odr::internal::abstract {
class Document;
} // namespace odr::internal::abstract

namespace odr::internal::abstract {
class ReadableFilesystem;
}

namespace odr::internal::zip::util {
class Archive;
} // namespace odr::internal::zip::util

namespace odr::internal::odf {

class OpenDocumentFile final : public virtual abstract::DocumentFile {
public:
  /// @p archive is the package @p filesystem reads from lazily, if any.
  /// @p source is the file the package was read from, if any.
  explicit OpenDocumentFile(
      std::shared_ptr<abstract::ReadableFilesystem> filesystem,
      std::shared_ptr<zip::util::Archive> archive = nullptr,
      std::shared_ptr<abstract::File> source = nullptr);

  [[nodiscard]] std::shared_ptr<abstract::File> file() const noexcept override;

  [[nodiscard]] FileType file_type() const noexcept override;
  [[nodiscard]] std::string_view mimetype() const noexcept override;
  [[nodiscard]] FileMeta file_meta() const override;

  [[nodiscard]] DocumentType document_type() const override;

  [[nodiscard]] std::shared_ptr<abstract::File> thumbnail() const override;

  [[nodiscard]] bool password_encrypted() const noexcept override;
  [[nodiscard]] EncryptionState encryption_state() const noexcept override;
  [[nodiscard]] std::shared_ptr<DecodedFile>
  decrypt(const std::string &password) const override;

  [[nodiscard]] bool is_decodable() const noexcept override;

  [[nodiscard]] std::shared_ptr<abstract::Document> document() const override;

private:
  std::shared_ptr<abstract::ReadableFilesystem> m_filesystem;
  std::shared_ptr<zip::util::Archive> m_archive;
  std::shared_ptr<abstract::File> m_source;
  EncryptionState m_encryption_state{EncryptionState::not_encrypted};
  FileMeta m_file_meta;
  Manifest m_manifest;
};

} // namespace odr::internal::odf
