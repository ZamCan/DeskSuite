#include <odr/internal/odf/odf_style.hpp>

#include <odr/internal/odf/odf_document.hpp>
#include <odr/internal/odf/odf_parser.hpp>
#include <odr/internal/xml/xml_util.hpp>

#include <array>
#include <cstdlib>
#include <cstring>
#include <ranges>
#include <stdexcept>
#include <string>
#include <string_view>
#include <unordered_map>
#include <utility>
#include <vector>

#include <fmt/format.h>

namespace odr::internal::odf {

namespace {

std::optional<std::string> read_string(const pugi::xml_attribute attribute) {
  if (attribute) {
    return attribute.value();
  }
  return {};
}

std::optional<Measure> read_measure(const pugi::xml_attribute attribute) {
  if (attribute) {
    try {
      return Measure(attribute.value());
    } catch (...) { // NOLINT(bugprone-empty-catch)
      // TODO log
    }
  }
  return {};
}

/// A percentage margin is of @p parent, the same margin in the parent style
/// ([OpenDocument] 16.2) - not of the containing block, which is what css
/// reads a `%` as.
std::optional<Measure> resolve_margin(const Measure &margin,
                                      const std::optional<Measure> &parent) {
  if (margin.unit().name() != "%") {
    return margin;
  }
  if (!parent.has_value()) {
    return {};
  }
  return Measure(parent->magnitude() * margin.magnitude() * 1e-2,
                 parent->unit());
}

std::optional<FontWeight>
read_font_weight(const pugi::xml_attribute attribute) {
  if (!attribute) {
    return {};
  }
  const char *value = attribute.value();
  if (std::strcmp("normal", value) == 0) {
    return FontWeight::normal;
  }
  if (std::strcmp("bold", value) == 0) {
    return FontWeight::bold;
  }
  return {};
}

std::optional<FontStyle> read_font_style(const pugi::xml_attribute attribute) {
  if (!attribute) {
    return {};
  }
  const char *value = attribute.value();
  if (std::strcmp("normal", value) == 0) {
    return FontStyle::normal;
  }
  if (std::strcmp("italic", value) == 0) {
    return FontStyle::italic;
  }
  return {};
}

/// first component of `style:text-position`: "super", "sub" or a signed
/// percent offset from the baseline
std::optional<FontPosition>
read_font_position(const pugi::xml_attribute attribute) {
  if (!attribute) {
    return {};
  }
  const char *value = attribute.value();
  if (std::strncmp("super", value, 5) == 0) {
    return FontPosition::super;
  }
  if (std::strncmp("sub", value, 3) == 0) {
    return FontPosition::sub;
  }
  char *end{nullptr};
  const double offset = std::strtod(value, &end);
  if (end == value) {
    return {};
  }
  if (offset > 0) {
    return FontPosition::super;
  }
  if (offset < 0) {
    return FontPosition::sub;
  }
  return FontPosition::normal;
}

/// [OpenDocument] 20.86/20.87.
std::optional<BreakType> read_break(const pugi::xml_attribute attribute) {
  if (!attribute) {
    return {};
  }
  const char *value = attribute.value();
  if (std::strcmp("page", value) == 0) {
    return BreakType::page;
  }
  if (std::strcmp("column", value) == 0) {
    return BreakType::column;
  }
  // `auto`: a style overriding an inherited break has to say so
  return BreakType::none;
}

/// [OpenDocument] 20.386. `start`/`end` are absolute here, unlike `w:jc`'s.
std::optional<TextAlign> read_text_align(const pugi::xml_attribute attribute) {
  if (!attribute) {
    return {};
  }
  const char *value = attribute.value();
  if (std::strcmp("left", value) == 0 || std::strcmp("start", value) == 0) {
    return TextAlign::left;
  }
  if (std::strcmp("right", value) == 0 || std::strcmp("end", value) == 0) {
    return TextAlign::right;
  }
  if (std::strcmp("center", value) == 0) {
    return TextAlign::center;
  }
  if (std::strcmp("justify", value) == 0) {
    return TextAlign::justify;
  }
  return {};
}

/// [OpenDocument] 20.404. The vertical modes name no horizontal direction.
std::optional<TextDirection>
read_text_direction(const pugi::xml_attribute attribute) {
  if (!attribute) {
    return {};
  }
  const char *value = attribute.value();
  if (std::strcmp("lr-tb", value) == 0 || std::strcmp("lr", value) == 0) {
    return TextDirection::left_to_right;
  }
  if (std::strcmp("rl-tb", value) == 0 || std::strcmp("rl", value) == 0) {
    return TextDirection::right_to_left;
  }
  return {};
}

std::optional<VerticalAlign>
read_vertical_align(const pugi::xml_attribute attribute) {
  if (!attribute) {
    return {};
  }
  const char *value = attribute.value();
  if (std::strcmp("top", value) == 0) {
    return VerticalAlign::top;
  }
  if (std::strcmp("middle", value) == 0) {
    return VerticalAlign::middle;
  }
  if (std::strcmp("bottom", value) == 0) {
    return VerticalAlign::bottom;
  }
  return {};
}

std::optional<TextWrap> read_text_wrap(const pugi::xml_attribute attribute) {
  if (!attribute) {
    return {};
  }
  const char *value = attribute.value();
  if (std::strcmp("none", value) == 0) {
    return TextWrap::none;
  }
  if (std::strcmp("biggest", value) == 0 ||
      std::strcmp("dynamic", value) == 0 || std::strcmp("left", value) == 0 ||
      std::strcmp("parallel", value) == 0) {
    return TextWrap::before;
  }
  if (std::strcmp("right", value) == 0) {
    return TextWrap::after;
  }
  if (std::strcmp("run-through", value) == 0) {
    return TextWrap::run_through;
  }
  return {};
}

/// `from-*` names no side - the offset places those frames.
std::optional<HorizontalAlign>
read_horizontal_position(const pugi::xml_attribute attribute) {
  if (!attribute) {
    return {};
  }
  const char *value = attribute.value();
  if (std::strcmp("left", value) == 0 || std::strcmp("inside", value) == 0) {
    return HorizontalAlign::left;
  }
  if (std::strcmp("center", value) == 0) {
    return HorizontalAlign::center;
  }
  if (std::strcmp("right", value) == 0 || std::strcmp("outside", value) == 0) {
    return HorizontalAlign::right;
  }
  return {};
}

std::optional<PrintOrientation>
read_print_orientation(const pugi::xml_attribute attribute) {
  if (!attribute) {
    return {};
  }
  const char *value = attribute.value();
  if (std::strcmp("portrait", value) == 0) {
    return PrintOrientation::portrait;
  }
  if (std::strcmp("landscape", value) == 0) {
    return PrintOrientation::landscape;
  }
  return {};
}

std::optional<Color> read_color(const pugi::xml_attribute attribute) {
  if (!attribute) {
    return {};
  }
  const char *value = attribute.value();
  if (std::strcmp("transparent", value) == 0) {
    return {}; // TODO use alpha
  }
  if (value[0] == '#') {
    const std::uint32_t color = std::strtoull(&value[1], nullptr, 16);
    return Color(static_cast<std::uint8_t>(color >> 16),
                 static_cast<std::uint8_t>(color >> 8),
                 static_cast<std::uint8_t>(color >> 0));
  }
  // TODO log
  // throw std::invalid_argument("# missing");
  return {};
}

/// A stated `transparent` clears the @p inherited background.
std::optional<Color> read_background(const pugi::xml_attribute attribute,
                                     const std::optional<Color> &inherited) {
  if (std::strcmp("transparent", attribute.value()) == 0) {
    return {};
  }
  const std::optional<Color> color = read_color(attribute);
  return color.has_value() ? color : inherited;
}

/// A stated `none` clears the @p inherited border.
std::optional<std::string>
read_border(const pugi::xml_attribute attribute,
            const std::optional<std::string> &inherited) {
  if (!attribute) {
    return inherited;
  }
  if (std::strcmp("none", attribute.value()) == 0) {
    return {};
  }
  return attribute.value();
}

PageLayout read_page_layout(const pugi::xml_node node) {
  PageLayout result;

  const pugi::xml_node page_layout_properties =
      node.child("style:page-layout-properties");

  result.width =
      read_measure(page_layout_properties.attribute("fo:page-width"));
  result.height =
      read_measure(page_layout_properties.attribute("fo:page-height"));
  result.print_orientation = read_print_orientation(
      page_layout_properties.attribute("style:print-orientation"));
  result.direction = read_text_direction(
      page_layout_properties.attribute("style:writing-mode"));
  result.margin = DirectionalStyle(
      read_measure(page_layout_properties.attribute("fo:margin")));
  if (const pugi::xml_attribute margin_right =
          page_layout_properties.attribute("fo:margin-right")) {
    result.margin.right = read_measure(margin_right);
  }
  if (const pugi::xml_attribute margin_top =
          page_layout_properties.attribute("fo:margin-top")) {
    result.margin.top = read_measure(margin_top);
  }
  if (const pugi::xml_attribute margin_left =
          page_layout_properties.attribute("fo:margin-left")) {
    result.margin.left = read_measure(margin_left);
  }
  if (const pugi::xml_attribute margin_bottom =
          page_layout_properties.attribute("fo:margin-bottom")) {
    result.margin.bottom = read_measure(margin_bottom);
  }

  return result;
}

void read_font_face(const char *name, const pugi::xml_node node,
                    TextStyle &result) {
  if (!node) {
    result.font_name = name;
    return;
  }

  result.font_name = node.attribute("svg:font-family").value();
}

} // namespace

Style::Style() = default;

Style::Style(const StyleRegistry *registry, std::string family,
             const pugi::xml_node node)
    : m_name{std::move(family)}, m_node{node} {
  resolve_style_(registry);
}

Style::Style(const StyleRegistry *registry, std::string name,
             const pugi::xml_node node, const Style *parent,
             const Style *family)
    : m_name{std::move(name)}, m_node{node} {
  if (const Style *copy_from = parent != nullptr ? parent : family;
      copy_from != nullptr) {
    m_resolved = copy_from->m_resolved;
  }

  resolve_style_(registry);
}

std::string Style::name() const { return m_name; }

const ResolvedStyle &Style::resolved() const { return m_resolved; }

void Style::resolve_style_(const StyleRegistry *registry) {
  // TODO use override?
  resolve_text_style_(registry, m_node, m_resolved.text_style);
  resolve_paragraph_style_(m_node, m_resolved.paragraph_style);
  resolve_table_style_(m_node, m_resolved.table_style);
  resolve_table_column_style_(m_node, m_resolved.table_column_style);
  resolve_table_row_style_(m_node, m_resolved.table_row_style);
  resolve_table_cell_style_(m_node, m_resolved.table_cell_style);
  resolve_graphic_style_(m_node, m_resolved.graphic_style);
}

void Style::resolve_text_style_(const StyleRegistry *registry,
                                const pugi::xml_node node, TextStyle &result) {
  const pugi::xml_node text_properties = node.child("style:text-properties");

  if (const pugi::xml_attribute font_name =
          text_properties.attribute("style:font-name")) {
    read_font_face(font_name.value(),
                   registry->font_face_node(font_name.value()), result);
  }
  if (const std::optional<Measure> font_size =
          read_measure(text_properties.attribute("fo:font-size"));
      font_size.has_value()) {
    // A percentage is of the parent's size, resolved here rather than passed
    // to css - the parent style is not on the element in the render.
    if (font_size->unit().name() != "%") {
      result.font_size = font_size;
    } else {
      if (const std::optional<Measure> parent_font_size = result.font_size;
          parent_font_size.has_value()) {
        result.font_size = Measure(parent_font_size->magnitude() *
                                       font_size->magnitude() * 1e-2,
                                   parent_font_size->unit());
      }
    }
  }
  if (const std::optional<FontWeight> font_weight =
          read_font_weight(text_properties.attribute("fo:font-weight"));
      font_weight.has_value()) {
    result.font_weight = font_weight;
  }
  if (const std::optional<FontStyle> font_style =
          read_font_style(text_properties.attribute("fo:font-style"));
      font_style.has_value()) {
    result.font_style = font_style;
  }
  if (const pugi::xml_attribute font_underline =
          text_properties.attribute("style:text-underline-style");
      font_underline) {
    result.font_underline = std::strcmp("none", font_underline.value()) != 0;
  }
  if (const pugi::xml_attribute font_line_through =
          text_properties.attribute("style:text-line-through-style");
      font_line_through) {
    result.font_line_through =
        std::strcmp("none", font_line_through.value()) != 0;
  }
  if (const std::optional<std::string> font_shadow =
          read_string(text_properties.attribute("fo:text-shadow"));
      font_shadow.has_value()) {
    result.font_shadow = font_shadow;
  }
  if (const std::optional<Color> font_color =
          read_color(text_properties.attribute("fo:color"));
      font_color.has_value()) {
    result.font_color = font_color;
  }
  result.background_color =
      read_background(text_properties.attribute("fo:background-color"),
                      result.background_color);
  if (const pugi::xml_attribute text_position =
          text_properties.attribute("style:text-position")) {
    if (const std::optional<FontPosition> font_position =
            read_font_position(text_position);
        font_position.has_value()) {
      result.font_position = font_position;
    }
    // optional second component: relative font size in percent
    if (const char *scale = std::strchr(text_position.value(), ' ');
        scale != nullptr && result.font_size.has_value()) {
      char *end{nullptr};
      if (const double magnitude = std::strtod(scale + 1, &end);
          end != scale + 1 && magnitude > 0) {
        result.font_size =
            Measure(result.font_size->magnitude() * magnitude * 1e-2,
                    result.font_size->unit());
      }
    }
  }
}

void Style::resolve_paragraph_style_(const pugi::xml_node node,
                                     ParagraphStyle &result) {
  const pugi::xml_node paragraph_properties =
      node.child("style:paragraph-properties");

  // [ODF 1.2] 20.373; LibreOffice drops only the inherited alignment
  if (std::string_view(node.child("style:table-cell-properties")
                           .attribute("style:text-align-source")
                           .value()) == "value-type") {
    result.text_align.reset();
  }
  if (const std::optional<TextAlign> text_align =
          read_text_align(paragraph_properties.attribute("fo:text-align"));
      text_align.has_value()) {
    result.text_align = text_align;
  }
  if (const std::optional<TextDirection> direction = read_text_direction(
          paragraph_properties.attribute("style:writing-mode"));
      direction.has_value()) {
    result.direction = direction;
  }
  // the shorthand is the four sides, each against its own inherited value
  if (const std::optional<Measure> margin =
          read_measure(paragraph_properties.attribute("fo:margin"));
      margin.has_value()) {
    result.margin.right = resolve_margin(*margin, result.margin.right);
    result.margin.top = resolve_margin(*margin, result.margin.top);
    result.margin.left = resolve_margin(*margin, result.margin.left);
    result.margin.bottom = resolve_margin(*margin, result.margin.bottom);
  }
  if (const std::optional<Measure> margin_right =
          read_measure(paragraph_properties.attribute("fo:margin-right"));
      margin_right.has_value()) {
    result.margin.right = resolve_margin(*margin_right, result.margin.right);
  }
  if (const std::optional<Measure> margin_top =
          read_measure(paragraph_properties.attribute("fo:margin-top"));
      margin_top.has_value()) {
    result.margin.top = resolve_margin(*margin_top, result.margin.top);
  }
  if (const std::optional<Measure> margin_left =
          read_measure(paragraph_properties.attribute("fo:margin-left"));
      margin_left.has_value()) {
    result.margin.left = resolve_margin(*margin_left, result.margin.left);
  }
  if (const std::optional<Measure> margin_bottom =
          read_measure(paragraph_properties.attribute("fo:margin-bottom"));
      margin_bottom.has_value()) {
    result.margin.bottom = resolve_margin(*margin_bottom, result.margin.bottom);
  }
  if (const std::optional<Measure> line_height =
          read_measure(paragraph_properties.attribute("fo:line-height"));
      line_height.has_value()) {
    // percent line height is relative to the text font size; the HTML
    // translation emits it as a unitless ratio
    result.line_height = line_height;
  }
  if (const std::optional<Measure> text_indent =
          read_measure(paragraph_properties.attribute("fo:text-indent"));
      text_indent.has_value()) {
    result.text_indent = text_indent;
  }
  if (const std::optional<BreakType> break_before =
          read_break(paragraph_properties.attribute("fo:break-before"));
      break_before.has_value()) {
    result.break_before = break_before;
  }
  if (const std::optional<BreakType> break_after =
          read_break(paragraph_properties.attribute("fo:break-after"));
      break_after.has_value()) {
    result.break_after = break_after;
  }
}

void Style::resolve_table_style_(const pugi::xml_node node,
                                 TableStyle &result) {
  const pugi::xml_node table_properties = node.child("style:table-properties");

  if (const std::optional<Measure> width =
          read_measure(table_properties.attribute("style:width"));
      width.has_value()) {
    result.width = width;
  }
}

void Style::resolve_table_column_style_(const pugi::xml_node node,
                                        TableColumnStyle &result) {
  const pugi::xml_node table_column_properties =
      node.child("style:table-column-properties");

  if (const std::optional<Measure> width =
          read_measure(table_column_properties.attribute("style:column-width"));
      width.has_value()) {
    result.width = width;
  }
}

void Style::resolve_table_row_style_(const pugi::xml_node node,
                                     TableRowStyle &result) {
  const pugi::xml_node table_row_properties =
      node.child("style:table-row-properties");

  if (const std::optional<Measure> height =
          read_measure(table_row_properties.attribute("style:row-height"));
      height.has_value()) {
    result.height = height;
  }
}

void Style::resolve_table_cell_style_(const pugi::xml_node node,
                                      TableCellStyle &result) {
  const pugi::xml_node table_cell_properties =
      node.child("style:table-cell-properties");

  if (const std::optional<VerticalAlign> vertical_align = read_vertical_align(
          table_cell_properties.attribute("style:vertical-align"));
      vertical_align.has_value()) {
    result.vertical_align = vertical_align;
  }
  if (const pugi::xml_attribute wrap_option =
          table_cell_properties.attribute("style:wrap-option")) {
    result.wrap_text = std::strcmp("wrap", wrap_option.value()) == 0;
  }
  result.background_color =
      read_background(table_cell_properties.attribute("fo:background-color"),
                      result.background_color);
  if (const std::optional<Measure> padding =
          read_measure(table_cell_properties.attribute("fo:padding"));
      padding.has_value()) {
    result.padding = DirectionalStyle(padding);
  }
  if (const std::optional<Measure> padding_right =
          read_measure(table_cell_properties.attribute("fo:padding-right"));
      padding_right.has_value()) {
    result.padding.right = padding_right;
  }
  if (const std::optional<Measure> padding_top =
          read_measure(table_cell_properties.attribute("fo:padding-top"));
      padding_top.has_value()) {
    result.padding.top = padding_top;
  }
  if (const std::optional<Measure> padding_left =
          read_measure(table_cell_properties.attribute("fo:padding-left"));
      padding_left.has_value()) {
    result.padding.left = padding_left;
  }
  if (const std::optional<Measure> padding_bottom =
          read_measure(table_cell_properties.attribute("fo:padding-bottom"));
      padding_bottom.has_value()) {
    result.padding.bottom = padding_bottom;
  }
  if (const pugi::xml_attribute border =
          table_cell_properties.attribute("fo:border")) {
    result.border = DirectionalStyle(read_border(border, {}));
  }
  result.border.right = read_border(
      table_cell_properties.attribute("fo:border-right"), result.border.right);
  result.border.top = read_border(
      table_cell_properties.attribute("fo:border-top"), result.border.top);
  result.border.left = read_border(
      table_cell_properties.attribute("fo:border-left"), result.border.left);
  result.border.bottom =
      read_border(table_cell_properties.attribute("fo:border-bottom"),
                  result.border.bottom);
}

void Style::resolve_graphic_style_(const pugi::xml_node node,
                                   GraphicStyle &result) {
  const pugi::xml_node graphic_properties =
      node.child("style:graphic-properties");

  if (const std::optional<Measure> stroke_width =
          read_measure(graphic_properties.attribute("svg:stroke-width"));
      stroke_width.has_value()) {
    result.stroke_width = stroke_width;
  }
  if (const std::optional<Color> stroke_color =
          read_color(graphic_properties.attribute("svg:stroke-color"));
      stroke_color.has_value()) {
    result.stroke_color = stroke_color;
  }
  // `draw:fill` and `draw:fill-color` cascade independently, so the fill state
  // rides in the alpha — see AGENTS.md
  if (const pugi::xml_attribute fill =
          graphic_properties.attribute("draw:fill")) {
    const Color previous = result.fill_color.value_or(Color());
    result.fill_color =
        Color(previous.red, previous.green, previous.blue,
              std::strcmp("solid", fill.value()) == 0 ? 255 : 0);
  }
  if (const std::optional<Color> fill_color =
          read_color(graphic_properties.attribute("draw:fill-color"));
      fill_color.has_value()) {
    result.fill_color =
        Color(fill_color->red, fill_color->green, fill_color->blue,
              result.fill_color.has_value() ? result.fill_color->alpha : 0);
  }
  if (const std::optional<VerticalAlign> vertical_align = read_vertical_align(
          graphic_properties.attribute("draw:textarea-vertical-align"));
      vertical_align.has_value()) {
    result.vertical_align = vertical_align;
  }
  if (const std::optional<TextWrap> text_wrap =
          read_text_wrap(graphic_properties.attribute("style:wrap"));
      text_wrap.has_value()) {
    result.text_wrap = text_wrap;
  }
  // assigned even when it reads as none, so a `from-*` overrides an inherited
  // side rather than keeping it
  if (const pugi::xml_attribute attribute =
          graphic_properties.attribute("style:horizontal-pos")) {
    result.horizontal_position = read_horizontal_position(attribute);
  }
}

StyleRegistry::StyleRegistry() = default;

StyleRegistry::StyleRegistry(Document &document,
                             const pugi::xml_node content_root,
                             const pugi::xml_node styles_root) {
  generate_indices_(content_root, styles_root);
  generate_styles_();
  generate_master_pages_(document);
}

void StyleRegistry::generate_indices_(const pugi::xml_node content_root,
                                      const pugi::xml_node styles_root) {
  generate_indices_(styles_root.child("office:font-face-decls"));
  generate_indices_(styles_root.child("office:styles"));
  generate_indices_(styles_root.child("office:automatic-styles"));
  generate_indices_(styles_root.child("office:master-styles"));

  // content styles
  generate_indices_(content_root.child("office:font-face-decls"));
  generate_indices_(content_root.child("office:automatic-styles"));
}

void StyleRegistry::generate_indices_(const pugi::xml_node node) {
  for (const pugi::xml_node e : node) {
    if (const std::string name = e.name(); name == "style:font-face") {
      m_index_font_face[e.attribute("style:name").value()] = e;
    } else if (name == "style:default-style") {
      m_index_default_style[e.attribute("style:family").value()] = e;
    } else if (name == "style:style") {
      m_index_style[e.attribute("style:name").value()] = e;
    } else if (name.starts_with("number:") && name.ends_with("-style")) {
      m_index_data_style[e.attribute("style:name").value()] = e;
    } else if (name == "text:list-style") {
      m_index_list_style[e.attribute("style:name").value()] = e;
    } else if (name == "text:outline-style") {
      m_index_outline_style[e.attribute("style:name").value()] = e;
    } else if (name == "style:page-layout") {
      m_index_page_layout[e.attribute("style:name").value()] = e;
    } else if (name == "style:master-page") {
      std::string master_page_name = e.attribute("style:name").value();
      m_index_master_page[master_page_name] = e;
      if (!m_first_master_page.has_value()) {
        m_first_master_page = master_page_name;
      }
    }
  }
}

void StyleRegistry::generate_styles_() {
  for (const auto &[name, node] : m_index_default_style) {
    generate_default_style_(name, node);
  }

  for (const auto &[name, node] : m_index_style) {
    generate_style_(name, node);
  }
}

pugi::xml_node
StyleRegistry::data_style_node(const std::string_view name) const {
  const auto it = m_index_data_style.find(std::string(name));
  return it == std::end(m_index_data_style) ? pugi::xml_node() : it->second;
}

pugi::xml_node StyleRegistry::cell_data_style(const char *style_name) const {
  std::size_t remaining = m_index_style.size();
  for (std::string name = style_name != nullptr ? style_name : "";
       !name.empty() && remaining > 0; --remaining) {
    const auto it = m_index_style.find(name);
    if (it == std::end(m_index_style)) {
      break;
    }
    if (const pugi::xml_attribute data_style =
            it->second.attribute("style:data-style-name")) {
      return data_style_node(data_style.value());
    }
    name = it->second.attribute("style:parent-style-name").value();
  }
  return data_style_node(default_style_node("table-cell")
                             .attribute("style:data-style-name")
                             .value());
}

pugi::xml_node
StyleRegistry::default_style_node(const std::string &family) const {
  const auto it = m_index_default_style.find(family);
  return it == std::end(m_index_default_style) ? pugi::xml_node() : it->second;
}

Style *StyleRegistry::generate_default_style_(const std::string &name,
                                              const pugi::xml_node node) {
  std::unique_ptr<Style> &style = m_default_styles[name];
  if (style) {
    return style.get();
  }
  style = std::make_unique<Style>(this, name, node);
  return style.get();
}

/// Walks the `style:parent-style-name` chain onto a stack and builds it from
/// the root down; recursing it costs a stack frame per link.
Style *StyleRegistry::generate_style_(const std::string &name,
                                      const pugi::xml_node node) {
  // the names are the map's own, which keep their addresses across a rehash
  std::vector<std::pair<const std::string *, pugi::xml_node>> chain;

  const std::string *current_name = &name;
  pugi::xml_node current_node = node;
  Style *parent{nullptr};

  while (true) {
    // an entry present but still null means the link is already on this chain
    const auto [style_it, inserted] = m_styles.try_emplace(*current_name);
    if (!inserted) {
      parent = style_it->second.get();
      break;
    }
    chain.emplace_back(&style_it->first, current_node);

    const pugi::xml_attribute parent_attr =
        current_node.attribute("style:parent-style-name");
    if (!parent_attr) {
      break;
    }
    const auto parent_it = m_index_style.find(parent_attr.value());
    if (parent_it == std::end(m_index_style)) {
      break;
    }
    current_name = &parent_it->first;
    current_node = parent_it->second;
  }

  for (const auto &[chain_name, chain_node] : chain | std::views::reverse) {
    Style *family{nullptr};
    if (const pugi::xml_attribute family_attr =
            chain_node.attribute("style:family");
        family_attr) {
      family = generate_default_style_(family_attr.value(), {});
    }

    std::unique_ptr<Style> &style = m_styles[*chain_name];
    style =
        std::make_unique<Style>(this, *chain_name, chain_node, parent, family);
    parent = style.get();
  }

  return parent;
}

void StyleRegistry::generate_master_pages_(Document &document) {
  for (const auto &[name, node] : m_index_master_page) {
    m_master_page_elements[name] =
        parse_tree(document.element_registry(), node);
  }

  if (m_first_master_page.has_value()) {
    m_first_master_page_element = m_master_page_elements[*m_first_master_page];
  }
}

namespace {

/// `#rrggbb`, or `transparent` for a colour with no alpha.
std::string color_value(const Color &color) {
  if (color.alpha == 0) {
    return "transparent";
  }
  return fmt::format("#{:06x}", color.rgb());
}

/// Writes the set fields of @p style as attributes of @p properties, the
/// asian and complex variants beside each western one.
void write_text_properties(pugi::xml_node properties, const TextStyle &style) {
  const auto set = [&](const char *name, const std::string &value) {
    xml::set_attribute(properties, name, value.c_str());
  };

  if (style.font_size.has_value()) {
    const std::string value = style.font_size->to_string();
    set("fo:font-size", value);
    set("style:font-size-asian", value);
    set("style:font-size-complex", value);
  }
  if (style.font_weight.has_value()) {
    const std::string value =
        *style.font_weight == FontWeight::bold ? "bold" : "normal";
    set("fo:font-weight", value);
    set("style:font-weight-asian", value);
    set("style:font-weight-complex", value);
  }
  if (style.font_style.has_value()) {
    const std::string value =
        *style.font_style == FontStyle::italic ? "italic" : "normal";
    set("fo:font-style", value);
    set("style:font-style-asian", value);
    set("style:font-style-complex", value);
  }
  if (style.font_underline.has_value()) {
    set("style:text-underline-style", *style.font_underline ? "solid" : "none");
  }
  if (style.font_line_through.has_value()) {
    set("style:text-line-through-style",
        *style.font_line_through ? "solid" : "none");
  }
  if (style.font_color.has_value()) {
    set("fo:color", color_value(*style.font_color));
  }
  if (style.background_color.has_value()) {
    set("fo:background-color", color_value(*style.background_color));
  }
}

/// The properties child @p name of @p style, made in the order [ODF 1.2]
/// 16.2 gives them where it is missing.
pugi::xml_node properties_of(pugi::xml_node style, const char *name) {
  static constexpr std::array<std::string_view, 3> order{
      "style:table-cell-properties", "style:paragraph-properties",
      "style:text-properties"};
  if (pugi::xml_node existing = style.child(name)) {
    return existing;
  }
  return xml::insert_in_sequence(style, name, order);
}

const char *text_align_value(const TextAlign align) {
  switch (align) {
  case TextAlign::left:
    return "left";
  case TextAlign::right:
    return "right";
  case TextAlign::center:
    return "center";
  case TextAlign::justify:
    return "justify";
  case TextAlign::start:
    return "start";
  case TextAlign::end:
    return "end";
  }
  return "start";
}

const char *text_align_value(const HorizontalAlign align) {
  switch (align) {
  case HorizontalAlign::left:
    return "left";
  case HorizontalAlign::center:
    return "center";
  case HorizontalAlign::right:
    return "right";
  case HorizontalAlign::general:
    break;
  }
  return "left";
}

} // namespace

std::string StyleRegistry::create_cell_style(pugi::xml_node automatic_styles,
                                             const char *base_name,
                                             const TableCellStyle &cell,
                                             const TextStyle &text) {
  const std::string base = base_name != nullptr ? base_name : "";
  const auto key_of = [](const auto &value) {
    return value.has_value() ? std::to_string(static_cast<int>(*value))
                             : std::string("-");
  };
  const std::string key = fmt::format(
      "{}|{}|{}|{}|{}|{}|{}|{}|{}", base,
      cell.background_color.has_value()
          ? fmt::format("{:08x}", cell.background_color->argb())
          : "-",
      key_of(cell.horizontal_align), key_of(text.font_weight),
      key_of(text.font_style), key_of(text.font_underline),
      key_of(text.font_line_through),
      text.font_color.has_value()
          ? fmt::format("{:08x}", text.font_color->argb())
          : "-",
      text.font_size.has_value() ? text.font_size->to_string() : "-");
  if (const auto it = m_created_cell_styles.find(key);
      it != std::end(m_created_cell_styles)) {
    return it->second;
  }

  const pugi::xml_node node = create_style_(
      automatic_styles, base, "table-cell", "ce", m_next_cell_style);
  const std::string name = node.attribute("style:name").value();

  if (cell.background_color.has_value()) {
    xml::set_attribute(properties_of(node, "style:table-cell-properties"),
                       "fo:background-color",
                       color_value(*cell.background_color).c_str());
  }
  if (cell.horizontal_align == HorizontalAlign::general) {
    xml::set_attribute(properties_of(node, "style:table-cell-properties"),
                       "style:text-align-source", "value-type");
    node.child("style:paragraph-properties").remove_attribute("fo:text-align");
  } else if (cell.horizontal_align.has_value()) {
    xml::set_attribute(properties_of(node, "style:table-cell-properties"),
                       "style:text-align-source", "fix");
    xml::set_attribute(properties_of(node, "style:paragraph-properties"),
                       "fo:text-align",
                       text_align_value(*cell.horizontal_align));
  }
  TextStyle text_properties = text;
  text_properties.background_color.reset();
  if (text_properties.font_size.has_value() ||
      text_properties.font_weight.has_value() ||
      text_properties.font_style.has_value() ||
      text_properties.font_underline.has_value() ||
      text_properties.font_line_through.has_value() ||
      text_properties.font_color.has_value()) {
    write_text_properties(properties_of(node, "style:text-properties"),
                          text_properties);
  }

  m_index_style[name] = node;
  generate_style_(name, node);
  m_created_cell_styles.emplace(key, name);
  return name;
}

std::string
StyleRegistry::create_paragraph_style(pugi::xml_node automatic_styles,
                                      const char *base_name,
                                      const ParagraphStyle &style) {
  if (!style.text_align.has_value()) {
    throw std::invalid_argument("paragraph alignment is missing");
  }
  const std::string base = base_name != nullptr ? base_name : "";
  const std::string key =
      fmt::format("{}|{}", base, static_cast<std::int32_t>(*style.text_align));
  if (const auto it = m_created_paragraph_styles.find(key);
      it != std::end(m_created_paragraph_styles)) {
    return it->second;
  }

  const pugi::xml_node node = create_style_(automatic_styles, base, "paragraph",
                                            "P", m_next_paragraph_style);
  const std::string name = node.attribute("style:name").value();

  xml::set_attribute(properties_of(node, "style:paragraph-properties"),
                     "fo:text-align", text_align_value(*style.text_align));

  m_index_style[name] = node;
  generate_style_(name, node);
  m_created_paragraph_styles.emplace(key, name);
  return name;
}

pugi::xml_node StyleRegistry::create_style_(pugi::xml_node automatic_styles,
                                            const std::string &base_name,
                                            const char *family,
                                            const char *prefix,
                                            std::uint32_t &next) {
  std::string name;
  for (;; ++next) {
    name = prefix + std::to_string(next);
    if (!m_index_style.contains(name)) {
      break;
    }
  }

  const auto base_it = m_index_style.find(base_name);
  const pugi::xml_node base_node =
      base_it != std::end(m_index_style) ? base_it->second : pugi::xml_node();
  // an automatic style may be shared, so it is copied; a named one is
  // inherited from
  if (base_node &&
      std::strcmp(base_node.parent().name(), "office:automatic-styles") == 0) {
    pugi::xml_node node = automatic_styles.append_copy(base_node);
    xml::set_attribute(node, "style:name", name.c_str());
    return node;
  }
  pugi::xml_node node = automatic_styles.append_child("style:style");
  node.append_attribute("style:name").set_value(name.c_str());
  node.append_attribute("style:family").set_value(family);
  if (!base_name.empty()) {
    node.append_attribute("style:parent-style-name")
        .set_value(base_name.c_str());
  }
  return node;
}

std::string StyleRegistry::create_text_style(pugi::xml_node automatic_styles,
                                             const char *base_name,
                                             const TextStyle &style) {
  std::string name;
  for (;; ++m_next_text_style) {
    name = "T" + std::to_string(m_next_text_style);
    if (!m_index_style.contains(name)) {
      break;
    }
  }

  pugi::xml_node node = automatic_styles.append_child("style:style");
  node.append_attribute("style:name").set_value(name.c_str());
  node.append_attribute("style:family").set_value("text");

  pugi::xml_node properties;
  if (base_name != nullptr && *base_name != '\0') {
    const auto base_it = m_index_style.find(base_name);
    const pugi::xml_node base =
        base_it != std::end(m_index_style) ? base_it->second : pugi::xml_node();
    // an automatic style may be shared, so it is copied; a named one is
    // inherited from
    if (base &&
        std::strcmp(base.parent().name(), "office:automatic-styles") == 0) {
      if (const pugi::xml_attribute parent =
              base.attribute("style:parent-style-name")) {
        node.append_copy(parent);
      }
      if (const pugi::xml_node base_properties =
              base.child("style:text-properties")) {
        properties = node.append_copy(base_properties);
      }
    } else {
      node.append_attribute("style:parent-style-name").set_value(base_name);
    }
  }
  if (!properties) {
    properties = node.append_child("style:text-properties");
  }
  write_text_properties(properties, style);

  m_index_style[name] = node;
  generate_style_(name, node);
  return name;
}

Style *StyleRegistry::style(const char *name) const {
  if (const auto style_it = m_styles.find(name);
      style_it != std::end(m_styles)) {
    return style_it->second.get();
  }
  return {};
}

PageLayout StyleRegistry::page_layout(const std::string &name) const {
  if (const auto page_layout_it = m_index_page_layout.find(name);
      page_layout_it != std::end(m_index_page_layout)) {
    return read_page_layout(page_layout_it->second);
  }
  return {};
}

pugi::xml_node StyleRegistry::font_face_node(const std::string &name) const {
  if (const auto font_face_it = m_index_font_face.find(name);
      font_face_it != std::end(m_index_font_face)) {
    return font_face_it->second;
  }
  return {};
}

pugi::xml_node StyleRegistry::list_style_node(const std::string &name) const {
  if (const auto list_style_it = m_index_list_style.find(name);
      list_style_it != std::end(m_index_list_style)) {
    return list_style_it->second;
  }
  return {};
}

ElementIdentifier StyleRegistry::master_page(const std::string &name) const {
  if (const auto master_page_elements_it = m_master_page_elements.find(name);
      master_page_elements_it != std::end(m_master_page_elements)) {
    return master_page_elements_it->second;
  }
  return {};
}

ElementIdentifier StyleRegistry::first_master_page() const {
  return m_first_master_page_element;
}

ElementIdentifier
StyleRegistry::master_page_of_style(const char *style_name) const {
  // Bounded against a style naming itself as its own parent.
  for (std::uint32_t depth = 0; depth < 16 && style_name[0] != '\0'; ++depth) {
    const auto style_it = m_index_style.find(style_name);
    if (style_it == std::end(m_index_style)) {
      break;
    }
    const pugi::xml_node node = style_it->second;
    if (const pugi::xml_attribute master_page_name =
            node.attribute("style:master-page-name");
        master_page_name && master_page_name.value()[0] != '\0') {
      return master_page(master_page_name.value());
    }
    style_name = node.attribute("style:parent-style-name").value();
  }
  return {};
}

} // namespace odr::internal::odf
