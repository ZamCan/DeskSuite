#pragma once

#include <odr/definitions.hpp>

#include <odr/internal/common/style.hpp>

#include <any>
#include <cstdint>
#include <memory>
#include <optional>
#include <string>
#include <string_view>
#include <unordered_map>

#include <pugixml.hpp>

namespace odr {
struct PageLayout;
struct GraphicStyle;
struct ParagraphStyle;
struct TableCellStyle;
struct TableColumnStyle;
struct TableRowStyle;
struct TableStyle;
struct TextStyle;
} // namespace odr

namespace odr::internal::odf {
class Document;
class StyleRegistry;

class Style final {
public:
  Style();
  Style(const StyleRegistry *registry, std::string family, pugi::xml_node node);
  /// `parent`/`family` are the already resolved bases to copy from; neither is
  /// retained.
  Style(const StyleRegistry *registry, std::string name, pugi::xml_node node,
        const Style *parent, const Style *family);

  [[nodiscard]] std::string name() const;

  [[nodiscard]] const ResolvedStyle &resolved() const;

private:
  std::string m_name;
  pugi::xml_node m_node;

  ResolvedStyle m_resolved;

  void resolve_style_(const StyleRegistry *registry);

  static void resolve_text_style_(const StyleRegistry *registry,
                                  pugi::xml_node node, TextStyle &result);
  static void resolve_paragraph_style_(pugi::xml_node node,
                                       ParagraphStyle &result);
  static void resolve_table_style_(pugi::xml_node node, TableStyle &result);
  static void resolve_table_column_style_(pugi::xml_node node,
                                          TableColumnStyle &result);
  static void resolve_table_row_style_(pugi::xml_node node,
                                       TableRowStyle &result);
  static void resolve_table_cell_style_(pugi::xml_node node,
                                        TableCellStyle &result);
  static void resolve_graphic_style_(pugi::xml_node node, GraphicStyle &result);
};

class StyleRegistry final {
public:
  StyleRegistry();
  StyleRegistry(Document &document, pugi::xml_node content_root,
                pugi::xml_node styles_root);

  [[nodiscard]] Style *style(const char *name) const;
  /// The data style (`number:number-style` and its kin) named @p name, null
  /// where there is none.
  [[nodiscard]] pugi::xml_node data_style_node(std::string_view name) const;
  /// Resolves a cell data style through its parents and the default
  /// `table-cell` style; null if absent.
  [[nodiscard]] pugi::xml_node cell_data_style(const char *style_name) const;
  /// The `style:default-style` of @p family, null where there is none.
  [[nodiscard]] pugi::xml_node
  default_style_node(const std::string &family) const;

  [[nodiscard]] PageLayout page_layout(const std::string &name) const;

  [[nodiscard]] pugi::xml_node font_face_node(const std::string &name) const;

  [[nodiscard]] pugi::xml_node list_style_node(const std::string &name) const;

  [[nodiscard]] ElementIdentifier master_page(const std::string &name) const;
  [[nodiscard]] ElementIdentifier first_master_page() const;
  /// The master page a style or one of its bases names (20.283); null if none.
  [[nodiscard]] ElementIdentifier
  master_page_of_style(const char *style_name) const;

  /// A text style under @p automatic_styles carrying @p style, under a fresh
  /// name it answers: a copy of the automatic style @p base_name names, a
  /// child of a named one, the delta alone where it is null.
  std::string create_text_style(pugi::xml_node automatic_styles,
                                const char *base_name, const TextStyle &style);
  /// A table-cell style carrying @p cell and @p text, made as a text style is.
  /// Two calls with one base and one delta answer one style.
  std::string create_cell_style(pugi::xml_node automatic_styles,
                                const char *base_name,
                                const TableCellStyle &cell,
                                const TextStyle &text);
  /// A paragraph style carrying the `text_align` of @p style.
  std::string create_paragraph_style(pugi::xml_node automatic_styles,
                                     const char *base_name,
                                     const ParagraphStyle &style);

private:
  /// Where the search for a free `T<n>` name starts.
  std::uint32_t m_next_text_style{1};
  std::uint32_t m_next_cell_style{1};
  std::uint32_t m_next_paragraph_style{1};
  std::unordered_map<std::string, std::string> m_created_cell_styles;
  std::unordered_map<std::string, std::string> m_created_paragraph_styles;

  std::unordered_map<std::string, pugi::xml_node> m_index_font_face;
  std::unordered_map<std::string, pugi::xml_node> m_index_default_style;
  std::unordered_map<std::string, pugi::xml_node> m_index_style;
  std::unordered_map<std::string, pugi::xml_node> m_index_data_style;
  std::unordered_map<std::string, pugi::xml_node> m_index_list_style;
  std::unordered_map<std::string, pugi::xml_node> m_index_outline_style;
  std::unordered_map<std::string, pugi::xml_node> m_index_page_layout;
  std::unordered_map<std::string, pugi::xml_node> m_index_master_page;
  std::optional<std::string> m_first_master_page;

  std::unordered_map<std::string, std::unique_ptr<Style>> m_default_styles;
  std::unordered_map<std::string, std::unique_ptr<Style>> m_styles;

  std::unordered_map<std::string, ElementIdentifier> m_master_page_elements;
  ElementIdentifier m_first_master_page_element{};

  void generate_indices_(pugi::xml_node content_root,
                         pugi::xml_node styles_root);
  void generate_indices_(pugi::xml_node node);

  void generate_styles_();
  Style *generate_default_style_(const std::string &name, pugi::xml_node node);
  Style *generate_style_(const std::string &name, pugi::xml_node node);

  void generate_master_pages_(Document &);

  /// A fresh `<prefix><n>` style: a copy of the automatic style @p base_name,
  /// or a child of the named one.
  pugi::xml_node create_style_(pugi::xml_node automatic_styles,
                               const std::string &base_name, const char *family,
                               const char *prefix, std::uint32_t &next);
};

} // namespace odr::internal::odf
