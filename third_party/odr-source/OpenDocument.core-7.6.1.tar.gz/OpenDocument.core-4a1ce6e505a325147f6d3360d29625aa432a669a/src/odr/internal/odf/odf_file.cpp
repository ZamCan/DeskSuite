#include <odr/internal/odf/odf_file.hpp>

#include <odr/exceptions.hpp>

#include <odr/internal/abstract/filesystem.hpp>
#include <odr/internal/odf/odf_crypto.hpp>
#include <odr/internal/odf/odf_document.hpp>
#include <odr/internal/xml/xml_util.hpp>

namespace odr::internal::abstract {
class Document;
class File;
} // namespace odr::internal::abstract

namespace odr::internal::odf {

OpenDocumentFile::OpenDocumentFile(
    std::shared_ptr<abstract::ReadableFilesystem> filesystem,
    std::shared_ptr<zip::util::Archive> archive,
    std::shared_ptr<abstract::File> source)
    : m_filesystem{std::move(filesystem)}, m_archive{std::move(archive)},
      m_source{std::move(source)} {
  if (m_filesystem->exists(AbsPath("/META-INF/manifest.xml"))) {
    const pugi::xml_document manifest =
        xml::parse(*m_filesystem, AbsPath("/META-INF/manifest.xml"));

    m_file_meta = parse_file_meta(*m_filesystem, &manifest, false);
    m_manifest = parse_manifest(manifest);
  } else {
    m_file_meta = parse_file_meta(*m_filesystem, nullptr, false);
  }

  if (m_file_meta.password_encrypted) {
    m_encryption_state = EncryptionState::encrypted;
  }
}

std::shared_ptr<abstract::File> OpenDocumentFile::file() const noexcept {
  return m_source;
}

FileType OpenDocumentFile::file_type() const noexcept {
  return m_file_meta.type;
}

std::string_view OpenDocumentFile::mimetype() const noexcept {
  return m_file_meta.mimetype;
}

FileMeta OpenDocumentFile::file_meta() const { return m_file_meta; }

DocumentType OpenDocumentFile::document_type() const {
  return m_file_meta.document_type;
}

std::shared_ptr<abstract::File> OpenDocumentFile::thumbnail() const {
  // [OpenDocument] 3.9. Encrypted alongside everything else.
  static const AbsPath path("/Thumbnails/thumbnail.png");
  if (m_encryption_state == EncryptionState::encrypted ||
      !m_filesystem->is_file(path)) {
    return {};
  }
  return m_filesystem->open(path);
}

bool OpenDocumentFile::password_encrypted() const noexcept {
  return m_file_meta.password_encrypted;
}

EncryptionState OpenDocumentFile::encryption_state() const noexcept {
  return m_encryption_state;
}

std::shared_ptr<abstract::DecodedFile>
OpenDocumentFile::decrypt(const std::string &password) const {
  if (m_encryption_state != EncryptionState::encrypted) {
    throw NotEncryptedError();
  }

  auto decrypted_filesystem = odf::decrypt(m_filesystem, m_manifest, password);
  auto decrypted_file = std::make_shared<OpenDocumentFile>(*this);
  decrypted_file->m_filesystem = std::move(decrypted_filesystem);
  decrypted_file->m_archive = nullptr;
  decrypted_file->m_file_meta =
      parse_file_meta(*decrypted_file->m_filesystem, nullptr, true);
  decrypted_file->m_encryption_state = EncryptionState::decrypted;
  return decrypted_file;
}

bool OpenDocumentFile::is_decodable() const noexcept {
  return m_encryption_state != EncryptionState::encrypted;
}

std::shared_ptr<abstract::Document> OpenDocumentFile::document() const {
  if (m_encryption_state == EncryptionState::encrypted) {
    throw FileEncryptedError();
  }

  switch (file_type()) {
  case FileType::opendocument_text:
    return std::make_shared<Document>(m_file_meta.type, DocumentType::text,
                                      m_filesystem, m_encryption_state,
                                      m_archive);
  case FileType::opendocument_presentation:
    return std::make_shared<Document>(m_file_meta.type,
                                      DocumentType::presentation, m_filesystem,
                                      m_encryption_state, m_archive);
  case FileType::opendocument_spreadsheet:
    return std::make_shared<Document>(m_file_meta.type,
                                      DocumentType::spreadsheet, m_filesystem,
                                      m_encryption_state, m_archive);
  case FileType::opendocument_graphics:
    return std::make_shared<Document>(m_file_meta.type, DocumentType::drawing,
                                      m_filesystem, m_encryption_state,
                                      m_archive);
  default:
    throw UnsupportedFileType(file_type());
  }
}

} // namespace odr::internal::odf
