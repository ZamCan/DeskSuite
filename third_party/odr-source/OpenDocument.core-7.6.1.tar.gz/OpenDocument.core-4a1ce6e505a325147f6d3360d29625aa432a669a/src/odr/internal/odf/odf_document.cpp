#include <odr/internal/odf/odf_document.hpp>

#include <odr/document_element.hpp>
#include <odr/exceptions.hpp>
#include <odr/sheet_position.hpp>

#include <odr/internal/abstract/filesystem.hpp>
#include <odr/internal/common/element_adapter.hpp>
#include <odr/internal/common/file.hpp>
#include <odr/internal/common/sheet_dependencies.hpp>
#include <odr/internal/common/table_cursor.hpp>
#include <odr/internal/crypto/crypto_util.hpp>
#include <odr/internal/formula/formula_parser.hpp>
#include <odr/internal/formula/formula_value.hpp>
#include <odr/internal/number_format/number_format.hpp>
#include <odr/internal/odf/odf_chart.hpp>
#include <odr/internal/odf/odf_element_registry.hpp>
#include <odr/internal/odf/odf_geometry.hpp>
#include <odr/internal/odf/odf_list.hpp>
#include <odr/internal/odf/odf_number_format.hpp>
#include <odr/internal/odf/odf_parser.hpp>
#include <odr/internal/odf/odf_sheet_references.hpp>
#include <odr/internal/odf/odf_table.hpp>
#include <odr/internal/util/number_util.hpp>
#include <odr/internal/util/string_util.hpp>
#include <odr/internal/xml/xml_tree_edit.hpp>
#include <odr/internal/xml/xml_util.hpp>
#include <odr/internal/zip/zip_archive.hpp>

#include <algorithm>
#include <array>
#include <charconv>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <functional>
#include <limits>
#include <mutex>
#include <ostream>
#include <span>
#include <sstream>
#include <string_view>
#include <unordered_map>
#include <unordered_set>

#include <fmt/format.h>

namespace odr::internal::odf {

namespace {
std::unique_ptr<abstract::ElementAdapter>
create_element_adapter(Document &document, ElementRegistry &registry);
}

Document::Document(const FileType file_type, const DocumentType document_type,
                   std::shared_ptr<abstract::ReadableFilesystem> files,
                   const EncryptionState encryption_state,
                   std::shared_ptr<zip::util::Archive> archive)
    : internal::Document(file_type, document_type, std::move(files),
                         encryption_state, std::move(archive)) {
  m_content_xml = xml::parse(*m_files, AbsPath("/content.xml"));

  if (m_files->exists(AbsPath("/styles.xml"))) {
    m_styles_xml = xml::parse(*m_files, AbsPath("/styles.xml"));
  }

  init_(m_content_xml.document_element(), m_styles_xml.document_element());
}

Document::Document(const FileType file_type, const DocumentType document_type,
                   pugi::xml_document flat_xml)
    : internal::Document(file_type, document_type, nullptr),
      m_content_xml{std::move(flat_xml)} {
  // content and styles live under the one root
  init_(m_content_xml.document_element(), m_content_xml.document_element());
}

void Document::init_(const pugi::xml_node content_root,
                     const pugi::xml_node styles_root) {
  m_root_element = parse_tree(m_element_registry,
                              content_root.child("office:body").first_child());

  m_style_registry = StyleRegistry(*this, content_root, styles_root);

  resolve_list_numbering(m_element_registry, m_style_registry, m_root_element);

  m_element_adapter = create_element_adapter(*this, m_element_registry);
}

ElementRegistry &Document::element_registry() { return m_element_registry; }

StyleRegistry &Document::style_registry() { return m_style_registry; }

const ElementRegistry &Document::element_registry() const {
  return m_element_registry;
}

const StyleRegistry &Document::style_registry() const {
  return m_style_registry;
}

bool Document::is_editable() const noexcept { return true; }

/// `zxx` and `none` state no language. LibreOffice writes `qlt` and the whole
/// tag in `style:rfc-language-tag` where the three attributes cannot spell it.
std::optional<std::string> Document::locale() const {
  const auto stated = [](const pugi::xml_attribute attribute) {
    const std::string_view value = attribute.value();
    return !value.empty() && value != "zxx" && value != "none";
  };
  for (const char *family : {"table-cell", "paragraph", "graphic"}) {
    const pugi::xml_node properties =
        m_style_registry.default_style_node(family).child(
            "style:text-properties");
    if (const pugi::xml_attribute tag =
            properties.attribute("style:rfc-language-tag");
        stated(tag)) {
      return tag.value();
    }
    const pugi::xml_attribute language = properties.attribute("fo:language");
    if (!stated(language)) {
      continue;
    }
    std::string result = language.value();
    for (const char *subtag : {"fo:script", "fo:country"}) {
      if (const pugi::xml_attribute attribute = properties.attribute(subtag);
          stated(attribute)) {
        result += '-';
        result += attribute.value();
      }
    }
    return result;
  }
  return std::nullopt;
}

bool Document::is_savable(const bool encrypted) const noexcept {
  return !encrypted && !is_decrypted();
}

void Document::save(std::ostream &out) const {
  if (!is_savable(false)) {
    throw UnsupportedOperation();
  }

  // no package to rebuild: a flat document is the one tree, and `save` puts
  // back the declaration the parse dropped
  if (m_files == nullptr) {
    m_content_xml.save(out, "", pugi::format_raw);
    return;
  }

  // TODO this would decrypt/inflate and encrypt/deflate again
  zip::ZipArchive archive;

  // `mimetype` has to be the first file and uncompressed
  if (m_files->is_file(AbsPath("/mimetype"))) {
    archive.insert_file(std::end(archive), RelPath("mimetype"),
                        m_files->open(AbsPath("/mimetype")), 0);
  }

  for (auto walker = m_files->file_walker(AbsPath("/")); !walker->end();
       walker->next()) {
    const AbsPath &abs_path = walker->path();
    RelPath rel_path = abs_path.rebase(AbsPath("/"));
    if (abs_path == Path("/mimetype")) {
      continue;
    }
    if (walker->is_directory()) {
      archive.insert_directory(std::end(archive), rel_path);
      continue;
    }
    if (const auto part = m_parts.find(abs_path); part != m_parts.end()) {
      std::stringstream content;
      part->second.print(content, "", pugi::format_raw);
      archive.insert_file(std::end(archive), rel_path,
                          std::make_shared<MemoryFile>(content.str()));
      continue;
    }
    if (abs_path == Path("/content.xml") || abs_path == Path("/styles.xml")) {
      // TODO stream
      std::stringstream content;
      (abs_path == Path("/content.xml") ? m_content_xml : m_styles_xml)
          .print(content, "", pugi::format_raw);
      auto tmp = std::make_shared<MemoryFile>(content.str());
      archive.insert_file(std::end(archive), rel_path, tmp);
      continue;
    }
    archive.insert_file(std::end(archive), rel_path, m_files->open(abs_path));
  }

  archive.save(out);
}

pugi::xml_node Document::part(const AbsPath &path) {
  if (path == Path("/styles.xml")) {
    return m_styles_xml.document_element();
  }
  if (path == Path("/content.xml")) {
    return m_content_xml.document_element();
  }
  if (m_files == nullptr || !m_files->is_file(path)) {
    return {};
  }
  if (const auto parsed = m_parts.find(path); parsed != m_parts.end()) {
    return parsed->second.document_element();
  }
  pugi::xml_document document = xml::parse(*m_files, path);
  return m_parts.emplace(path, std::move(document))
      .first->second.document_element();
}

void Document::save(std::ostream & /*out*/, const char * /*password*/) const {
  throw UnsupportedOperation();
}

namespace {

/// Absent or unparsable geometry yields nullopt rather than throwing.
std::optional<Measure> read_measure(const pugi::xml_attribute attribute) {
  if (!attribute) {
    return std::nullopt;
  }
  try {
    return Measure(attribute.value());
  } catch (...) { // NOLINT(bugprone-empty-catch)
    return std::nullopt;
  }
}

/// Same, for attributes the API reports unconditionally.
Measure read_measure_or_zero(const pugi::xml_attribute attribute) {
  return read_measure(attribute).value_or(Measure(0, DynamicUnit()));
}

/// The unit an `svg:d` with no view box is written in (19.180).
Measure hundredth_millimetres(const double value) {
  return Measure(value / 100.0, DynamicUnit("mm"));
}

/// A `draw:connector` states no box of its own, so its path is what places it.
std::optional<DrawingPath> connector_box(const pugi::xml_node node) {
  if (std::strcmp(node.name(), "draw:connector") != 0) {
    return {};
  }
  return read_path(node);
}

/// Every attribute a cell states its value with, so a cell left with its
/// formula alone states no result. [ODF 1.2] 19.385 and around it.
void remove_value_attributes(pugi::xml_node node) {
  static constexpr std::array stated = {
      "office:value-type", "office:value",      "office:boolean-value",
      "office:date-value", "office:time-value", "office:string-value",
      "office:currency",   "calcext:value-type"};
  for (const char *attribute : stated) {
    node.remove_attribute(attribute);
  }
}

/// Boolean `&` uses words from LibreOffice 27.2 (commit 5663da9fa7).
/// Unknown for other generators or 27.2 alpha builds.
std::optional<bool> boolean_word_of(std::string_view generator) {
  for (const std::string_view name : {"LibreOffice/", "LibreOfficeDev/"}) {
    if (!generator.starts_with(name)) {
      continue;
    }
    generator.remove_prefix(name.size());
    std::uint32_t major = 0;
    std::uint32_t minor = 0;
    const auto [dot, major_error] = std::from_chars(
        generator.data(), generator.data() + generator.size(), major);
    if (major_error != std::errc{} ||
        dot == generator.data() + generator.size() || *dot != '.' ||
        std::from_chars(dot + 1, generator.data() + generator.size(), minor)
                .ec != std::errc{}) {
      return std::nullopt;
    }
    if (major < 27 || (major == 27 && minor < 2)) {
      return false;
    }
    const std::string_view version = generator.substr(0, generator.find('$'));
    if (major == 27 && minor == 2 &&
        version.find("alpha") != std::string_view::npos) {
      return std::nullopt;
    }
    return true;
  }
  return std::nullopt;
}

/// [ODF 1.2] 19.385 `office:value-type`. A cell stating neither a type nor
/// any content is empty, which a cell holding an empty text is not.
ValueType value_type_of(const pugi::xml_node node) {
  // LibreOffice states an error a formula computed as a text of its spelling
  if (std::strcmp("error", node.attribute("calcext:value-type").value()) == 0) {
    return ValueType::error;
  }
  const char *value_type = node.attribute("office:value-type").value();
  // a percentage and a currency state their number in `office:value` too
  if (std::strcmp("float", value_type) == 0 ||
      std::strcmp("percentage", value_type) == 0 ||
      std::strcmp("currency", value_type) == 0) {
    return ValueType::float_number;
  }
  if (std::strcmp("boolean", value_type) == 0) {
    return ValueType::boolean;
  }
  if (std::strcmp("date", value_type) == 0) {
    return ValueType::date;
  }
  if (std::strcmp("time", value_type) == 0) {
    return ValueType::time;
  }
  if (*value_type == '\0' && !node.first_child()) {
    return ValueType::unknown;
  }
  return ValueType::string;
}

/// An `office:date-value`, `YYYY-MM-DD` with an optional `THH:MM:SS` and a
/// fraction of a second, as days since 1899-12-30. Nothing where it is none.
std::optional<double> date_days(const std::string_view text) {
  if (text.size() < 10 || text[4] != '-' || text[7] != '-') {
    return std::nullopt;
  }
  const auto year =
      util::number::parse_integer<std::int64_t>(text.substr(0, 4));
  const auto month =
      util::number::parse_integer<std::uint32_t>(text.substr(5, 2));
  const auto day =
      util::number::parse_integer<std::uint32_t>(text.substr(8, 2));
  if (!year.has_value() || !month.has_value() || !day.has_value() ||
      *month < 1 || *month > 12 || *day < 1 || *day > 31) {
    return std::nullopt;
  }
  const double result =
      static_cast<double>(number_format::days_from_civil(*year, *month, *day));
  if (text.size() == 10) {
    return result;
  }
  if (text.size() < 19 || text[10] != 'T' || text[13] != ':' ||
      text[16] != ':') {
    return std::nullopt;
  }
  const auto hours =
      util::number::parse_integer<std::uint32_t>(text.substr(11, 2));
  const auto minutes =
      util::number::parse_integer<std::uint32_t>(text.substr(14, 2));
  std::string_view seconds = text.substr(17);
  if (seconds.ends_with('Z')) {
    seconds.remove_suffix(1);
  }
  const std::optional<double> second = util::number::parse(seconds);
  if (!hours.has_value() || !minutes.has_value() || !second.has_value()) {
    return std::nullopt;
  }
  return result + (*hours * 3600.0 + *minutes * 60.0 + *second) / 86400;
}

/// An `office:time-value`, an ISO 8601 duration such as `PT18H30M00S`, as
/// days. Nothing where it is none.
std::optional<double> duration_days(std::string_view text) {
  const bool negative = text.starts_with('-');
  if (negative) {
    text.remove_prefix(1);
  }
  if (!text.starts_with('P')) {
    return std::nullopt;
  }
  text.remove_prefix(1);
  double result = 0;
  bool time = false;
  while (!text.empty()) {
    if (text.front() == 'T') {
      time = true;
      text.remove_prefix(1);
      continue;
    }
    const std::size_t unit = text.find_first_of("DHMS");
    const std::optional<double> amount =
        unit == std::string_view::npos
            ? std::nullopt
            : util::number::parse(text.substr(0, unit));
    if (!amount.has_value()) {
      return std::nullopt;
    }
    switch (text[unit]) {
    case 'D':
      result += *amount;
      break;
    case 'H':
      result += *amount / 24;
      break;
    case 'M':
      // a month before `T` has no length in days
      if (!time) {
        return std::nullopt;
      }
      result += *amount / 1440;
      break;
    default:
      result += *amount / 86400;
      break;
    }
    text.remove_prefix(unit + 1);
  }
  return negative ? -result : result;
}

/// Seconds with nanosecond precision, omitting a zero fractional part.
std::string seconds_value(const std::int64_t nanoseconds) {
  std::string result = fmt::format("{:02d}", nanoseconds / 1000000000);
  if (const std::int64_t fraction = nanoseconds % 1000000000; fraction != 0) {
    std::string digits = fmt::format("{:09d}", fraction);
    digits.erase(digits.find_last_not_of('0') + 1);
    result += "." + digits;
  }
  return result;
}

/// @p days since 1899-12-30 as an `office:date-value`.
std::string date_value(const double days) {
  constexpr std::int64_t ticks_per_second = 1000000000;
  constexpr std::int64_t ticks_per_day = 86400 * ticks_per_second;
  std::int64_t day = static_cast<std::int64_t>(std::floor(days));
  const std::int64_t ticks = std::llround((days - static_cast<double>(day)) *
                                          static_cast<double>(ticks_per_day));
  day += ticks / ticks_per_day;
  const std::int64_t time = ticks % ticks_per_day;
  const std::int64_t seconds = time / ticks_per_second;
  const auto [year, month, month_day] = number_format::civil_from_days(day);
  std::string result =
      fmt::format("{:04d}-{:02d}-{:02d}", year, month, month_day);
  if (time != 0) {
    result +=
        fmt::format("T{:02d}:{:02d}:{}", seconds / 3600, seconds / 60 % 60,
                    seconds_value(time % (60 * ticks_per_second)));
  }
  return result;
}

/// @p days as an `office:time-value`, preserving fractional seconds.
std::string time_value(const double days) {
  constexpr std::int64_t ticks_per_second = 1000000000;
  const double magnitude = std::abs(days);
  const auto hours = static_cast<std::int64_t>(std::floor(magnitude)) * 24;
  const std::int64_t ticks =
      std::llround(std::fmod(magnitude, 1) * 86400 * ticks_per_second);
  const std::int64_t seconds = ticks / ticks_per_second;
  return fmt::format("{}PT{:02d}H{:02d}M{}S", days < 0 ? "-" : "",
                     hours + seconds / 3600, seconds / 60 % 60,
                     seconds_value(ticks % (60 * ticks_per_second)));
}

/// Whether the engine has a form to write @p value in.
bool writable(const CellValue &value) {
  switch (value.type()) {
  case ValueType::unknown:
  case ValueType::string:
  case ValueType::float_number:
  case ValueType::boolean:
    return true;
  case ValueType::date:
    // the years an `office:date-value` spells in four digits
    return value.has_number() &&
           value.number() >= number_format::days_from_civil(1, 1, 1) &&
           value.number() < number_format::days_from_civil(10000, 1, 1);
  case ValueType::time:
    return value.has_number() &&
           std::abs(value.number()) <
               static_cast<double>(std::numeric_limits<std::int64_t>::max()) /
                   86400;
  case ValueType::error:
    return false;
  }
  return false;
}

using TreeEditor = xml::TreeEditor<ElementRegistry>;
using xml::NodeSpan;

/// Writes @p text as odf text nodes before @p before, or at the end of
/// @p parent where that is null. Empty text still gets a node to anchor to.
NodeSpan write_text_nodes(pugi::xml_node parent, const pugi::xml_node before,
                          const std::string &text) {
  NodeSpan span;

  const auto track = [&](const pugi::xml_node new_node) {
    if (!span.first) {
      span.first = new_node;
    }
    span.last = new_node;
    return new_node;
  };
  const auto insert = [&](const pugi::xml_node_type type) {
    return track(before ? parent.insert_child_before(type, before)
                        : parent.append_child(type));
  };
  const auto insert_named = [&](const char *name) {
    return track(before ? parent.insert_child_before(name, before)
                        : parent.append_child(name));
  };

  for (const xml::StringToken &token : xml::tokenize_text(text)) {
    switch (token.type) {
    case xml::StringToken::Type::none:
      break;
    case xml::StringToken::Type::string: {
      auto text_node = insert(pugi::xml_node_type::node_pcdata);
      text_node.text().set(token.string.c_str());
    } break;
    case xml::StringToken::Type::spaces: {
      auto space_node = insert_named("text:s");
      space_node.prepend_attribute("text:c").set_value(token.string.size());
    } break;
    case xml::StringToken::Type::tabs: {
      for (std::size_t i = 0; i < token.string.size(); ++i) {
        insert_named("text:tab");
      }
    } break;
    }
  }

  if (!span.first) {
    insert(pugi::xml_node_type::node_pcdata);
  }
  return span;
}

using AdapterBase = internal::RegistryElementAdapter<
    ElementRegistry, abstract::TextRootAdapter, abstract::SlideAdapter,
    abstract::PageAdapter, abstract::SheetAdapter, abstract::SheetCellAdapter,
    abstract::MasterPageAdapter, abstract::LineBreakAdapter,
    abstract::ParagraphAdapter, abstract::SpanAdapter, abstract::TextAdapter,
    abstract::LinkAdapter, abstract::BookmarkAdapter, abstract::ListAdapter,
    abstract::ListItemAdapter, abstract::TableAdapter,
    abstract::TableColumnAdapter, abstract::TableRowAdapter,
    abstract::TableCellAdapter, abstract::FrameAdapter, abstract::ImageAdapter>;

class ElementAdapter final : public AdapterBase {
public:
  ElementAdapter(Document &document, ElementRegistry &registry)
      : AdapterBase(registry), m_document(&document) {}

  [[nodiscard]] bool
  element_is_editable(const ElementIdentifier element_id) const override {
    const ElementRegistry::Element &element =
        m_registry->element_at(element_id);
    if (element.type == ElementType::sheet_cell) {
      return !m_registry->sheet_cell_element_at(element_id).is_repeated;
    }
    if (element.parent_id != null_element_id) {
      return element_is_editable(element.parent_id);
    }
    return true;
  }

  [[nodiscard]] PageLayout
  text_root_page_layout(const ElementIdentifier element_id) const override {
    if (const ElementIdentifier master_page_id =
            text_root_first_master_page(element_id);
        master_page_id != null_element_id) {
      return master_page_page_layout(master_page_id);
    }
    return {};
  }
  static bool is_anchored_frame(const pugi::xml_node node) {
    return std::strcmp(node.name(), "draw:frame") == 0;
  }

  /// Whether laying this out would put a word on the page; a frame is anchored,
  /// not written.
  static bool writes_text(const pugi::xml_node node) {
    for (const pugi::xml_node child : node.children()) {
      if (child.type() == pugi::node_pcdata &&
          !std::string_view(child.value()).empty()) {
        return true;
      }
      if (!is_anchored_frame(child) && writes_text(child)) {
        return true;
      }
    }
    return false;
  }

  [[nodiscard]] ElementIdentifier text_root_first_master_page(
      const ElementIdentifier element_id) const override {
    // A paragraph may name the master page its page uses (20.283). One page box
    // is all we lay out, so only a name ahead of every written word counts.
    for (const pugi::xml_node child : get_node(element_id).children()) {
      if (is_anchored_frame(child)) {
        continue;
      }
      if (const ElementIdentifier master_page_id =
              m_document->style_registry().master_page_of_style(
                  child.attribute("text:style-name").value());
          master_page_id != null_element_id) {
        return master_page_id;
      }
      if (writes_text(child)) {
        break;
      }
    }
    return m_document->style_registry().first_master_page();
  }

  [[nodiscard]] PageLayout
  slide_page_layout(const ElementIdentifier element_id) const override {
    if (const ElementIdentifier master_page_id = slide_master_page(element_id);
        master_page_id != null_element_id) {
      return master_page_page_layout(master_page_id);
    }
    return {};
  }
  [[nodiscard]] ElementIdentifier
  slide_master_page(const ElementIdentifier element_id) const override {
    const pugi::xml_node node = get_node(element_id);
    if (const pugi::xml_attribute master_page_name_attr =
            node.attribute("draw:master-page-name");
        master_page_name_attr) {
      return m_document->style_registry().master_page(
          master_page_name_attr.value());
    }
    return {};
  }
  [[nodiscard]] std::string
  slide_name(const ElementIdentifier element_id) const override {
    const pugi::xml_node node = get_node(element_id);
    return node.attribute("draw:name").value();
  }

  [[nodiscard]] PageLayout
  page_layout(const ElementIdentifier element_id) const override {
    if (const ElementIdentifier master_page_id = page_master_page(element_id);
        master_page_id != null_element_id) {
      return master_page_page_layout(master_page_id);
    }
    return {};
  }
  [[nodiscard]] ElementIdentifier
  page_master_page(const ElementIdentifier element_id) const override {
    const pugi::xml_node node = get_node(element_id);
    if (const pugi::xml_attribute master_page_name_attr =
            node.attribute("draw:master-page-name");
        master_page_name_attr) {
      return m_document->style_registry().master_page(
          master_page_name_attr.value());
    }
    return {};
  }
  [[nodiscard]] std::string
  page_name(const ElementIdentifier element_id) const override {
    return get_node(element_id).attribute("draw:name").value();
  }

  [[nodiscard]] std::string
  sheet_name(const ElementIdentifier element_id) const override {
    return get_node(element_id).attribute("table:name").value();
  }
  [[nodiscard]] PageLayout
  sheet_page_layout(const ElementIdentifier element_id) const override {
    // The table style names the master page (20.383); a sheet that names none
    // takes the first.
    ElementIdentifier master_page_id =
        m_document->style_registry().master_page_of_style(
            get_node(element_id).attribute("table:style-name").value());
    if (master_page_id == null_element_id) {
      master_page_id = m_document->style_registry().first_master_page();
    }
    if (master_page_id == null_element_id) {
      return {};
    }
    return master_page_page_layout(master_page_id);
  }
  [[nodiscard]] TableDimensions
  sheet_dimensions(const ElementIdentifier element_id) const override {
    return m_registry->sheet_element_at(element_id).dimensions;
  }
  [[nodiscard]] TableDimensions
  sheet_content(const ElementIdentifier element_id,
                const std::optional<TableDimensions> range) const override {
    const TableDimensions limit = range.value_or(
        TableDimensions(std::numeric_limits<std::uint32_t>::max(),
                        std::numeric_limits<std::uint32_t>::max()));
    TableDimensions result;
    for_each_cell_run(element_id, [&](const ElementRegistry::Sheet::Cell &cell,
                                      const std::uint32_t row,
                                      const TableDimensions &repeated) {
      if (!cell.node.first_child() || row >= limit.rows ||
          cell.begin >= limit.columns) {
        return;
      }
      const std::uint32_t colspan = std::max(
          1u, cell.node.attribute("table:number-columns-spanned").as_uint(1));
      const std::uint32_t rowspan = std::max(
          1u, cell.node.attribute("table:number-rows-spanned").as_uint(1));
      const auto end_row = static_cast<std::uint32_t>(std::min<std::uint64_t>(
          std::uint64_t{row} + repeated.rows + rowspan - 1, limit.rows));
      const auto end_column =
          static_cast<std::uint32_t>(std::min<std::uint64_t>(
              std::uint64_t{cell.end} + colspan - 1, limit.columns));
      result.rows = std::max(result.rows, end_row);
      result.columns = std::max(result.columns, end_column);
    });

    return result;
  }
  [[nodiscard]] ElementIdentifier
  sheet_cell(const ElementIdentifier element_id, const std::uint32_t column,
             const std::uint32_t row) const override {
    return m_registry->sheet_cell_id(element_id, column, row);
  }
  [[nodiscard]] ElementIdentifier
  sheet_first_shape(const ElementIdentifier element_id) const override {
    return m_registry->sheet_element_at(element_id).first_shape_id;
  }
  /// The runs the parser indexed, not the grid they stand for: a repeat is
  /// one entry however many positions it covers.
  void sheet_visit_formulas(
      const ElementIdentifier element_id,
      const abstract::SheetFormulaVisitor &visitor) const override {
    for_each_cell_run(element_id, [&](const ElementRegistry::Sheet::Cell &cell,
                                      const std::uint32_t row,
                                      const TableDimensions &repeated) {
      if (const pugi::xml_attribute formula =
              cell.node.attribute("table:formula")) {
        // [ODF 1.2] 19.684: an array formula states the range it fills
        const pugi::xml_attribute matrix_columns =
            cell.node.attribute("table:number-matrix-columns-spanned");
        const TableDimensions span =
            matrix_columns
                ? TableDimensions(
                      cell.node.attribute("table:number-matrix-rows-spanned")
                          .as_uint(1),
                      matrix_columns.as_uint(1))
                : repeated;
        visitor(cell.begin, row, span, bool(matrix_columns), formula.value());
      }
    });
  }
  bool
  sheet_visit_cells(const ElementIdentifier element_id,
                    const abstract::SheetCellVisitor &visitor) const override {
    for_each_cell_run(element_id, [&](const ElementRegistry::Sheet::Cell &cell,
                                      const std::uint32_t row,
                                      const TableDimensions &repeated) {
      if (cell.element_id != null_element_id) {
        visitor(cell.begin, row, repeated, cell.element_id);
      }
    });
    return true;
  }
  /// Calls @p visit with every cell run of the sheet the parser indexed, the
  /// row it starts at, and the rows and columns its repeat stands for.
  template <typename Visit>
  void for_each_cell_run(const ElementIdentifier element_id,
                         const Visit &visit) const {
    const ElementRegistry::Sheet &sheet =
        m_registry->sheet_element_at(element_id);
    std::uint32_t row = 0;
    for (const ElementRegistry::Sheet::Row &run : sheet.rows) {
      for (const ElementRegistry::Sheet::Cell &cell : sheet.row_cells(run)) {
        visit(cell, row, TableDimensions(run.end - row, cell.end - cell.begin));
      }
      row = run.end;
    }
  }
  /// [ODF 1.2] 19.385: the value is an attribute and the `text:p` under the
  /// cell shows it, so both are written or the file contradicts itself.
  void sheet_set_cell(const ElementIdentifier element_id,
                      const std::uint32_t column, const std::uint32_t row,
                      const CellValue &value) const override {
    if (!writable(value)) {
      throw UnsupportedOperation();
    }
    if (is_covered(element_id, column, row)) {
      throw UnsupportedOperation();
    }
    // a formula a reader cannot parse would be one LibreOffice cannot either
    if (value.has_formula() &&
        !formula::parse(value.formula(), formula::Syntax::opendocument)
             .has_value()) {
      throw UnsupportedOperation();
    }
    const ElementRegistry::Sheet::Cell *cell =
        m_registry->sheet_element_at(element_id).cell(column, row);

    ElementIdentifier cell_id = null_element_id;
    if (cell == nullptr) {
      // the sheet stops before the position, so there is nothing to refuse
      cell_id = grow_to_cell(element_id, column, row);
    } else {
      cell_id = cell->element_id;

      // both refusals are decided before the split writes anything
      if (cell->node.attribute("table:number-matrix-columns-spanned")) {
        throw UnsupportedOperation(); // the anchor of an array formula
      }
      if (cell_id != null_element_id && !holds_plain_lines(cell_id)) {
        throw UnsupportedOperation();
      }

      if (cell_id == null_element_id ||
          m_registry->sheet_cell_element_at(cell_id).is_repeated) {
        cell_id = claim_cell(element_id, column, row); // `cell` is stale after
      }
    }

    pugi::xml_node node = get_node(cell_id);
    const bool had_formula = !node.attribute("table:formula").empty();
    const std::string text =
        shown_value(element_id, cell_id, {column, row}, value)
            .value_or(value.has_text() ? value.text() : "");
    write_lines(cell_id, text);

    remove_value_attributes(node);
    node.remove_attribute("table:formula");
    if (value.has_formula()) {
      node.append_attribute("table:formula")
          .set_value(
              ("of:=" + std::string(formula::strip_prefix(value.formula())))
                  .c_str());
    }

    switch (value.type()) {
    case ValueType::unknown:
      break;
    case ValueType::string:
      node.append_attribute("office:value-type").set_value("string");
      break;
    case ValueType::float_number:
      node.append_attribute("office:value-type").set_value("float");
      node.append_attribute("office:value")
          .set_value(fmt::format("{}", value.number()).c_str());
      break;
    case ValueType::boolean:
      node.append_attribute("office:value-type").set_value("boolean");
      node.append_attribute("office:boolean-value")
          .set_value(value.has_number() && value.number() != 0 ? "true"
                                                               : "false");
      break;
    case ValueType::date:
      node.append_attribute("office:value-type").set_value("date");
      node.append_attribute("office:date-value")
          .set_value(date_value(value.number()).c_str());
      break;
    case ValueType::time:
      node.append_attribute("office:value-type").set_value("time");
      node.append_attribute("office:time-value")
          .set_value(time_value(value.number()).c_str());
      break;
    case ValueType::error:
      throw UnsupportedOperation(); // `writable` refused it above
    }

    // a formula without a result states none, not an empty one
    if (value.has_formula() && value.type() == ValueType::unknown &&
        !value.has_text()) {
      drop_cell_result(
          *m_registry->sheet_element_at(element_id).cell(column, row));
    }
    drop_stale_results(element_id, column, row);
    m_document->note_written(element_id, TablePosition(column, row));
    if (had_formula || value.has_formula()) {
      m_document->drop_sheet_dependencies();
    }
  }

  /// [ODF 1.2] 19.385: caches results as value attributes and `text:p`, using
  /// the data style for the type and `calcext:value-type` for errors.
  void sheet_set_result(const ElementIdentifier element_id,
                        const std::uint32_t column, const std::uint32_t row,
                        const CellValue &result) const override {
    const ElementRegistry::Sheet::Cell *cell =
        m_registry->sheet_element_at(element_id).cell(column, row);
    if (cell == nullptr || cell->element_id == null_element_id ||
        !cell->node.attribute("table:formula") ||
        m_registry->sheet_cell_element_at(cell->element_id).is_repeated) {
      throw UnsupportedOperation();
    }
    write_result(element_id, *cell, column, row, result);
  }

  void sheet_set_array_result(const ElementIdentifier element_id,
                              const std::uint32_t column,
                              const std::uint32_t row,
                              const CellValue &result) const override {
    const ElementRegistry::Sheet::Cell *cell =
        m_registry->sheet_element_at(element_id).cell(column, row);
    if (cell == nullptr || cell->element_id == null_element_id ||
        cell->node.attribute("table:formula") ||
        m_registry->sheet_cell_element_at(cell->element_id).is_repeated) {
      throw UnsupportedOperation();
    }
    write_result(element_id, *cell, column, row, result);
  }

  /// [ODF 1.2] 19.386 `office:value`: what a formula computes for @p cell,
  /// and its text in the cell's format. An unknown result drops the stale
  /// one.
  void write_result(const ElementIdentifier element_id,
                    const ElementRegistry::Sheet::Cell &cell,
                    const std::uint32_t column, const std::uint32_t row,
                    const CellValue &result) const {
    if (result.type() == ValueType::unknown) {
      drop_cell_result(cell);
      return;
    }
    const ElementIdentifier cell_id = cell.element_id;
    const TablePosition position(column, row);

    CellValue typed = result;
    if (result.type() == ValueType::float_number) {
      switch (data_category(element_id, cell_id, position)
                  .value_or(number_format::Category::number)) {
      case number_format::Category::date:
        typed = CellValue(ValueType::date)
                    .with_number(
                        m_document->formula_settings().days(result.number()));
        break;
      case number_format::Category::time:
        typed = CellValue(ValueType::time).with_number(result.number());
        break;
      case number_format::Category::number:
        break;
      }
    }

    if ((typed.type() == ValueType::date || typed.type() == ValueType::time) &&
        !writable(typed)) {
      typed = result;
    }
    std::string text;
    if (const std::optional<std::string> shown =
            shown_value(element_id, cell_id, position, typed);
        shown.has_value()) {
      text = *shown;
    } else if (typed.type() == ValueType::boolean) {
      text = typed.number() != 0 ? "TRUE" : "FALSE";
    } else if (typed.has_number()) {
      text = number_format::Format().format(
          typed.number(), number_format::Epoch::from_1900,
          number_format::symbols_of(m_document->locale().value_or("")));
    } else if (typed.has_text()) {
      text = typed.text();
    }
    write_lines(cell_id, text);

    pugi::xml_node node = get_node(cell_id);
    remove_value_attributes(node);
    const auto type = [&](const char *value_type) {
      node.append_attribute("office:value-type").set_value(value_type);
    };
    switch (typed.type()) {
    case ValueType::unknown:
      break;
    case ValueType::string:
      type("string");
      node.append_attribute("office:string-value").set_value(text.c_str());
      break;
    case ValueType::float_number:
      type("float");
      node.append_attribute("office:value")
          .set_value(fmt::format("{}", typed.number()).c_str());
      break;
    case ValueType::boolean:
      type("boolean");
      node.append_attribute("office:boolean-value")
          .set_value(typed.number() != 0 ? "true" : "false");
      break;
    case ValueType::date:
      type("date");
      node.append_attribute("office:date-value")
          .set_value(date_value(typed.number()).c_str());
      break;
    case ValueType::time:
      type("time");
      node.append_attribute("office:time-value")
          .set_value(time_value(typed.number()).c_str());
      break;
    case ValueType::error: {
      node.append_attribute("office:value-type").set_value("string");
      node.append_attribute("office:string-value").set_value("");
      // an older file declares no `calcext`, which the attribute needs
      pugi::xml_node root = node;
      while (root.parent().type() == pugi::node_element) {
        root = root.parent();
      }
      if (!root.attribute("xmlns:calcext")) {
        root.append_attribute("xmlns:calcext")
            .set_value("urn:org:documentfoundation:names:experimental:calc:"
                       "xmlns:calcext:1.0");
      }
      node.append_attribute("calcext:value-type").set_value("error");
    } break;
    }
  }

  void sheet_set_cell_style(const ElementIdentifier element_id,
                            const std::uint32_t column, const std::uint32_t row,
                            const TableCellStyle &cell_style,
                            const TextStyle &text_style) const override {
    const ElementRegistry::Sheet::Cell *cell =
        m_registry->sheet_element_at(element_id).cell(column, row);

    if (is_covered(element_id, column, row)) {
      throw UnsupportedOperation();
    }

    ElementIdentifier cell_id = null_element_id;
    if (cell == nullptr) {
      cell_id = grow_to_cell(element_id, column, row);
    } else {
      cell_id = cell->element_id;
      if (cell_id == null_element_id ||
          m_registry->sheet_cell_element_at(cell_id).is_repeated) {
        cell_id = claim_cell(element_id, column, row); // `cell` is stale after
      }
    }

    pugi::xml_node node = get_node(cell_id);
    const std::string name = m_document->style_registry().create_cell_style(
        automatic_styles_of(node),
        cell_style_name(element_id, cell_id, {column, row}), cell_style,
        text_style);
    pugi::xml_attribute attribute = node.attribute("table:style-name");
    if (!attribute) {
      attribute = node.prepend_attribute("table:style-name");
    }
    attribute.set_value(name.c_str());
  }

  /// LibreOffice applies a row's `table:default-cell-style-name` to the whole
  /// sheet, so a row style goes onto its cells, to the last declared column.
  void sheet_set_row_style(const ElementIdentifier element_id,
                           const std::uint32_t row,
                           const TableCellStyle &cell_style,
                           const TextStyle &text_style) const override {
    const ElementRegistry::Sheet &sheet =
        m_registry->sheet_element_at(element_id);
    const pugi::xml_node row_node = claim_row(element_id, row);

    std::uint32_t stated = 0;
    for (const pugi::xml_node cell : row_node.children()) {
      stated += cell.attribute("table:number-columns-repeated").as_uint(1);
    }
    if (stated < sheet.dimensions.columns) {
      append_empty_cells(row_node, sheet.dimensions.columns - stated);
    }

    // a cell stating no style shows the row's default before its column's
    const char *row_default =
        row_node.attribute("table:default-cell-style-name").value();
    std::uint32_t column = 0;
    for (pugi::xml_node cell = row_node.first_child(); cell;) {
      const pugi::xml_node next = cell.next_sibling();
      const std::uint32_t repeated =
          cell.attribute("table:number-columns-repeated").as_uint(1);
      if (std::strcmp(cell.name(), "table:table-cell") == 0) {
        if (const pugi::xml_attribute own = cell.attribute("table:style-name");
            own || *row_default != '\0') {
          restyle(cell, "table:style-name", own ? own.value() : row_default,
                  cell_style, text_style);
        } else {
          restyle_by_column(sheet, cell, column, repeated, cell_style,
                            text_style);
        }
      }
      column += repeated;
      cell = next;
    }

    reindex_sheet(*m_registry, element_id);
  }

  /// The column's `table:default-cell-style-name`, and every cell of it that
  /// would not take that: one stating its own style, or in a row stating a
  /// default. A repeated row is not cut, because its cell stands for all.
  void sheet_set_column_style(const ElementIdentifier element_id,
                              const std::uint32_t column,
                              const TableCellStyle &cell_style,
                              const TextStyle &text_style) const override {
    ElementRegistry::Sheet &sheet = m_registry->sheet_element_at(element_id);
    const pugi::xml_node sheet_node = get_node(element_id);
    grow_columns(sheet_node, sheet, column);

    const ElementRegistry::Sheet::Column *entry = sheet.column(column);
    const std::size_t index = entry - sheet.columns.data();
    split_run(entry->node, "table:number-columns-repeated",
              index == 0 ? 0 : sheet.columns[index - 1].end, entry->end,
              column);
    const pugi::xml_node column_node = entry->node;

    for_each_table_row(sheet_node, [&](const pugi::xml_node row_node) {
      std::uint32_t begin = 0;
      for (const pugi::xml_node cell : row_node.children()) {
        const std::uint32_t end =
            begin + cell.attribute("table:number-columns-repeated").as_uint(1);
        if (column >= end) {
          begin = end;
          continue;
        }
        const char *base = cell.attribute("table:style-name").value();
        if (*base == '\0') {
          base = row_node.attribute("table:default-cell-style-name").value();
        }
        if (std::strcmp(cell.name(), "table:table-cell") == 0 &&
            *base != '\0') {
          split_run(cell, "table:number-columns-repeated", begin, end, column);
          restyle(cell, "table:style-name", base, cell_style, text_style);
        }
        break;
      }
    });

    restyle(column_node, "table:default-cell-style-name",
            column_node.attribute("table:default-cell-style-name").value(),
            cell_style, text_style);
    reindex_sheet(*m_registry, element_id);
  }

  /// A row, a cell or a column declaration, and the positions it stands for.
  struct Run final {
    pugi::xml_node node;
    std::uint32_t begin{0};
    std::uint32_t end{0};
  };

  static constexpr const char *rows_repeated = "table:number-rows-repeated";
  static constexpr const char *columns_repeated =
      "table:number-columns-repeated";

  /// The rows from @p row on move down, and so does every reference to them
  /// on every sheet. A trailing run of empty rows gives up as many, so the
  /// extent stays.
  void sheet_insert_rows(const ElementIdentifier element_id,
                         const std::uint32_t row,
                         const std::uint32_t count) const override {
    const pugi::xml_node sheet_node = get_node(element_id);
    const std::vector<Run> runs = row_runs(sheet_node);
    if (merge_reaches_over(runs, row)) {
      throw UnsupportedOperation();
    }
    const Run *trailing = !runs.empty() && row_states_nothing(runs.back().node)
                              ? &runs.back()
                              : nullptr;
    const std::uint32_t stated_end = trailing != nullptr ? trailing->begin
                                     : runs.empty()      ? 0
                                                         : runs.back().end;
    const std::uint64_t moved_end = std::uint64_t{stated_end} + count;
    if (row < stated_end && moved_end > row_limit) {
      throw UnsupportedOperation();
    }

    const std::vector<SheetPosition> touched = move_references(
        sheet_node.parent(),
        {.sheet = sheet_name(element_id), .index = row, .count = count});

    if (row < stated_end) {
      const pugi::xml_node at = cut(row_runs(sheet_node), row, rows_repeated);
      const pugi::xml_node added =
          at.parent().insert_child_before("table:table-row", at);
      set_repeat(added, rows_repeated, count);
      append_empty_cells(
          added, m_registry->sheet_element_at(element_id).dimensions.columns);
      if (trailing != nullptr) {
        const std::uint32_t kept = trailing->end - trailing->begin;
        if (kept > count) {
          set_repeat(trailing->node, rows_repeated, kept - count);
        } else {
          remove_run(trailing->node);
        }
      }
    }

    reindex_sheet(*m_registry, element_id);
    drop_moved_results(touched);
  }

  /// The rows from @p row on are removed, and the rows below and every
  /// reference to them move up.
  void sheet_delete_rows(const ElementIdentifier element_id,
                         const std::uint32_t row,
                         const std::uint32_t count) const override {
    const pugi::xml_node sheet_node = get_node(element_id);
    const std::vector<Run> runs = row_runs(sheet_node);
    const std::uint32_t end = static_cast<std::uint32_t>(
        std::min<std::uint64_t>(static_cast<std::uint64_t>(row) + count,
                                std::numeric_limits<std::uint32_t>::max()));
    if (merge_reaches_over(runs, row) || merge_reaches_over(runs, end)) {
      throw UnsupportedOperation();
    }

    const std::vector<SheetPosition> touched =
        move_references(sheet_node.parent(), {.sheet = sheet_name(element_id),
                                              .index = row,
                                              .count = count,
                                              .insert = false});

    if (const std::uint32_t rows_end = runs.empty() ? 0 : runs.back().end;
        row < rows_end) {
      // the far end first: the cut at `row` then reads the runs as they are
      if (end < rows_end) {
        cut(row_runs(sheet_node), end, rows_repeated);
      }
      cut(row_runs(sheet_node), row, rows_repeated);
      std::vector<Run> removed;
      for (const Run &run : row_runs(sheet_node)) {
        if (run.begin >= row && run.begin < end) {
          removed.push_back(run);
        }
      }
      retire_cells(element_id, removed);
      for (const Run &run : removed) {
        remove_run(run.node);
      }
    }

    reindex_sheet(*m_registry, element_id);
    drop_moved_results(touched);
  }

  /// Every row is cut at @p column and gets as many empty cells there, and so
  /// are the column declarations. A row, or the declarations, ending in a run
  /// that states nothing gives up as many, so the extent stays.
  void sheet_insert_columns(const ElementIdentifier element_id,
                            const std::uint32_t column,
                            const std::uint32_t count) const override {
    const pugi::xml_node sheet_node = get_node(element_id);
    const std::vector<Run> rows = row_runs(sheet_node);
    std::uint32_t stated_end = 0;
    for (const Run &row : rows) {
      const std::vector<Run> cells = cell_runs(row.node);
      if (span_reaches(cells, column)) {
        throw UnsupportedOperation();
      }
      for (const Run &cell : cells) {
        if (!states_nothing(cell.node)) {
          stated_end = std::max(stated_end, cell.end);
        }
      }
    }
    if (column < stated_end &&
        std::uint64_t{stated_end} + count > column_limit) {
      throw UnsupportedOperation();
    }

    const std::vector<SheetPosition> touched =
        move_references(sheet_node.parent(), {.sheet = sheet_name(element_id),
                                              .axis = formula::Axis::column,
                                              .index = column,
                                              .count = count});

    for (const Run &row : rows) {
      insert_run(cell_runs(row.node), "table:table-cell", column, count);
    }
    insert_run(column_runs(sheet_node), "table:table-column", column, count);

    reindex_sheet(*m_registry, element_id);
    drop_moved_results(touched);
  }

  /// Every row loses its cells from @p column on, and the declarations lose
  /// theirs.
  void sheet_delete_columns(const ElementIdentifier element_id,
                            const std::uint32_t column,
                            const std::uint32_t count) const override {
    const pugi::xml_node sheet_node = get_node(element_id);
    const std::vector<Run> rows = row_runs(sheet_node);
    const std::uint32_t end = static_cast<std::uint32_t>(
        std::min<std::uint64_t>(std::uint64_t{column} + count,
                                std::numeric_limits<std::uint32_t>::max()));
    for (const Run &row : rows) {
      const std::vector<Run> cells = cell_runs(row.node);
      if (span_reaches(cells, column) || span_reaches(cells, end)) {
        throw UnsupportedOperation();
      }
    }

    const std::vector<SheetPosition> touched =
        move_references(sheet_node.parent(), {.sheet = sheet_name(element_id),
                                              .axis = formula::Axis::column,
                                              .index = column,
                                              .count = count,
                                              .insert = false});

    std::vector<Run> removed;
    for (const Run &row : rows) {
      const auto cells =
          cut_out([&] { return cell_runs(row.node); }, column, end);
      removed.insert(removed.end(), cells.begin(), cells.end());
    }
    retire_cells(element_id, removed);
    for (const Run &cell : removed) {
      cell.node.parent().remove_child(cell.node);
    }
    for (const Run &row : rows) {
      // [ODF 1.2] 9.1.3: a row states at least one cell.
      if (cell_runs(row.node).empty()) {
        append_empty_cells(row.node, 1);
      }
    }
    for (const Run &declaration :
         cut_out([&] { return column_runs(sheet_node); }, column, end)) {
      remove_run(declaration.node);
    }
    if (column_runs(sheet_node).empty()) {
      insert_ordered(sheet_node, "table:table-column", after_columns);
    }

    reindex_sheet(*m_registry, element_id);
    drop_moved_results(touched);
  }

  /// The columns of a LibreOffice sheet, which keeps a cell in `XFD` and drops
  /// one past it.
  static constexpr std::uint32_t column_limit = 16384;

  /// Puts a run of @p count plain @p name nodes at @p at, where @p runs reach
  /// it. A last run stating nothing gives up as many, so the extent stays.
  static void insert_run(const std::vector<Run> &runs, const char *name,
                         const std::uint32_t at, const std::uint32_t count) {
    const pugi::xml_node next = cut(runs, at, columns_repeated);
    if (!next) {
      return;
    }
    set_repeat(next.parent().insert_child_before(name, next), columns_repeated,
               count);
    // a cut keeps the last node last
    const pugi::xml_node last = runs.back().node;
    if (!states_nothing(last)) {
      return;
    }
    if (const std::uint32_t kept = last.attribute(columns_repeated).as_uint(1);
        kept > count) {
      set_repeat(last, columns_repeated, kept - count);
    } else {
      remove_run(last);
    }
  }

  /// The runs between @p at and @p end, cut out of the ones reaching over
  /// either, for the caller to remove.
  static std::vector<Run> cut_out(const std::function<std::vector<Run>()> &runs,
                                  const std::uint32_t at,
                                  const std::uint32_t end) {
    // the far end first: the cut at `at` then reads the runs as they are
    cut(runs(), end, columns_repeated);
    cut(runs(), at, columns_repeated);
    std::vector<Run> result;
    for (const Run &run : runs()) {
      if (run.begin >= at && run.begin < end) {
        result.push_back(run);
      }
    }
    return result;
  }

  /// Whether a `table:number-columns-spanned` starting left of @p column
  /// reaches it.
  static bool span_reaches(const std::vector<Run> &cells,
                           const std::uint32_t column) {
    return std::ranges::any_of(cells, [&](const Run &cell) {
      return cell.begin < column &&
             cell.begin + cell.node.attribute("table:number-columns-spanned")
                              .as_uint(1) >
                 column;
    });
  }

  /// Moves content and chart references; reads all affected parts before
  /// writing.
  [[nodiscard]] std::vector<SheetPosition>
  move_references(const pugi::xml_node spreadsheet,
                  const formula::SheetEdit &edit) const {
    std::vector<pugi::xml_node> objects;
    try {
      for (const pugi::xpath_node object :
           spreadsheet.select_nodes("//draw:object[@xlink:href]")) {
        const AbsPath path = Path(object.node().attribute("xlink:href").value())
                                 .make_absolute()
                                 .join(RelPath("content.xml"));
        // an embedded spreadsheet reads its own sheets
        if (const pugi::xml_node root = m_document->part(path);
            root.child("office:body").child("office:chart")) {
          objects.push_back(root);
        }
      }
    } catch (const std::exception &) {
      throw UnsupportedOperation(); // a part that does not parse
    }
    const pugi::xml_node styles = m_document->part(AbsPath("/styles.xml"));
    check_formula_syntax(spreadsheet.parent().parent());
    check_formula_syntax(styles);
    for (const pugi::xml_node object : objects) {
      check_formula_syntax(object);
    }
    std::vector<SheetPosition> touched =
        move_sheet_references(spreadsheet, edit);
    move_object_references(styles, edit);
    for (const pugi::xml_node object : objects) {
      move_object_references(object, edit);
    }
    return touched;
  }

  /// The rows of a LibreOffice sheet; ODF states no grid.
  static constexpr std::uint32_t row_limit = 1048576;

  static std::vector<Run> row_runs(const pugi::xml_node sheet_node) {
    std::vector<Run> result;
    std::uint32_t row = 0;
    for_each_table_row(sheet_node, [&](const pugi::xml_node node) {
      const std::uint32_t end =
          row + node.attribute("table:number-rows-repeated").as_uint(1);
      result.push_back({.node = node, .begin = row, .end = end});
      row = end;
    });
    return result;
  }

  static std::vector<Run> column_runs(const pugi::xml_node sheet_node) {
    std::vector<Run> result;
    std::uint32_t column = 0;
    for_each_table_column(sheet_node, [&](const pugi::xml_node node) {
      const std::uint32_t end =
          column + node.attribute(columns_repeated).as_uint(1);
      result.push_back({.node = node, .begin = column, .end = end});
      column = end;
    });
    return result;
  }

  /// The cells of @p row, a covered one too, since it holds a position.
  static std::vector<Run> cell_runs(const pugi::xml_node row) {
    std::vector<Run> result;
    std::uint32_t column = 0;
    for (const pugi::xml_node node : row.children()) {
      if (node.type() != pugi::node_element) {
        continue;
      }
      const std::uint32_t end =
          column + node.attribute(columns_repeated).as_uint(1);
      result.push_back({.node = node, .begin = column, .end = end});
      column = end;
    }
    return result;
  }

  /// Whether a `table:number-rows-spanned` starting above @p row reaches it.
  static bool merge_reaches_over(const std::vector<Run> &runs,
                                 const std::uint32_t row) {
    for (const Run &run : runs) {
      if (run.begin >= row) {
        break;
      }
      for (const pugi::xml_node cell : run.node.children("table:table-cell")) {
        if (run.begin + cell.attribute("table:number-rows-spanned").as_uint(1) >
            row) {
          return true;
        }
      }
    }
    return false;
  }

  /// Whether @p cell states no more than a style.
  static bool states_nothing(const pugi::xml_node cell) {
    return !cell.first_child() && !cell.attribute("office:value-type") &&
           !cell.attribute("table:formula") &&
           cell.attribute("table:number-rows-spanned").as_uint(1) <= 1 &&
           cell.attribute("table:number-columns-spanned").as_uint(1) <= 1;
  }

  /// Whether @p row states no more than styles.
  static bool row_states_nothing(const pugi::xml_node row) {
    return std::ranges::all_of(cell_runs(row), [](const Run &run) {
      return states_nothing(run.node);
    });
  }

  /// The node whose run starts at @p at, cut out of the run @p at falls
  /// inside. Null past the runs. The caller reindexes.
  static pugi::xml_node cut(const std::vector<Run> &runs,
                            const std::uint32_t at, const char *repeated) {
    for (const Run &run : runs) {
      if (at >= run.end) {
        continue;
      }
      if (run.begin < at) {
        set_repeat(run.node.parent().insert_copy_before(run.node, run.node),
                   repeated, at - run.begin);
        set_repeat(run.node, repeated, run.end - at);
      }
      return run.node;
    }
    return {};
  }

  /// Retires old cell ids before their DOM addresses can be reused.
  void retire_cells(const ElementIdentifier sheet_id,
                    const std::span<const Run> runs) const {
    std::unordered_set<const void *> removed;
    for (const Run &run : runs) {
      if (std::string_view(run.node.name()) == "table:table-row") {
        for (const pugi::xml_node cell :
             run.node.children("table:table-cell")) {
          removed.insert(cell.internal_object());
        }
      } else {
        removed.insert(run.node.internal_object());
      }
    }
    for (auto &cell : m_registry->sheet_element_at(sheet_id).cells) {
      if (cell.element_id != null_element_id &&
          removed.contains(cell.node.internal_object())) {
        m_registry->invalidate(cell.element_id);
        cell.element_id = null_element_id;
      }
    }
  }

  /// Removes @p node, and a grouping element it leaves empty.
  static void remove_run(pugi::xml_node node) {
    for (pugi::xml_node parent = node.parent();;) {
      parent.remove_child(node);
      if (std::string_view(parent.name()) == "table:table" ||
          parent.find_child([](const pugi::xml_node child) {
            return child.type() == pugi::node_element;
          })) {
        return;
      }
      node = parent;
      parent = node.parent();
    }
  }

  /// Points @p attribute of @p node at @p base with the delta applied.
  void restyle(pugi::xml_node node, const char *attribute, const char *base,
               const TableCellStyle &cell_style,
               const TextStyle &text_style) const {
    const std::string name = m_document->style_registry().create_cell_style(
        automatic_styles_of(node), base, cell_style, text_style);
    pugi::xml_attribute target = node.attribute(attribute);
    if (!target) {
      target = node.append_attribute(attribute);
    }
    target.set_value(name.c_str());
  }

  /// Cuts a run of cells that state no style where the default of their
  /// column changes, and restyles each part from that default.
  void restyle_by_column(const ElementRegistry::Sheet &sheet,
                         pugi::xml_node cell, const std::uint32_t begin,
                         const std::uint32_t repeated,
                         const TableCellStyle &cell_style,
                         const TextStyle &text_style) const {
    std::vector<std::pair<std::uint32_t, std::string>> parts;
    for (std::uint32_t column = begin; column < begin + repeated;) {
      const ElementRegistry::Sheet::Column *entry = sheet.column(column);
      const std::uint32_t end = entry == nullptr
                                    ? begin + repeated
                                    : std::min(entry->end, begin + repeated);
      const std::string base =
          entry == nullptr
              ? std::string()
              : entry->node.attribute("table:default-cell-style-name").value();
      if (!parts.empty() && parts.back().second == base) {
        parts.back().first += end - column;
      } else {
        parts.emplace_back(end - column, base);
      }
      column = end;
    }

    pugi::xml_node part = cell;
    for (std::size_t i = 0; i < parts.size(); ++i) {
      if (i > 0) {
        part = part.parent().insert_copy_after(part, part);
      }
      set_repeat(part, "table:number-columns-repeated", parts[i].first);
      restyle(part, "table:style-name", parts[i].second.c_str(), cell_style,
              text_style);
    }
  }

  /// The node of @p row alone, cut out of its run or stated past the last.
  [[nodiscard]] pugi::xml_node claim_row(const ElementIdentifier sheet_id,
                                         const std::uint32_t row) const {
    const ElementRegistry::Sheet &sheet =
        m_registry->sheet_element_at(sheet_id);
    if (sheet.row(row) != nullptr) {
      return split_row_at(sheet, row);
    }
    const pugi::xml_node sheet_node = get_node(sheet_id);
    const std::uint32_t rows_end =
        sheet.rows.empty() ? 0 : sheet.rows.back().end;
    if (row > rows_end) {
      pugi::xml_node filler =
          insert_ordered(sheet_node, "table:table-row", after_rows);
      set_repeat(filler, "table:number-rows-repeated", row - rows_end);
      append_empty_cells(filler, sheet.dimensions.columns);
    }
    const pugi::xml_node row_node =
        insert_ordered(sheet_node, "table:table-row", after_rows);
    append_empty_cells(row_node, sheet.dimensions.columns);
    return row_node;
  }

  /// The sheets of the document in the order an operation names them by.
  [[nodiscard]] std::vector<ElementIdentifier> sheets_() const {
    std::vector<ElementIdentifier> result;
    for (ElementIdentifier id = element_first_child(m_document->root_element());
         id != null_element_id; id = element_next_sibling(id)) {
      if (element_type(id) == ElementType::sheet) {
        result.push_back(id);
      }
    }
    return result;
  }

  /// A write leaves every formula reading it computing an old input, and ODF
  /// states no switch asking a reader to recompute, so the cached result goes
  /// instead. A formula the graph could read no position out of
  /// (`SheetDependencies::unresolved`) keeps its result: nothing links it to
  /// the write.
  void drop_stale_results(const ElementIdentifier sheet_id,
                          const std::uint32_t column,
                          const std::uint32_t row) const {
    const std::vector<ElementIdentifier> sheets = sheets_();
    if (const auto written = std::ranges::find(sheets, sheet_id);
        written != sheets.end()) {
      drop_results(m_document->sheet_dependencies().dependents(
          {SheetPosition(static_cast<std::uint32_t>(written - sheets.begin()),
                         TablePosition(column, row))}));
    }
  }

  /// Rebuilds dependencies after a structural edit and invalidates @p touched
  /// formulas and their dependents.
  void drop_moved_results(std::vector<SheetPosition> touched) const {
    m_document->drop_sheet_dependencies();
    m_document->note_moved();
    const std::vector<SheetPosition> dependents =
        m_document->sheet_dependencies().dependents(touched);
    touched.insert(touched.end(), dependents.begin(), dependents.end());
    drop_results(touched);
  }

  void drop_results(const std::vector<SheetPosition> &positions) const {
    const std::vector<ElementIdentifier> sheets = sheets_();
    for (const SheetPosition &position : positions) {
      if (position.sheet >= sheets.size()) {
        continue;
      }
      if (const ElementRegistry::Sheet::Cell *cell =
              m_registry->sheet_element_at(sheets[position.sheet])
                  .cell(position.cell.column, position.cell.row);
          cell != nullptr) {
        drop_cell_result(*cell);
      }
    }
  }

  /// Takes what the cell states about a result away, and nothing else: the
  /// formula, the cell's style and a drawing anchored in it stay.
  void drop_cell_result(const ElementRegistry::Sheet::Cell &cell) const {
    pugi::xml_node node = cell.node;
    remove_value_attributes(node);
    if (cell.element_id == null_element_id) {
      return;
    }

    // collected first, because removing one relinks the chain the walk is on
    std::vector<ElementIdentifier> paragraphs;
    for (ElementIdentifier child = element_first_child(cell.element_id);
         child != null_element_id; child = element_next_sibling(child)) {
      if (element_type(child) == ElementType::paragraph) {
        paragraphs.push_back(child);
      }
    }
    for (const ElementIdentifier paragraph : paragraphs) {
      element_remove(paragraph);
    }
  }

  [[nodiscard]] TableStyle
  sheet_style(const ElementIdentifier element_id) const override {
    return get_partial_style(element_id).table_style;
  }
  [[nodiscard]] TableColumnStyle
  sheet_column_style(const ElementIdentifier element_id,
                     const std::uint32_t column) const override {
    const ElementRegistry::Sheet &sheet_registry =
        m_registry->sheet_element_at(element_id);
    const pugi::xml_node column_node = sheet_registry.column_node(column);
    if (const pugi::xml_attribute attr =
            column_node.attribute("table:style-name");
        attr) {
      if (const Style *style = m_document->style_registry().style(attr.value());
          style != nullptr) {
        return style->resolved().table_column_style;
      }
    }
    return {};
  }
  [[nodiscard]] TableRowStyle
  sheet_row_style(const ElementIdentifier element_id,
                  const std::uint32_t row) const override {
    const ElementRegistry::Sheet &sheet_registry =
        m_registry->sheet_element_at(element_id);
    const pugi::xml_node row_node = sheet_registry.row_node(row);
    if (const pugi::xml_attribute attr =
            row_node.attribute("table:style-name")) {
      if (const Style *style = m_document->style_registry().style(attr.value());
          style != nullptr) {
        return style->resolved().table_row_style;
      }
    }
    return {};
  }
  [[nodiscard]] TableCellStyle
  sheet_cell_style(const ElementIdentifier element_id,
                   const std::uint32_t column,
                   const std::uint32_t row) const override {
    const ElementIdentifier cell_id = sheet_cell(element_id, column, row);
    return get_partial_cell_style(element_id, cell_id, {column, row})
        .table_cell_style;
  }

  /// [ODF 1.2] 19.684 `table:number-matrix-columns-spanned`.
  [[nodiscard]] std::optional<TableDimensions>
  sheet_cell_array_span(const ElementIdentifier element_id) const override {
    if (m_registry->sheet_cell_element(element_id) == nullptr) {
      return std::nullopt;
    }
    const pugi::xml_node node = get_node(element_id);
    const pugi::xml_attribute columns =
        node.attribute("table:number-matrix-columns-spanned");
    if (!columns || !node.attribute("table:formula")) {
      return std::nullopt;
    }
    return TableDimensions(
        node.attribute("table:number-matrix-rows-spanned").as_uint(1),
        columns.as_uint(1));
  }

  [[nodiscard]] std::optional<std::string>
  sheet_number_format(const ElementIdentifier element_id,
                      const std::uint32_t column,
                      const std::uint32_t row) const override {
    return data_style_code(element_id, sheet_cell(element_id, column, row),
                           {column, row});
  }

  [[nodiscard]] TablePosition
  sheet_cell_position(const ElementIdentifier element_id) const override {
    if (positional_id::holds(element_id)) {
      return {positional_id::column_of(element_id),
              positional_id::row_of(element_id)};
    }
    return m_registry->sheet_cell_element_at(element_id).position;
  }
  [[nodiscard]] bool
  sheet_cell_is_covered(const ElementIdentifier element_id) const override {
    return std::strcmp(get_node(element_id).name(),
                       "table:covered-table-cell") == 0;
  }
  [[nodiscard]] TableDimensions
  sheet_cell_span(const ElementIdentifier element_id) const override {
    const pugi::xml_node node = get_node(element_id);
    return {node.attribute("table:number-rows-spanned").as_uint(1),
            node.attribute("table:number-columns-spanned").as_uint(1)};
  }
  [[nodiscard]] ValueType
  sheet_cell_value_type(const ElementIdentifier element_id) const override {
    return value_type_of(get_node(element_id));
  }
  /// The code of the cell's data style. Nothing for a cell the file does not
  /// state, which takes its style from its row or column.
  [[nodiscard]] std::optional<std::string>
  sheet_cell_number_format(const ElementIdentifier element_id) const override {
    if (m_registry->sheet_cell_element(element_id) == nullptr) {
      return std::nullopt;
    }
    return data_style_code(element_parent(element_id), element_id,
                           sheet_cell_position(element_id));
  }
  /// [ODF 1.2] 19.386 `office:value`, 19.642 `table:formula`. A date and a
  /// time state days since 1899-12-30; a boolean states 1 or 0.
  [[nodiscard]] CellValue
  sheet_cell_value(const ElementIdentifier element_id) const override {
    const pugi::xml_node node = get_node(element_id);

    CellValue result = CellValue(sheet_cell_value_type(element_id));
    if (const std::optional<double> number =
            result.type() == ValueType::date
                ? date_days(node.attribute("office:date-value").value())
            : result.type() == ValueType::time
                ? duration_days(node.attribute("office:time-value").value())
                : util::number::parse(node.attribute("office:value").value());
        number.has_value()) {
      result = result.with_number(*number);
    }
    if (result.type() == ValueType::boolean) {
      const bool set =
          std::strcmp("true", node.attribute("office:boolean-value").value()) ==
          0;
      result = result.with_number(set ? 1 : 0);
    }
    if (const pugi::xml_attribute formula = node.attribute("table:formula")) {
      result = result.with_formula(formula.value());
    }
    return result;
  }

  [[nodiscard]] PageLayout
  master_page_page_layout(const ElementIdentifier element_id) const override {
    const pugi::xml_node node = get_node(element_id);
    if (const pugi::xml_attribute attribute =
            node.attribute("style:page-layout-name");
        attribute) {
      return m_document->style_registry().page_layout(attribute.value());
    }
    return {};
  }

  [[nodiscard]] TextStyle
  line_break_style(const ElementIdentifier element_id) const override {
    return get_intermediate_style(element_id).text_style;
  }

  [[nodiscard]] ElementIdentifier
  paragraph_split(const ElementIdentifier element_id,
                  const ElementIdentifier after_id) const override {
    return TreeEditor(*m_registry).split(element_id, after_id);
  }

  void paragraph_merge_next(const ElementIdentifier element_id) const override {
    const ElementIdentifier next_id = element_next_sibling(element_id);
    if (next_id == null_element_id ||
        element_type(next_id) != ElementType::paragraph) {
      throw std::invalid_argument("no paragraph follows the one to merge into");
    }
    TreeEditor(*m_registry).merge_next(element_id);
  }

  [[nodiscard]] ElementIdentifier
  paragraph_insert_after(const ElementIdentifier element_id) const override {
    return TreeEditor(*m_registry).insert_sibling_after(element_id);
  }

  [[nodiscard]] ParagraphStyle
  paragraph_style(const ElementIdentifier element_id) const override {
    return get_intermediate_style(element_id).paragraph_style;
  }
  [[nodiscard]] TextStyle
  paragraph_text_style(const ElementIdentifier element_id) const override {
    return get_intermediate_style(element_id).text_style;
  }
  void paragraph_set_style(const ElementIdentifier element_id,
                           const ParagraphStyle &style) const override {
    pugi::xml_node node = get_node(element_id);
    const std::string name =
        m_document->style_registry().create_paragraph_style(
            automatic_styles_of(node),
            node.attribute("text:style-name").value(), style);
    pugi::xml_attribute attribute = node.attribute("text:style-name");
    if (!attribute) {
      attribute = node.prepend_attribute("text:style-name");
    }
    attribute.set_value(name.c_str());
  }

  [[nodiscard]] TextStyle
  span_style(const ElementIdentifier element_id) const override {
    return get_intermediate_style(element_id).text_style;
  }

  [[nodiscard]] std::string
  text_content(const ElementIdentifier element_id) const override {
    const ElementRegistry::Text &text_element =
        m_registry->text_element_at(element_id);

    const pugi::xml_node first = get_node(element_id);
    const pugi::xml_node end = text_element.last.next_sibling();

    std::string result;
    for (pugi::xml_node node = first; node != end; node = node.next_sibling()) {
      result += get_text(node);
    }
    return result;
  }
  void text_set_content(const ElementIdentifier element_id,
                        const std::string &text) const override {
    ElementRegistry::Element &element = m_registry->element_at(element_id);
    ElementRegistry::Text &text_element =
        m_registry->text_element_at(element_id);

    const NodeSpan old_span{element.node, text_element.last};
    pugi::xml_node parent = old_span.first.parent();
    const NodeSpan new_span = write_text_nodes(parent, old_span.first, text);

    element.node = new_span.first;
    text_element.last = new_span.last;

    xml::remove_nodes(old_span);
  }

  [[nodiscard]] ElementIdentifier
  text_insert(const ElementIdentifier element_id, const Placement where,
              const std::string &text) const override {
    const ElementRegistry::Text &anchor =
        m_registry->text_element_at(element_id);
    pugi::xml_node parent = get_node(element_id).parent();
    // a run beside this one in the same parent carries the same style
    const pugi::xml_node before = where == Placement::after
                                      ? anchor.last.next_sibling()
                                      : get_node(element_id);

    const NodeSpan span = write_text_nodes(parent, before, text);
    const auto &[new_id, unused_element, unused_text] =
        m_registry->create_text_element(span.first, span.last);
    if (where == Placement::after) {
      m_registry->insert_sibling_after(element_id, new_id);
    } else {
      m_registry->insert_sibling_before(element_id, new_id);
    }
    return new_id;
  }

  [[nodiscard]] ElementIdentifier
  element_append_text(const ElementIdentifier element_id,
                      const std::string &text) const override {
    pugi::xml_node node = get_node(element_id);
    const NodeSpan span = write_text_nodes(node, {}, text);
    const auto &[new_id, unused_element, unused_text] =
        m_registry->create_text_element(span.first, span.last);
    m_registry->append_child(element_id, new_id);
    return new_id;
  }

  void element_remove(const ElementIdentifier element_id) const override {
    TreeEditor(*m_registry).remove(element_id);
  }
  [[nodiscard]] TextStyle
  text_style(const ElementIdentifier element_id) const override {
    return get_intermediate_style(element_id).text_style;
  }
  /// Cuts the span around the run and copies its style, or wraps a bare run
  /// in a new span carrying the delta alone.
  void text_set_style(const ElementIdentifier element_id,
                      const TextStyle &style) const override {
    const ElementIdentifier parent_id = element_parent(element_id);
    ElementIdentifier span_id = null_element_id;
    const char *base_name = nullptr;
    if (parent_id != null_element_id &&
        element_type(parent_id) == ElementType::span) {
      span_id = TreeEditor(*m_registry).isolate(element_id);
      base_name = get_node(span_id).attribute("text:style-name").value();
    } else {
      span_id = wrap_in_span(element_id);
    }

    pugi::xml_node span_node = get_node(span_id);
    const std::string name = m_document->style_registry().create_text_style(
        automatic_styles_of(span_node), base_name, style);
    pugi::xml_attribute attribute = span_node.attribute("text:style-name");
    if (!attribute) {
      attribute = span_node.prepend_attribute("text:style-name");
    }
    attribute.set_value(name.c_str());
  }

  [[nodiscard]] std::string
  link_href(const ElementIdentifier element_id) const override {
    return get_node(element_id).attribute("xlink:href").value();
  }

  [[nodiscard]] std::string
  bookmark_name(const ElementIdentifier element_id) const override {
    return get_node(element_id).attribute("text:name").value();
  }

  [[nodiscard]] ListType
  list_type(const ElementIdentifier element_id) const override {
    return m_registry->list_type(element_id);
  }

  [[nodiscard]] TextStyle
  list_item_style(const ElementIdentifier element_id) const override {
    return get_intermediate_style(element_id).text_style;
  }

  [[nodiscard]] std::string
  list_item_marker(const ElementIdentifier element_id) const override {
    return m_registry->list_marker(element_id).text;
  }

  [[nodiscard]] std::optional<std::uint32_t>
  list_item_number(const ElementIdentifier element_id) const override {
    return m_registry->list_marker(element_id).number;
  }

  [[nodiscard]] TableDimensions
  table_dimensions(const ElementIdentifier element_id) const override {
    const pugi::xml_node node = get_node(element_id);

    TableDimensions result;
    TableCursor cursor;

    for_each_table_column(node, [&](const pugi::xml_node column) {
      const auto columns_repeated =
          column.attribute("table:number-columns-repeated").as_uint(1);
      cursor.add_column(columns_repeated);
    });

    result.columns = cursor.column();
    cursor = {};

    for_each_table_row(node, [&](const pugi::xml_node row) {
      const auto rows_repeated =
          row.attribute("table:number-rows-repeated").as_uint(1);
      cursor.add_row(rows_repeated);
    });

    result.rows = cursor.row();

    return result;
  }
  [[nodiscard]] ElementIdentifier
  table_first_column(const ElementIdentifier element_id) const override {
    return m_registry->table_element_at(element_id).first_column_id;
  }
  [[nodiscard]] ElementIdentifier
  table_first_row(const ElementIdentifier element_id) const override {
    return element_first_child(element_id);
  }
  [[nodiscard]] TableStyle
  table_style(const ElementIdentifier element_id) const override {
    return get_partial_style(element_id).table_style;
  }

  [[nodiscard]] TableColumnStyle
  table_column_style(const ElementIdentifier element_id) const override {
    return get_partial_style(element_id).table_column_style;
  }

  [[nodiscard]] TableRowStyle
  table_row_style(const ElementIdentifier element_id) const override {
    return get_partial_style(element_id).table_row_style;
  }

  [[nodiscard]] bool
  table_cell_is_covered(const ElementIdentifier element_id) const override {
    return std::strcmp(get_node(element_id).name(),
                       "table:covered-table-cell") == 0;
  }
  [[nodiscard]] TableDimensions
  table_cell_span(const ElementIdentifier element_id) const override {
    const pugi::xml_node node = get_node(element_id);
    return {node.attribute("table:number-rows-spanned").as_uint(1),
            node.attribute("table:number-columns-spanned").as_uint(1)};
  }
  [[nodiscard]] ValueType
  table_cell_value_type(const ElementIdentifier element_id) const override {
    return value_type_of(get_node(element_id));
  }
  [[nodiscard]] TableCellStyle
  table_cell_style(const ElementIdentifier element_id) const override {
    return get_partial_style(element_id).table_cell_style;
  }

  [[nodiscard]] ShapeType
  frame_shape_type(const ElementIdentifier element_id) const override {
    return m_registry->shape_type(element_id);
  }
  [[nodiscard]] AnchorType
  frame_anchor_type(const ElementIdentifier element_id) const override {
    const pugi::xml_node node = get_node(element_id);

    const char *anchor_type = node.attribute("text:anchor-type").value();
    if (std::strcmp("as-char", anchor_type) == 0) {
      return AnchorType::as_char;
    }
    if (std::strcmp("char", anchor_type) == 0) {
      return AnchorType::at_char;
    }
    if (std::strcmp("paragraph", anchor_type) == 0) {
      return AnchorType::at_paragraph;
    }
    if (std::strcmp("page", anchor_type) == 0) {
      return AnchorType::at_page;
    }
    return AnchorType::at_page;
  }
  [[nodiscard]] std::optional<Measure>
  frame_x(const ElementIdentifier element_id) const override {
    const pugi::xml_node node = get_node(element_id);
    if (const std::optional<Measure> measure =
            read_measure(node.attribute("svg:x"));
        measure.has_value()) {
      return measure;
    }
    if (const std::optional<DrawingPath> box = connector_box(node);
        box.has_value()) {
      return hundredth_millimetres(box->x);
    }
    return {};
  }
  [[nodiscard]] std::optional<Measure>
  frame_y(const ElementIdentifier element_id) const override {
    const pugi::xml_node node = get_node(element_id);
    if (const std::optional<Measure> measure =
            read_measure(node.attribute("svg:y"));
        measure.has_value()) {
      return measure;
    }
    if (const std::optional<DrawingPath> box = connector_box(node);
        box.has_value()) {
      return hundredth_millimetres(box->y);
    }
    return {};
  }
  [[nodiscard]] std::optional<Measure>
  frame_width(const ElementIdentifier element_id) const override {
    const pugi::xml_node node = get_node(element_id);
    if (const std::optional<Measure> measure =
            read_measure(node.attribute("svg:width"));
        measure.has_value()) {
      return measure;
    }
    if (const std::optional<DrawingPath> box = connector_box(node);
        box.has_value()) {
      return hundredth_millimetres(box->width);
    }
    return {};
  }
  [[nodiscard]] std::optional<Measure>
  frame_height(const ElementIdentifier element_id) const override {
    const pugi::xml_node node = get_node(element_id);
    if (const std::optional<Measure> measure =
            read_measure(node.attribute("svg:height"));
        measure.has_value()) {
      return measure;
    }
    if (const std::optional<DrawingPath> box = connector_box(node);
        box.has_value()) {
      return hundredth_millimetres(box->height);
    }
    return {};
  }
  [[nodiscard]] std::optional<std::int32_t>
  frame_z_index(const ElementIdentifier element_id) const override {
    const pugi::xml_attribute attribute =
        get_node(element_id).attribute("draw:z-index");
    if (!attribute) {
      return std::nullopt;
    }
    return static_cast<std::int32_t>(attribute.as_int());
  }
  [[nodiscard]] std::optional<DrawingTransform>
  frame_transform(const ElementIdentifier element_id) const override {
    return read_transform(get_node(element_id));
  }
  [[nodiscard]] std::optional<DrawingPath>
  frame_path(const ElementIdentifier element_id) const override {
    if (m_registry->shape_type(element_id) != ShapeType::custom) {
      return {};
    }
    return read_path(get_node(element_id));
  }
  [[nodiscard]] std::optional<DrawingLine>
  frame_line(const ElementIdentifier element_id) const override {
    if (m_registry->shape_type(element_id) != ShapeType::line) {
      return {};
    }
    const pugi::xml_node node = get_node(element_id);
    return DrawingLine{
        .x1 = read_measure_or_zero(node.attribute("svg:x1")),
        .y1 = read_measure_or_zero(node.attribute("svg:y1")),
        .x2 = read_measure_or_zero(node.attribute("svg:x2")),
        .y2 = read_measure_or_zero(node.attribute("svg:y2")),
    };
  }
  [[nodiscard]] GraphicStyle
  frame_style(const ElementIdentifier element_id) const override {
    return get_intermediate_style(element_id).graphic_style;
  }

  [[nodiscard]] bool
  image_is_internal(const ElementIdentifier element_id) const override {
    if (image_data(element_id)) {
      return true;
    }
    if (m_document->as_filesystem() == nullptr) {
      return false;
    }
    if (is_object(element_id)) {
      return object_file(element_id).has_value();
    }
    try {
      const AbsPath path = Path(image_href(element_id)).make_absolute();
      return m_document->as_filesystem()->is_file(path);
    } catch (...) { // NOLINT(bugprone-empty-catch): any error => not internal
    }
    return false;
  }
  [[nodiscard]] std::optional<File>
  image_file(const ElementIdentifier element_id) const override {
    if (const pugi::xml_node data = image_data(element_id)) {
      return File(std::make_shared<MemoryFile>(
          crypto::util::base64_decode(data.text().get())));
    }
    if (m_document->as_filesystem() == nullptr) {
      return std::nullopt;
    }
    if (is_object(element_id)) {
      return object_file(element_id);
    }
    const AbsPath path = Path(image_href(element_id)).make_absolute();
    return File(m_document->as_filesystem()->open(path));
  }
  [[nodiscard]] std::string
  image_href(const ElementIdentifier element_id) const override {
    // an embedded image has no path of its own, and the renderer names the
    // resource it writes after this
    if (image_data(element_id)) {
      return "image" + std::to_string(element_id);
    }
    std::string href = get_node(element_id).attribute("xlink:href").value();
    if (is_object(element_id)) {
      return replacement_href(element_id).value_or(href + "/chart.svg");
    }
    return href;
  }

private:
  Document *m_document{nullptr};
  mutable std::mutex m_charts_mutex;
  mutable std::unordered_map<ElementIdentifier, std::optional<std::string>>
      m_charts;

  [[nodiscard]] pugi::xml_node
  get_node(const ElementIdentifier element_id) const {
    return m_registry->element_at(element_id).node;
  }

  /// The attribute where @p node repeats at all, none where it covers one.
  static void set_repeat(pugi::xml_node node, const char *attribute,
                         const std::uint32_t repeated) {
    node.remove_attribute(attribute);
    if (repeated > 1) {
      node.append_attribute(attribute).set_value(repeated);
    }
  }

  /// Cuts the run [@p begin, @p end) so @p at stands alone, copying the parts
  /// around it. @p node stays as the one at @p at, so its element survives.
  static void split_run(pugi::xml_node node, const char *attribute,
                        const std::uint32_t begin, const std::uint32_t end,
                        const std::uint32_t at) {
    if (end > at + 1) {
      set_repeat(node.parent().insert_copy_after(node, node), attribute,
                 end - at - 1);
    }
    if (at > begin) {
      set_repeat(node.parent().insert_copy_before(node, node), attribute,
                 at - begin);
    }
    set_repeat(node, attribute, 1);
  }

  /// Cuts the row run @p row is one position of, so its node stands for that
  /// row alone, and hands that node back. The caller reindexes.
  static pugi::xml_node split_row_at(const ElementRegistry::Sheet &sheet,
                                     const std::uint32_t row) {
    const ElementRegistry::Sheet::Row *row_entry = sheet.row(row);
    const std::size_t row_index = row_entry - sheet.rows.data();
    const std::uint32_t row_begin =
        row_index == 0 ? 0 : sheet.rows[row_index - 1].end;

    split_run(row_entry->node, "table:number-rows-repeated", row_begin,
              row_entry->end, row);

    return row_entry->node;
  }

  /// Whether a span covers (@p column, @p row). The index holds no covered
  /// cell, so the row's dom is asked ([ODF 1.2] 9.1.5).
  [[nodiscard]] bool is_covered(const ElementIdentifier sheet_id,
                                const std::uint32_t column,
                                const std::uint32_t row) const {
    const ElementRegistry::Sheet::Row *row_entry =
        m_registry->sheet_element_at(sheet_id).row(row);
    if (row_entry == nullptr) {
      return false;
    }
    std::uint32_t begin = 0;
    for (const pugi::xml_node cell : row_entry->node.children()) {
      const std::string_view name = cell.name();
      if (name != "table:table-cell" && name != "table:covered-table-cell") {
        continue;
      }
      begin += cell.attribute("table:number-columns-repeated").as_uint(1);
      if (column < begin) {
        return name == "table:covered-table-cell";
      }
    }
    return false;
  }

  /// Gives (@p column, @p row) an element of its own: cuts the row and the
  /// cell run it is one position of, and states the `text:p` an empty cell
  /// has none of. Reindexes: every pointer read before is stale.
  [[nodiscard]] ElementIdentifier claim_cell(const ElementIdentifier sheet_id,
                                             const std::uint32_t column,
                                             const std::uint32_t row) const {
    const ElementRegistry::Sheet &sheet =
        m_registry->sheet_element_at(sheet_id);

    const ElementRegistry::Sheet::Cell *cell_entry = sheet.cell(column, row);
    pugi::xml_node cell_node = cell_entry->node;
    // not the end of the cell before: a span leaves a gap after that one
    const std::uint32_t cell_begin =
        cell_entry->end -
        cell_node.attribute("table:number-columns-repeated").as_uint(1);

    // the row first: the cell keeps its node, so its own run is unmoved
    split_row_at(sheet, row);
    split_run(cell_node, "table:number-columns-repeated", cell_begin,
              cell_entry->end, column);

    if (!cell_node.first_child()) {
      cell_node.append_child("text:p"); // a node with no content gets none
    }

    reindex_sheet(*m_registry, sheet_id);

    return m_registry->sheet_element_at(sheet_id).cell(column, row)->element_id;
  }

  /// What has to follow a `table:table-row` under a `table:table`, and what
  /// has to follow a `table:table-column` ([ODF 1.2] 9.1.2 orders them).
  static constexpr std::array after_rows{
      std::string_view("table:named-expressions")};
  static constexpr std::array after_columns{
      std::string_view("table:table-header-rows"),
      std::string_view("table:table-rows"),
      std::string_view("table:table-row-group"),
      std::string_view("table:table-row"),
      std::string_view("table:named-expressions")};

  /// A new @p name child of @p table, before the first one that has to follow
  /// it.
  static pugi::xml_node
  insert_ordered(pugi::xml_node table, const char *name,
                 const std::span<const std::string_view> after) {
    for (const pugi::xml_node child : table.children()) {
      if (std::ranges::find(after, std::string_view(child.name())) !=
          std::end(after)) {
        return table.insert_child_before(name, child);
      }
    }
    return table.append_child(name);
  }

  static void append_empty_cells(pugi::xml_node row,
                                 const std::uint32_t repeated) {
    set_repeat(row.append_child("table:table-cell"),
               "table:number-columns-repeated", repeated);
  }

  /// Declares the columns the sheet stops before, so its extent reaches
  /// @p column ([ODF 1.2] 9.1.6).
  static void grow_columns(pugi::xml_node sheet_node,
                           ElementRegistry::Sheet &sheet,
                           const std::uint32_t column) {
    if (column < sheet.dimensions.columns) {
      return;
    }
    const std::uint32_t repeated = column + 1 - sheet.dimensions.columns;

    // every declaration comes before the rows, so this lands after all of them
    pugi::xml_node node =
        insert_ordered(sheet_node, "table:table-column", after_columns);
    set_repeat(node, "table:number-columns-repeated", repeated);

    sheet.register_column(sheet.dimensions.columns, repeated, node);
    sheet.dimensions.columns = column + 1;
  }

  /// States the rows and the cells the sheet stops before, so (@p column,
  /// @p row) is a cell of its own holding the `text:p` a value needs.
  /// Reindexes: every pointer read before is stale.
  [[nodiscard]] ElementIdentifier grow_to_cell(const ElementIdentifier sheet_id,
                                               const std::uint32_t column,
                                               const std::uint32_t row) const {
    ElementRegistry::Sheet &sheet = m_registry->sheet_element_at(sheet_id);
    pugi::xml_node sheet_node = get_node(sheet_id);

    pugi::xml_node row_node;
    std::uint32_t cells_end = 0;

    if (const ElementRegistry::Sheet::Row *row_entry = sheet.row(row);
        row_entry == nullptr) {
      const std::uint32_t rows_end =
          sheet.rows.empty() ? 0 : sheet.rows.back().end;
      if (row > rows_end) {
        // a row states at least one cell, so the filler holds an empty one
        pugi::xml_node filler =
            insert_ordered(sheet_node, "table:table-row", after_rows);
        set_repeat(filler, "table:number-rows-repeated", row - rows_end);
        append_empty_cells(filler, sheet.dimensions.columns);
      }
      row_node = insert_ordered(sheet_node, "table:table-row", after_rows);
    } else {
      // its cells stand for every position the row repeats over
      row_node = split_row_at(sheet, row);
      // the index holds no covered cell, and a row may end in one
      const std::vector<Run> cells = cell_runs(row_node);
      cells_end = cells.empty() ? 0 : cells.back().end;
    }

    if (column > cells_end) {
      append_empty_cells(row_node, column - cells_end);
    }
    row_node.append_child("table:table-cell").append_child("text:p");

    grow_columns(sheet_node, sheet, column);
    reindex_sheet(*m_registry, sheet_id);

    const ElementRegistry::Sheet::Cell *cell =
        m_registry->sheet_element_at(sheet_id).cell(column, row);
    if (cell == nullptr || cell->element_id == null_element_id) {
      // a rowspan out of an earlier row can push the cell off the position;
      // what was appended is empty, so no reader sees a difference
      throw UnsupportedOperation();
    }
    return cell->element_id;
  }

  /// A new `text:span` around the nodes of @p element_id, taking its place in
  /// the tree.
  [[nodiscard]] ElementIdentifier
  wrap_in_span(const ElementIdentifier element_id) const {
    const NodeSpan nodes = TreeEditor(*m_registry).node_span(element_id);
    pugi::xml_node span_node =
        nodes.first.parent().insert_child_before("text:span", nodes.first);
    // the moves invalidate `next_sibling`, so where the span ends is read first
    const pugi::xml_node end = nodes.last.next_sibling();
    for (pugi::xml_node node = nodes.first; node != end;) {
      const pugi::xml_node next = node.next_sibling();
      span_node.append_move(node);
      node = next;
    }

    const auto &[span_id, unused] =
        m_registry->create_element(ElementType::span, span_node);
    m_registry->insert_sibling_before(element_id, span_id);
    m_registry->unlink_child(element_id);
    m_registry->append_child(span_id, element_id);
    return span_id;
  }

  /// The `office:automatic-styles` of the file @p node sits in, made where
  /// there is none.
  [[nodiscard]] static pugi::xml_node
  automatic_styles_of(const pugi::xml_node node) {
    pugi::xml_node root;
    for (const pugi::xml_node child : node.root().children()) {
      if (child.type() == pugi::xml_node_type::node_element) {
        root = child;
        break;
      }
    }
    if (const pugi::xml_node automatic_styles =
            root.child("office:automatic-styles")) {
      return automatic_styles;
    }
    if (const pugi::xml_node body = root.child("office:body")) {
      return root.insert_child_before("office:automatic-styles", body);
    }
    return root.append_child("office:automatic-styles");
  }

  /// The only child of @p element_id, null where it has none or several.
  [[nodiscard]] ElementIdentifier
  only_child(const ElementIdentifier element_id) const {
    const ElementIdentifier child_id = element_first_child(element_id);
    return child_id != null_element_id &&
                   element_next_sibling(child_id) == null_element_id
               ? child_id
               : null_element_id;
  }

  /// Text, line breaks and spans of them, and nothing else, all the way down.
  [[nodiscard]] bool holds_plain_runs(const ElementIdentifier parent_id) const {
    for (ElementIdentifier child_id = element_first_child(parent_id);
         child_id != null_element_id;
         child_id = element_next_sibling(child_id)) {
      const ElementType type = element_type(child_id);
      if (type == ElementType::text || type == ElementType::line_break) {
        continue;
      }
      if (type != ElementType::span || !holds_plain_runs(child_id)) {
        return false;
      }
    }
    return true;
  }

  /// Whether a write can go through the cell: paragraphs of plain runs. A link
  /// or a drawing is content the write would take away unseen.
  [[nodiscard]] bool holds_plain_lines(const ElementIdentifier cell_id) const {
    for (ElementIdentifier child_id = element_first_child(cell_id);
         child_id != null_element_id;
         child_id = element_next_sibling(child_id)) {
      if (element_type(child_id) != ElementType::paragraph ||
          !holds_plain_runs(child_id)) {
        return false;
      }
    }
    return true;
  }

  /// One `text:p` per line, as LibreOffice writes a cell. The first line goes
  /// through the cell's own run and keeps its style.
  void write_lines(const ElementIdentifier cell_id,
                   const std::string_view text) const {
    const std::size_t first_end = text.find('\n');
    text_set_content(text_run_of(cell_id),
                     std::string(text.substr(0, first_end)));

    ElementIdentifier paragraph_id = element_first_child(cell_id);
    for (ElementIdentifier next_id = element_next_sibling(paragraph_id);
         next_id != null_element_id;
         next_id = element_next_sibling(paragraph_id)) {
      element_remove(next_id);
    }

    for (std::size_t start = first_end; start != std::string_view::npos;) {
      const std::size_t end = text.find('\n', start + 1);
      const std::string_view line = text.substr(
          start + 1, end == std::string_view::npos ? end : end - start - 1);
      paragraph_id = TreeEditor(*m_registry).insert_sibling_after(paragraph_id);
      if (!line.empty()) {
        std::ignore = element_append_text(paragraph_id, std::string(line));
      }
      start = end;
    }
  }

  /// Reuses a sole text run to preserve its style; otherwise creates one,
  /// adding a paragraph if needed. Requires @ref holds_plain_lines.
  [[nodiscard]] ElementIdentifier
  text_run_of(const ElementIdentifier cell_id) const {
    ElementIdentifier paragraph_id = element_first_child(cell_id);
    if (paragraph_id == null_element_id) {
      pugi::xml_node cell_node = get_node(cell_id);
      const auto &[new_id, unused] = m_registry->create_element(
          ElementType::paragraph, cell_node.append_child("text:p"));
      m_registry->append_child(cell_id, new_id);
      paragraph_id = new_id;
    }

    // the deepest element holding the whole content: writing through it keeps
    // the style it carries, as `spreadsheet.js::runOf` does on the page
    ElementIdentifier holder_id = paragraph_id;
    for (ElementIdentifier only_id = only_child(holder_id);
         only_id != null_element_id &&
         element_type(only_id) == ElementType::span;
         only_id = only_child(holder_id)) {
      holder_id = only_id;
    }

    if (const ElementIdentifier text_id = only_child(holder_id);
        text_id != null_element_id &&
        element_type(text_id) == ElementType::text) {
      return text_id;
    }

    pugi::xml_node holder_node = get_node(holder_id);
    m_registry->invalidate_children(holder_id);
    holder_node.remove_children();

    const pugi::xml_node text_node =
        holder_node.append_child(pugi::xml_node_type::node_pcdata);
    const auto &[new_id, unused1, unused2] =
        m_registry->create_text_element(text_node, text_node);
    m_registry->append_child(holder_id, new_id);
    return new_id;
  }

  /// The image's base64 bytes where the markup carries them itself.
  [[nodiscard]] pugi::xml_node
  image_data(const ElementIdentifier element_id) const {
    const pugi::xml_node data =
        get_node(element_id).child("office:binary-data");
    return data.text().empty() ? pugi::xml_node() : data;
  }

  [[nodiscard]] bool is_object(const ElementIdentifier element_id) const {
    return std::strcmp(get_node(element_id).name(), "draw:object") == 0;
  }

  /// The `draw:image` the producer wrote beside the object (10.4.6.2), which
  /// is what draws where the object itself cannot be read.
  [[nodiscard]] std::optional<std::string>
  replacement_href(const ElementIdentifier element_id) const {
    if (chart_svg(element_id).has_value()) {
      return {};
    }
    const pugi::xml_attribute href = get_node(element_id)
                                         .parent()
                                         .child("draw:image")
                                         .attribute("xlink:href");
    if (!href) {
      return {};
    }
    return href.value();
  }

  [[nodiscard]] std::optional<File>
  object_file(const ElementIdentifier element_id) const {
    if (const std::optional<std::string> svg = chart_svg(element_id);
        svg.has_value()) {
      return File(std::make_shared<MemoryFile>(*svg));
    }
    const std::optional<std::string> replacement = replacement_href(element_id);
    if (!replacement.has_value()) {
      return std::nullopt;
    }
    try {
      const AbsPath path = Path(*replacement).make_absolute();
      return File(m_document->as_filesystem()->open(path));
    } catch (...) { // NOLINT(bugprone-empty-catch): no replacement either
    }
    return std::nullopt;
  }

  [[nodiscard]] std::optional<AbsPath>
  object_part(const ElementIdentifier element_id) const {
    const char *href = get_node(element_id).attribute("xlink:href").value();
    if (href[0] == '\0' || m_document->as_filesystem() == nullptr) {
      return {};
    }
    try {
      AbsPath path = Path(href).make_absolute().join(RelPath("content.xml"));
      if (m_document->as_filesystem()->is_file(path)) {
        return path;
      }
    } catch (...) { // NOLINT(bugprone-empty-catch): no part of its own
    }
    return {};
  }

  /// The object's own part rendered, or nothing where it holds no chart. Kept,
  /// because `image_is_internal`, the resource and the `src` each ask for it.
  [[nodiscard]] const std::optional<std::string> &
  chart_svg(const ElementIdentifier element_id) const {
    const std::lock_guard lock(m_charts_mutex);
    if (const auto it = m_charts.find(element_id); it != m_charts.end()) {
      return it->second;
    }
    std::optional<std::string> result;
    if (const std::optional<AbsPath> path = object_part(element_id);
        path.has_value()) {
      try {
        const pugi::xml_document content =
            xml::parse(*m_document->as_filesystem()->open(*path));
        result = render_chart(content.document_element());
      } catch (...) { // NOLINT(bugprone-empty-catch): no chart we can read
      }
    }
    return m_charts.emplace(element_id, std::move(result)).first->second;
  }

  [[nodiscard]] static std::string get_text(const pugi::xml_node node) {
    if (node.type() == pugi::node_pcdata) {
      return node.value();
    }

    const std::string name = node.name();
    if (name == "text:s") {
      const std::size_t count = node.attribute("text:c").as_uint(1);
      return std::string(count, ' ');
    }
    if (name == "text:tab") {
      return "\t";
    }
    return "";
  }

  [[nodiscard]] const char *
  get_style_name(const ElementIdentifier element_id) const {
    const pugi::xml_node node = get_node(element_id);
    for (const pugi::xml_attribute attribute : node.attributes()) {
      if (util::string::ends_with(attribute.name(), ":style-name")) {
        return attribute.value();
      }
    }
    return {};
  }

  [[nodiscard]] ResolvedStyle
  get_partial_style(const ElementIdentifier element_id) const {
    if (m_registry->sheet_cell_element(element_id) != nullptr) {
      // the id's position, not the anchor's: the column default is per column
      return get_partial_cell_style(element_parent(element_id), element_id,
                                    sheet_cell_position(element_id));
    }
    if (const char *style_name = get_style_name(element_id);
        style_name != nullptr) {
      if (const Style *style = m_document->style_registry().style(style_name)) {
        return style->resolved();
      }
    }
    return {};
  }

  [[nodiscard]] ResolvedStyle
  get_intermediate_style(const ElementIdentifier element_id) const {
    const ElementIdentifier parent_id = element_parent(element_id);
    if (parent_id == null_element_id) {
      return get_partial_style(element_id);
    }
    ResolvedStyle base = get_intermediate_style(parent_id);
    base.override(get_partial_style(element_id));
    return base;
  }

  [[nodiscard]] ResolvedStyle
  get_partial_cell_style(const ElementIdentifier sheet_id,
                         const ElementIdentifier cell_id,
                         const TablePosition &position) const {
    if (const char *style_name = cell_style_name(sheet_id, cell_id, position);
        style_name != nullptr) {
      if (const Style *style = m_document->style_registry().style(style_name);
          style != nullptr) {
        return style->resolved();
      }
    }
    return {};
  }

  /// The code of the cell's data style. Nothing where the cell has none.
  [[nodiscard]] std::optional<std::string>
  data_style_code(const ElementIdentifier sheet_id,
                  const ElementIdentifier cell_id,
                  const TablePosition &position) const {
    const StyleRegistry &styles = m_document->style_registry();
    const pugi::xml_node data_style =
        styles.cell_data_style(cell_style_name(sheet_id, cell_id, position));
    if (!data_style) {
      return std::nullopt;
    }
    return format_code(data_style, [&styles](const std::string_view name) {
      return styles.data_style_node(name);
    });
  }

  /// What the cell's data style shows a number as. Nothing where the cell
  /// has no data style, or one whose code does not parse.
  [[nodiscard]] std::optional<number_format::Category>
  data_category(const ElementIdentifier sheet_id,
                const ElementIdentifier cell_id,
                const TablePosition &position) const {
    const std::optional<std::string> code =
        data_style_code(sheet_id, cell_id, position);
    if (!code.has_value()) {
      return std::nullopt;
    }
    try {
      return number_format::Format(*code).category();
    } catch (const std::invalid_argument &) {
      return std::nullopt;
    }
  }

  /// Formats numbers, dates and times using the matching data style and its
  /// language. Returns null if the style does not match the value type.
  [[nodiscard]] std::optional<std::string>
  shown_value(const ElementIdentifier sheet_id, const ElementIdentifier cell_id,
              const TablePosition &position, const CellValue &value) const {
    const bool dated =
        value.type() == ValueType::date || value.type() == ValueType::time;
    if (value.type() != ValueType::float_number && !dated) {
      return std::nullopt;
    }
    const StyleRegistry &styles = m_document->style_registry();
    const pugi::xml_node data_style =
        styles.cell_data_style(cell_style_name(sheet_id, cell_id, position));
    if (!data_style) {
      return std::nullopt;
    }
    const std::optional<std::string> code =
        format_code(data_style, [&styles](const std::string_view name) {
          return styles.data_style_node(name);
        });
    if (!code.has_value()) {
      return std::nullopt;
    }
    try {
      const number_format::Format format(*code);
      if ((format.category() != number_format::Category::number) != dated) {
        return std::nullopt;
      }
      // a time of day has no date to move onto the 1900 system
      const bool day_part =
          value.type() == ValueType::date && value.number() >= 1;
      return format.format(
          day_part ? number_format::serial_from_days(
                         value.number(), number_format::Epoch::from_1900)
                   : value.number(),
          number_format::Epoch::from_1900,
          number_format::symbols_of(
              data_style_locale(data_style)
                  .value_or(m_document->locale().value_or(""))));
    } catch (const std::invalid_argument &) {
      return std::nullopt;
    }
  }

  /// The style the cell shows: its own, else its row's or its column's
  /// default. Null where none of them names one.
  [[nodiscard]] const char *
  cell_style_name(const ElementIdentifier sheet_id,
                  const ElementIdentifier cell_id,
                  const TablePosition &position) const {
    const char *style_name = nullptr;

    if (cell_id != null_element_id) {
      if (const pugi::xml_attribute attribute =
              get_node(cell_id).attribute("table:style-name");
          attribute) {
        style_name = attribute.value();
      }
    }

    const auto [column, row] = position;
    const ElementRegistry::Sheet &sheet_registry =
        m_registry->sheet_element_at(sheet_id);

    if (style_name == nullptr) {
      const pugi::xml_node cell_node = sheet_registry.cell_node(column, row);
      if (const pugi::xml_attribute attribute =
              cell_node.attribute("table:style-name");
          attribute) {
        style_name = attribute.value();
      }
    }

    if (style_name == nullptr) {
      const pugi::xml_node row_node = sheet_registry.row_node(row);
      if (const pugi::xml_attribute attribute =
              row_node.attribute("table:default-cell-style-name");
          attribute) {
        style_name = attribute.value();
      }
    }
    if (style_name == nullptr) {
      const pugi::xml_node column_node = sheet_registry.column_node(column);
      if (const pugi::xml_attribute attribute =
              column_node.attribute("table:default-cell-style-name");
          attribute) {
        style_name = attribute.value();
      }
    }

    return style_name;
  }
};

std::unique_ptr<abstract::ElementAdapter>
create_element_adapter(Document &document, ElementRegistry &registry) {
  return std::make_unique<ElementAdapter>(document, registry);
}

} // namespace

formula::Settings Document::formula_settings() const {
  formula::Settings result{.dialect = formula::Dialect::libreoffice,
                           .case_sensitive = true,
                           .wildcards = false,
                           .regular_expressions = true};
  const pugi::xml_node settings = m_content_xml.document_element()
                                      .child("office:body")
                                      .child("office:spreadsheet")
                                      .child("table:calculation-settings");
  const auto flag = [&](const char *name, const bool unstated) {
    const pugi::xml_attribute attribute = settings.attribute(name);
    return attribute ? std::string_view(attribute.value()) == "true" : unstated;
  };
  result.case_sensitive = flag("table:case-sensitive", result.case_sensitive);
  result.wildcards = flag("table:use-wildcards", result.wildcards);
  result.regular_expressions =
      flag("table:use-regular-expressions", result.regular_expressions);
  result.whole_cell =
      flag("table:search-criteria-must-apply-to-whole-cell", result.whole_cell);
  result.null_year =
      settings.attribute("table:null-year").as_llong(result.null_year);
  if (const std::optional<double> days =
          date_days(settings.child("table:null-date")
                        .attribute("table:date-value")
                        .value());
      days.has_value()) {
    result.null_date = static_cast<std::int64_t>(*days);
  }
  // [ODF 1.2] 4.3.2.1 `meta:generator`, the application that computed the
  // cached results
  pugi::xml_document meta_xml;
  pugi::xml_node meta = m_content_xml.document_element().child("office:meta");
  if (!meta && m_files != nullptr && m_files->is_file(AbsPath("/meta.xml"))) {
    meta_xml = xml::parse(*m_files, AbsPath("/meta.xml"));
    meta = meta_xml.document_element().child("office:meta");
  }
  result.boolean_word =
      boolean_word_of(meta.child("meta:generator").text().get());
  // [ODF 1.2] 19.636 `table:iteration`
  if (const pugi::xml_node iteration = settings.child("table:iteration");
      std::string_view(iteration.attribute("table:status").value()) ==
      "enable") {
    result.iteration = formula::Iteration{
        iteration.attribute("table:steps").as_uint(100),
        iteration.attribute("table:maximum-difference").as_double(0.001)};
  }
  return result;
}

std::vector<formula::Name> Document::formula_names() const {
  std::vector<formula::Name> result;
  const auto collect = [&](const pugi::xml_node names,
                           const std::optional<std::uint32_t> sheet) {
    for (const pugi::xml_node name : names.children()) {
      const std::string_view kind = name.name();
      if (kind == "table:named-range") {
        // an address is a reference without its brackets ([ODF 1.2] 9.2.5)
        result.push_back(formula::Name{
            name.attribute("table:name").value(), sheet,
            "[" +
                std::string(
                    name.attribute("table:cell-range-address").value()) +
                "]"});
      } else if (kind == "table:named-expression") {
        result.push_back(
            formula::Name{name.attribute("table:name").value(), sheet,
                          name.attribute("table:expression").value()});
      }
    }
  };
  const pugi::xml_node spreadsheet = m_content_xml.document_element()
                                         .child("office:body")
                                         .child("office:spreadsheet");
  collect(spreadsheet.child("table:named-expressions"), std::nullopt);
  std::uint32_t ordinal = 0;
  for (const pugi::xml_node table : spreadsheet.children("table:table")) {
    collect(table.child("table:named-expressions"), ordinal++);
  }
  return result;
}

} // namespace odr::internal::odf
