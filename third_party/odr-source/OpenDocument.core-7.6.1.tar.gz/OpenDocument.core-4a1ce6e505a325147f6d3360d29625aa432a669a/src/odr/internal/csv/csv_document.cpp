#include <odr/internal/csv/csv_document.hpp>

#include <odr/document_element.hpp>
#include <odr/exceptions.hpp>
#include <odr/style.hpp>
#include <odr/table_position.hpp>

#include <odr/internal/abstract/document.hpp>
#include <odr/internal/abstract/file.hpp>
#include <odr/internal/common/element_adapter.hpp>
#include <odr/internal/encoding/transcode.hpp>
#include <odr/internal/util/number_util.hpp>
#include <odr/internal/util/stream_util.hpp>

#include <algorithm>
#include <istream>
#include <limits>
#include <memory>
#include <ostream>
#include <stdexcept>
#include <string>
#include <utility>

#include <fmt/format.h>

namespace odr::internal::csv {

namespace {

/// An id is the coordinate, not a registry index; `null_element_id` is zero,
/// so no kind may be. See `AGENTS.md`.
enum class Kind : std::uint64_t {
  root = 1,
  sheet = 2,
  cell = 3,
  text = 4,
};

constexpr std::uint64_t kind_shift = 61;
constexpr std::uint64_t row_shift = 24;
constexpr std::uint64_t column_mask = (std::uint64_t{1} << row_shift) - 1;
constexpr std::uint64_t row_mask =
    (std::uint64_t{1} << (kind_shift - row_shift)) - 1;

constexpr std::uint32_t max_columns = std::uint32_t{1} << row_shift;
constexpr std::uint32_t max_rows = std::numeric_limits<std::uint32_t>::max();

void check_position(const std::uint32_t column, const std::uint32_t row) {
  if (column >= max_columns || row >= max_rows) {
    throw std::out_of_range("csv position out of range");
  }
}

ElementIdentifier make_id(const Kind kind, const std::uint32_t column = 0,
                          const std::uint32_t row = 0) {
  check_position(column, row);
  return static_cast<std::uint64_t>(kind) << kind_shift |
         (static_cast<std::uint64_t>(row) & row_mask) << row_shift |
         (static_cast<std::uint64_t>(column) & column_mask);
}

Kind kind_of(const ElementIdentifier element_id) {
  return static_cast<Kind>(element_id >> kind_shift);
}

std::uint32_t row_of(const ElementIdentifier element_id) {
  return static_cast<std::uint32_t>(element_id >> row_shift & row_mask);
}

std::uint32_t column_of(const ElementIdentifier element_id) {
  return static_cast<std::uint32_t>(element_id & column_mask);
}

using AdapterBase =
    internal::ElementAdapter<abstract::SheetAdapter, abstract::SheetCellAdapter,
                             abstract::TextAdapter>;

class ElementAdapter final : public AdapterBase {
public:
  explicit ElementAdapter(CsvDocument &document) : m_document{&document} {}

  [[nodiscard]] ElementType
  element_type(const ElementIdentifier element_id) const override {
    const auto coordinates =
        element_id & ((std::uint64_t{1} << kind_shift) - 1);
    if ((coordinates >> row_shift) >= max_rows) {
      return ElementType::none;
    }
    switch (kind_of(element_id)) {
    case Kind::root:
      return coordinates == 0 ? ElementType::root : ElementType::none;
    case Kind::sheet:
      return coordinates == 0 ? ElementType::sheet : ElementType::none;
    case Kind::cell:
      return ElementType::sheet_cell;
    case Kind::text:
      return ElementType::text;
    default:
      return ElementType::none;
    }
  }

  [[nodiscard]] ElementIdentifier
  element_parent(const ElementIdentifier element_id) const override {
    switch (kind_of(element_id)) {
    case Kind::sheet:
      return make_id(Kind::root);
    case Kind::cell:
      return make_id(Kind::sheet);
    case Kind::text:
      return make_id(Kind::cell, column_of(element_id), row_of(element_id));
    default:
      return null_element_id;
    }
  }

  [[nodiscard]] ElementIdentifier
  element_first_child(const ElementIdentifier element_id) const override {
    switch (kind_of(element_id)) {
    case Kind::root:
      return make_id(Kind::sheet);
    case Kind::cell:
      return make_id(Kind::text, column_of(element_id), row_of(element_id));
    default:
      // a sheet's cells are reached by coordinate, not by walking
      return null_element_id;
    }
  }

  [[nodiscard]] ElementIdentifier
  element_last_child(const ElementIdentifier element_id) const override {
    return element_first_child(element_id);
  }

  [[nodiscard]] ElementIdentifier element_previous_sibling(
      [[maybe_unused]] const ElementIdentifier element_id) const override {
    return null_element_id;
  }
  [[nodiscard]] ElementIdentifier element_next_sibling(
      [[maybe_unused]] const ElementIdentifier element_id) const override {
    return null_element_id;
  }

  // SheetAdapter

  [[nodiscard]] std::string sheet_name(
      [[maybe_unused]] const ElementIdentifier element_id) const override {
    return "csv";
  }
  [[nodiscard]] PageLayout sheet_page_layout(
      [[maybe_unused]] const ElementIdentifier element_id) const override {
    return {};
  }
  [[nodiscard]] TableDimensions sheet_dimensions(
      [[maybe_unused]] const ElementIdentifier element_id) const override {
    return m_document->dimensions();
  }
  [[nodiscard]] TableDimensions
  sheet_content([[maybe_unused]] const ElementIdentifier element_id,
                const std::optional<TableDimensions> range) const override {
    const TableDimensions dimensions = m_document->dimensions();
    if (!range.has_value()) {
      return dimensions;
    }
    return {std::min(dimensions.rows, range->rows),
            std::min(dimensions.columns, range->columns)};
  }
  [[nodiscard]] ElementIdentifier
  sheet_cell([[maybe_unused]] const ElementIdentifier element_id,
             const std::uint32_t column,
             const std::uint32_t row) const override {
    return make_id(Kind::cell, column, row);
  }
  [[nodiscard]] ElementIdentifier sheet_first_shape(
      [[maybe_unused]] const ElementIdentifier element_id) const override {
    return null_element_id;
  }
  void sheet_set_cell([[maybe_unused]] const ElementIdentifier element_id,
                      const std::uint32_t column, const std::uint32_t row,
                      const CellValue &value) const override {
    if (value.has_formula()) {
      throw UnsupportedOperation(); // a csv field holds no formula
    }
    m_document->set_cell(column, row, cell_text(value));
  }
  void sheet_insert_rows([[maybe_unused]] const ElementIdentifier element_id,
                         const std::uint32_t row,
                         const std::uint32_t count) const override {
    m_document->insert_rows(row, count);
  }
  void sheet_delete_rows([[maybe_unused]] const ElementIdentifier element_id,
                         const std::uint32_t row,
                         const std::uint32_t count) const override {
    m_document->delete_rows(row, count);
  }
  void sheet_insert_columns([[maybe_unused]] const ElementIdentifier element_id,
                            const std::uint32_t column,
                            const std::uint32_t count) const override {
    m_document->insert_columns(column, count);
  }
  void sheet_delete_columns([[maybe_unused]] const ElementIdentifier element_id,
                            const std::uint32_t column,
                            const std::uint32_t count) const override {
    m_document->delete_columns(column, count);
  }
  [[nodiscard]] TableStyle sheet_style(
      [[maybe_unused]] const ElementIdentifier element_id) const override {
    return {};
  }
  [[nodiscard]] TableColumnStyle sheet_column_style(
      [[maybe_unused]] const ElementIdentifier element_id,
      [[maybe_unused]] const std::uint32_t column) const override {
    return {};
  }
  [[nodiscard]] TableRowStyle
  sheet_row_style([[maybe_unused]] const ElementIdentifier element_id,
                  [[maybe_unused]] const std::uint32_t row) const override {
    return {};
  }
  [[nodiscard]] TableCellStyle
  sheet_cell_style([[maybe_unused]] const ElementIdentifier element_id,
                   [[maybe_unused]] const std::uint32_t column,
                   [[maybe_unused]] const std::uint32_t row) const override {
    return {};
  }

  // SheetCellAdapter

  [[nodiscard]] TablePosition
  sheet_cell_position(const ElementIdentifier element_id) const override {
    // `TablePosition` is (column, row); `TableDimensions` is (rows, columns)
    return TablePosition(column_of(element_id), row_of(element_id));
  }
  [[nodiscard]] bool sheet_cell_is_covered(
      [[maybe_unused]] const ElementIdentifier element_id) const override {
    return false;
  }
  [[nodiscard]] TableDimensions sheet_cell_span(
      [[maybe_unused]] const ElementIdentifier element_id) const override {
    return {1, 1};
  }
  [[nodiscard]] ValueType
  sheet_cell_value_type(const ElementIdentifier element_id) const override {
    return m_document->value_type(column_of(element_id), row_of(element_id));
  }
  [[nodiscard]] CellValue
  sheet_cell_value(const ElementIdentifier element_id) const override {
    CellValue result = CellValue(sheet_cell_value_type(element_id));
    if (result.type() == ValueType::float_number) {
      if (const std::optional<double> number = util::number::parse(
              m_document->cell(column_of(element_id), row_of(element_id)));
          number.has_value()) {
        result = result.with_number(*number);
      }
    }
    return result;
  }

  // TextAdapter

  [[nodiscard]] std::string
  text_content(const ElementIdentifier element_id) const override {
    return std::string(
        m_document->cell(column_of(element_id), row_of(element_id)));
  }
  [[nodiscard]] TextStyle text_style(
      [[maybe_unused]] const ElementIdentifier element_id) const override {
    return {};
  }

private:
  CsvDocument *m_document;

  static std::string cell_text(const CellValue &value) {
    switch (value.type()) {
    case ValueType::unknown:
      return "";
    case ValueType::string:
      return value.has_text() ? value.text() : "";
    case ValueType::float_number:
      return value.has_text() ? value.text()
                              : fmt::format("{}", value.number());
    case ValueType::boolean:
      return value.has_number() && value.number() != 0 ? "TRUE" : "FALSE";
    case ValueType::date:
    case ValueType::time:
    case ValueType::error:
      break;
    }
    throw UnsupportedOperation();
  }
};

/// RFC 4180 2.6 and 2.7: a field is quoted where it holds the separator, the
/// quote or a line break, and a quote inside it is doubled.
void write_field(std::ostream &out, const std::string_view field,
                 const Dialect &dialect) {
  if (field.find_first_of(std::string{dialect.separator, dialect.quote, '\r',
                                      '\n'}) == std::string_view::npos) {
    out << field;
    return;
  }
  out << dialect.quote;
  for (const char c : field) {
    if (c == dialect.quote) {
      out << dialect.quote;
    }
    out << c;
  }
  out << dialect.quote;
}

} // namespace

CsvDocument::CsvDocument(const abstract::File &file,
                         const TextEncoding encoding, const Dialect dialect,
                         const bool skip_first_line)
    : internal::Document(FileType::comma_separated_values,
                         DocumentType::spreadsheet, nullptr),
      m_dialect{dialect}, m_separator_directive{skip_first_line} {
  const std::unique_ptr<std::istream> in = file.stream();
  const std::string bytes = util::stream::read(*in);
  // Excel reads a csv without one as the system's code page
  m_byte_order_mark =
      encoding != TextEncoding::utf8 || bytes.starts_with("\xef\xbb\xbf");
  std::string text = encoding::to_utf8(bytes, encoding);

  m_final_line_end = text.empty() || text.back() == '\n' || text.back() == '\r';

  RecordReader reader(text, dialect);
  std::vector<std::string> fields;
  if (skip_first_line) {
    reader.read(fields);
  }
  std::uint32_t columns = 0;
  while (reader.read(fields)) {
    if (fields.size() > max_columns || m_rows.size() >= max_rows) {
      throw std::length_error("csv dimensions out of range");
    }
    columns = std::max(columns, static_cast<std::uint32_t>(fields.size()));
    m_rows.push_back(fields);
  }

  m_line_end = reader.line_end().empty() ? "\r\n" : reader.line_end();
  m_dimensions = {static_cast<std::uint32_t>(m_rows.size()), columns};

  // Inspect stored fields only; ragged rows must not expand the traversal.
  // Exclude the header from column value-type inference.
  std::vector<bool> has_value(columns, false);
  m_numeric_columns.assign(columns, true);
  for (std::size_t row = 1; row < m_rows.size(); ++row) {
    const std::vector<std::string> &fields = m_rows[row];
    for (std::size_t column = 0; column < fields.size(); ++column) {
      const std::string &value = fields[column];
      if (value.empty()) {
        continue;
      }
      has_value[column] = true;
      if (!is_number(value)) {
        m_numeric_columns[column] = false;
      }
    }
  }
  for (std::uint32_t column = 0; column < columns; ++column) {
    m_numeric_columns[column] = m_numeric_columns[column] && has_value[column];
  }

  m_root_element = make_id(Kind::root);
  m_element_adapter = std::make_unique<ElementAdapter>(*this);
}

std::string_view CsvDocument::cell(const std::uint32_t column,
                                   const std::uint32_t row) const {
  if (row >= m_rows.size()) {
    return {};
  }
  // the sheet is rectangular even where the file is not
  const std::vector<std::string> &fields = m_rows[row];
  if (column >= fields.size()) {
    return {};
  }
  return fields[column];
}

TableDimensions CsvDocument::dimensions() const noexcept {
  return m_dimensions;
}

ValueType CsvDocument::value_type(const std::uint32_t column,
                                  const std::uint32_t row) const {
  if (column >= m_numeric_columns.size() || !m_numeric_columns[column]) {
    return ValueType::string;
  }
  // the header of a numeric column is still a name
  return is_number(cell(column, row)) ? ValueType::float_number
                                      : ValueType::string;
}

void CsvDocument::set_cell(const std::uint32_t column, const std::uint32_t row,
                           std::string text) {
  check_position(column, row);
  if (row >= m_rows.size()) {
    m_rows.resize(row + 1);
  }
  std::vector<std::string> &fields = m_rows[row];
  if (column >= fields.size()) {
    fields.resize(column + 1);
  }
  fields[column] = std::move(text);

  m_dimensions = {std::max(m_dimensions.rows, row + 1),
                  std::max(m_dimensions.columns, column + 1)};
  if (m_numeric_columns.size() < m_dimensions.columns) {
    m_numeric_columns.resize(m_dimensions.columns, false);
  }

  // a header names its column; a value ends a numeric column or keeps one, and
  // only the other writes need the whole column read again
  const std::string_view written = fields[column];
  if (row == 0 ||
      (!written.empty() && m_numeric_columns[column] && is_number(written))) {
    return;
  }
  if (!written.empty() && !is_number(written)) {
    m_numeric_columns[column] = false;
    return;
  }
  type_column(column);
}

void CsvDocument::insert_rows(const std::uint32_t row,
                              const std::uint32_t count) {
  if (row >= m_rows.size()) {
    return;
  }
  if (count > max_rows - m_dimensions.rows) {
    throw std::length_error("csv row count out of range");
  }
  // a field per column, as the lines around it state
  m_rows.insert(m_rows.begin() + row, count,
                std::vector<std::string>(m_dimensions.columns));
  m_dimensions.rows = static_cast<std::uint32_t>(m_rows.size());
  type_columns();
}

void CsvDocument::delete_rows(const std::uint32_t row,
                              const std::uint32_t count) {
  if (row >= m_rows.size()) {
    return;
  }
  m_rows.erase(m_rows.begin() + row,
               m_rows.begin() +
                   (row + std::min<std::size_t>(count, m_rows.size() - row)));
  m_dimensions.rows = static_cast<std::uint32_t>(m_rows.size());
  type_columns();
}

void CsvDocument::insert_columns(const std::uint32_t column,
                                 const std::uint32_t count) {
  if (column >= m_dimensions.columns) {
    return;
  }
  if (count > max_columns - m_dimensions.columns) {
    throw std::length_error("csv column count out of range");
  }
  for (std::vector<std::string> &fields : m_rows) {
    if (column < fields.size()) {
      fields.insert(fields.begin() + column, count, std::string());
    }
  }
  m_dimensions.columns += count;
  m_numeric_columns.insert(m_numeric_columns.begin() + column, count, false);
}

void CsvDocument::delete_columns(const std::uint32_t column,
                                 const std::uint32_t count) {
  if (column >= m_dimensions.columns) {
    return;
  }
  const std::uint32_t end =
      column + std::min(count, m_dimensions.columns - column);
  for (std::vector<std::string> &fields : m_rows) {
    if (column < fields.size()) {
      fields.erase(fields.begin() + column,
                   fields.begin() + std::min<std::size_t>(end, fields.size()));
    }
  }
  m_dimensions.columns -= end - column;
  m_numeric_columns.erase(m_numeric_columns.begin() + column,
                          m_numeric_columns.begin() + end);
}

void CsvDocument::type_columns() {
  // the first row may be another one now, and it names its column
  for (std::uint32_t column = 0; column < m_numeric_columns.size(); ++column) {
    type_column(column);
  }
}

void CsvDocument::type_column(const std::uint32_t column) {
  bool has_value = false;
  bool numeric = true;
  for (std::uint32_t row = 1; row < m_rows.size(); ++row) {
    const std::string_view value = cell(column, row);
    if (!value.empty()) {
      has_value = true;
      numeric = numeric && is_number(value);
    }
  }
  m_numeric_columns[column] = numeric && has_value;
}

bool CsvDocument::is_editable() const noexcept { return true; }

bool CsvDocument::is_savable(const bool encrypted) const noexcept {
  return !encrypted;
}

void CsvDocument::save(std::ostream &out) const {
  if (m_byte_order_mark) {
    out << "\xef\xbb\xbf";
  }
  if (m_separator_directive) {
    out << "sep=" << m_dialect.separator << m_line_end;
  }
  for (std::size_t row = 0; row < m_rows.size(); ++row) {
    const std::vector<std::string> &fields = m_rows[row];
    if (fields.size() <= 1 &&
        cell(0, static_cast<std::uint32_t>(row)).empty()) {
      // an empty line is no record, so an empty row states its one field
      out << m_dialect.quote << m_dialect.quote;
    }
    for (std::size_t column = 0; column < fields.size(); ++column) {
      if (column > 0) {
        out << m_dialect.separator;
      }
      write_field(out, fields[column], m_dialect);
    }
    if (row + 1 < m_rows.size() || m_final_line_end) {
      out << m_line_end;
    }
  }
}

} // namespace odr::internal::csv
