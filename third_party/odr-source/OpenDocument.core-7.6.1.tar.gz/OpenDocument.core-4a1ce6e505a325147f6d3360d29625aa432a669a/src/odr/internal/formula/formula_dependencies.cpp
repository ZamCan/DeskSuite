#include <odr/internal/formula/formula_dependencies.hpp>

#include <odr/internal/formula/formula_function.hpp>
#include <odr/internal/util/string_util.hpp>

#include <algorithm>
#include <limits>
#include <variant>

namespace odr::internal::formula {

namespace {

constexpr std::uint32_t index_limit = std::numeric_limits<std::uint32_t>::max();

/// The rectangle two corners span. An axis neither corner states reaches the
/// whole sheet; the second corner's unstated sheet is the first's.
Extent extent_of(const CellReference &from, const CellReference &to) {
  const auto index = [](const std::optional<Coordinate> &axis,
                        const std::uint32_t unstated) {
    return axis.has_value() ? axis->index : unstated;
  };
  const std::uint32_t from_column = index(from.column, 0);
  const std::uint32_t to_column = index(to.column, index_limit);
  const std::uint32_t from_row = index(from.row, 0);
  const std::uint32_t to_row = index(to.row, index_limit);
  return Extent{
      from.document, from.sheet,
      TableRange{
          {std::min(from_column, to_column), std::min(from_row, to_row)},
          {std::max(from_column, to_column), std::max(from_row, to_row)}}};
}

void add_extent(const CellReference &from, const CellReference &to,
                References &into) {
  if ((from.sheet.has_value() && from.sheet->find(':') != std::string::npos) ||
      (to.document.has_value() && to.document != from.document) ||
      (to.sheet.has_value() &&
       (!from.sheet.has_value() ||
        !util::string::equals_ignore_case(*from.sheet, *to.sheet)))) {
    into.complete = false;
  }
  into.extents.push_back(extent_of(from, to));
}

const CellReference *as_cell(const Node &node) {
  return std::get_if<CellReference>(&node.content);
}

void collect(const Node &node, References &into) {
  if (const auto *cell = as_cell(node)) {
    add_extent(*cell, *cell, into);
    return;
  }
  if (const auto *range = std::get_if<RangeReference>(&node.content)) {
    add_extent(range->from, range->to, into);
    return;
  }
  if (node.holds<NameReference>()) {
    into.complete = false;
    return;
  }
  // a range the file spelled as two nodes around `:` rather than as one token
  if (const auto *binary = std::get_if<BinaryOperation>(&node.content);
      binary != nullptr && binary->op == BinaryOperator::range &&
      node.children.size() == 2) {
    const CellReference *from = as_cell(node.children.front());
    const CellReference *to = as_cell(node.children.back());
    if (from != nullptr && to != nullptr) {
      add_extent(*from, *to, into);
      return;
    }
    // a corner that is no reference: what the range spans cannot be read
    into.complete = false;
  }
  for (const Node &child : node.children) {
    collect(child, into);
  }
}

/// Puts in what each name stands for. A name that names itself stays one
/// past a few levels, so the formula reads anything.
void put_in_names(
    Node &node,
    const std::function<std::optional<Node>(std::string_view)> &name_of,
    const std::uint32_t depth) {
  if (const auto *name = std::get_if<NameReference>(&node.content)) {
    if (depth < 16 && !name->document.has_value() && !name->sheet.has_value()) {
      if (std::optional<Node> stands_for = name_of(name->name);
          stands_for.has_value()) {
        node = std::move(*stands_for);
        put_in_names(node, name_of, depth + 1);
      }
    }
    return;
  }
  for (Node &child : node.children) {
    put_in_names(child, name_of, depth);
  }
}

/// The open end of an axis a reference leaves out.
std::string spell_bound(const std::uint32_t index) {
  return index == index_limit ? "*" : std::to_string(index);
}

} // namespace

} // namespace odr::internal::formula

namespace odr::internal {

formula::References formula::references(const Node &node) {
  References result;
  result.complete = !has_dynamic_references(node);
  collect(node, result);
  return result;
}

std::string formula::spell_reads(
    const Node &node, const std::uint32_t own_sheet,
    const std::function<std::optional<std::uint32_t>(std::string_view)>
        &sheet_of,
    const std::function<std::optional<Node>(std::string_view)> &name_of) {
  std::string unresolved = std::to_string(own_sheet) + ",0,*,0,*";
  Node named = node;
  put_in_names(named, name_of, 0);
  const References read = references(named);
  // a volatile function computes on every edit, so it reads every position
  if (!read.complete || is_volatile(named)) {
    return unresolved;
  }

  std::string result;
  for (const Extent &extent : read.extents) {
    if (extent.document.has_value()) {
      continue; // another file, which no edit here reaches
    }
    std::uint32_t sheet = own_sheet;
    if (extent.sheet.has_value()) {
      const std::optional<std::uint32_t> named = sheet_of(*extent.sheet);
      if (!named.has_value()) {
        return unresolved;
      }
      sheet = *named;
    }
    if (!result.empty()) {
      result += " ";
    }
    result += std::to_string(sheet) + "," +
              spell_bound(extent.range.from().column) + "," +
              spell_bound(extent.range.to().column) + "," +
              spell_bound(extent.range.from().row) + "," +
              spell_bound(extent.range.to().row);
  }
  return result;
}

} // namespace odr::internal
