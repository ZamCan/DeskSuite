#include <odr/file.hpp>

#include <odr/archive.hpp>
#include <odr/document.hpp>
#include <odr/exceptions.hpp>
#include <odr/odr.hpp>

#include <odr/internal/abstract/file.hpp>
#include <odr/internal/common/file.hpp>
#include <odr/internal/csv/csv_file.hpp>
#include <odr/internal/encoding/transcode.hpp>
#include <odr/internal/magic.hpp>
#include <odr/internal/open_strategy.hpp>
#include <odr/internal/text/text_file.hpp>
#include <odr/internal/util/file_util.hpp>
#include <odr/internal/util/stream_util.hpp>

#include <nlohmann/json.hpp>

#include <fstream>
#include <optional>
#include <ostream>
#include <sstream>
#include <stdexcept>

namespace odr {

namespace {

/// The other constructors reject a null impl, so only a default-constructed
/// @ref File reaches the throw.
const internal::abstract::File &
deref(const std::shared_ptr<internal::abstract::File> &impl) {
  if (impl == nullptr) {
    throw NullPointerError("impl");
  }
  return *impl;
}

} // namespace

DecodeOptions DecodeOptions::as(const FileType type) {
  DecodeOptions result;
  result.as_file_type = type;
  return result;
}

DecodeOptions DecodeOptions::as_csv(const CsvOptions &options) {
  DecodeOptions result = as(FileType::comma_separated_values);
  result.csv = options;
  return result;
}

File File::from_disk(const std::string &path) {
  return File(std::make_shared<internal::DiskFile>(path));
}

File File::from_memory(std::string data, std::string name) {
  return File(
      std::make_shared<internal::MemoryFile>(std::move(data), std::move(name)));
}

File::File() = default;

File::File(std::shared_ptr<internal::abstract::File> impl)
    : m_impl{std::move(impl)} {
  if (m_impl == nullptr) {
    throw NullPointerError("impl");
  }
}

File::File(const std::string &path)
    : m_impl{std::make_shared<internal::DiskFile>(path)} {}

/// `noexcept` leaves no way to report a null impl, hence `unknown`.
FileLocation File::location() const noexcept {
  return m_impl == nullptr ? FileLocation::unknown : m_impl->location();
}

std::size_t File::size() const { return deref(m_impl).size(); }

std::string File::name() const { return deref(m_impl).name(); }

std::optional<std::string> File::disk_path() const {
  if (const std::optional<internal::AbsPath> path = deref(m_impl).disk_path();
      path.has_value()) {
    return path->string();
  }
  return {};
}

std::optional<std::string_view> File::memory_data() const {
  return deref(m_impl).memory_data();
}

std::unique_ptr<std::istream> File::stream() const {
  return deref(m_impl).stream();
}

void File::pipe(std::ostream &out) const {
  internal::util::stream::pipe(*stream(), out);
}

void File::copy(const std::string &path) const {
  internal::util::file::write(*stream(), path);
}

std::shared_ptr<internal::abstract::File> File::impl() const { return m_impl; }

DecodedFile::DecodedFile(std::shared_ptr<internal::abstract::DecodedFile> impl)
    : m_impl{std::move(impl)} {
  if (m_impl == nullptr) {
    throw NullPointerError("impl");
  }
}

File DecodedFile::file() const { return File(m_impl->file()); }

FileType DecodedFile::file_type() const noexcept { return m_impl->file_type(); }

FileCategory DecodedFile::file_category() const noexcept {
  return m_impl->file_category();
}

FileMeta DecodedFile::file_meta() const { return m_impl->file_meta(); }

bool DecodedFile::password_encrypted() const {
  return m_impl->password_encrypted();
}

EncryptionState DecodedFile::encryption_state() const {
  return m_impl->encryption_state();
}

DecodedFile DecodedFile::decrypt(const std::string &password) const {
  return DecodedFile(m_impl->decrypt(password));
}

bool DecodedFile::is_decodable() const noexcept {
  return m_impl->is_decodable();
}

FileTypeCapabilities DecodedFile::capabilities() const {
  FileTypeCapabilities result = capabilities_by_file_type(file_type());

  // we are holding the decoded file, so this one is settled
  result.open = true;
  // only an actually encrypted file can be decrypted
  result.decrypt =
      result.decrypt && encryption_state() == EncryptionState::encrypted;
  // an encrypted file has to be decrypted before it renders
  result.translate_html =
      result.translate_html && encryption_state() != EncryptionState::encrypted;
  // there is no scheme without html
  result.color_scheme = result.color_scheme && result.translate_html;
  // a file we cannot append to cannot be annotated, whatever the format can do
  result.annotate = result.annotate && m_impl->annotatable();

  // `edit`/`save`/`encrypt` stay as declared — resolving them would mean
  // decoding the document; ask `Document` for the precise answer

  return result;
}

bool DecodedFile::is_text_file() const {
  return std::dynamic_pointer_cast<internal::abstract::TextFile>(m_impl) !=
         nullptr;
}

bool DecodedFile::is_csv_file() const {
  return std::dynamic_pointer_cast<internal::abstract::CsvFile>(m_impl) !=
         nullptr;
}

bool DecodedFile::is_markdown_file() const {
  return std::dynamic_pointer_cast<internal::abstract::MarkdownFile>(m_impl) !=
         nullptr;
}

bool DecodedFile::is_image_file() const {
  return std::dynamic_pointer_cast<internal::abstract::ImageFile>(m_impl) !=
         nullptr;
}

bool DecodedFile::is_archive_file() const {
  return std::dynamic_pointer_cast<internal::abstract::ArchiveFile>(m_impl) !=
         nullptr;
}

bool DecodedFile::is_document_file() const {
  return std::dynamic_pointer_cast<internal::abstract::DocumentFile>(m_impl) !=
         nullptr;
}

bool DecodedFile::is_pdf_file() const {
  return std::dynamic_pointer_cast<internal::abstract::PdfFile>(m_impl) !=
         nullptr;
}

bool DecodedFile::is_font_file() const {
  return std::dynamic_pointer_cast<internal::abstract::FontFile>(m_impl) !=
         nullptr;
}

TextFile DecodedFile::as_text_file() const {
  if (const std::shared_ptr text_file =
          std::dynamic_pointer_cast<internal::abstract::TextFile>(m_impl);
      text_file != nullptr) {
    return TextFile(text_file);
  }
  throw NoTextFile();
}

CsvFile DecodedFile::as_csv_file() const {
  if (const std::shared_ptr csv_file =
          std::dynamic_pointer_cast<internal::abstract::CsvFile>(m_impl);
      csv_file != nullptr) {
    return CsvFile(csv_file);
  }
  throw NoCsvFile();
}

MarkdownFile DecodedFile::as_markdown_file() const {
  if (const std::shared_ptr markdown_file =
          std::dynamic_pointer_cast<internal::abstract::MarkdownFile>(m_impl);
      markdown_file != nullptr) {
    return MarkdownFile(markdown_file);
  }
  throw NoMarkdownFile();
}

ImageFile DecodedFile::as_image_file() const {
  if (const std::shared_ptr image_file =
          std::dynamic_pointer_cast<internal::abstract::ImageFile>(m_impl);
      image_file != nullptr) {
    return ImageFile(image_file);
  }
  throw NoImageFile();
}

ArchiveFile DecodedFile::as_archive_file() const {
  if (const std::shared_ptr archive_file =
          std::dynamic_pointer_cast<internal::abstract::ArchiveFile>(m_impl);
      archive_file != nullptr) {
    return ArchiveFile(archive_file);
  }
  throw NoArchiveFile();
}

DocumentFile DecodedFile::as_document_file() const {
  if (const std::shared_ptr document_file =
          std::dynamic_pointer_cast<internal::abstract::DocumentFile>(m_impl);
      document_file != nullptr) {
    return DocumentFile(document_file);
  }
  throw NoDocumentFile();
}

PdfFile DecodedFile::as_pdf_file() const {
  if (const std::shared_ptr pdf_file =
          std::dynamic_pointer_cast<internal::abstract::PdfFile>(m_impl);
      pdf_file != nullptr) {
    return PdfFile(pdf_file);
  }
  throw NoPdfFile();
}

FontFile DecodedFile::as_font_file() const {
  if (const std::shared_ptr font_file =
          std::dynamic_pointer_cast<internal::abstract::FontFile>(m_impl);
      font_file != nullptr) {
    return FontFile(font_file);
  }
  throw NoFontFile();
}

TextFile::TextFile(std::shared_ptr<internal::abstract::TextFile> impl)
    : DecodedFile(impl), m_impl{std::move(impl)} {}

TextEncoding TextFile::encoding() const { return m_impl->encoding(); }

std::unique_ptr<std::istream> TextFile::stream() const {
  return m_impl->file()->stream();
}

std::string TextFile::text() const {
  const auto stream = m_impl->file()->stream();
  std::string bytes = internal::util::stream::read(*stream);

  const TextEncoding encoding = this->encoding();
  if (!text_encoding_is_decodable(encoding)) {
    return bytes;
  }
  return internal::encoding::to_utf8(bytes, encoding);
}

bool TextFile::is_savable() const noexcept {
  // json is a text file too, and one this library does not write
  if (file_type() != FileType::text_file) {
    return false;
  }
  const TextEncoding encoding = this->encoding();
  return encoding == TextEncoding::unknown ||
         text_encoding_is_decodable(encoding);
}

namespace {

/// The text @p operations set, or none where they state no operation.
std::optional<std::string> content_of(const std::string_view operations) {
  const nlohmann::json json = nlohmann::json::parse(operations);
  if (json.value("version", nlohmann::json{}) != 2) {
    throw std::invalid_argument("unsupported edit version");
  }

  if (!json.at("ops").is_array()) {
    throw std::invalid_argument("edit operations must be an array");
  }

  std::optional<std::string> content;
  for (const nlohmann::json &operation : json.at("ops")) {
    const auto name = operation.at("op").get<std::string>();
    if (name != "setContent") {
      throw std::invalid_argument("unknown operation " + name);
    }
    content = operation.at("text").get<std::string>();
  }
  return content;
}

} // namespace

void TextFile::edit(const std::string_view operations,
                    const Logger & /*logger*/) const {
  if (!is_savable()) {
    throw UnsupportedOperation();
  }
  std::optional<std::string> content = content_of(operations);
  if (!content.has_value()) {
    return;
  }
  const auto text_file =
      std::dynamic_pointer_cast<internal::text::TextFile>(m_impl);
  if (text_file == nullptr) {
    throw UnsupportedOperation();
  }
  text_file->set_text(std::move(*content));
}

void TextFile::save(const std::string &path) const {
  if (!is_savable()) {
    throw UnsupportedOperation();
  }
  internal::util::file::write(text(), path);
}

void TextFile::save(std::ostream &out) const {
  if (!is_savable()) {
    throw UnsupportedOperation();
  }
  out << text();
}

File TextFile::save_to_memory() const {
  std::ostringstream out;
  save(out);
  return File::from_memory(std::move(out).str());
}

void TextFile::write_edited(const std::string_view operations,
                            std::ostream &out,
                            const Logger & /*logger*/) const {
  if (!is_savable()) {
    throw UnsupportedOperation();
  }
  const std::optional<std::string> content = content_of(operations);

  // an envelope stating any operation replaces every byte, so the file is
  // only read where it states none
  out << (content.has_value() ? *content : text());
}

std::shared_ptr<internal::abstract::TextFile> TextFile::impl() const {
  return m_impl;
}

CsvFile::CsvFile(std::shared_ptr<internal::abstract::CsvFile> impl)
    : DecodedFile(impl), m_impl{std::move(impl)} {}

Document CsvFile::document() const { return Document(m_impl->document()); }

TextFile CsvFile::text_file() const { return TextFile(m_impl->text_file()); }

CsvOptions CsvFile::options() const { return m_impl->options(); }

std::shared_ptr<internal::abstract::CsvFile> CsvFile::impl() const {
  return m_impl;
}

MarkdownFile::MarkdownFile(
    std::shared_ptr<internal::abstract::MarkdownFile> impl)
    : DecodedFile(impl), m_impl{std::move(impl)} {}

Document MarkdownFile::document() const { return Document(m_impl->document()); }

TextFile MarkdownFile::text_file() const {
  return TextFile(m_impl->text_file());
}

std::shared_ptr<internal::abstract::MarkdownFile> MarkdownFile::impl() const {
  return m_impl;
}

ImageFile::ImageFile(std::shared_ptr<internal::abstract::ImageFile> impl)
    : DecodedFile(impl), m_impl{std::move(impl)} {}

std::unique_ptr<std::istream> ImageFile::stream() const {
  return m_impl->file()->stream();
}

ArchiveFile::ArchiveFile(std::shared_ptr<internal::abstract::ArchiveFile> impl)
    : DecodedFile(impl), m_impl{std::move(impl)} {}

Archive ArchiveFile::archive() const { return Archive(m_impl->archive()); }

DocumentFile::DocumentFile(
    std::shared_ptr<internal::abstract::DocumentFile> impl)
    : DecodedFile(impl), m_impl{std::move(impl)} {}

DocumentType DocumentFile::document_type() const {
  return m_impl->document_type();
}

DocumentFile DocumentFile::decrypt(const std::string &password) const {
  return DecodedFile::decrypt(password).as_document_file();
}

std::optional<File> DocumentFile::thumbnail() const {
  if (const std::shared_ptr<internal::abstract::File> thumbnail =
          m_impl->thumbnail()) {
    return File(thumbnail);
  }
  return {};
}

Document DocumentFile::document() const { return Document(m_impl->document()); }

std::shared_ptr<internal::abstract::DocumentFile> DocumentFile::impl() const {
  return m_impl;
}

PdfFile::PdfFile(std::shared_ptr<internal::abstract::PdfFile> impl)
    : DecodedFile(impl), m_impl{std::move(impl)} {}

PdfFile PdfFile::decrypt(const std::string &password) const {
  return DecodedFile::decrypt(password).as_pdf_file();
}

bool PdfFile::is_annotatable() const noexcept { return m_impl->annotatable(); }

bool PdfFile::has_permissions() const noexcept {
  return m_impl->permissions().has_value();
}

PdfPermissions PdfFile::permissions() const {
  const std::optional<PdfPermissions> permissions = m_impl->permissions();
  if (!permissions.has_value()) {
    throw ValueNotStated();
  }
  return *permissions;
}

void PdfFile::annotate(const std::string_view annotations, std::ostream &out,
                       const Logger &logger) const {
  m_impl->annotate(annotations, out, logger);
}

std::shared_ptr<internal::abstract::PdfFile> PdfFile::impl() const {
  return m_impl;
}

FontFile::FontFile(std::shared_ptr<internal::abstract::FontFile> impl)
    : DecodedFile(impl), m_impl{std::move(impl)} {}

std::unique_ptr<std::istream> FontFile::stream() const {
  return m_impl->file()->stream();
}

std::shared_ptr<internal::abstract::FontFile> FontFile::impl() const {
  return m_impl;
}

} // namespace odr
