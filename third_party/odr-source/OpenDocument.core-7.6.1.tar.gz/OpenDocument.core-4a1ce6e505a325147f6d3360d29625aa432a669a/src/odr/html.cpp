#include <odr/html.hpp>

#include <odr/archive.hpp>
#include <odr/exceptions.hpp>
#include <odr/filesystem.hpp>
#include <odr/odr.hpp>

#include <odr/internal/abstract/html_service.hpp>
#include <odr/internal/common/path.hpp>
#include <odr/internal/html/document.hpp>
#include <odr/internal/html/filesystem.hpp>
#include <odr/internal/html/font_file.hpp>
#include <odr/internal/html/html_writer.hpp>
#include <odr/internal/html/image_file.hpp>
#include <odr/internal/html/media_file.hpp>
#include <odr/internal/html/pdf_file.hpp>
#include <odr/internal/html/text_file.hpp>
#include <odr/internal/html/xml_file.hpp>
#include <odr/internal/util/file_util.hpp>

#include <algorithm>
#include <filesystem>
#include <fstream>
#include <functional>
#include <mutex>
#include <unordered_set>

using namespace odr::internal;

namespace odr {

namespace {

template <typename T> const T &deref(const std::shared_ptr<T> &impl) {
  if (impl == nullptr) {
    throw NullPointerError("HTML handle");
  }
  return *impl;
}

void write_file(const Path &path,
                const std::function<void(std::ostream &)> &write) {
  std::filesystem::create_directories(path.parent().path());
  std::ofstream out = util::file::create(path.string());
  write(out);
  out.close();
  if (!out) {
    throw FileWriteError(path.string());
  }
}

void bring_offline(const HtmlResources &resources,
                   const std::string &output_path) {
  for (const auto &[resource, location] : resources) {
    if (!location.has_value() || resource.is_external() ||
        !resource.is_accessible()) {
      continue;
    }
    const Path path = Path(output_path).join(RelPath(*location));

    write_file(path, [&](std::ostream &out) { resource.write_resource(out); });
  }
}

} // namespace

HtmlConfig::HtmlConfig() { init(); }

HtmlConfig::HtmlConfig(std::string output_path_)
    : output_path(std::move(output_path_)) {
  init();
}

void HtmlConfig::init() {
  resource_locator = html::standard_resource_locator();
}

Html::Html(HtmlConfig config, std::vector<HtmlPage> pages)
    : m_config{std::move(config)}, m_pages{std::move(pages)} {}

const HtmlConfig &Html::config() const { return m_config; }

const std::vector<HtmlPage> &Html::pages() const { return m_pages; }

HtmlPage::HtmlPage(std::string name, std::string path)
    : name{std::move(name)}, path{std::move(path)} {}

HtmlService::HtmlService() = default;

struct HtmlService::ViewCache final {
  std::once_flag initialized;
  HtmlViews views;
};

HtmlService::HtmlService(std::shared_ptr<abstract::HtmlService> impl)
    : m_impl{std::move(impl)}, m_views{std::make_shared<ViewCache>()} {
  static_cast<void>(deref(m_impl));
}

const HtmlConfig &HtmlService::config() const { return deref(m_impl).config(); }

const HtmlViews &HtmlService::list_views() const {
  const auto &service = deref(m_impl);
  std::call_once(m_views->initialized, [&] {
    HtmlViews views;
    for (const HtmlView &view : service.list_views()) {
      // The public cache retains the service; its own views remain non-owning.
      views.emplace_back(
          std::shared_ptr<abstract::HtmlView>(m_impl, view.impl().get()));
    }
    m_views->views = std::move(views);
  });
  return m_views->views;
}

void HtmlService::warmup() const { deref(m_impl).warmup(); }

bool HtmlService::exists(const std::string &path) const {
  return deref(m_impl).exists(path);
}

std::string HtmlService::mimetype(const std::string &path) const {
  return deref(m_impl).mimetype(path);
}

void HtmlService::write(const std::string &path, std::ostream &out) const {
  deref(m_impl).write(path, out);
}

HtmlResources HtmlService::write_html(const std::string &path,
                                      std::ostream &out) const {
  internal::html::HtmlWriter writer(out, config());
  return deref(m_impl).write_html(path, writer);
}

Html HtmlService::bring_offline(const std::string &output_path) const {
  return bring_offline(output_path, list_views());
}

Html HtmlService::bring_offline(const std::string &output_path,
                                const std::vector<HtmlView> &views) const {
  std::vector<HtmlPage> pages;

  HtmlResources resources;

  for (const HtmlView &view : views) {
    const Path path = Path(output_path).join(RelPath(view.path()));

    HtmlResources view_resources;
    write_file(path, [&](std::ostream &out) {
      view_resources = view.write_html(out);
    });

    resources.insert(resources.end(), view_resources.begin(),
                     view_resources.end());

    pages.emplace_back(view.name(), path.string());
  }

  // a resource shared by two views appears once per view, and those need not be
  // adjacent - dedup by path, keeping the first occurrence and the order
  {
    std::unordered_set<std::string> seen;
    const auto removed =
        std::ranges::remove_if(resources, [&seen](const auto &resource) {
          return !seen.insert(resource.first.path()).second;
        });
    resources.erase(removed.begin(), removed.end());
  }

  odr::bring_offline(resources, output_path);

  return {config(), std::move(pages)};
}

const std::shared_ptr<abstract::HtmlService> &HtmlService::impl() const {
  return m_impl;
}

HtmlView::HtmlView() = default;

HtmlView::HtmlView(std::shared_ptr<abstract::HtmlView> impl)
    : m_impl{std::move(impl)} {
  static_cast<void>(deref(m_impl));
}

const std::string &HtmlView::name() const { return deref(m_impl).name(); }

std::size_t HtmlView::index() const { return deref(m_impl).index(); }

const std::string &HtmlView::path() const { return deref(m_impl).path(); }

const HtmlConfig &HtmlView::config() const { return deref(m_impl).config(); }

const std::optional<HtmlSheetCut> &HtmlView::sheet_cut() const {
  return deref(m_impl).sheet_cut();
}

HtmlResources HtmlView::write_html(std::ostream &out) const {
  internal::html::HtmlWriter writer(out, config());
  return deref(m_impl).write_html(writer);
}

Html HtmlView::bring_offline(const std::string &output_path) const {
  HtmlResources resources;

  const Path path = Path(output_path).join(RelPath(this->path()));

  write_file(path, [&](std::ostream &out) { resources = write_html(out); });

  odr::bring_offline(resources, output_path);

  return {config(), {{name(), path.string()}}};
}

const std::shared_ptr<abstract::HtmlView> &HtmlView::impl() const {
  return m_impl;
}

HtmlResource::HtmlResource() = default;

HtmlResource::HtmlResource(std::shared_ptr<abstract::HtmlResource> impl)
    : m_impl{std::move(impl)} {
  static_cast<void>(deref(m_impl));
}

HtmlResourceType HtmlResource::type() const { return deref(m_impl).type(); }

const std::string &HtmlResource::mime_type() const {
  return deref(m_impl).mime_type();
}

const std::string &HtmlResource::name() const { return deref(m_impl).name(); }

const std::string &HtmlResource::path() const { return deref(m_impl).path(); }

const std::optional<File> &HtmlResource::file() const {
  return deref(m_impl).file();
}

bool HtmlResource::is_shipped() const { return deref(m_impl).is_shipped(); }

bool HtmlResource::is_external() const { return deref(m_impl).is_external(); }

bool HtmlResource::is_accessible() const {
  return deref(m_impl).is_accessible();
}

void HtmlResource::write_resource(std::ostream &os) const {
  deref(m_impl).write_resource(os);
}

namespace {

HtmlService translate_text_file(const TextFile &text_file,
                                const HtmlConfig &config,
                                const Logger &logger) {
  return internal::html::create_text_service(text_file, config, logger);
}

HtmlService translate_image_file(const ImageFile &image_file,
                                 const HtmlConfig &config,
                                 const Logger &logger) {
  // refusing says what a blank `<img>` cannot
  if (!capabilities_by_file_type(image_file.file_type()).translate_html) {
    throw UnsupportedFileType(image_file.file_type());
  }
  return internal::html::create_image_service(image_file, config, logger);
}

HtmlService translate_archive_file(const ArchiveFile &archive_file,
                                   const HtmlConfig &config,
                                   const Logger &logger) {
  return html::translate(archive_file.archive(), config, logger);
}

HtmlService translate_document_file(const DocumentFile &document_file,
                                    const HtmlConfig &config,
                                    const Logger &logger) {
  return html::translate(document_file.document(), config, logger);
}

HtmlService translate_pdf_file(const PdfFile &pdf_file,
                               const HtmlConfig &config, const Logger &logger) {
  return internal::html::create_pdf_service(pdf_file, config, logger);
}

HtmlService translate_font_file(const FontFile &font_file,
                                const HtmlConfig &config,
                                const Logger &logger) {
  return internal::html::create_font_service(font_file, config, logger);
}

} // namespace

HtmlService html::translate(const DecodedFile &file, const HtmlConfig &config,
                            const Logger &logger) {
  if (file.is_csv_file()) {
    return translate(file.as_csv_file().document(), config, logger);
  }
  if (file.is_markdown_file()) {
    return translate(file.as_markdown_file().document(), config, logger);
  }
  // an xml file *is* a text file, so this has to come first; open as
  // `text_file` for the plain line list
  if (file.file_type() == FileType::xml) {
    return internal::html::create_xml_service(file.as_text_file(), config,
                                              logger);
  }
  if (file.is_text_file()) {
    return translate_text_file(file.as_text_file(), config, logger);
  }
  if (file.is_image_file()) {
    return translate_image_file(file.as_image_file(), config, logger);
  }
  if (file.is_archive_file()) {
    return translate_archive_file(file.as_archive_file(), config, logger);
  }
  if (file.is_document_file()) {
    return translate_document_file(file.as_document_file(), config, logger);
  }
  if (file.is_pdf_file()) {
    return translate_pdf_file(file.as_pdf_file(), config, logger);
  }
  if (file.is_font_file()) {
    return translate_font_file(file.as_font_file(), config, logger);
  }
  // No wrapper type to go through: nothing is decoded, so the plain
  // `DecodedFile` already carries the bytes and the type that names them.
  if (const FileCategory category = file.file_category();
      category == FileCategory::audio || category == FileCategory::video) {
    return internal::html::create_media_service(file, config, logger);
  }

  throw UnsupportedFileType(file.file_type());
}

HtmlResourceLocator html::standard_resource_locator() {
  return [](const HtmlResource &resource,
            const HtmlConfig &config) -> HtmlResourceLocation {
    // what we cannot read can only be linked
    if (!resource.is_accessible()) {
      return resource.path();
    }

    if ((config.embed_shipped_resources && resource.is_shipped()) ||
        (config.embed_images && resource.type() == HtmlResourceType::image)) {
      return std::nullopt;
    }

    if (resource.is_shipped()) {
      Path path = Path(config.resource_path).join(RelPath(resource.path()));
      // `rebase` throws across absolute and relative; a relative one is already
      // relative to the document.
      if (const Path output(config.output_path.value_or(""));
          config.relative_resource_paths && config.output_path.has_value() &&
          path.absolute() == output.absolute()) {
        path = path.rebase(output);
      }
      return path.string();
    }

    return resource.path();
  };
}

HtmlService html::translate(const Filesystem &filesystem,
                            const HtmlConfig &config, const Logger &logger) {
  return internal::html::create_filesystem_service(filesystem, config, logger);
}

HtmlService html::translate(const Archive &archive, const HtmlConfig &config,
                            const Logger &logger) {
  return translate(archive.as_filesystem(), config, logger);
}

HtmlService html::translate(const Document &document, const HtmlConfig &config,
                            const Logger &logger) {
  return internal::html::create_document_service(document, config, logger);
}

} // namespace odr
