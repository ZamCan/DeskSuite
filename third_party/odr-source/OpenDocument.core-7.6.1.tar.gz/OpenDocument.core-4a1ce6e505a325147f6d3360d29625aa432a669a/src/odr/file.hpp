#pragma once

#include <odr/logger.hpp>

#include <iosfwd>
#include <memory>
#include <optional>
#include <string>
#include <string_view>
#include <vector>

namespace odr::internal::abstract {
class File;
class DecodedFile;
class TextFile;
class CsvFile;
class MarkdownFile;
class ImageFile;
class ArchiveFile;
class DocumentFile;
class PdfFile;
class FontFile;
} // namespace odr::internal::abstract

namespace odr {
class TextFile;
class CsvFile;
class MarkdownFile;
class ImageFile;
class ArchiveFile;
class DocumentFile;
class PdfFile;
class FontFile;

class Archive;
class Document;

/// Collection of file types.
enum class FileType {
  unknown,

  // https://en.wikipedia.org/wiki/OpenDocument
  opendocument_text,
  opendocument_presentation,
  opendocument_spreadsheet,
  opendocument_graphics,

  // https://en.wikipedia.org/wiki/Office_Open_XML
  office_open_xml_document,
  office_open_xml_presentation,
  office_open_xml_workbook,
  office_open_xml_encrypted,
  // Classification only — `.xlsb` stores the workbook in binary parts, not in
  // the spreadsheetml XML the OOXML engine reads, so there is no decoder.
  excel_binary_workbook,

  // https://en.wikipedia.org/wiki/List_of_Microsoft_Office_filename_extensions
  legacy_word_document,
  legacy_powerpoint_presentation,
  legacy_excel_worksheets,

  // Detection only — magic recognises it so a caller can report the type, but
  // there is no decoder behind it and opening one throws.
  // https://en.wikipedia.org/wiki/WordPerfect
  word_perfect,

  // Read as a text document; character and paragraph formatting, tables and
  // pictures are not decoded yet.
  // https://en.wikipedia.org/wiki/Rich_Text_Format
  rich_text_format,

  // https://en.wikipedia.org/wiki/PDF
  portable_document_format,

  // https://en.wikipedia.org/wiki/Text_file
  text_file,
  // https://en.wikipedia.org/wiki/Comma-separated_values
  comma_separated_values,
  // https://en.wikipedia.org/wiki/JSON
  javascript_object_notation,
  // https://en.wikipedia.org/wiki/Markdown
  markdown,

  // https://en.wikipedia.org/wiki/Zip_(file_format)
  zip,
  // https://en.wikipedia.org/wiki/Compound_File_Binary_Format
  compound_file_binary_format,

  portable_network_graphics,
  graphics_interchange_format,
  jpeg,
  bitmap_image_file,

  starview_metafile,

  // https://en.wikipedia.org/wiki/TrueType
  truetype_font,
  // https://en.wikipedia.org/wiki/OpenType
  opentype_font,

  // Media a viewer is handed alongside documents. Nothing here is decoded:
  // opening one wraps its bytes and translating it hands them to an `<img>` or
  // a player - but unnamed, a video would fall back to plain text.
  // New entries go at the end: the bindings mirror this enum by ordinal.
  // https://en.wikipedia.org/wiki/WebP
  webp,
  // https://en.wikipedia.org/wiki/TIFF
  tagged_image_file_format,
  // https://en.wikipedia.org/wiki/High_Efficiency_Image_File_Format
  high_efficiency_image_format,
  // https://en.wikipedia.org/wiki/AVIF
  av1_image_file_format,

  // https://en.wikipedia.org/wiki/MP3
  mpeg_audio,
  // https://en.wikipedia.org/wiki/MP4_file_format
  mpeg4_audio,
  // https://en.wikipedia.org/wiki/Ogg
  ogg_audio,
  // https://en.wikipedia.org/wiki/WAV
  waveform_audio,
  // https://en.wikipedia.org/wiki/FLAC
  free_lossless_audio_codec,

  // https://en.wikipedia.org/wiki/MP4_file_format
  mpeg4_video,
  // https://en.wikipedia.org/wiki/QuickTime_File_Format
  quicktime_video,
  // https://en.wikipedia.org/wiki/3GP_and_3G2
  third_generation_partnership_video,
  // https://en.wikipedia.org/wiki/Matroska
  matroska_video,
  // https://en.wikipedia.org/wiki/Audio_Video_Interleave
  audio_video_interleave,

  // More images that arrive alongside documents, named the same way and for
  // the same reason as the block above - nothing here is decoded either,
  // except svg, which is xml.
  // https://en.wikipedia.org/wiki/SVG
  scalable_vector_graphics,
  // https://en.wikipedia.org/wiki/ICO_(file_format)
  windows_icon,
  // https://en.wikipedia.org/wiki/JPEG_XL
  jpeg_xl,
  // https://en.wikipedia.org/wiki/JPEG_2000
  jpeg_2000,
  // https://en.wikipedia.org/wiki/Adobe_Photoshop#File_format
  photoshop_document,
  // https://en.wikipedia.org/wiki/Windows_Metafile
  windows_metafile,
  // https://en.wikipedia.org/wiki/Windows_Metafile#Enhanced_Metafile
  enhanced_metafile,

  // Also reported under the formats built on it - an svg comes back as
  // `[text_file, xml, scalable_vector_graphics]`.
  // https://en.wikipedia.org/wiki/XML
  xml,

  // https://en.wikipedia.org/wiki/IWork
  iwork_pages,
  // Classification only - `.numbers` and `.key` sit in the same package the
  // pages engine reads, but which app wrote one is read off its root archive
  // and no fixture pins those two, so nothing detects or decodes them yet.
  iwork_numbers,
  iwork_keynote,

  // Classification only - never detected from its bytes.
  // https://en.wikipedia.org/wiki/HTML
  hypertext_markup_language,
};

/// Collection of file categories.
enum class FileCategory {
  unknown,
  text,
  image,
  archive,
  document,
  font,
  // appended rather than sorted in, for the same reason as `FileType`
  audio,
  video,
};

/// Collection of file locations.
enum class FileLocation {
  unknown, ///< no file behind the handle
  memory,
  disk,
};

/// Format-level capability limits; a concrete file may support less.
/// Query DecodedFile or Document for per-file capabilities.
struct FileTypeCapabilities final {
  bool detect_by_content{}; ///< recognised from its bytes alone
  bool open{};              ///< a decoder exists; @ref odr::open can decode it
  bool decrypt{};           ///< encrypted instances can be decrypted
  bool translate_html{};    ///< @ref html::translate produces html a browser
                            ///< paints
  bool color_scheme{};      ///< the view honors @ref HtmlConfig::color_scheme
  bool edit{};              ///< @ref Document::is_editable can be `true`
  bool save{};              ///< @ref Document::save, or for a plain file
                            ///< @ref TextFile::write_edited
  bool encrypt{};  ///< @ref Document::save with a password is supported
  bool annotate{}; ///< @ref PdfFile::annotate is supported; a concrete file
                   ///< still answers for itself with
                   ///< @ref PdfFile::is_annotatable
  bool create{};   ///< @ref create_document makes a new one
};

/// Collection of encryption states.
enum class EncryptionState {
  unknown,
  not_encrypted,
  encrypted,
  decrypted,
};

/// Collection of document types.
enum class DocumentType {
  unknown,
  text,
  presentation,
  spreadsheet,
  drawing,
};

/// @brief Collection of text encodings.
///
/// Only some can be decoded — see @ref text_encoding_is_decodable; the rest are
/// named so a caller can say what a file is and hand it to something that can.
enum class TextEncoding {
  unknown,

  // unicode
  utf8,
  utf16le,
  utf16be,
  utf32le,
  utf32be,

  // single byte
  ibm866,
  iso_8859_1,
  iso_8859_2,
  iso_8859_3,
  iso_8859_4,
  iso_8859_5,
  iso_8859_6,
  iso_8859_7,
  iso_8859_8,
  iso_8859_10,
  iso_8859_13,
  iso_8859_14,
  iso_8859_15,
  iso_8859_16,
  koi8_r,
  koi8_u,
  macintosh,
  windows_874,
  windows_1250,
  windows_1251,
  windows_1252,
  windows_1253,
  windows_1254,
  windows_1255,
  windows_1256,
  windows_1257,
  windows_1258,
  x_mac_cyrillic,

  // multi byte; named but not decoded
  big5,
  euc_jp,
  euc_kr,
  gb18030,
  iso_2022_jp,
  iso_2022_kr,
  shift_jis,
};

/// @brief How to read a csv file.
///
/// An unset field is detected from the file's opening bytes; a set one is taken
/// as given. @ref CsvFile::options returns these with every field resolved, so
/// a caller can show what was detected and offer to change it.
struct CsvOptions final {
  std::optional<TextEncoding> encoding{};
  std::optional<char> separator{};
  std::optional<char> quote{};
};

/// @brief How to decode a file.
///
/// Every field is optional; the default detects everything. @ref as_file_type
/// skips detection outright, @ref file_type_priority only reorders what
/// detection found.
struct DecodeOptions final {
  /// Decode as exactly this type, rather than detecting one.
  std::optional<FileType> as_file_type;
  /// Preferred types, most preferred first, among those detected.
  std::vector<FileType> file_type_priority;
  /// Format-specific overrides for a file decoded as csv.
  CsvOptions csv;

  /// Decode as exactly @p type, skipping detection.
  [[nodiscard]] static DecodeOptions as(FileType type);
  /// Decode as csv, reading it with @p options.
  [[nodiscard]] static DecodeOptions as_csv(const CsvOptions &options);
};

/// @brief Meta information about a file.
///
/// The document fields are only meaningful when @ref document_type is set;
/// `document_type == DocumentType::unknown` means the file is not a document.
struct FileMeta final {
  FileType type{FileType::unknown};
  std::string_view mimetype;
  bool password_encrypted{false};

  DocumentType document_type{DocumentType::unknown};
  std::optional<std::uint32_t> entry_count;

  // Document information properties (e.g. a PDF `/Info` dictionary). All
  // optional; a backend leaves unset what it does not carry.
  std::optional<std::string> title;
  std::optional<std::string> author;
  std::optional<std::string> subject;
  std::optional<std::string> keywords;
  std::optional<std::string> creator;
  std::optional<std::string> producer;
  std::optional<std::string> creation_date;
  std::optional<std::string> modification_date;
};

/// Represents a file.
class File final {
public:
  /// A file read from @p path on disk.
  [[nodiscard]] static File from_disk(const std::string &path);
  /// @brief A file held in memory; @p data is its bytes, moved in, @p name
  /// what it is called, if known.
  ///
  /// The only way to hand the library a file that has no path — a download, a
  /// browser upload, a decrypted payload.
  [[nodiscard]] static File from_memory(std::string data,
                                        std::string name = {});

  /// Constructs the null file — every accessor but @ref location throws @ref
  /// NullPointerError on it, so assign a real one before use.
  File();
  /// @throws NullPointerError if the impl is null.
  explicit File(std::shared_ptr<internal::abstract::File>);
  /// Equivalent to @ref from_disk.
  explicit File(const std::string &path);

  [[nodiscard]] FileLocation location() const noexcept;
  [[nodiscard]] std::size_t size() const;

  /// The file name, without any directory; empty where there is none.
  [[nodiscard]] std::string name() const;

  [[nodiscard]] std::optional<std::string> disk_path() const;
  [[nodiscard]] std::optional<std::string_view> memory_data() const;

  [[nodiscard]] std::unique_ptr<std::istream> stream() const;
  void pipe(std::ostream &out) const;
  void copy(const std::string &path) const;

  /// The internal file this wraps. The bindings need it to hand one wrapper's
  /// value to another; every public wrapper here offers the same.
  [[nodiscard]] std::shared_ptr<internal::abstract::File> impl() const;

protected:
  std::shared_ptr<internal::abstract::File> m_impl;
};

/// Represents a decoded file.
class DecodedFile {
public:
  /// Decoding is @ref odr::open; this wraps what it produced.
  explicit DecodedFile(std::shared_ptr<internal::abstract::DecodedFile> impl);

  [[nodiscard]] File file() const;

  [[nodiscard]] FileType file_type() const noexcept;
  [[nodiscard]] FileCategory file_category() const noexcept;
  [[nodiscard]] FileMeta file_meta() const;

  [[nodiscard]] bool password_encrypted() const;
  [[nodiscard]] EncryptionState encryption_state() const;
  [[nodiscard]] DecodedFile decrypt(const std::string &password) const;

  [[nodiscard]] bool is_decodable() const noexcept;

  /// @brief What can be done with this file.
  ///
  /// Refines @ref capabilities_by_file_type with what is known about this file.
  /// `edit`/`save`/`encrypt` stay as declared — ask @ref Document::is_editable
  /// / @ref Document::is_savable for those.
  [[nodiscard]] FileTypeCapabilities capabilities() const;

  [[nodiscard]] bool is_text_file() const;
  [[nodiscard]] bool is_csv_file() const;
  [[nodiscard]] bool is_markdown_file() const;
  [[nodiscard]] bool is_image_file() const;
  [[nodiscard]] bool is_archive_file() const;
  [[nodiscard]] bool is_document_file() const;
  [[nodiscard]] bool is_pdf_file() const;
  [[nodiscard]] bool is_font_file() const;

  [[nodiscard]] TextFile as_text_file() const;
  [[nodiscard]] CsvFile as_csv_file() const;
  [[nodiscard]] MarkdownFile as_markdown_file() const;
  [[nodiscard]] ImageFile as_image_file() const;
  [[nodiscard]] ArchiveFile as_archive_file() const;
  [[nodiscard]] DocumentFile as_document_file() const;
  [[nodiscard]] PdfFile as_pdf_file() const;
  [[nodiscard]] FontFile as_font_file() const;

protected:
  std::shared_ptr<internal::abstract::DecodedFile> m_impl;
};

/// Represents a text file.
class TextFile final : public DecodedFile {
public:
  explicit TextFile(std::shared_ptr<internal::abstract::TextFile>);

  /// The encoding the file's bytes were detected as, or decoded with.
  [[nodiscard]] TextEncoding encoding() const;

  /// The file's bytes as they are.
  [[nodiscard]] std::unique_ptr<std::istream> stream() const;
  /// The file's text, decoded to UTF-8 where @ref encoding is decodable, and
  /// the raw bytes where it is not.
  [[nodiscard]] std::string text() const;

  /// False where the file type is not `text_file`, and where @ref encoding
  /// cannot be decoded: the view hands those bytes to the browser as they are,
  /// so what comes back cannot be put back.
  [[nodiscard]] bool is_savable() const noexcept;

  /// Applies @p operations - `{"version": 2, "ops": [{"op": "setContent",
  /// "text": "…"}]}` - to the file, and every handle over it sees the edit. The
  /// text is UTF-8 afterwards. See `docs/design/txt-editing.md`.
  /// @throws UnsupportedOperation where @ref is_savable is false.
  void edit(std::string_view operations,
            const Logger &logger = Logger::null()) const;

  /// Writes the text as UTF-8, with every @ref edit applied.
  /// @throws UnsupportedOperation where @ref is_savable is false.
  void save(const std::string &path) const;
  void save(std::ostream &out) const;
  /// The saved file in memory.
  [[nodiscard]] File save_to_memory() const;

  /// Deprecated: @ref edit, then @ref save. Writes what @p operations make of
  /// the file to @p out, and leaves the file as it is.
  /// @throws UnsupportedOperation where @ref is_savable is false.
  void write_edited(std::string_view operations, std::ostream &out,
                    const Logger &logger = Logger::null()) const;

  [[nodiscard]] std::shared_ptr<internal::abstract::TextFile> impl() const;

private:
  std::shared_ptr<internal::abstract::TextFile> m_impl;
};

/// Represents a csv file.
class CsvFile final : public DecodedFile {
public:
  explicit CsvFile(std::shared_ptr<internal::abstract::CsvFile>);

  /// The csv as a one-sheet spreadsheet.
  /// @throws UnsupportedTextEncoding if the encoding cannot be decoded.
  [[nodiscard]] Document document() const;

  /// The same bytes as plain text. A csv holds a text file rather than being
  /// one, so @ref DecodedFile::is_text_file is false for it.
  [[nodiscard]] TextFile text_file() const;

  /// The options in use, every field resolved.
  [[nodiscard]] CsvOptions options() const;

  [[nodiscard]] std::shared_ptr<internal::abstract::CsvFile> impl() const;

private:
  std::shared_ptr<internal::abstract::CsvFile> m_impl;
};

/// Represents a markdown file.
class MarkdownFile final : public DecodedFile {
public:
  explicit MarkdownFile(std::shared_ptr<internal::abstract::MarkdownFile>);

  /// The markdown as a text document.
  /// @throws UnsupportedTextEncoding if the encoding cannot be decoded.
  [[nodiscard]] Document document() const;

  /// The same bytes as plain text, as @ref CsvFile::text_file is.
  [[nodiscard]] TextFile text_file() const;

  [[nodiscard]] std::shared_ptr<internal::abstract::MarkdownFile> impl() const;

private:
  std::shared_ptr<internal::abstract::MarkdownFile> m_impl;
};

/// Represents an image file.
class ImageFile final : public DecodedFile {
public:
  explicit ImageFile(std::shared_ptr<internal::abstract::ImageFile>);

  [[nodiscard]] std::unique_ptr<std::istream> stream() const;

private:
  std::shared_ptr<internal::abstract::ImageFile> m_impl;
};

/// Represents an archive file.
class ArchiveFile final : public DecodedFile {
public:
  explicit ArchiveFile(std::shared_ptr<internal::abstract::ArchiveFile>);

  [[nodiscard]] Archive archive() const;

private:
  std::shared_ptr<internal::abstract::ArchiveFile> m_impl;
};

/// Represents a document file.
class DocumentFile final : public DecodedFile {
public:
  /// Narrowing is @ref DecodedFile::as_document_file; this wraps its result.
  explicit DocumentFile(std::shared_ptr<internal::abstract::DocumentFile>);

  [[nodiscard]] DocumentType document_type() const;

  [[nodiscard]] DocumentFile decrypt(const std::string &password) const;

  /// @brief The preview image the package carries, if any.
  ///
  /// What the producing application stored — never rendered by us, so it is
  /// only as current as the last save. Empty for a package that carries none
  /// or is still encrypted.
  [[nodiscard]] std::optional<File> thumbnail() const;

  [[nodiscard]] Document document() const;

  [[nodiscard]] std::shared_ptr<internal::abstract::DocumentFile> impl() const;

private:
  std::shared_ptr<internal::abstract::DocumentFile> m_impl;
};

/// The permission bits (`/P`) of an encrypted pdf, ISO 32000-1 table 22. The
/// renderer enforces them only under @ref HtmlConfig::pdf_enforce_permissions.
struct PdfPermissions final {
  bool print{};
  bool modify_contents{};
  bool copy{};
  bool modify_annotations{};
  bool fill_forms{};
  bool copy_for_accessibility{};
  bool assemble{};
  bool print_high_quality{};
};

/// Represents a PDF file.
class PdfFile final : public DecodedFile {
public:
  explicit PdfFile(std::shared_ptr<internal::abstract::PdfFile>);

  [[nodiscard]] PdfFile decrypt(const std::string &password) const;

  /// Whether annotation is supported for this file. False for any `/Encrypt`
  /// dictionary (even after unlocking) or a recovered cross-reference table.
  [[nodiscard]] bool is_annotatable() const noexcept;

  /// Whether the file states permissions: an `/Encrypt` with a `/P`.
  [[nodiscard]] bool has_permissions() const noexcept;
  /// @throws ValueNotStated if @ref has_permissions is false.
  [[nodiscard]] PdfPermissions permissions() const;

  /// Appends highlight, underline, strike-out, squiggly or ink annotations in
  /// PDF user space to a copy of the source, using the browser annotator
  /// schema.
  /// @throws std::invalid_argument if @p annotations is malformed.
  /// @throws std::runtime_error if @ref is_annotatable is false.
  void annotate(std::string_view annotations, std::ostream &out,
                const Logger &logger = Logger::null()) const;

  [[nodiscard]] std::shared_ptr<internal::abstract::PdfFile> impl() const;

private:
  std::shared_ptr<internal::abstract::PdfFile> m_impl;
};

/// Represents a font file.
class FontFile final : public DecodedFile {
public:
  explicit FontFile(std::shared_ptr<internal::abstract::FontFile>);

  [[nodiscard]] std::unique_ptr<std::istream> stream() const;

  [[nodiscard]] std::shared_ptr<internal::abstract::FontFile> impl() const;

private:
  std::shared_ptr<internal::abstract::FontFile> m_impl;
};

} // namespace odr
