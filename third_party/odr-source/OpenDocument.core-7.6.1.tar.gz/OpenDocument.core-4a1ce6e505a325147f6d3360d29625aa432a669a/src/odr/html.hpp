#pragma once

#include <odr/document.hpp>
#include <odr/file.hpp>
#include <odr/logger.hpp>
#include <odr/style.hpp>
#include <odr/table_dimension.hpp>

#include <functional>
#include <memory>
#include <optional>
#include <string>
#include <string_view>
#include <vector>

namespace odr::internal::abstract {
class HtmlService;
class HtmlView;
class HtmlResource;
} // namespace odr::internal::abstract

namespace odr {
class Archive;
class Filesystem;
struct HtmlPage;
class HtmlService;
struct HtmlConfig;

enum class HtmlResourceType {
  html_fragment,
  css,
  js,
  image,
  font,
  // appended rather than sorted in: the bindings mirror this enum by ordinal
  /// Audio or video, never embedded — see @ref HtmlConfig::embed_images.
  media,
  /// An entry of an archive, offered as itself rather than rendered.
  file,
};

/// One file a rendered view needs: a stylesheet, a script, an image, a
/// font. @ref HtmlConfig decides which are embedded and which are linked.
class HtmlResource final {
public:
  /// Empty handle; accessing it throws `NullPointerError`.
  HtmlResource();
  explicit HtmlResource(std::shared_ptr<internal::abstract::HtmlResource> impl);

  [[nodiscard]] HtmlResourceType type() const;
  [[nodiscard]] const std::string &mime_type() const;
  [[nodiscard]] const std::string &name() const;
  [[nodiscard]] const std::string &path() const;
  [[nodiscard]] const std::optional<File> &file() const;
  /// One of the renderer's own compiled-in css/js rather than something the
  /// document carries. See @ref HtmlConfig::embed_shipped_resources.
  [[nodiscard]] bool is_shipped() const;
  [[nodiscard]] bool is_external() const;
  [[nodiscard]] bool is_accessible() const;

  void write_resource(std::ostream &os) const;

private:
  std::shared_ptr<internal::abstract::HtmlResource> m_impl;
};

using HtmlResourceLocation = std::optional<std::string>;
using HtmlResourceLocator = std::function<HtmlResourceLocation(
    const HtmlResource &resource, const HtmlConfig &config)>;
using HtmlResources =
    std::vector<std::pair<HtmlResource, HtmlResourceLocation>>;

/// HTML table gridlines.
enum class HtmlTableGridlines {
  none,
  soft,
  hard,
};

/// The colors the emitted HTML renders against. @ref
/// FileTypeCapabilities::color_scheme says which views honor it.
enum class HtmlColorScheme {
  light,  ///< a white page, carrying the colors the document gives its content
  dark,   ///< a dark page, which the document's own colors give way to
  system, ///< `light` or `dark`, by the reader's `prefers-color-scheme`
};

/// The zoom a view opens at, and who fits it: the browser through the viewport
/// meta tag, which desktop browsers ignore, or the view itself.
enum class HtmlViewportMode {
  automatic,   ///< `fit_width` for fixed-size paged content (PDF pages, slides,
               ///< drawings, images, text documents with page margins),
               ///< `actual_size` for reflowing content (spreadsheets, text)
  fit_width,   ///< initial zoom fits the content's full width on screen
  actual_size, ///< initial zoom locked to 100% (`initial-scale=1.0`)
  none,        ///< no viewport meta tag at all
  /// Like @ref fit_width, but measured by the view and kept current, so a
  /// rotation refits. Needs the script. Last because the bindings map this
  /// enum by ordinal.
  fit_width_by_view,
};

/// How far an edit in a document view may reach. Host policy, not an engine
/// fact.
enum class HtmlEditingScope {
  paragraph, ///< inside one paragraph: no split and no merge; in a sheet,
             ///< no formula input and no results before a save
  document,  ///< across paragraphs: every operation
};

/// How text is emitted in PDF→HTML output. Neither mode needs JavaScript.
enum class PdfTextMode {
  dual_layer,   ///< a visual layer (paint order, embedded PUA glyphs) plus a
                ///< transparent selection layer (reading order, real Unicode),
                ///< like pdf.js
  single_layer, ///< one layer, every glyph mapped to Unicode by frequency
                ///< analysis, like pdf2htmlEX
};

/// HTML configuration.
struct HtmlConfig {
  /// File name for the view that writes the whole document.
  std::string document_output_file_name{"document.html"};

  // per-element view file names; `{index}` is the element's 0-based number
  std::string slide_output_file_name{"slide{index}.html"};
  std::string sheet_output_file_name{"sheet{index}.html"};
  std::string page_output_file_name{"page{index}.html"};

  /// Embed images as data urls rather than writing them beside the document.
  bool embed_images{true};
  /// Load the images a document names outside itself, and keep its relative
  /// links. Off, only a navigable scheme leaves the view, in a new window.
  bool allow_external_content{false};
  /// Write the renderer's own css and js into every document rather than beside
  /// it as one shared file the documents link.
  bool embed_shipped_resources{true};

  /// Where linked shipped resources go, relative to the output path unless
  /// named absolutely. Empty puts them beside the document.
  std::string resource_path;
  /// Link an absolute @ref resource_path relative to the document, so the
  /// output stays movable.
  bool relative_resource_paths{true};

  /// Write the editing scaffolding: the page's editing state, the address an
  /// edit operation names, and the editor script. The mode itself starts off -
  /// the host turns it on with `odr.editing.enable()`.
  bool editable{false};
  /// How much of the document editor the page offers; it refuses the rest
  /// with @ref ErrorCode::edit_out_of_scope. Only the document view reads it.
  HtmlEditingScope editing_scope{HtmlEditingScope::document};

  /// Whether the view's scripts take the keys that move the selection: the
  /// arrows, Tab, Escape, and the keys that open an editor over it.
  bool keyboard_navigation{true};
  /// Whether the view's scripts take the editing chords: undo and redo.
  bool keyboard_shortcuts{true};

  /// The path from `window` to a function that takes each `odr.on*` callback
  /// as a JSON `{type, detail}` string. Empty sends nothing.
  std::string host_message_handler;

  /// Whether a click opens the sheet editor, where a double click always does.
  /// Unset asks the pointer. The page's `setSheetOptions` overrides it.
  std::optional<bool> sheet_edit_on_click;

  /// Render a text document as fixed-size pages rather than reflowing text.
  bool text_document_margin{false};

  /// The colors the output renders against.
  HtmlColorScheme color_scheme{HtmlColorScheme::light};

  /// Largest sheet region written, per axis; cells past it are dropped.
  std::optional<TableDimensions> spreadsheet_limit{
      TableDimensions(100000, 500)};
  /// Cell budget, at least one; caps columns first, then rows by that width.
  std::optional<std::uint64_t> spreadsheet_cell_limit{500000};
  /// Trim a sheet to the cells it uses before the limits above apply.
  bool spreadsheet_limit_by_content{true};
  /// Which gridlines a sheet paints.
  HtmlTableGridlines spreadsheet_gridlines{HtmlTableGridlines::soft};
  /// How much of a sheet's body is held back while `<head>` collects the
  /// classes its cells name. Past it the head goes out with what it has, and a
  /// style block first seen later stays inline.
  std::uint64_t spreadsheet_style_buffer{128u << 20};

  /// The zoom the view opens at; see @ref HtmlViewportMode.
  HtmlViewportMode viewport_mode{HtmlViewportMode::automatic};
  /// Overrides @ref viewport_mode for spreadsheet content when set.
  std::optional<HtmlViewportMode> spreadsheet_viewport_mode;
  /// Raw `content` for the viewport meta tag; overrides the modes above.
  std::optional<std::string> viewport_content;
  /// The width the output is shown at, in css pixels; fits paged content to it.
  std::optional<std::uint32_t> viewport_width;
  /// The zoom the view opens at, 1 being actual size; unset follows the fit.
  std::optional<double> initial_zoom;
  /// Lay out only the lines, rows, pages and slides near the viewport. Off,
  /// the browser lays out all of them, which a large file may not survive, but
  /// its own find and a screen reader reach every one.
  bool lazy_layout{true};
  /// Write the chunks of a text file, a sheet and a pdf after the first as
  /// scripts of their own, which the page loads once the reader comes near,
  /// and the text of those chunks as a search index beside them.
  /// `bring_offline` writes them beside the page, and the HTTP server serves
  /// them. Needs @ref lazy_layout. An editable render, a text file the page
  /// cannot spell in UTF-8, and a pdf in the single layer write everything
  /// into the page.
  bool lazy_loading{false};

  /// The least distance the generated content keeps from the view's border. A
  /// set side raises the inset the view already has, never lowers it; a unit
  /// css cannot read as a length is ignored. A sheet is never inset.
  DirectionalStyle<Measure> min_content_margin;

  /// Indent and break the output into lines rather than writing one stream.
  bool format_html{false};
  /// Repeated @ref html_indent_string per nesting level; 0 disables indenting.
  std::uint8_t html_indent{1};
  std::string html_indent_string{"\t"};

  /// Renders only the pages with 0-based index in `[page_range_begin,
  /// page_range_end)`; page views and `#pN` anchors keep their document-global
  /// numbers. Honored by the pdf pipeline.
  std::uint32_t page_range_begin{0};
  std::optional<std::uint32_t> page_range_end;

  /// How pdf text is written; see @ref PdfTextMode.
  PdfTextMode pdf_text_mode{PdfTextMode::dual_layer};
  /// System fonts `dual_layer` sets its selection layer in, first that
  /// resolves.
  std::vector<std::string> pdf_dual_layer_fallback_fonts{
      "Arial", "Helvetica", "Liberation Sans", "DejaVu Sans", "Nimbus Sans"};
  /// Shrinks the fallback's metrics toward the pdf's (0-1) so css justify can
  /// fill the box. Safe to underestimate: the excess is clipped, not shrunk.
  double pdf_dual_layer_fallback_font_size_adjust{0.5};
  /// Whether an armed annotation tool marks each selection as it is made. The
  /// page's `odr.annotation.setOptions` overrides it.
  bool pdf_annotation_mark_on_selection{false};
  /// Honor @ref PdfFile::permissions, as pdf.js `enablePermissions` does: no
  /// copy, and no print unless the file allows one.
  bool pdf_enforce_permissions{false};

  std::optional<std::string> output_path;
  HtmlResourceLocator resource_locator;

  HtmlConfig();
  explicit HtmlConfig(std::string output_path_);

private:
  void init();
};

/// @brief HTML output.
///
/// Represents the output of a translated file to HTML.
class Html final {
public:
  Html(HtmlConfig config, std::vector<HtmlPage> pages);

  [[nodiscard]] const HtmlConfig &config() const;
  [[nodiscard]] const std::vector<HtmlPage> &pages() const;

private:
  HtmlConfig m_config;
  std::vector<HtmlPage> m_pages;
};

/// @brief HTML page.
///
/// Captures the name and path of an HTML page.
struct HtmlPage final {
  std::string name;
  std::string path;

  HtmlPage(std::string name, std::string path);
};

/// What a view leaves out of the sheet it renders. See @ref
/// HtmlView::sheet_cut.
struct HtmlSheetCut final {
  /// The extent the sheet's cells span.
  TableDimensions content;
  /// The extent the markup carries.
  TableDimensions rendered;
};

/// One page of a rendering: a slide, a sheet, a pdf page, or the whole of
/// a text document. @ref write_html emits it and names the resources it
/// needs.
class HtmlView final {
public:
  /// Empty handle; accessing it throws `NullPointerError`.
  HtmlView();
  explicit HtmlView(std::shared_ptr<internal::abstract::HtmlView> impl);

  [[nodiscard]] const std::string &name() const;
  [[nodiscard]] std::size_t index() const;
  [[nodiscard]] const std::string &path() const;
  [[nodiscard]] const HtmlConfig &config() const;

  /// What the spreadsheet limits cut from this view's sheet, or nothing where
  /// they cut nothing. A view of several sheets answers for the first it cut.
  [[nodiscard]] const std::optional<HtmlSheetCut> &sheet_cut() const;

  HtmlResources write_html(std::ostream &out) const;

  [[nodiscard]] Html bring_offline(const std::string &output_path) const;

  [[nodiscard]] const std::shared_ptr<internal::abstract::HtmlView> &
  impl() const;

private:
  std::shared_ptr<internal::abstract::HtmlView> m_impl;
};

using HtmlViews = std::vector<HtmlView>;

/// A whole document, rendered. Its @ref list_views are the pages, and it
/// serves them and their resources by path — what @ref odr::HttpServer
/// puts on a socket.
class HtmlService final {
public:
  /// Empty handle; accessing it throws `NullPointerError`.
  HtmlService();
  explicit HtmlService(std::shared_ptr<internal::abstract::HtmlService> impl);

  [[nodiscard]] const HtmlConfig &config() const;
  /// Returned views retain the service when copied.
  [[nodiscard]] const HtmlViews &list_views() const;

  void warmup() const;

  [[nodiscard]] bool exists(const std::string &path) const;
  [[nodiscard]] std::string mimetype(const std::string &path) const;

  void write(const std::string &path, std::ostream &out) const;
  HtmlResources write_html(const std::string &path, std::ostream &out) const;

  [[nodiscard]] Html bring_offline(const std::string &output_path) const;
  [[nodiscard]] Html bring_offline(const std::string &output_path,
                                   const std::vector<HtmlView> &views) const;

  [[nodiscard]] const std::shared_ptr<internal::abstract::HtmlService> &
  impl() const;

private:
  struct ViewCache;
  std::shared_ptr<internal::abstract::HtmlService> m_impl;
  std::shared_ptr<ViewCache> m_views;
};

namespace html {

HtmlResourceLocator standard_resource_locator();

/// Translates a decoded file to HTML, dispatching on the decoded type.
HtmlService translate(const DecodedFile &file, const HtmlConfig &config,
                      const Logger &logger = Logger::null());

/// Translates a document to HTML.
HtmlService translate(const Document &document, const HtmlConfig &config,
                      const Logger &logger = Logger::null());
/// Translates a filesystem to HTML.
HtmlService translate(const Filesystem &filesystem, const HtmlConfig &config,
                      const Logger &logger = Logger::null());
/// Translates an archive to HTML.
HtmlService translate(const Archive &archive, const HtmlConfig &config,
                      const Logger &logger = Logger::null());

} // namespace html

} // namespace odr
