#pragma once

#include <cstddef>
#include <cstdint>
#include <iterator>
#include <memory>
#include <optional>
#include <string>

#include <odr/definitions.hpp>
#include <odr/quantity.hpp>
#include <odr/table_dimension.hpp>

namespace odr {
struct TablePosition;
class File;
struct TextStyle;
struct ParagraphStyle;
struct TableStyle;
struct TableColumnStyle;
struct TableRowStyle;
struct TableCellStyle;
struct GraphicStyle;
struct PageLayout;
} // namespace odr

namespace odr::internal::abstract {

class ElementAdapter;
class TextRootAdapter;
class SlideAdapter;
class PageAdapter;
class SheetAdapter;
class SheetCellAdapter;
class MasterPageAdapter;
class LineBreakAdapter;
class ParagraphAdapter;
class SpanAdapter;
class TextAdapter;
class LinkAdapter;
class BookmarkAdapter;
class ListAdapter;
class ListItemAdapter;
class TableAdapter;
class TableColumnAdapter;
class TableRowAdapter;
class TableCellAdapter;
class FrameAdapter;
class ImageAdapter;
} // namespace odr::internal::abstract

namespace odr {

class Element;
class ElementIterator;
class ElementRange;
class TextRoot;
class Slide;
class Sheet;
class SheetCell;
class Page;
class MasterPage;
class LineBreak;
class Paragraph;
class Span;
class Text;
class Link;
class Bookmark;
class List;
class ListItem;
class Table;
class TableColumn;
class TableRow;
class TableCell;
class Frame;
class Image;

/// Collection of element types.
enum class ElementType {
  none,

  root,
  slide,
  sheet,
  page,

  master_page,

  sheet_cell,

  text,
  line_break,
  page_break,
  paragraph,
  span,
  link,
  bookmark,

  list,
  list_item,

  table,
  table_column,
  table_row,
  table_cell,

  frame,
  image,

  group,
};

/// Collection of shapes a frame draws.
enum class ShapeType {
  none, ///< a plain box, drawing no outline of its own
  rect,
  ellipse,
  line,
  custom, ///< an outline of its own, read from @ref Frame::path
};

/// Collection of anchor types.
enum class AnchorType {
  none, ///< the frame does not exist, so it is anchored nowhere
  as_char,
  at_char,
  at_frame,
  at_page,
  at_paragraph,
};

/// Cell value category. Percentages and currencies are numeric; date and time
/// categories may come from the cell’s number format.
enum class ValueType {
  unknown,
  string,
  float_number,
  boolean, ///< states 1 or 0 as its number
  date,
  time,
  error, ///< an evaluation error the file recorded
};

/// Immutable cell value for SheetCell::value and Sheet::set_cell.
/// Numeric values may carry display text or use the cell’s number format.
class CellValue final {
public:
  /// A cell stating no value.
  CellValue() noexcept = default;
  /// A string cell showing @p text.
  explicit CellValue(std::string text);
  /// A number cell showing @p text for @p number.
  explicit CellValue(double number, std::string text);
  /// A number cell showing @p number in the shortest spelling that reads back
  /// as it.
  explicit CellValue(double number);
  /// A cell typed @p type and stating nothing else — what a decoder builds on,
  /// since a file types a cell whatever it goes on to state.
  explicit CellValue(ValueType type);

  /// Adds a numeric value, also used by boolean, date and time cells.
  [[nodiscard]] CellValue with_number(double number) const;
  /// The same value shown as @p text.
  [[nodiscard]] CellValue with_text(std::string text) const;
  /// The same value behind @p formula, in the format's own syntax —
  /// `of:=SUM([.A1:.B2])` for odf, `SUM(A1:B2)` for ooxml. Empty where an
  /// ooxml cell shares a formula only the group's master spells.
  [[nodiscard]] CellValue with_formula(std::string formula) const;

  [[nodiscard]] ValueType type() const noexcept;

  [[nodiscard]] bool has_number() const noexcept;
  [[nodiscard]] bool has_text() const noexcept;
  [[nodiscard]] bool has_formula() const noexcept;

  /// A date states days since 1899-12-30, the time of day in the fraction,
  /// whatever the file counts from; a time states its length in days.
  /// @throws ValueNotStated where the cell states none.
  [[nodiscard]] double number() const;
  /// @throws ValueNotStated where the cell shows no text.
  [[nodiscard]] const std::string &text() const;
  /// @throws ValueNotStated where the cell holds no formula.
  [[nodiscard]] const std::string &formula() const;

private:
  ValueType m_type{ValueType::unknown};
  std::optional<double> m_number;
  std::optional<std::string> m_text;
  std::optional<std::string> m_formula;
};

/// Collection of list types.
enum class ListType {
  unordered,
  ordered,
};

/// Represents an element in a document.
class Element {
public:
  Element();
  Element(const internal::abstract::ElementAdapter *adapter,
          ElementIdentifier identifier);

  explicit operator bool() const;

  [[nodiscard]] ElementType type() const;

  /// The address an edit operation names this element by; unique within one
  /// document, and the same for every decode of the same bytes.
  [[nodiscard]] ElementIdentifier identifier() const noexcept;

  [[nodiscard]] Element parent() const;
  [[nodiscard]] Element first_child() const;
  [[nodiscard]] Element previous_sibling() const;
  [[nodiscard]] Element next_sibling() const;

  [[nodiscard]] bool is_unique() const;
  [[nodiscard]] bool is_self_locatable() const;
  [[nodiscard]] bool is_editable() const;

  [[nodiscard]] ElementRange children() const;

  [[nodiscard]] TextRoot as_text_root() const;
  [[nodiscard]] Slide as_slide() const;
  [[nodiscard]] Sheet as_sheet() const;
  [[nodiscard]] Page as_page() const;
  [[nodiscard]] SheetCell as_sheet_cell() const;
  [[nodiscard]] MasterPage as_master_page() const;
  [[nodiscard]] LineBreak as_line_break() const;
  [[nodiscard]] Paragraph as_paragraph() const;
  [[nodiscard]] Span as_span() const;
  [[nodiscard]] Text as_text() const;
  [[nodiscard]] Link as_link() const;
  [[nodiscard]] Bookmark as_bookmark() const;
  [[nodiscard]] List as_list() const;
  [[nodiscard]] ListItem as_list_item() const;
  [[nodiscard]] Table as_table() const;
  [[nodiscard]] TableColumn as_table_column() const;
  [[nodiscard]] TableRow as_table_row() const;
  [[nodiscard]] TableCell as_table_cell() const;
  [[nodiscard]] Frame as_frame() const;
  [[nodiscard]] Image as_image() const;

protected:
  const internal::abstract::ElementAdapter *m_adapter{nullptr};
  ElementIdentifier m_identifier{null_element_id};

  /// Identifiers are only unique within one document, so the adapter has to
  /// take part. Elements that don't exist carry no adapter to compare and are
  /// all equal to each other.
  friend bool operator==(const Element &lhs, const Element &rhs) {
    if (!lhs.exists_() || !rhs.exists_()) {
      return lhs.exists_() == rhs.exists_();
    }
    return lhs.m_adapter == rhs.m_adapter &&
           lhs.m_identifier == rhs.m_identifier;
  }

  [[nodiscard]] bool exists_() const;
};

/// Represents an iterator for elements in a document.
class ElementIterator {
public:
  using value_type = Element;
  using difference_type = std::ptrdiff_t;
  using pointer = Element *;
  using reference = Element;
  using iterator_category = std::forward_iterator_tag;

  ElementIterator();
  ElementIterator(const internal::abstract::ElementAdapter *adapter,
                  ElementIdentifier identifier);

  Element operator*() const;

  ElementIterator &operator++();
  ElementIterator operator++(int);

private:
  const internal::abstract::ElementAdapter *m_adapter{nullptr};
  ElementIdentifier m_identifier{null_element_id};

  /// Same rule as @ref Element: compare the adapter too, and treat every
  /// exhausted iterator as the end iterator regardless of which range it came
  /// from.
  friend bool operator==(const ElementIterator &lhs,
                         const ElementIterator &rhs) {
    if (!lhs.exists_() || !rhs.exists_()) {
      return lhs.exists_() == rhs.exists_();
    }
    return lhs.m_adapter == rhs.m_adapter &&
           lhs.m_identifier == rhs.m_identifier;
  }

  [[nodiscard]] bool exists_() const;
};

/// Represents a range of elements in a document.
class ElementRange {
public:
  ElementRange();
  explicit ElementRange(const ElementIterator &begin);
  ElementRange(const ElementIterator &begin, const ElementIterator &end);

  [[nodiscard]] ElementIterator begin() const;
  [[nodiscard]] ElementIterator end() const;

private:
  ElementIterator m_begin;
  ElementIterator m_end;
};

/// Represents a typed element in a document.
template <typename T> class ElementBase : public Element {
public:
  ElementBase() = default;
  ElementBase(const internal::abstract::ElementAdapter *adapter,
              ElementIdentifier identifier, const T *adapter2)
      : Element(adapter, identifier), m_adapter2{adapter2} {}

  explicit operator bool() const { return exists_(); }

protected:
  const T *m_adapter2{nullptr};

  [[nodiscard]] bool exists_() const {
    return Element::exists_() && m_adapter2 != nullptr;
  }
};

/// Represents a root element in a document.
class TextRoot final : public ElementBase<internal::abstract::TextRootAdapter> {
public:
  using ElementBase::ElementBase;

  [[nodiscard]] PageLayout page_layout() const;

  [[nodiscard]] MasterPage first_master_page() const;
};

/// Represents a slide element in a document.
class Slide final : public ElementBase<internal::abstract::SlideAdapter> {
public:
  using ElementBase::ElementBase;

  [[nodiscard]] std::string name() const;

  [[nodiscard]] PageLayout page_layout() const;

  [[nodiscard]] MasterPage master_page() const;
};

/// Represents a sheet element in a document.
class Sheet final : public ElementBase<internal::abstract::SheetAdapter> {
public:
  using ElementBase::ElementBase;

  [[nodiscard]] std::string name() const;

  /// The paper the sheet is meant to be printed on, where the file states one.
  [[nodiscard]] PageLayout page_layout() const;

  [[nodiscard]] TableDimensions dimensions() const;
  [[nodiscard]] TableDimensions
  content(std::optional<TableDimensions> range) const;

  [[nodiscard]] SheetCell cell(std::uint32_t column, std::uint32_t row) const;
  [[nodiscard]] ElementRange shapes() const;

  /// Sets a cell value. ODF clears dependent formula caches; OOXML keeps them
  /// and requests recalculation on load. A formula is in the syntax
  /// @ref CellValue::with_formula states, and has no result until
  /// @ref Document::recalculate or a save computes one.
  /// @throws UnsupportedOperation for unwritable cells, a formula that does
  /// not parse, the anchor of an array or a shared formula, a formula in a
  /// csv, or nonfinite numbers.
  /// @throws ValueNotStated for a numeric value without a number.
  void set_cell(std::uint32_t column, std::uint32_t row,
                const CellValue &value) const;
  /// Takes the cell's value away, keeping the style it carries. Not the same
  /// as writing an empty string.
  void clear_cell(std::uint32_t column, std::uint32_t row) const;
  /// States the set fields of both styles on the cell and leaves the rest; a
  /// fill of alpha 0 takes the fill away.
  /// @throws UnsupportedOperation where the cell cannot be styled, or a style
  ///         sets a field no engine writes.
  void set_cell_style(std::uint32_t column, std::uint32_t row,
                      const TableCellStyle &cell_style,
                      const TextStyle &text_style) const;
  /// @ref set_cell_style on every cell of the row, also the ones a later
  /// write makes.
  void set_row_style(std::uint32_t row, const TableCellStyle &cell_style,
                     const TextStyle &text_style) const;
  /// @ref set_cell_style on every cell of the column, also the ones a later
  /// write makes.
  void set_column_style(std::uint32_t column, const TableCellStyle &cell_style,
                        const TextStyle &text_style) const;

  /// Inserts @p count empty rows at @p row, shifting cells and all
  /// references.
  /// @throws UnsupportedOperation if the edit cuts a merge or pushes a cell
  /// off the grid.
  void insert_rows(std::uint32_t row, std::uint32_t count) const;
  /// Removes @p count rows from @p row on, and moves the rows below up. A
  /// reference into the removed rows becomes `#REF!`.
  /// @throws UnsupportedOperation where the edit would cut a merge.
  void delete_rows(std::uint32_t row, std::uint32_t count) const;

  /// Inserts @p count empty columns at @p column, shifting cells and all
  /// references.
  /// @throws UnsupportedOperation if the edit cuts a merge or pushes a cell
  /// off the grid.
  void insert_columns(std::uint32_t column, std::uint32_t count) const;
  /// Removes @p count columns from @p column on, and moves the columns right
  /// of them left. A reference into the removed columns becomes `#REF!`.
  /// @throws UnsupportedOperation where the edit would cut a merge.
  void delete_columns(std::uint32_t column, std::uint32_t count) const;

  [[nodiscard]] TableStyle style() const;
  [[nodiscard]] TableColumnStyle column_style(std::uint32_t column) const;
  [[nodiscard]] TableRowStyle row_style(std::uint32_t row) const;
  [[nodiscard]] TableCellStyle cell_style(std::uint32_t column,
                                          std::uint32_t row) const;
  /// @ref SheetCell::number_format by position, so an empty cell has one too:
  /// the format of its row or its column.
  [[nodiscard]] std::optional<std::string>
  cell_number_format(std::uint32_t column, std::uint32_t row) const;
};

/// Represents a sheet cell element in a document.
class SheetCell final
    : public ElementBase<internal::abstract::SheetCellAdapter> {
public:
  using ElementBase::ElementBase;

  [[nodiscard]] TablePosition position() const;
  [[nodiscard]] bool is_covered() const;
  [[nodiscard]] TableDimensions span() const;
  [[nodiscard]] ValueType value_type() const;
  /// @ref value_type is the narrower and cheaper question the renderer asks.
  [[nodiscard]] CellValue value() const;
  /// The format code the cell shows a number in, as MS-XLS 2.4.126 spells
  /// it: `0.00%`. Nothing for `General`.
  [[nodiscard]] std::optional<std::string> number_format() const;
  /// The columns and rows the cell's array formula fills, from the cell on.
  /// Nothing for a cell that states no array formula.
  [[nodiscard]] std::optional<TableDimensions> array_span() const;
};

/// Represents a page element in a document.
class Page final : public ElementBase<internal::abstract::PageAdapter> {
public:
  using ElementBase::ElementBase;

  [[nodiscard]] std::string name() const;

  [[nodiscard]] PageLayout page_layout() const;

  [[nodiscard]] MasterPage master_page() const;
};

/// Represents a master page element in a document.
class MasterPage final
    : public ElementBase<internal::abstract::MasterPageAdapter> {
public:
  using ElementBase::ElementBase;

  [[nodiscard]] PageLayout page_layout() const;
};

/// Represents a line break element in a document.
class LineBreak final
    : public ElementBase<internal::abstract::LineBreakAdapter> {
public:
  using ElementBase::ElementBase;

  [[nodiscard]] TextStyle style() const;
};

/// Represents a paragraph element in a document.
class Paragraph final
    : public ElementBase<internal::abstract::ParagraphAdapter> {
public:
  using ElementBase::ElementBase;

  [[nodiscard]] ParagraphStyle style() const;
  /// States the set fields of @p style on the paragraph and leaves the rest.
  /// Only `text_align` is written; any other field refuses with
  /// `UnsupportedOperation`.
  void set_style(const ParagraphStyle &style) const;
  [[nodiscard]] TextStyle text_style() const;
};

/// Represents a span element in a document.
class Span final : public ElementBase<internal::abstract::SpanAdapter> {
public:
  using ElementBase::ElementBase;

  [[nodiscard]] TextStyle style() const;
};

/// Represents a text element in a document.
class Text final : public ElementBase<internal::abstract::TextAdapter> {
public:
  using ElementBase::ElementBase;

  [[nodiscard]] std::string content() const;
  void set_content(const std::string &text) const;

  [[nodiscard]] TextStyle style() const;
  /// States the set fields of @p style on the run and leaves the rest. A
  /// `background_color` with alpha 0 removes a highlight. `font_name`,
  /// `font_shadow` and `font_position` refuse with `UnsupportedOperation`.
  void set_style(const TextStyle &style) const;
};

/// Represents a link element in a document.
class Link final : public ElementBase<internal::abstract::LinkAdapter> {
public:
  using ElementBase::ElementBase;

  [[nodiscard]] std::string href() const;
};

/// Represents a bookmark element in a document.
class Bookmark final : public ElementBase<internal::abstract::BookmarkAdapter> {
public:
  using ElementBase::ElementBase;

  [[nodiscard]] std::string name() const;
};

/// Represents a list element in a document.
class List final : public ElementBase<internal::abstract::ListAdapter> {
public:
  using ElementBase::ElementBase;

  [[nodiscard]] ListType type() const;
};

/// Represents a list item element in a document.
class ListItem final : public ElementBase<internal::abstract::ListItemAdapter> {
public:
  using ElementBase::ElementBase;

  [[nodiscard]] TextStyle style() const;

  /// The label this item is marked with, already resolved against the list
  /// style and the running counters — a bullet, "1.", "I.a)", or empty where
  /// the list style asks for no label.
  [[nodiscard]] std::string marker() const;
  /// The counter behind `marker`, absent for an unordered item.
  [[nodiscard]] std::optional<std::uint32_t> number() const;
};

/// Represents a table element in a document.
class Table final : public ElementBase<internal::abstract::TableAdapter> {
public:
  using ElementBase::ElementBase;

  [[nodiscard]] TableRow first_row() const;
  [[nodiscard]] TableColumn first_column() const;

  [[nodiscard]] ElementRange columns() const;
  [[nodiscard]] ElementRange rows() const;

  [[nodiscard]] TableDimensions dimensions() const;

  [[nodiscard]] TableStyle style() const;
};

/// Represents a table column element in a document.
class TableColumn final
    : public ElementBase<internal::abstract::TableColumnAdapter> {
public:
  using ElementBase::ElementBase;

  [[nodiscard]] TableColumnStyle style() const;
};

/// Represents a table row element in a document.
class TableRow final : public ElementBase<internal::abstract::TableRowAdapter> {
public:
  using ElementBase::ElementBase;

  [[nodiscard]] TableRowStyle style() const;
};

/// Represents a table cell element in a document.
class TableCell final
    : public ElementBase<internal::abstract::TableCellAdapter> {
public:
  using ElementBase::ElementBase;

  [[nodiscard]] bool is_covered() const;
  [[nodiscard]] TableDimensions span() const;
  [[nodiscard]] ValueType value_type() const;

  [[nodiscard]] TableCellStyle style() const;
};

/// @brief Represents a drawing shape's outline, as an svg path.
///
/// `data` is written in the user-space box `x`, `y`, `width`, `height`, which
/// the shape's own box stretches to, aspect ratio not preserved.
struct DrawingPath final {
  std::string data;
  double x{0};
  double y{0};
  double width{0};
  double height{0};
};

/// Represents the two ends of a line shape, in the parent's space.
struct DrawingLine final {
  Measure x1{0, DynamicUnit()};
  Measure y1{0, DynamicUnit()};
  Measure x2{0, DynamicUnit()};
  Measure y2{0, DynamicUnit()};
};

/// @brief Represents the affine transform a drawing shape carries.
///
/// `(x, y)` maps to `(a*x + c*y + e, b*x + d*y + f)`, the lettering of
/// `matrix(a b c d e f)`. `e` and `f` are lengths in the unit the document
/// wrote, and unitless only where they are zero.
struct DrawingTransform final {
  double a{1};
  double b{0};
  double c{0};
  double d{1};
  Measure e{0, DynamicUnit()};
  Measure f{0, DynamicUnit()};
};

/// Represents a frame element in a document.
class Frame final : public ElementBase<internal::abstract::FrameAdapter> {
public:
  using ElementBase::ElementBase;

  [[nodiscard]] ShapeType shape_type() const;
  [[nodiscard]] AnchorType anchor_type() const;
  [[nodiscard]] std::optional<Measure> x() const;
  [[nodiscard]] std::optional<Measure> y() const;
  [[nodiscard]] std::optional<Measure> width() const;
  [[nodiscard]] std::optional<Measure> height() const;
  [[nodiscard]] std::optional<std::int32_t> z_index() const;
  [[nodiscard]] std::optional<DrawingTransform> transform() const;
  /// Nothing for a shape whose geometry we cannot read, leaving its box.
  [[nodiscard]] std::optional<DrawingPath> path() const;
  /// The ends of a @ref ShapeType::line, which states them instead of a box.
  [[nodiscard]] std::optional<DrawingLine> line() const;

  [[nodiscard]] GraphicStyle style() const;
};

/// Represents an image element in a document.
class Image final : public ElementBase<internal::abstract::ImageAdapter> {
public:
  using ElementBase::ElementBase;

  [[nodiscard]] bool is_internal() const;
  [[nodiscard]] std::optional<File> file() const;
  [[nodiscard]] std::string href() const;
};

} // namespace odr
