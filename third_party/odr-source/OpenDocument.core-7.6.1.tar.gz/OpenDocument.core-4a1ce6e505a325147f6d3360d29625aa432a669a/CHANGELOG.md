# Changelog

What changed in the engine, for whoever builds against it — the apps, the
bindings, and the packages on conan, maven, PyPI, npm and SwiftPM. Each
[release](https://github.com/opendocument-app/OpenDocument.core/releases) puts
its section on top of the generated per-pull-request list. Back to v5.3.0;
before that the releases are all there is.

An entry goes under `Unreleased` in the pull request that makes the change, and
only for what a consumer notices: API, formats, rendering, behaviour, packaging.
Refactoring, tests and CI are in the generated list already. A breaking change
says **Breaking** first.

The release run heads these entries with the version and opens a fresh
`## Unreleased`. A release with nothing under it is refused.

## Unreleased

## v7.6.1 - 2026-10-25

### HTML output

- `odr.search` no longer computes the style of the parts of a page the
  browser does not lay out. On a text file of 200,000 lines it took 31 s and
  ran out of memory in an Android WebView; it now takes half a second.
- A text file and a sheet state the height of a part far from the viewport
  so that a browser before Chrome 95 keeps it too. Such a browser dropped it,
  so the parts had no height, the scroll bar was short, and a step to a far
  search hit did not reach it.

### Build and packaging

- The Android AAR, the xcframework, the PyPI wheels and the conan package
  embed the formula module of their version, so an editable ods or xlsx sheet
  computes what is typed into it, as the npm package does. In 7.6.0 only the
  npm package carried it, and the others locked the formula cells. Each
  native library is about 640 KB larger. A build names the module with
  `ODR_FORMULA_MODULE`, now also from the environment.

## v7.6.0 - 2026-10-25

### Spreadsheets

- Under `HtmlEditingScope::paragraph`, a sheet page refuses a typed formula
  with `outOfScope` (1010) and computes no formula cell. An edit marks them
  stale and raises `odr.onCellsStale`, and a save computes them.

### Text documents and presentations

- A run whose text is only spaces keeps its spaces. Word writes one wherever
  the formatting changes at a space, so words ran together in docx, also in a
  file that odr saved after an edit.

### HTML output

- In an editable text file, a delete across three or more chunks of lines
  completes, and it can be saved, undone and redone.
- A row or column edit recalculates every formula in the sheet page, also
  `ROW()`, `COLUMN()` and a reference whose position changes.
- `font-family` ends with a generic family, so a font that is not installed
  falls back to one of the same kind: a sans-serif font for Calibri, not the
  browser's serif default. A bare font name is quoted, but a generic family
  such as the `monospace` of Markdown code stays a keyword.
- An editable ods or xlsx sheet page carries the formula module, where the
  build has one: the npm package does, and another build names it with
  `ODR_FORMULA_MODULE`. The page is about 540 KB larger.
- A text file, a pdf, a sheet, a presentation and a drawing let the
  browser lay out only the lines, pages, rows and slides near the viewport.
  A text file of 1 M lines shows its first frame after 0.85 s, not 154 s,
  and a deck of 600 slides after 150 ms, not 570 ms.
  `HtmlConfig::lazy_layout` (on by default, also in the bindings) turns
  this off.
- The npm package takes `lazyLayout` in its html config too.
- The find of the browser does not reach a part that is far from the
  viewport, but `odr.search` does. A host that offers the find of its web
  view needs `odr.search` instead, or `lazy_layout` off
  (opendocument-app/OpenDocument.droid#732).
- The line numbers of a text file are in each line, so a wrapped line keeps
  its number beside it.
- `HtmlConfig::lazy_loading` (off by default, also in the bindings) writes
  the parts of a view after the first as scripts beside the page, which the
  page loads when the reader comes near. `bring_offline` writes the
  scripts, and the HTTP server serves them. A print shows a part that has
  not loaded as empty space.
  - A text file of 1 M lines is then a page of 495 KB.
  - The sheet of 500 K cells in `efficiency-big-1.ods` is a page of 370 KB.
    Such a sheet has no sort control, because a sort needs every row.
  - A pdf renders each page after the first alone, and links the fonts as
    files. The 2985 pages of a technical manual are a document of 1.4 MB,
    which the HTTP server answers after 0.5 s, not 5.4 s. The script of a
    page renders in half the time it took, because the service tests each
    font once whether it re-encodes. A pdf in the single layer keeps every
    page in the document.
- `odr.search` finds the parts that have not loaded, from a search index
  that `HtmlConfig::lazy_loading` writes beside the page
  (`text-search/<n>.js`, `sheet<n>-search/<m>.js`, `pdf-search/<n>.js`).
  A step to a hit loads its part. For a pdf, the service renders each page
  once for the index and keeps the text: 4.9 s for the technical manual,
  whose index is 5.3 MB.
  - Where parts load, `odr.search` returns the hits it knows at once. The
    new `odr.onSearchChange({count, current, complete})`, which the host
    bridge forwards as `searchChange`, and `odr.searchDone()`, a Promise,
    give the final count.
- `odr.search` no longer finds the row numbers and the column letters of a
  sheet, because they label the cells and are not their content.
- The HTTP server looks up the linked files of a pdf under a lock of their
  own. A render of another view of the same pdf added to that list while it
  was read, which could crash the server.
- With `HtmlConfig::embed_images` off, an image loads once the reader comes
  near it (`loading="lazy"`), so a page fetches 3 of the 187 images of a
  long docx at the start. A print still shows every image.
- With `HtmlConfig::embed_images` off, an SVM image is a file of SVG, as
  its data url is, and every linked image states its media type. Before,
  the browser got the SVM as it is, labelled `image/jpg`, and showed a
  broken image. An SVM that does not convert is an empty file and a
  warning.

### Spreadsheets

- The sheet editor takes a function name as LibreOffice shows it in the
  language of the document, for example `SUMME` for `SUM` in a German one,
  and opens a formula cell with those names. The file keeps the English
  ones. The names come from LibreOffice's translations, for the 16
  languages of the boolean words.
- A recalculation and a save compute a cycle where the document iterates
  (`table:iteration` in an ods, `calcPr iterate` in an xlsx), as LibreOffice
  and Excel do: each group of cells that read each other, from what they
  hold, until no cell changes by the difference. The sheet page computes
  them the same way.
- A recalculation and a save compute a reference into another document from
  the copy the file caches: the hidden sheet of an ods, and the
  `externalLink` part of an xlsx.
- A recalculation, a save and the sheet page compute an array formula and
  every cell of the range it fills, in an ods and an xlsx. The page locks
  the range with the new code `array` (1013), and refuses a row or column
  edit through it. `SheetCell::array_span()` gives the range. A function
  maps over the elements of an array, as `SUM(LEN(A1:A3))` reads three
  lengths, also in `SUMPRODUCT`.
- The formula evaluator computes `NOW`, `TODAY`, `RAND`, `RANDBETWEEN` and
  `CELL`. A recalculation, a save and the sheet page compute them with the
  local clock and random numbers, the page on every edit of the sheet.
  `CELL` answers `address`, `col`, `row`, `contents` and `type`, where
  LibreOffice and Excel agree.
- The formula evaluator computes `OFFSET` and `INDIRECT`, in a
  recalculation, a save and the sheet page. `INDIRECT` reads A1, R1C1 where
  its second argument is false, and a name; in an ods also LibreOffice's
  `Sheet1.A1`. Where LibreOffice refuses with a code of its own, or Excel
  does not document the result, the cell has no answer.
- The sheet editor takes formula input where the page carries the formula
  module. A typed `=SUM(A1;B1)` computes at once and goes into the log in the
  syntax of the file, and a formula cell opens on its formula. A formula cell
  is locked only where the build has no module. A formula that does not
  parse refuses with the new code `formulaInvalid` (1012).
- Localized function input accepts lowercase and mixed-case non-ASCII letters,
  including German umlauts and Russian names.
- A locale tag with a script (`pt-Latn-BR`), with `_` (`de_CH`) or in another
  case (`DE-ch`) now selects the function names, the decimal sign and the
  grouping, the month names and the boolean words of its language and region.
  Before, the script read as the region, and the other two missed the tables.
- An xlsx formula with a cached string result writes valid formula-result XML.
  Rejecting an invalid formula no longer creates an empty cell or grows the sheet.
- `Sheet::set_cell` and the `setCell` op write a formula: `{"type":
  "formula", "formula": "of:=[.A1]*2"}`, in the syntax of the file. A formula
  cell can now be overwritten, except the anchor of an array or of a shared
  xlsx formula. A save computes the new formula, and an xlsx drops the
  `calcChain` entry of a formula that a value replaced. A csv refuses a
  formula.
- An xlsx whose `calcChain` an edit empties no longer keeps an empty one,
  which the schema does not allow: the part, its relationship and its
  content type go.
- `SheetCell::number_format()` gives the format code a cell shows a number
  in, for example `0.00%`, and nothing for `General`. Python and Java have it
  too. `Sheet::cell_number_format(column, row)` gives it by position, so an
  empty cell has the format of its row or its column.
- An editable sheet page that carries the formula module computes its formula
  cells as the user edits: a commit, an undo and a redo show the new results
  in the format of each cell. A cell the evaluator has no answer for stays
  stale, and only those reach `odr.onCellsStale`. A row or column edit moves
  each formula of the page as a save moves it, so the page computes after it
  too, and takes formula input. A boolean result takes the words the page
  shows its booleans in, for example `WAHR` and `FALSCH`.
  `odr.editing.loadFormulas()` loads the module ahead of the first edit.
- An editable sheet page states what a formula in the page reads: the syntax
  and the calculation settings of the document on `<body>`, the name of the
  sheet, the format code of every cell (`data-odr-format`), so a typed
  formula shows its result in the format of its cell, the type and the
  value of a boolean or an error cell (`data-odr-type`), and the names the
  document defines (`data-odr-formula-names`), so a formula with a name
  computes in the page too.
- An ods cell right after a merge at the end of its row can be written. The
  write refused, because the new cell landed one column too far.
- An xlsx cell with the built-in date format 14 or 22 shows the date as Excel
  shows it for en-US, for example `1/1/2014` and not `01-01-14`.

### Build and packaging

- Each release has `odr-formula-vX.Y.Z.js`: the formula evaluator as one
  script with its WebAssembly inside, about 530 KB. A page that computes its
  formula cells as the user edits will carry it.

## v7.5.2 - 2026-10-10

### Text documents and presentations

- The browser text editor attaches to a page with an addressed paragraph and
  no run, as a new odt or docx renders. Typing there went nowhere and said
  nothing.

### API, files and saving

- `DecodedFile::file()` returns the file an odf, ooxml, iWork or legacy Office
  package was read from. It returned an empty handle, so `file().name()` threw
  `NullPointerError`, and so did `fileName` in npm for every such document.

## v7.5.1 - 2026-10-10

### Spreadsheets

- A formula that reads through `INDIRECT` or `OFFSET` is unresolved, and a
  browser edit marks a formula with unresolved reads as stale.
- An ods formula with spaces before a function's parenthesis, as LibreOffice
  writes `ROUND (`, parses, computes and moves with structural edits.
- A row or column edit refuses before it changes anything where an affected
  formula does not parse.

### Printing

- A pdf page, a slide, a drawing page and a text page with margins print one
  to a sheet, at the size of the page and without the grey viewer background.
  A dark render prints in light colors.
- A text page that holds a frame anchored to the page, such as a letter
  template, prints whole on one sheet, so the frame stays in place.

### PDF

- A JPEG image with a soft mask shows its transparency, not the color the
  JPEG holds there, which is often black.
- Text in Adobe small capitals and old-style figures (`Asmall`,
  `oneoldstyle`) is found by a search and copies as letters and digits.

### Other

- A copied `HtmlView` stays usable after its `HtmlService` is destroyed.
- `bring_offline` reports a page or a resource it fails to write, also where
  only closing the file fails.
- XML nested deeper than 1024 elements is refused before a document tree is
  built or HTML is rendered, so it cannot overflow the stack. A standalone XML
  file that deep opens as plain text.
- A UTF-16 or UTF-32 json is detected as json.

## v7.5.0 - 2026-10-06

### Spreadsheets

- `Sheet::insert_rows`, `delete_rows`, `insert_columns` and `delete_columns`,
  and their ops, for an ods, an xlsx and a csv, in every binding
  (`insertRows` and so on in java and npm, `insertRows(at:count:)` and so on
  in swift). What names a moved row or column moves with it: formulas, also
  on other sheets and in xlsx tables, merges, conditional formats,
  validations, cell styles, xlsx `x14` extensions, sparklines, page breaks,
  pivot tables and tables, and the ranges of ods and xlsx charts. A reference
  into a removed range becomes `#REF!`. An edit that cuts a merge, an xlsx
  array formula, the place of a pivot table, or the header or totals row of a
  table refuses with `UnsupportedOperation`.

- The sheet editor inserts and deletes rows and columns, one undo step each:
  `odr.editing.insertRows("above" | "below")`, `deleteRows()`,
  `insertColumns("left" | "right")` and `deleteColumns()`, or Ctrl or Cmd
  with Shift and `+` or `-` on a header. An edge inside a merge refuses with
  `unsupportedEdit`.

- `Document::recalculate`, in every binding (`recalculateWithError:` in
  objective-c), writes the results of the stale formulas of an ods or an
  xlsx and returns the changed, circular and unevaluated cells. A save
  recalculates after an edit. A cell it cannot compute, such as an array
  formula, has no result in an ods and keeps its old one in an xlsx. STDEV.S,
  STDEV.P, VAR.S and VAR.P are new.

- `odr::create_document(FileType)` makes an empty odt, ods, docx or xlsx, and
  `FileTypeCapabilities::create` names the types it makes, in every binding
  (`pyodr.create_document`, `odr.create` in npm).

- A csv is editable and savable: `Sheet::set_cell` and the `setCell` op write
  a value, and `Document::save` writes UTF-8, with a byte order mark unless
  the source was UTF-8 without one. A cell style is refused.

- Dates and times: a date `CellValue` states days since 1899-12-30 (a 1904
  xlsx date counts 1462 more), and a time its length in days. `setCell` takes
  `"date"` and `"time"` values. An ods writes `office:date-value` or
  `office:time-value` and the text of its data style; an xlsx writes a serial
  and, without a date format, the built-in format Excel gives. The sheet
  editor reads a typed ISO 8601 or locale-order date or time, opens a cell on
  its value, and sorts a date or time column by the value. An ods keeps
  fractional seconds, and a non-finite number or date is refused.

- Number display: an xlsx cell shows its number as its `numFmt` or a built-in
  format says, a date or time format types it `ValueType::date` or `time`,
  and a boolean shows `TRUE` or `FALSE`. A number written into an ods cell
  with a data style shows as that style says, in its language (`1.234,50 €`).
  Month and day names follow the language of an ods data style or of an xlsx
  format code (`[$-419]d mmmm` shows `15 марта`). An ods `percentage` or
  `currency` cell is `ValueType::float_number`.

- The sheet editor opens a formatted number on its value in the spelling of
  `Document::locale` (BCP 47, in every binding), and an unchanged commit
  writes nothing. A string that reads as a number, or starts with `'` or `=`,
  opens with a leading `'`, so it stays a string.

- A cell takes several lines: Alt or Ctrl with Enter breaks a line. An ods
  writes a `text:p` per line, and an xlsx turns `wrapText` on.

- `Sheet::set_row_style` and `set_column_style`, and their ops, style a whole
  row or column of an ods or an xlsx, also past the stated cells, in every
  binding. The sheet editor uses them for a header selection.
  `HorizontalAlign::general` (`align: null` in the ops and in
  `odr.editing.format`) sets a cell back to the alignment of its value type.

- The sheet editor refuses with `ErrorCode::edit_sheet_cut` (1011, `sheetCut`)
  over a sheet the limits cut, or a move past the rendered extent.

- Reading: an ods or xlsx cell that states no value is `ValueType::unknown`,
  and an ods formula error is `ValueType::error`. An ods cell with a value or
  a formula but no text is read, so its formula survives a save. Merged and
  covered ods cells, also after an array formula, read at their own column.
  An xlsx cell without a style of its own takes the style of its row, else of
  its column. An xlsx infers omitted row and cell coordinates, resolves its
  styles and shared strings through relationships, and opens and takes
  formatting edits without a styles part.

- Formulas: parsing, rounding and numbers ignore the host locale. A formula
  nested more than 64 levels deep does not parse. An ods `&` of a boolean
  follows the LibreOffice in `meta:generator`, and an xlsx comparison near
  the 15th digit gets no answer. Recalculation finds long cycles. Rewritten
  references keep quoted sheet spans, and extreme shifts give `#REF!`.

- Number formats: correct negative signs in scaled, percentage and fraction
  formats, fraction literals, percent signs and subnormal values. A format
  that cannot represent a value falls back to General, and cyclic ods style
  inheritance no longer hangs.

- Rendering: a preview keeps the ods cells at its window boundaries and
  trims an xlsx to the cells with content, a border or a fill. The cell
  budget bounds the columns too. Text no longer spills over a cell that a
  merge from above covers. An explicit transparent background or `none`
  border overrides an inherited ods style. ODF charts keep missing points at
  their categories, honor repeated rows and draw single-slice pies.

### Text documents and presentations

- Text typed into an empty paragraph of a docx or pptx gets a run of its own,
  with the formatting of the paragraph mark, so Word, PowerPoint and
  LibreOffice show it.

- An explicit OOXML off value clears inherited bold, italic, underline,
  strike and shadow. A docx opens without a styles part, and a pptx slide
  keeps its own background without a layout.

- PPTX edits keep one text node per DrawingML run and copy run properties on
  insert. Unsupported containers, synthetic docx list wrappers and pptx slide
  removal refuse instead of leaving dangling nodes.

- Browser text editors delete a whole supplementary Unicode character when
  the browser gives no range.

### PDF

- Text: Identity-H/V fonts keep two-byte codes, embedded CMaps match complete
  codes for mixed-width CJK text, and predefined CMaps keep inherited
  mappings, which restores text in vertical CJK fonts.

- Images: JPEG 2000 ignores the Decode array and scales low bit depths to
  the full range. Soft masks apply the full Decode interval, and inline
  images keep them. TIFF and PNG predictors decode packed samples of 1, 2 or
  4 bits. Gradients read sampled and calculator functions. Lab, ICC and
  indexed colors honor their component ranges.

- Encryption: named crypt filters with an explicit or omitted `None` method
  work, also with AES-256, and AES-256 uses only the first 127 bytes of a
  password. AES padding is checked before it is removed.

- Annotations: ink keeps its final pointer-up position and follows one
  pointer at a time. Authors and comments keep Unicode text when saved.
  Snapshots do not expose pending state, and unknown option keys change
  nothing.

- A malformed file no longer crashes, hangs or exhausts memory. Cross-reference
  tables, object streams, incremental updates, objects, functions, color
  spaces, fonts, images, JBIG2, LZW and fax data are bounds-checked. An image
  with an invalid parameter is skipped, and the rest of the page renders.
  Recovery and incremental updates use the latest generation of an object.

### Other formats

- Fonts: Type1 conversion honors subroutine returns, fractional widths,
  vertical side bearings and unencrypted charstrings. SFNT output uses format
  12 for large character maps, writes Unicode names, and a broken character
  map no longer hides the next one.

- StarView keeps the character positions of supplementary Unicode text, and
  unknown record extensions no longer shift later fields.

- iWork dates keep their calendar range and the sign of expanded years.

- Legacy Office reports an unencrypted document as decodable.

- A malformed iWork, legacy Office, StarView, Markdown, RTF, CFB, ZIP, XML,
  CSV or font file is refused instead of overflowing, wrapping or reading
  past its end. A CSV keeps its carriage-return line endings and separator
  directives, and a ZIP keeps full entry names.

### HTML output

- A document view honors its configured output filename. Audio and video are
  served at custom locator paths, and a named in-memory WebM keeps its MIME
  type.

- A document image or archive entry cannot replace a viewer script or
  stylesheet; a colliding image is embedded. Locale metadata is escaped, and
  invalid length units cannot inject markup.

- PNG output splits large image data into bounded chunks.

### API, files and saving

- A save over a path keeps the destination on a write failure, keeps lazy
  resources when it saves over the input, and keeps its permissions.
  Temporary copies are private and exclusive. A filesystem copy onto itself
  keeps its source.

- Stream copies and reads report a failure instead of returning partial
  data, also in the python, java and apple bindings.

- Empty file and HTML handles throw instead of dereferencing null, and a
  handle to a removed cell or node is retired before the node is freed.

- `DecodedFile::file_meta`, `identify` and the position `to_string` methods
  are no longer `noexcept`.

- Paths normalize repeated separators and accept names that begin with
  `..`. Quantities and integers parse independently of the host locale, and
  JSON edits validate their indices, version and operations.

### Bindings and CLI

- WebAssembly: the TypeScript declarations include `ErrorCode` and
  `spreadsheetStyleBuffer`. Reentrant calls from callbacks and invalid
  numbers are refused, and CSV editing shares one document.

- Java: handles are released on failure, dependent handles refuse calls
  after their owner closes, out-of-range numbers are refused, equality agrees
  with hashing, and Unicode survives in exception messages.

- Apple: `Measure(string:)` is failable, a CSV delimiter must be one
  character, and a root without a text-root interface is an `Element`.

- Python: `Frame.line()` returns its `DrawingLine`, and the CLI opens output
  paths with URL-special characters.

- CLI: `meta` accepts every decoded file type, `server` detects its input,
  and `back_translate` supports text and CSV. The container keeps executable
  permissions and forwards arguments.

### Build and packaging

- The declared CMake minimum is 3.20, also for Python wheels.
  `ODR_CLANG_TIDY=ON` runs clang-tidy during the build.

- Conan packages include the license text, and Android profiles identify
  NDK 28.1 as Clang 19. Android packaging refuses a missing or empty native
  library, and the JNI jar requires JDK 17.

## v7.4.0 - 2026-10-03

- `PdfFile::permissions` reports the permission bits of an encrypted pdf, in
  every binding. `HtmlConfig::pdf_enforce_permissions`, off by default as
  pdf.js `enablePermissions` is, makes the page refuse a copy and a print that
  the file does not allow.

- By default the page loads no image that a document names outside itself,
  and a relative link loses its `href`. Only a link with a navigable scheme
  leaves the view, in a new window. `HtmlConfig::allow_external_content` (in
  every binding) restores both. An image `data:` url always loads.

- `HtmlConfig::host_message_handler` names a function, such as
  `webkit.messageHandlers.odr.postMessage`, that gets every `odr.on*` callback
  of the page as one JSON `{type, detail}` string. The host needs no injected
  script for this.

- `HtmlConfig::sheet_edit_on_click` and `pdf_annotation_mark_on_selection` set
  the start values of `setSheetOptions({editOnClick})` and
  `odr.annotation.setOptions({markOnSelection})`, in every binding.

- A sheet cell is written with its spaces and tabs as they are, and
  `spreadsheet.css` preserves them. The sheet editor no longer saves a
  no-break space in place of a space, and it keeps a space at the start or
  the end of a value. Nothing is indented inside a cell any more.

- A run of a document is written with its spaces and tabs as they are, in
  place of `&nbsp;` and `&emsp;`, and `document.css` preserves them. An edit
  in the text editor no longer saves a no-break space or an em space in place
  of a space or a tab. A line can now break where two runs meet at a space,
  and a tab goes to the next 0.5in tab stop.

- The text editor shows a typed space at the end of a run, and two typed
  spaces in a row. Before, the space was in the document but did not show,
  and the caret did not move.

- A paragraph of an odt, odp, odg, docx or pptx file takes an alignment
  (`Paragraph::set_style`, `setParagraphStyle`, `odr.editing.format({align})`,
  and the bindings). The docx reader now reads `w:jc="both"` as justified.

- The python, Java, Objective-C and npm bindings style a sheet cell
  (`Sheet::set_cell_style`). In Java and Objective-C, a `TableCellStyle` can
  now be built and written.

- The sheet editor formats cells. A selection is a rectangle, spanned by a
  shift click, a shift arrow, a mouse drag or a header click, and
  `odr.editing.format` and `toggle` take `fill` and `align` beside the text
  keys. `onSelectionChange` reports what the selected cells agree on. One
  gesture is one undo step, and the log holds one `setCellStyle` op per cell.

- A cell of an ods or xlsx file takes a style: `Sheet::set_cell_style` and
  the `setCellStyle` op write the fill, the horizontal alignment, and bold,
  italic, underline, strikethrough, colour and size.

- **Fix**: in an ods file, a value written into a covered cell landed outside
  the merge, and one written into an empty cell right of a merge failed. The
  first now refuses, and the second lands in its cell.

- **Fix**: an xlsx column in a gap between `<col>` ranges took the width and
  the style of the next range. It now has neither.

- **Fix**: many xlsx fills showed a wrong colour. A cell now shows its fill,
  theme colours and tints, italic, underline, strikethrough and every
  alignment.

- **Fix**: a cell fill disappeared in the dark color scheme. The cell now keeps
  its fill in a dark version with the same hue, and the text stays readable on
  it.

## v7.3.2 - 2026-09-24

- **Fix**: a markdown document in the paged view put its text on the edge of
  the page. The page now has a margin of `2em` on each side.

- **Fix**: a selection in a pdf view moved away from the text a little more
  at every word of a line. It now stays on the text for the full line.

- **Fix**: a selection in a pdf view showed a white hole at many spaces
  between words, and after a word of one letter. It now covers the space.

## v7.3.1 - 2026-09-23

- **Fix**: with the pen armed, a drag on a pdf page that had no mark yet
  scrolled the page on iOS instead of drawing. It draws now.

- **Fix**: a selection dragged in a pdf view no longer jumps to the page's
  start or end over blank space or a link.

## v7.3.0 - 2026-09-23

- **Fix**: a pdf CFF font with no glyph but `.notdef` is no longer embedded,
  because browsers reject it. Its text uses a substitute font.

- **Fix**: a pdf whose zlib streams declare a smaller window than they use
  failed to open with "Inflator: error in compressed block". It opens now.

- **Performance**: a pdf with a `ToUnicode` range on every page no longer
  spends about 7 MB a page on it, and JBIG2 scans decode about a third faster.

- **Fix**: a pdf from old Ghostscript (8.x) showed every glyph as an empty box
  or as the wrong glyph. Its embedded TrueType fonts now show the right glyphs.

- **Fix**: a pdf that starts its cross-reference table on the line of the
  last `endobj` (`endobj xref`) failed to open with "expected stream". It
  opens now, and its metadata reads.

- **Fix**: a pdf image compressed as a fax (`CCITTFaxDecode`, Group 3 or 4)
  was left out, so a scanned page came out blank. It shows now.

- **Performance**: a black-and-white pdf image becomes a 1-bit png rather than
  an 8-bit colour one, so a 600-dpi scan translates about 8 times faster.

- **Fix**: a pdf text clip (`Tr` 4 to 7) was ignored, so a title filled with
  a picture covered the whole page. The paint now stays inside the glyphs.

## v7.2.2 - 2026-09-20

- **Fix**: drawing on a pdf put the stroke about twice as far from the page's
  corner as the finger went, in a webkit view that fits the page to the screen.

## v7.2.1 - 2026-09-20

- **Fix**: marking text in a pdf view left the selection one handle, because a
  run of the selection layer clipped the end that handle belongs to. Nothing
  clips a run now, so both handles show and the mark can be adjusted.

- **Fix**: selecting text in a pdf view hid the words it selected. The
  `::selection` background v7.2.0 states is `Highlight`, which is opaque, and
  the layer carrying it paints over the glyph layer. It is see-through now, so
  the text reads through its own selection.

## v7.2.0 - 2026-09-20

- **Fix**: a pdf underline and squiggle were drawn through the text rather than
  under it, both in the view and in the saved file. They now hang below the
  glyphs. A strike-out still crosses the text.

- **Fix**: a pdf mark cut the tails off the text it marked and broke apart at
  every word gap, because it took the selection layer's em box. It now covers
  the glyphs under the selection, as one box per line.

- Fitting the width states a `minimum-scale` where the content is more than
  four screens wide, which the browser's own floor of 0.25 cannot reach. An A0
  pdf page now zooms out to fit; narrower content is unchanged.

- `odr.editing.setSheetOptions({editOnClick})` states whether a click opens a
  sheet cell's editor, because the pointer is a guess: an android WebView
  reports a fine one on a touch screen. Unstated, the pointer answers.

- **Fix**: selecting text in a pdf view showed the invisible layer that carries
  it, as a second set of glyphs over the drawn ones. That layer now stays
  transparent under `::selection`, and states the highlight background, which
  an author `::selection` otherwise drops.

- A tap opens a sheet cell's editor where the pointer is coarse, so a phone
  needs one tap rather than a double tap. A mouse keeps the double click.

- **Fix**: a second click on a pinned cell cleared the pin while the sheet was
  being edited, so a reader who tapped a cell twice lost it. A cell now holds
  its pin there; a row or column header still clears on that click.

- Editing scope `paragraph` takes `odr.editing.format` inside one paragraph and
  refuses it over two, rather than refusing every call. The `formatBold` chords
  stay behind the gate.

## v7.1.0 - 2026-09-19

- The pdf view reports the pending annotation count on
  `odr.onAnnotationChange({count})`, and `odr.annotation.press` and `recolor`
  do what a tool button does.

- The wasm `Document.edit`, `save`, `isEditable` and `isSavable` work for a
  plain text file, which saves as UTF-8.

- `TextFile::is_savable` is false for a json file.

- `TextFile::edit`, `save` and `save_to_memory`, also in Python, Java,
  Objective-C and Swift. `write_edited` is deprecated.

- **Fix**: one undo in the document view's editor took back only part of an
  edit that took several steps, such as Enter inside a run, and showed states
  between the steps that the reader never made. `odr.editing.undo()` and
  `redo()` now take back and replay the whole edit.

- **Fix**: the document view's editor recorded nothing an Android keyboard
  typed, so a save lost it. A composition is now recorded after each change.

## v7.0.0 - 2026-09-13

- **Breaking**: `DocumentPath`, `Element::document_path()` and
  `Element::navigate_path()` are gone, with their python and Java mirrors.
  An element is addressed by `Element::identifier()` and
  `Document::element_by_id()`, which is what the edit envelope uses.

- **Breaking**: `ValueType` gains `boolean`, `date`, `time` and `error`, and
  the odf and xlsx readers report them; a boolean states 1 or 0 as its number.
  `Sheet::set_cell` writes a boolean and refuses the other three. The enum
  mirrors in every binding follow.

- **Breaking**: `TextStyle::font_name` is a `std::string` rather than a
  `std::string_view` that borrowed from the document, so a style outlives the
  document it was read from and a caller can build one.

- `Text::set_style` and the edit op `setTextStyle {id, style}` write bold,
  italic, underline, strikethrough, highlight, colour and size onto a run of
  an odf, docx or pptx document. The other engines refuse it.

- A `.docx` run's shading (`w:shd`) renders as its background where no
  highlight paints over it.

- The document view's editor formats text under scope `document`:
  `odr.editing.format({bold, italic, underline, strikethrough, highlight,
  color, size})`, `odr.editing.toggle("bold")`, the ctrl/cmd+B, I and U
  chords, and `odr.onSelectionChange` for a host's buttons. A toggle on a
  collapsed caret marks the next typed text. Scope `paragraph` refuses it.

- `Text::set_style` in every binding: `Text.set_style` in python,
  `Text.setStyle` in Java, `-[ODRText setStyle:error:]` in Objective-C, both
  with a constructible `TextStyle`, and `setTextStyle(id, style)` in npm.

- A run that is both underlined and struck through renders both lines. The
  page wrote two `text-decoration` declarations, and the second replaced the
  first.

- **Breaking**: `all_file_types()` and `all_text_encodings()` return a
  `std::span` over the library's tables instead of a `std::vector`, like the
  other table lookups. The bindings still hand out a list.

- `HtmlConfig::editing_scope` narrows the document view's editor to edits
  inside one paragraph (`paragraph`); the page refuses the rest with the new
  `ErrorCode::edit_out_of_scope` (1010, `outOfScope`). Bound in every binding.

- Writing a cell of an `.ods` takes the cached result of every formula reading
  it away, keeping the formula itself, so the saved file states no number that
  is now wrong. Such a cell renders empty until a reader computes it.

- An editable sheet view states each formula cell's expression
  (`data-odr-formula`, `odr.sheet.formulaAt`) and the cells it reads, and marks
  the ones an edit left out of date (`odr-sheet-stale`, `odr.onCellsStale`).

- `Document::dependents(position)` answers which cells' formulas read a
  position, directly or through another, and `unresolved_formulas()` those
  whose references could not all be read. A position is the new
  `SheetPosition`: the sheet by its place among the document's sheets.

- A shared formula in an `.xlsx` is read for every cell of its group, not only
  the master that spells it: `SheetCell::value().formula()` answers a member
  with the expression moved to it, and `#REF!` where it moved off the grid.

- `TablePosition::try_to_column_num` / `try_to_row_num` read a column or row
  spelling as an optional instead of throwing, and without case. **Fix**:
  `to_column_num` wrapped silently past the index range instead of refusing.

- **Breaking**: the codes the page reports through `odr.onError` and
  `odr.onEditRefused` moved from 1 to 9 onto 1001 to 1009. `readOnly` is 1005,
  not 5; the `reason` string is unchanged.

- **Added**: `odr::ErrorCode` (`odr/error_code.hpp`), one number space every
  binding reports for both a thrown exception and a refused edit. `ODRError`
  casts from it, `OdrException.getCode()` and the wasm envelope's `code` carry
  it, and `enumTables()` and the python module expose it.

- **Breaking**: `AnchorType` gains `none` as its first value, so every later
  ordinal shifts by one. `Frame::anchor_type()` answers it for a frame that
  does not exist, instead of `as_char`, which a real frame also answers.

- **Fix**: a percentage `fo:margin` on an odf paragraph is resolved against the
  parent style ([OpenDocument] 16.2) instead of being dropped. LibreOffice
  writes `fo:margin="100%"` for "whatever the parent had".

- **Fix**: `Text::set_content` on an `.xlsx` run did nothing and said nothing.
  An xlsx declares `edit`, so a caller had no way to learn the write was
  dropped; it now throws `UnsupportedOperation`, as every other engine that
  cannot write a run does.

- **Fix**: the pdf object parser skipped over `null`, `true` and `false`
  without reading them, so `nXYZ` parsed as null. The keyword is checked now,
  without case, as the surrounding parser already allows.

- Every binding reaches the structural edit API. python, jni and apple take
  elements (`remove`, `insertTextBefore`/`After`, `appendText`,
  `splitParagraph`, `mergeParagraphWithNext`, `insertParagraphAfter`); wasm
  addresses the same operations by element id, because nothing escapes it as a
  handle. `element_by_id` and `TextFile.write_edited` are bound too.

- **Breaking**: a csv and a markdown file hold a text file instead of being
  one. `is_text_file()` answers false for them; the plain-text view is
  `as_csv_file().text_file()` / `as_markdown_file().text_file()`. `CsvFile` and
  `MarkdownFile` are bound in python, jni and apple to carry both views.

- A selection reaching over a picture is taken, and the picture goes with the
  text: a frame carries `data-odr-id`, so an operation can name it. A frame
  holding text of its own is still refused.

- **Fix**: undoing a paragraph split threw, taking every later edit in the
  session with it — the node it restored each moved child before could be the
  line box, which the split had replaced.

- **Fix**: deleting across several lines of a `.txt` left stray line numbers
  in the gutter. The renderer writes whitespace between the number cells, so
  `lastChild` there was a text node and the removal took that instead of a cell.

- **Fix**: two refusal messages described what their code meant before the
  editor could span runs. `newLine` said "new line not supported" though Enter
  is taken, and `range` said "an edit has to lie inside one run of text" though
  it now marks a range reaching over a picture. The codes are unchanged.

- **Fix**: `odr.editing.getOperations()` and `odr.generateDiff()` stated
  `"version": 1` while `Document::edit` takes 2, so every save the browser
  produced was refused. A check page now asserts the version.

- A `.txt` view carries `odr.editing` like every other view, rather than the
  second API `text.js` was. **Breaking**: `HtmlConfig::editable` no longer
  writes `contenteditable` — `odr.editing.enable()` does.

- `TextFile::write_edited` saves an edited plain file and `is_savable()` says
  whether it can; `txt` states `edit` and `save`. The output is UTF-8 whatever
  the source encoding was, because there is no encoder back.

- A `.pptx` can be edited and saved: every text operation a `.docx` takes, and
  a save that writes the slide parts back into the package. Its
  `FileTypeCapabilities` now states `edit` and `save`.

- A text document is edited the way a reader expects: typing, replacing and
  deleting across runs and paragraphs, Enter, Backspace at a paragraph start,
  and a plain-text paste that opens a paragraph per line.

- **Undo and redo are the editor's.** `odr.editing.undo()` / `redo()` answer
  for a text document, `odr.onEditChange` reports `canUndo` / `canRedo`
  truthfully, and ctrl/cmd+Z is taken.

- Enter is no longer refused. Reason `newLine` (1001) now marks only a soft
  line break, which no operation carries.

- A paragraph splits, merges and is inserted — `splitParagraph`,
  `mergeParagraph`, `insertParagraph`, and the matching `Document` methods in
  C++. Enter, Backspace at a paragraph start and a delete across paragraphs.

- An edit can span several runs: the new `insertText` and `removeElement`
  operations, and `Document::remove` / `insert_text_before` / `insert_text_after`
  in C++. ODF and `.docx`; every other format refuses.

- **Fix**: a `.docx` edit keeps the space at either end of a run, by stating
  `xml:space="preserve"` on the `w:t` that needs it.

- **Breaking** (wire only): an edit operation names its element by the id the
  render writes into the page, `data-odr-id`, not by a document path. The
  envelope is `{"version": 2, ...}`; version 1 is refused. An editable render
  addresses its paragraphs as well as its runs.

- `Element::identifier()` and `Document::element_by_id()` are the two ends of
  that address, in C++ and in the python, jni and apple bindings.

- `odr.editing` is on every document view, not only on a sheet's. The mode,
  the refusals, the log and the `odr.onEdit*` callbacks are one surface a host
  wires per document, and each format attaches its own editor to it.

- **Breaking**: `HtmlConfig::editable` writes the editing scaffolding rather
  than `contenteditable` - the address an op names, the lock on a locked cell,
  the state on `<body>`, the editor script. `odr.editing.enable()` writes
  `contenteditable`, so switching modes needs no second render.

- **Breaking**: a render with `editable` off carries no editing markup at all,
  and the document's editable state moved off the `.odr-sheet` table onto
  `<body>` as `data-odr-editable`. The table keeps `data-odr-sheet`.

- **Breaking**: a refused new line reaches `odr.onEditRefused` with reason
  `newLine` rather than `odr.onError`, keeps its code, and now fires only
  inside an editable run while the mode is on.

- `HtmlConfig::keyboard_navigation` and `keyboard_shortcuts`, both on by
  default, decide whether the page takes the keys that move the selection and
  the undo chord. An open editor's own keys are never taken away.

- A text document is edited as a document: the mode makes the whole view
  editable rather than each run, so the caret, a selection and a double click
  cross runs and paragraphs the way a reader expects.

- Every edit a text document cannot replay is refused through
  `odr.onEditRefused` rather than silently impossible: a new line
  (`newLine`, 1001), an edit landing outside every run (`range`, 1008), and
  anything else the browser offers (`unsupportedEdit`, 1007).

- **Fix**: searching a text document while the mode is on no longer marks it
  unsaved. The log is collected from `input`, which the browser raises for an
  edit it applied, rather than from every text mutation - a search highlighting
  nine matches was nine no-op `setText` operations.

- **Fix**: double-clicking a sheet cell no longer flashes its border off. A
  click on the pinned cell clears the pin, and the second click of a double
  click was taking it - so selecting a word left the border coming and going.

- A cell of several runs is written rather than locked: the write replaces what
  the cell shows with one run. A cell holding one run is written through it, so
  that run keeps its style. The `rich` lock stays on what a write would take
  away unseen: several paragraphs, a link, a line break.

- An `.xlsx` cell the file states no `c` for is written: the write states the
  `c` in its row in column order, the `row` in `sheetData` in row order where
  the file states none, and widens `dimension` to hold the new cell. A position
  a merge covers still refuses, whether or not the file states a `c` for it.

- **Fix**: a cell in the last row or column of a merged range reports
  `SheetCell::is_covered` as true. `TableRange::contains` left the end of the
  range out, so an `.xlsx` merge too big to walk cell by cell marked one row
  and one column too few.

- A `.ods` sheet grows to the position a write names. Past the last cell of a
  row, past the last row, or past both, the write states the rows and the empty
  cells it takes to reach it and declares the columns the sheet stops before,
  so the extent covers the new cell.

- An empty `.ods` cell can be written: the write cuts the run of empty cells
  the position belongs to and states the `text:p` the file spells none of. A
  merged cell that holds no paragraph takes one the same way.

- A sheet cell can be typed into: an overlay opens on a double click or a key,
  Enter and Tab commit, and `odr.editing.getOperations()` hands the host the
  envelope `Document::edit` takes.

- `odr.sheet` also answers what the page shows: `valueAt`, `showValue`,
  `reflow` and `lower`.

- A sheet edit can be taken back: `odr.editing.undo()`, `redo()`, ctrl/cmd+Z,
  and `committed()` after a save; `odr.onEditChange` reports the state of the
  log to the host.

- **Fix**: a zip entry name with a leading slash is read relative to the
  archive root rather than throwing, and one named `/` alone is dropped. An
  `.odt` carrying such an entry now opens; LibreOffice still refuses it.

- The rendered sheet exposes `odr.editing`: `enable()` / `disable()` turn the
  mode on, `lockAt()` answers for a cell, and a refusal reaches the host as
  `odr.onEditRefused` / `odr.onEditModeChange`, whose codes share the space
  `odr.onError` numbers. Beside it `odr.sheet` addresses the view the way an op
  does — `cellAt`, `positionOf`, `pinned` and `pin`, by position rather than by
  where a cell happens to sit after a merge or a sort.

- A sheet states in its markup what the page cannot work out: the sheet an op
  names (`data-odr-sheet`), whether the document can be edited at all
  (`data-odr-editable`), and the lock on a cell that cannot be —
  `data-odr-lock` of `formula`, `rich` or `shapes`, with an `odr-locked` class
  beside it.

- A sheet rendered with `HtmlConfig::editable` carries no `contenteditable`
  and no `data-odr-id`: its editing is an overlay, so the markup states
  none. A cell's runs fold into the `td` as they do read-only.

- **Breaking** (wire only) `Document::edit` takes an op envelope,
  `{"version": 2, "ops": [...]}`, with `setCell` writing a sheet cell by
  position and `setText` carrying what the `modifiedText` map carried.

- `Sheet::set_cell` writes a repeated `.ods` cell: the run is cut into the
  position written and the parts around it, which keep the value they had.
  Only a cell the file states no element for still refuses.

- **Fix**: a repeated `.ods` cell answers for the position it was looked up
  at rather than the anchor of its range, so `SheetCell::position()`,
  `Sheet::cell()` and `DocumentPath` all name the cell that was asked for.

- `Sheet::set_cell` and `::clear_cell` write one cell of an `.ods` or an
  `.xlsx`, and `Document::is_editable` is true for both. An absent, repeated,
  covered, formula or richly marked-up cell refuses.

- `.xlsx` gains `Document::save`, with `edit` and `save` capabilities to match.
  A saved workbook sets `fullCalcOnLoad`, since nothing here computes a formula.

- **Fix**: a `.xlsx` cell holding an inline string (`t="inlineStr"`) read as
  empty.

- `CellValue` is what a cell holds — type, number, text, formula — read by
  `SheetCell::value` and written by `Sheet::set_cell`. Immutable, built from a
  text or a number, its getters throwing `ValueNotStated` where a cell states
  none. `value_type` is unchanged and stays what the renderer asks.

- `PdfFile::annotate` writes highlight, underline, strike-out, squiggly and ink
  annotations into a pdf as an incremental update — source bytes untouched,
  any viewer reading them — in every binding, with an `annotate` capability.

- The rendered pdf view exposes `odr.annotation`: the five tools, live preview
  and undo, whose `getAnnotations()` produces exactly what `annotate` takes.
  It marks on `mark()`, and `setOptions` holds the gesture policy: what marks,
  which pointers draw, what a touch on an armed page does.

- `PdfFile::is_annotatable` answers for the file what the `annotate` capability
  answers for the format, and narrows it. Encrypted and repaired pdfs say no.

- **Breaking**: `html::edit` becomes `Document::edit`, in every binding —
  java's `Html.edit(document, diff)` becomes `document.edit(diff)`, and so on.
  `Text::set_content` is unchanged.

- **Breaking**: `DecodePreference` becomes `DecodeOptions`, gains a `csv` field
  and is all `open` takes besides the file and logger. `CsvFile::from_file` and
  `::with_options` go — use `DecodeOptions::as(type)` / `::as_csv(options)`.

- **Breaking**: naming a type reports the engine's own refusal, so
  `open(f, DecodeOptions::as(FileType::rich_text_format))` on non-rtf bytes
  throws `NoRtfFile`, not `UnknownFileType`. Detection alone is unchanged.

- `TextEncoding` and its five lookups now reach the java, python, objc and wasm
  bindings, and a text file reports `encoding()` beside the `charset()` it
  keeps. wasm gets it as `Odr.enums.TextEncoding`. Nothing is removed.

- **Breaking**: `odr::open` is the only way to decode a file. The `DecodedFile`
  and `DocumentFile` constructors and `DocumentFile::from_disk`/`::from_memory`
  are gone, in every binding; narrow with `open(...).as_document_file()`.

- **Breaking**: `DecodedFile::list_file_types`/`::mimetype` and
  `DocumentFile::type`/`::meta` are gone, in every binding. Use the free
  `odr::list_file_types`/`odr::mimetype`, or `odr::open(...).file_type()`.

- **Breaking**: `html::translate` takes only a `DecodedFile`, `Document`,
  `Filesystem` or `Archive` now; drop the cache path, in every binding. Open a
  file as `FileType::text_file` to render it as a numbered line list.

- **Breaking**: the inert `HtmlConfig` fields `background_image_format`,
  `background_image_dpi`, `no_drm` and `embed_outline` are gone, with their
  java, python, objc and wasm mirrors. Drop them; nothing replaces them.

- **Breaking**: `TextFile::charset()` and the `UnknownCharset` exception are
  gone. Use `TextFile::encoding()`, which returns `TextEncoding::unknown` where
  `charset()` returned `nullopt`. The bindings' own `charset()` is unchanged.

- **Breaking**: `GlobalParams` is gone, with its java, python and objc mirrors,
  `OdrAndroid.init`, and the `ODR_WITH_LIBMAGIC` / `ODR_BUNDLE_ASSETS` cmake
  options. All of it was inert; delete the calls, nothing replaces them.

- **Breaking**: building `odr` from source now needs a **C++23** compiler. Using
  it does not — the public headers still compile as C++20, and the package
  forces no standard on a consumer.

- **Breaking**: the drawing elements `Rect`, `Line`, `Circle` and `CustomShape`
  are gone, with their `ElementType` values and `Element::as_rect`/`as_line`/
  `as_circle`/`as_custom_shape`. Every shape is a `Frame` now, naming itself
  through the new `ShapeType Frame::shape_type()` and carrying `Frame::path()`
  and the new `Frame::line()`. Shapes gain `anchor_type()` and `z_index()`,
  which only frames had. Mirrored in the JNI, Apple and Python bindings. No
  rendered html changes. Closes #773.

## v6.14.0 - 2026-09-06

- Fixed: a semi-transparent colour wrote `rgba(0,0,0,0,501961)` where the host
  had set a global locale with a comma decimal separator. Adds a `fmt`
  dependency.

- A sheet cell keeps its text on one line unless the file says to wrap it, read
  into a new `TableCellStyle::wrap_text`. A line too long for its cell spills
  over the empty cells beside it and is cut where the next has content. #238

- A spreadsheet view writes far less html for the same rendering: repeated style
  blocks become classes, and a plain cell drops the run around it. The register
  file's 500,000 cells fall from 121 MB to 38 MB. New
  `HtmlConfig::spreadsheet_style_buffer`. #822

- New `Sheet::page_layout()`: the paper an ods states for a sheet, read from
  the master page its table style names. Mirrored in the Python, JNI and Apple
  bindings. Empty for xlsx, xls, numbers and csv.

- A printed sheet is fitted to the paper the file states, at the file's own
  column proportions. Towards #816.

- A right-to-left document renders right-to-left. `style:writing-mode`,
  `w:bidi` and `a:pPr@rtl` are read into a new `TextDirection` on
  `ParagraphStyle` and `PageLayout`, and the view's root carries it as
  `<html dir>`. Towards
  [OpenDocument.droid#653](https://github.com/opendocument-app/OpenDocument.droid/issues/653).

- **Breaking**: `TextAlign` gains `start` and `end`, which `w:jc` now resolves
  to instead of `left` / `right`; they follow the paragraph's direction.
  `fo:text-align`'s same-named values stay absolute. Existing enumerators keep
  their values, so only an exhaustive `switch` needs changing. Mirrored in
  every binding.

- A printed sheet drops our row/column ruler and is capped to the page width
  rather than cut off at the right edge. Print only; the on-screen view is
  unchanged. Towards #816.

- New `File::name()`: the file name on disk, the entry name inside an archive,
  or the name `File::from_memory(data, name)` was given. A named in-memory file
  gets the same name-derived type candidate a path does, so `notes.md` bytes
  decode as markdown. Mirrored in every binding; wasm takes it as
  `odr.open(bytes, { name })` and `odr.detect(bytes, name)` and exposes
  `Document.fileName`.

## v6.13.0 - 2026-09-03

- A `.md` opened by path decodes as markdown rather than as plain text, and
  `list_file_types` offers it. The extension only adds a candidate the bytes
  already allow; `File::from_memory` has no name, so it still needs
  `FileType::markdown`. Closes #760.

- **Breaking**: a document decrypted from a password-protected package is no
  longer savable — every `save` overload throws `UnsupportedOperation`, where it
  used to write the content out unprotected. Towards #64.

- A `.docx` `wp:anchor` drawing floats at its offset with its wrap and side,
  instead of sitting in the line. Closes #803.

- A `.docx` table's own borders (`w:tblPr/w:tblBorders`) are drawn, and no
  longer four times too thick. New `TableStyle::border`,
  `::border_inside_horizontal` and `::border_inside_vertical`, mirrored in the
  JNI, Apple and Python bindings.

- A table cell in a text document starts its content at the top, as word and
  odf do.

- A fitted or zoomed view scales its text with the page in WebKit, where the
  type used to stay at its unscaled size. `HtmlViewportMode::fit_width_by_view`
  is usable on iOS. Closes #761.

- A PDF `gs` applies the `/ExtGState` stroke parameters `/LW`, `/LC`, `/LJ`,
  `/ML` and `/D`. A producer that sets the line width only there — Canva does —
  used to have every stroke drawn at the initial width of 1.

- A manual page break starts a new page box, and prints as `break-before:page`.
  New `BreakType` and `ParagraphStyle::break_before`/`break_after`, mirrored in
  the JNI, Apple and Python bindings. Towards #174.

- ODF's `text:soft-page-break` is no longer part of the element tree, so a
  `DocumentPath` past one shifts.

- New `DocumentFile::thumbnail()`, the preview the package carries or
  `nullopt`, mirrored in the JNI, Apple and Python bindings. Closes #21.

- **Breaking** (Swift only): `HtmlConfig`'s optional settings are Swift
  optionals of the real type rather than `NSNumber`/`NSValue` boxes —
  `spreadsheetLimit` is a `TableDimensions?`, `initialZoom` a `Double?`, and so
  on. ObjC callers see the boxed properties unchanged. Closes #759.

- The HTML renderer warns, rather than silently dropping, when it reaches an
  element type it has no `translate_*` for. Across the test corpus that is
  `page_break` and nothing else. Towards #150.

- An ODF `draw:object` chart is drawn from the chart part's own markup, not
  from the replacement image beside it: bar, line, area, scatter, pie and ring,
  with their titles, legends, axes and series colours. An object holding no
  chart we can read keeps the replacement. Closes #179.

- An ODF custom shape is drawn as the shape its `draw:enhanced-geometry`
  describes rather than as its bounding box: `draw:enhanced-path`,
  `draw:equation`, `draw:modifiers` and the two mirror attributes. Closes #159.

- ODF draws the shape elements it used to drop whole: `draw:path`,
  `draw:polygon`, `draw:polyline`, `draw:regular-polygon`, `draw:connector`,
  `draw:ellipse`, `draw:measure` and `draw:caption`. New `path()` on
  `CustomShape`, mirrored in the JNI, Apple and Python bindings.

- An ODF `draw:circle` is drawn as an ellipse rather than a circle inscribed in
  its box.

- An ODF drawing shape is drawn where its `draw:transform` puts it. New
  `transform()` on `Frame`, `Rect`, `Line`, `Circle` and `CustomShape`,
  mirrored in the JNI, Apple and Python bindings.

- A StarView metafile's text is decoded by the charset it names. Every
  encoding but `UCS2` used to emit the file's own bytes, and the invalid utf-8
  a non-ascii label made of that cost the whole image.

- A curve in a StarView metafile is drawn as a curve. The polygon flags that
  say which of its points are bezier control points were read and dropped, so
  every curve came out as a line through them.

- A StarView metafile's map mode is read in full: its unit, so a drawing that
  switches to twips or points is no longer off by the factor between them, and
  the relative map mode, which composes with the one before it rather than
  replacing it.

- A StarView metafile draws its gradients, hatches and transparent shapes:
  `GRADIENT`, `GRADIENTEX`, `HATCH` and `TRANSPARENT`.

- A spreadsheet decodes in less memory: 626 MB peak instead of 914 MB on a
  297 MB `content.xml`. Rendered output is unchanged.

- A StarView metafile draws its remaining primitives: `LINE`, `ELLIPSE`,
  `ROUNDRECT`, `ARC`, `PIE`, `CHORD`, `POINT` and `PIXEL`. The lines are what
  rules a table drawn as a metafile, which used to come out as floating
  numbers.

- A StarView metafile clips what it says it clips: `CLIPREGION` and the two
  that intersect one into it. A drawing that ran outside the clip used to be
  shown in full.

- A StarView metafile draws its bitmaps (#194): `BMP`, `BMPEX` and their
  scaling and part variants, transparency mask included. Such a chart used to
  render as an empty frame.

- A text action in a StarView metafile draws the run it names, not the whole
  string. Text drawn in runs used to overprint itself into a smear.

- StarView metafile text keeps its font: italic, bold, underline, strikeout,
  rotation, alignment, per-character positions, and the width a stretched run
  fills (#95).

- A StarView metafile draws through a graphics state stack: a colour, font or
  map mode set inside a `PUSH` no longer leaks past its `POP`.

- A filled StarView shape keeps its outline, a poly-polygon cuts its holes, a
  line takes its `LineInfo`, and the font size scales with the drawing.

- Text in a StarView metafile is escaped into the svg it renders as. An `&` or
  `<` in a label used to cost the whole image.

- A StarView metafile translation logs what it drops: unimplemented actions,
  and a failure it used to fall back from silently.

- An html attribute value drops the control characters xml forbids. One
  escaper writes both html and svg now.

## v6.12.0 - 2026-08-30

- New `Document::save(std::ostream &)` and `Document::save_to_memory()`, which
  returns the saved document as an in-memory `File`. The path overloads are
  unchanged.

- The wasm binding gained `edit(diff)`, `save()`, `isEditable()` and
  `isSavable()`, so a browser can save an edit back.

- Memory saves in the other bindings: `save_to_memory()` returns `bytes` in
  python, `saveToMemory()` `byte[]` in java, `-saveToMemoryWithError:` `NSData`
  in Objective-C.

- Two entries of the same zip document can be read at once; nothing serialises
  on a single lock any more.

- The zip backend is `miniz/3.1.1`, up from `3.0.2`. Rendered output is
  unchanged.

- New `FileType::hypertext_markup_language` for `html`, `htm`, `xhtml`,
  `text/html` and `application/xhtml+xml`. Classification only: no `open`, no
  `translate_html`, and never detected from its bytes.

- **Breaking** An ods sheet stores a repeated cell once, at the range it
  covers, rather than once per position: `SheetCell::position()` reports the
  anchor of that range instead of the position the cell was looked up at, and
  `Sheet::cell()` hands back the same element everywhere in it.
- An ods `table:number-columns-repeated` beside a `table:number-rows-repeated`
  no longer inflates — the grid's own `1048576 × 1024` asked for three billion
  elements out of four hundred bytes.
- An xlsx `<mergeCell>` whose `ref` names more positions than the sheet has
  cells opens again; `ref="A1:XFD1048576"` used to visit all 17 billion.
- Decoding a spreadsheet costs about half the memory it did — pugixml is built
  in compact mode and the ods sheet index is sorted vectors rather than maps.
  A consumer that includes an internal header now needs `PUGIXML_COMPACT`, and
  the conan package declares it.

## v6.11.0 - 2026-08-29

- No view declares `<base target="_blank">` any more. A link back into what
  serves the page — an archive entry, a PDF `#pN` anchor, a relative hyperlink —
  navigates in place; only a link that leaves the page carries
  `target="_blank" rel="noopener noreferrer"`.

- A document hyperlink renders without an `href` unless its target is `http`,
  `https`, `mailto`, `ftp`, `ftps`, `tel` or a relative reference — the
  allowlist a PDF `/URI` action already went through. `Link::href()` is
  unchanged.
- `HtmlView::sheet_cut` reports the extent a sheet's cells span against the
  extent the rendered markup carries, or nothing where the limits cut nothing.
  Bound in python, jni, wasm and apple as `sheet_cut` / `sheetCut`.
- New `HtmlConfig::spreadsheet_cell_limit`, 500000 cells for one sheet, bounds
  the rows a sheet keeps by its width; `spreadsheet_limit` rises from 10000 to
  100000 rows. wasm gains both.
- A saved document opens in LibreOffice again: every zip entry's size goes into
  its local header instead of a trailing data descriptor, which LibreOffice
  rejects on a stored entry — an odf package always stores `mimetype`.
- `HtmlConfig::min_content_margin` puts a floor under the distance the
  generated content keeps from the view's border, per side. A set side raises
  the inset a view already has, never lowers it; a sheet is never inset. Bound
  in python, jni, wasm and apple as `minContentMargin`.
- **Breaking** Bytes that do not read as text no longer come back as
  `text_file` and render as nonsense - `decode` throws `UnknownFileType` and
  `list_file_types` comes back empty. A file is text when it is empty, or its
  encoding can be named and it carries no NUL outside utf-16 and utf-32.
- `open(file, as)` no longer returns a container holding another document type
  as the type that was asked for. An encrypted ooxml still opens as whichever
  was asked - it names no inner type until it is decrypted.
- `.fodt`, `.fodp`, `.fods` and `.fodg` open, render, edit and save like their
  packaged counterparts instead of decoding as an xml source view. An
  `office:binary-data` image now decodes in a package too.
- `Document::as_filesystem` answers with an empty filesystem for a document
  that is one file rather than a package.
- A `.pages` file opens as a text document and renders its body text and the
  tables it anchors, instead of the zip it is made of; styles and images are not
  read yet.
- A `.key` file opens as a presentation and renders the text of each slide in
  boxes where the file positions them, instead of the zip it is made of; slide
  masters, styles, images, tables and presenter notes are not read yet.
- A `.numbers` file opens as a spreadsheet instead of the zip it is made of,
  with one sheet per Numbers table named `<sheet> – <table>`. Cells show the
  values the app last computed; number formats, merged ranges, charts and
  formulas are not read yet.
- An rtf opens and renders as a text document instead of throwing
  `UnknownFileType`. Its text, encoding, paragraphs and tabs are read;
  formatting, tables and pictures are not yet.
- A markdown file opens and renders as prose: CommonMark plus GFM, parsed with
  md4c (a new dependency); raw html, images and rules are not modelled yet.
  Like a csv it stays a text file that also loads as a document, through
  `as_markdown_file()`.
- Markdown has no signature, so it decodes only when `FileType::markdown` is
  asked for — a `.md` still comes back as a text file.
- `psd`, `jp2`, `wmf` and `emf` no longer declare `translate_html` — no browser
  paints them, and `html::translate` throws `UnsupportedFileType` instead of
  writing a blank page. They are still detected and still open.
- `odr.setZoom(value, focus)` holds the point the pinch is centred on. Webkit
  does not carry an applied `body{zoom}` in `getBoundingClientRect`, so the
  focus moved with the zoom.
- New `odr.getViewportRect(element)`: the element's box in the coordinates
  `elementFromPoint` takes, for a host hit-testing while a zoom is applied.
- A view whose zoom does not follow the viewport — `viewport_width`,
  `initial_zoom`, a sheet — keeps the reader's place across a width change.
- New `HtmlViewportMode::fit_width_by_view`: the view measures the fit and keeps
  it current, so a rotation refits instead of holding what it opened at. For a
  host whose web view does not fit a top-level document itself.
- A `.pptx` whose package relates a part that is not xml — a Google Slides
  export relates a protobuf — opens instead of throwing `NoXmlFile`. Only the
  slides `p:sldIdLst` names are read.
- A `.pptx` line break (`a:br`) renders as one instead of joining the runs
  around it, and a run's font, a paragraph's alignment and its left and right
  margins arrive: they were read from the wordprocessingml attributes, which a
  pptx never carries.
- New `PageLayout::background_color`, the ground a page is painted on. A `.pptx`
  slide takes it from the slide, its layout or its master; nothing else sets it
  yet.
- A `.pptx` renders in colour: text, highlights and shape fills, including the
  ones its theme names. Line height, space before and after, sub/superscript and
  vertical text alignment arrive with them. Tinted and shaded theme colours
  still come out at full strength, and shapes a master or layout draws are still
  missing.
- An odf shape or frame that is not filled no longer paints the colour of one
  that was.
- Text in a pdf can be selected, searched and copied where it came out as CJK
  before. A simple font's codes are one byte each, whatever codespace its
  `ToUnicode` map declares, and producers routinely declare two.
- A pdf page that is off screen is no longer laid out or painted. On a drawing-
  heavy file this halves the time to open and takes a zoom step from ~340ms to
  ~50ms.
- A pdf image placed on several pages is one image, and the pdf view honors
  `HtmlConfig::embed_images`, which it used to ignore.
- Text in a pdf no longer comes out in giant overlapping type on a browser with
  a minimum font size. A line block one would clamp is laid out at 24px and
  scaled back down. Such a run is also placed more accurately.

## v6.10.1 - 2026-08-21

- A linked image in a docx or xlsx (`embed_images = false`) is named relative
  to the document, like odf, so a host serving the html under a mount point
  resolves it.

## v6.10.0 - 2026-08-20

- Html views take a zoom from their host: `odr.getZoom()`, `setZoom(value,
  focus)`, `adjustZoom()`, `resetZoom()`, `isZoomFitted()`, `onZoomChange`.
  `HtmlConfig::initial_zoom` sets what they open at, script or no script.
- A pdf that nests parentheses inside a string opens, and keeps its document
  metadata — `cairo` and `pdfTeX` write their `/Producer` that way.
- A jni build without a JDK fails instead of shipping a package missing
  `odr-core-java.jar`. `ODR_JNI_JAR=OFF` is how the AAR build asks for the
  native half alone.
- A `FileWalker` over a document or an archive can be steered: `flat_next()`,
  `pop()` and `depth()` do what they say instead of nothing.
- A directory a document or an archive only implies is one: `exists()` and
  `is_directory()` answer for `/` and for a path that files sit under.
- `Odr.load()` works under a Content-Security-Policy without `'unsafe-eval'`:
  the wasm module is linked with `-sDYNAMIC_EXECUTION=0`, so embind builds its
  invokers without `new Function`. `script-src 'self' 'wasm-unsafe-eval'` is
  now enough.
- `wasm/README.md` says what Content-Security-Policy the rendered output needs,
  and what each directive is for. The failures are quiet: a pdf whose `data:`
  fonts are blocked renders as tofu rather than falling back.
- An odf table keeps the rows and columns a grouping element holds, such as the
  `<table:table-header-rows>` LibreOffice writes for a repeating header row.
  They were dropped from the output entirely, in text documents and
  spreadsheets alike.
- Text copied out of a pdf laid out glyph by glyph reads as words, not as
  `L o r e m`. A word break also survives a run with nothing extractable in it.
- An encrypted `.doc`, `.ppt` or `.xls` reports itself encrypted and raises
  `FileEncrypted` instead of a parse error, so a reader can prompt for the
  password. Decrypting them is still out of reach.
- Marking text in a rendered pdf highlights the words rather than a trail of
  narrow boxes beside them.
- A pdf that writes `Tm(text)Tj`, with nothing between the operator and the
  string, renders that text instead of dropping it.
- An embedded font that will not re-encode says so in the log rather than being
  swapped for a substitute in silence.
- Paged output rendered **into a frame** fits the viewport itself. A viewport
  meta tag is honoured for the top-level document only, so an embedder got no
  fit at all. Only ever down, and a top-level document is left to the meta tag.
- **New** `HtmlConfig::viewport_width`: the width the output will be shown at,
  in css pixels. The fit is then a factor in the emitted css — no script, framed
  or not. Bound in the python, wasm, jni and apple bindings as `viewportWidth`.
- An image view fits the viewport too: `img{max-width:100%}`, so a scan wider
  than the frame stops overflowing. `actual_size` still shows it 1:1.
- Output that fits itself keeps the reader's place when the viewport changes.
  The browser's own guess is wrong here because the scale changes with the
  width, and a long document came back a page or more from where it was.

## v6.9.0 - 2026-08-18

- A filled pdf form shows what was filled in, and a marked-up one its markup:
  an annotation's appearance stream is painted onto the page. Hidden, no-view
  and popup annotations stay unpainted.
- A scanned pdf page is no longer blank: `JBIG2Decode` images decode in house.
  MMR/Huffman, refinement and halftone regions still skip the image.
- Justified pdf text is spaced as the file asks: word spacing (`Tw`) applies to
  runs painted with an embedded font, which had rendered short.
- A pdf page is turned as its `/Rotate` says.
- A pdf whose subset font names its glyphs `gidNNNNN` reads correctly, and a
  named glyph variant such as `hyphen.case` is the one painted: a simple font's
  `/Encoding` names select through the font program's charset.
- A pdf whose Flate streams omit the ADLER32 trailer opens.
- A `.docx` is spaced the way word spaces it: paragraph spacing before and after
  and line height (`w:spacing`), the `w:contextualSpacing` that keeps a list
  tight, and table row heights (`w:trHeight`, as a minimum height).
- A `.docx` table follows its table style: the paragraph and text properties
  `w:tblStyle` names reach everything in the table.
- **Deprecated** `HtmlConfig::embed_outline`, `no_drm`,
  `background_image_format` and `background_image_dpi`. Nothing has read them
  for a while; they still store and return what is set.

## v6.8.0 - 2026-08-18

- A file can be read in the dark: `HtmlConfig::color_scheme` is `light`, `dark`
  or `system`, following the reader's `prefers-color-scheme`. Every view honors
  it but the pdf one, and the colors the file authored give way to it. Bound in
  the python, wasm, jni and apple bindings as `HtmlColorScheme`.
- `FileTypeCapabilities::color_scheme` says whether a type's view honors it —
  every type that renders but pdf, audio and video. Bound in the bindings too.
- A text document reflowed to the viewport is inset 3mm from the screen edge
  rather than starting at the first pixel of it.
- Prose is no longer read as a csv. A separator that every field follows with a
  space, in fields long enough to be sentences, is punctuation; `a, b, c` with
  short values is still a csv. One record is a line, not a table.
- A large text file appears at once: sizing the line numbers laid the page out
  once per line. A megabyte took 38s and now takes under a second.

## v6.7.1 - 2026-08-16

- A pdf whose fonts are not embedded sits where the file puts it: a recovered
  word break was both written into the run and spanned by its offset, so every
  word drifted another space right and a search hit landed on its neighbour.
- A pdf's bold and italic text is bold and italic — a non-embedded font is
  asked for by the name of that cut, not faked at the regular cut's widths.
- A pdf line that mixes fonts or sizes puts each run at its own baseline
  instead of against the metrics of whichever run opened the line. Subscripts
  and superscripts sit where the file puts them, and the text after a bullet
  no longer parts company with the highlight that selects it.
- A search hit or a selection running across words in a pdf paints the word
  gaps between them rather than leaving a sliver of white in each. A gap wider
  than the text is left alone: it is a column of white, not a space.

## v6.7.0 - 2026-08-16

- `odr.search()`, `searchNext()`, `searchPrevious()` and `resetSearch()` now
  come with every view that renders text — a pdf, a text file, an xml view, an
  archive listing — as the shipped `search.css` and `search.js`, which a host
  that links rather than embeds has to serve.
- A search hit in a pdf tints its glyphs instead of covering them; a pdf's
  glyph layer and the text view's line numbers are not searched.
- A keyword is found across the spans it happens to be written in — a pdf puts
  a word in each — and a space matches whichever kind the page carries. It
  still does not run across a line, a cell or a paragraph.
- A tap on a paged document reaches its text: a negative `z-index` painted the
  page behind its container, which took every tap. No caret, and no keyboard on
  ios.

## v6.6.0 - 2026-08-14

- A paragraph states its own font, so a run that names none of its own is read
  at that font instead of at nothing. Slides whose text was there but invisible
  now show it.
- An empty paragraph keeps the height its font implies, whether or not the file
  names a size for it, and copying across one yields a blank line.
- A sheet's cells read in the font the file names, falling back to the sheet's
  own only where it names none.
- An image stays inside its frame on a page read without the shipped stylesheet,
  rather than covering the whole page.
- A frame that names a side instead of an offset sits on that side, so a centred
  image in an odt is centred. The side it names is `GraphicStyle`'s new
  `horizontal_position`, carried by the python, java and objc bindings.
- A pdf that comments its content stream renders: `%` to the end of the line is
  white space wherever it stands, not the start of a token.
- Text that decodes to half a surrogate pair costs that character a replacement
  mark instead of the whole document.
- A pdf's text sits where the file puts it: a line was placed against the
  browser's default font rather than its own, which dropped small text by
  several points.
- A pdf's cmyk colours are converted as Adobe converts them, so a process cyan
  reads as one instead of as pure `#00ffff`.
- A pdf page is the size of its crop box and shows what is on it and no more,
  as a viewer shows it.
- A pdf's JPEG 2000 images render. New dependency: `openjpeg`.
- A frame anchored to the page sits where the page says, whatever the text
  around it wraps like - a letter's address and date boxes land in their fields
  instead of in the running text.
- A text document is laid out on the master page it names, so a letter template
  keeps the margins that leave room for its letterhead.
- A docx or odt that chains its styles deeply opens instead of taking the
  process down with it: the `w:basedOn` / `style:parent-style-name` chain is
  walked onto a stack rather than recursed, so its length costs no stack.
- A document's xml parts are read once instead of buffered twice on the way into
  the parser, which lowers the memory opening a large one takes.

## v6.5.0 - 2026-08-10

- An xml file opens as xml and reads as a foldable, highlighted source view
  rather than as one very long line, in the encoding its declaration names.
- An svg is recognised by reading it rather than by what it is called, so bytes
  that are not one no longer open as an image that cannot be shown.
- A text file reads in a quieter gutter: the line numbers line up with their
  lines, stay out of a copy of the page, and the hovered line is marked.
- Every page states its own body margin and background instead of inheriting the
  browser's, so no view opens inset by an eight-pixel border.

## v6.4.0 - 2026-08-09

- csv opens as a spreadsheet, its dialect probed unless the caller gives one,
  and a value that only looks numeric left as text.
- Text encodings are named and decoded, so a document that is not UTF-8 comes
  out as text rather than mojibake.
- An archive's entries are served as files instead of one page of base64.
- A docx renders on the page it was written for, and a numbered list carries its
  markers as text a copy keeps.
- Sheets render in a quieter grid, under a ruler that stays put while scrolling.

## v6.3.0 - 2026-08-08

- The engine runs in the browser. A WebAssembly build published as
  `@opendocument/odr-core` renders documents with no server.
- A file can be opened from memory — `File::from_memory` — and every entry point
  that took a path now also takes a `File`.
- `translate` no longer needs a cache path. The overloads taking one remain and
  ignore it; nothing on the render path writes to disk.
- svg, ico, jxl, jp2, psd, wmf and emf are detected and translated as images.
- Embedded PDF fonts no longer render as tofu or as the wrong glyphs.
- Two translates can run at once. The unit registry and the logger clock were
  not thread-safe, and the HTTP server serves from a thread pool.
- argon2id is implemented in-tree, which drops the `conan-odr-index` remote:
  every dependency now comes from ConanCenter.

## v6.2.0 - 2026-08-02

- Objective-C bindings and a Swift package, with the `OdrCoreObjC.xcframework`
  attached to each release.
- The renderer's css and js are written into the html, so a consumer no longer
  ships `odr.js` or points the library at a data directory.
- Audio and video play in the browser, and the media formats the engine could
  only name are now opened.
- `mimetype` is answered without libmagic, and the libmagic option is
  deprecated.
- The html viewport config is bound for Java and Python.
- A release reports where it landed, so one that reached only some of the
  package registries is visible instead of silent.

## v6.1.0 - 2026-07-30

- The supported-format tables are public, with a per-file-type capability query,
  so a caller can ask what the engine does with a type before holding a file.
- The Java library and a new Android AAR are published to Maven Central, the
  AAR tested on a device.
- `HttpServer::stop()` and destruction wait for `listen()` to return.
- A JNI wrapper stays reachable while its handle is in a native call.

## v6.0.1 - 2026-07-27

- The logger thread attaches to the JVM on Android.

## v6.0.0 - 2026-07-27

**Breaking.** A cleanup of the public API, source-incompatible throughout.

- The deprecated API and the pdf2htmlEX / wvWare backends are gone, and with
  them `DecoderEngine` and the whole decoder-selection dimension — with the
  external backends dropped there was one engine left to select.
- `FileMeta` absorbs `DocumentMeta`, `Logger` is a value type with a public
  `ILogger` sink, and `HttpServer::listen` splits into `bind` and `listen`.
- Shape geometry is typed: `Frame`, `Rect`, `Line`, `Circle` and `CustomShape`
  return `Measure`, not `std::string`. `Measure::to_string` keeps 7 significant
  digits instead of 4, so drawing coordinates stop being rounded away.
- Every exception derives from `odr::Exception`; `Color` uses `from_rgb` /
  `from_argb`; `const char *` is gone from the public headers in favour of
  `std::string_view`.
- Two long-standing defects: `ElementIterator::operator++(int)` could not
  advance, and elements compared equal across unrelated documents.
- The python wheel ships the libmagic database inside it.

## v5.7.1 - 2026-07-26

- The Java API loads on Android API 26 again.
- Conan consumers can turn the cli off.

## v5.7.0 - 2026-07-26

- Python bindings (`pyodr`) live here rather than in `OpenDocument.py`.
- JNI bindings with an `app.opendocument.core` Java API, published to GitHub
  Packages.

## v5.6.0 - 2026-07-25

- Initial zoom is configurable through `HtmlViewportMode`, and fixed-size
  content — PDF and images — opens fit-to-width on mobile.

## v5.5.0 - 2026-07-25

- Legacy Microsoft formats gain formatting: character formatting in doc and ppt,
  cell fonts and fills in xls, and pictures, slide size and slide names in ppt.
- OOXML gains pptx slide size and tables, xlsx merged cells and value types, and
  docx table merges; ODF gains sub/superscript, percent line-height and
  first-line indent.
- PDF exposes per-page html views, and a page range limits any document.

## v5.4.1 - 2026-07-11

- **Relicensed from GPL-3.0 to MPL-2.0.**
- The HTTP server is optional (`ODR_WITH_HTTP_SERVER`), and asset bundling
  defaults to off.

## v5.4.0 - 2026-07-05

- **PDF is rendered by this engine.** Text is placed by its baseline, embedded
  TrueType, CFF, Type1 and Type3 fonts are used and missing ones substituted
  against standard-14 metrics, and images, paths, clipping, shadings, tiling
  patterns, transparency and blend modes are drawn. Links become `<a>` overlays.
- Encrypted PDFs open with the standard security handler, damaged
  cross-reference tables are recovered, and xref streams, object streams and
  hybrid files are read.
- Text extraction handles ToUnicode CMaps, composite fonts and the legacy CJK
  CMaps, so older documents no longer come out garbled.
- Initial ppt and xls support, read in-tree.

## v5.3.0 - 2026-06-06

Mostly build and CI.

- Plain-text output honours `HtmlConfig::editable`.
- CMake options are prefixed `ODR_`.
