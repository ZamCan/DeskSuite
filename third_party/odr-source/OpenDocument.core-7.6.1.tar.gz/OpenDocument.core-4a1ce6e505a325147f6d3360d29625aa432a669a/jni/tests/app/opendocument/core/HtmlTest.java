package app.opendocument.core;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Arrays;
import java.util.function.Consumer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class HtmlTest {
  @TempDir Path tempDir;

  private Html translateOffline(Path input) throws IOException {
    Path output = Files.createDirectories(tempDir.resolve("output"));
    DecodedFile file = Odr.open(input.toString());
    HtmlService service = Html.translate(file, new HtmlConfig());
    return service.bringOffline(output.toString());
  }

  private String renderOdt(HtmlConfig config) throws IOException {
    DecodedFile file = Odr.open(TestFiles.odtFile(tempDir).toString());
    HtmlService service = Html.translate(file, config);
    return service.listViews().get(0).writeHtml().html;
  }

  @Test
  void closingServiceInvalidatesItsViews() throws IOException {
    try (DecodedFile file = Odr.open(TestFiles.odtFile(tempDir).toString())) {
      HtmlService service = Html.translate(file, new HtmlConfig());
      try (HtmlView view = service.listViews().get(0)) {
        service.close();
        assertThrows(IllegalStateException.class, view::writeHtml);
      }
    }
  }

  @Test
  void htmlConfigDefaults() {
    HtmlConfig config = new HtmlConfig();
    assertTrue(config.embedImages);
    assertTrue(!config.allowExternalContent);
    assertTrue(!config.pdfEnforcePermissions);
    assertTrue(!config.editable);
    assertEquals(HtmlEditingScope.DOCUMENT, config.editingScope);
    assertEquals(HtmlTableGridlines.SOFT, config.spreadsheetGridlines);
    assertEquals(HtmlViewportMode.AUTOMATIC, config.viewportMode);
    assertNull(config.spreadsheetViewportMode);
    assertNull(config.viewportContent);
    assertNull(config.viewportWidth);
    assertNull(config.initialZoom);
    assertTrue(config.lazyLayout);
    assertFalse(config.lazyLoading);
  }

  @Test
  void invalidIntegerLimitsAreRejected() throws IOException {
    List<Consumer<HtmlConfig>> invalid = Arrays.asList(
        c -> c.spreadsheetLimit = new TableDimensions(-1, 1),
        c -> c.spreadsheetLimit = new TableDimensions(1, -1),
        c -> c.spreadsheetCellLimit = -1L,
        c -> c.spreadsheetStyleBuffer = -1L,
        c -> c.viewportWidth = -1,
        c -> c.htmlIndent = -1,
        c -> c.htmlIndent = 256,
        c -> c.pageRangeBegin = -1,
        c -> c.pageRangeEnd = -1);
    try (DecodedFile file = Odr.open(TestFiles.odtFile(tempDir).toString())) {
      for (Consumer<HtmlConfig> change : invalid) {
        HtmlConfig config = new HtmlConfig();
        change.accept(config);
        assertThrows(OdrException.class, () -> Html.translate(file, config));
      }
      HtmlConfig config = new HtmlConfig();
      config.htmlIndent = 255;
      config.pageRangeEnd = Integer.MAX_VALUE;
      config.spreadsheetCellLimit = Long.MAX_VALUE;
      try (HtmlService service = Html.translate(file, config)) {
        HtmlConfig result = service.config();
        assertEquals(255, result.htmlIndent);
        assertEquals(Integer.valueOf(Integer.MAX_VALUE), result.pageRangeEnd);
        assertEquals(Long.valueOf(Long.MAX_VALUE), result.spreadsheetCellLimit);
      }
    }
  }

  @Test
  void viewportConfigRoundTrips() throws IOException {
    HtmlConfig config = new HtmlConfig();
    config.viewportMode = HtmlViewportMode.FIT_WIDTH;
    config.spreadsheetViewportMode = HtmlViewportMode.ACTUAL_SIZE;
    config.viewportContent = "width=420";
    config.viewportWidth = 420;
    config.initialZoom = 1.5;
    config.lazyLayout = false;
    config.lazyLoading = true;
    config.sheetEditOnClick = false;
    config.pdfAnnotationMarkOnSelection = true;
    config.hostMessageHandler = "reader.postMessage";

    DecodedFile file = Odr.open(TestFiles.odtFile(tempDir).toString());
    HtmlConfig readBack = Html.translate(file, config).config();

    assertEquals(HtmlViewportMode.FIT_WIDTH, readBack.viewportMode);
    assertEquals(HtmlViewportMode.ACTUAL_SIZE, readBack.spreadsheetViewportMode);
    assertEquals("width=420", readBack.viewportContent);
    assertEquals(Integer.valueOf(420), readBack.viewportWidth);
    assertEquals(Double.valueOf(1.5), readBack.initialZoom);
    assertFalse(readBack.lazyLayout);
    assertTrue(readBack.lazyLoading);
    assertEquals(Boolean.FALSE, readBack.sheetEditOnClick);
    assertTrue(readBack.pdfAnnotationMarkOnSelection);
    assertEquals("reader.postMessage", readBack.hostMessageHandler);
  }

  /** Proves the scope crosses JNI; the C++ suite covers the rest. */
  @Test
  void editingScopeReachesTheHtml() throws IOException {
    // the attribute, not the name: the script names it too
    assertTrue(!renderOdt(new HtmlConfig()).contains("data-odr-editing-scope=\""));

    HtmlConfig editable = new HtmlConfig();
    editable.editable = true;
    assertTrue(renderOdt(editable).contains("data-odr-editing-scope=\"document\""));

    HtmlConfig narrowed = new HtmlConfig();
    narrowed.editable = true;
    narrowed.editingScope = HtmlEditingScope.PARAGRAPH;
    assertTrue(renderOdt(narrowed).contains("data-odr-editing-scope=\"paragraph\""));

    DecodedFile file = Odr.open(TestFiles.odtFile(tempDir).toString());
    HtmlConfig readBack = Html.translate(file, narrowed).config();
    assertEquals(HtmlEditingScope.PARAGRAPH, readBack.editingScope);
  }

  /** The C++ suite covers where the floor lands; this only proves it crosses JNI. */
  @Test
  void minContentMarginReachesTheHtml() throws IOException {
    assertNull(new HtmlConfig().minContentMargin.top);
    assertTrue(!renderOdt(new HtmlConfig()).contains(":root{--odr-min-margin"));

    // the field is the host's to null, and reading one is not a crash
    HtmlConfig cleared = new HtmlConfig();
    cleared.minContentMargin = null;
    assertTrue(!renderOdt(cleared).contains(":root{--odr-min-margin"));

    HtmlConfig config = new HtmlConfig();
    config.minContentMargin =
        new DirectionalMeasure(null, new Measure(12, "px"), new Measure(1, "cm"), null);
    assertTrue(
        renderOdt(config).contains(":root{--odr-min-margin-top:12px;--odr-min-margin-left:1cm;}"));

    DecodedFile file = Odr.open(TestFiles.odtFile(tempDir).toString());
    HtmlConfig readBack = Html.translate(file, config).config();
    assertEquals(new Measure(12, "px"), readBack.minContentMargin.top);
    assertEquals(new Measure(1, "cm"), readBack.minContentMargin.left);
    assertNull(readBack.minContentMargin.right);
  }

  /** The C++ suite covers the mode matrix; this only proves the config crosses JNI. */
  @Test
  void viewportModeReachesTheHtml() throws IOException {

    // A text document without margins is reflowing content, so `AUTOMATIC`
    // resolves to `ACTUAL_SIZE`.
    String automatic = renderOdt(new HtmlConfig());
    assertTrue(
        automatic.contains(
            "<meta name=\"viewport\""
                + " content=\"width=device-width,initial-scale=1.0,user-scalable=yes\"/>"));

    HtmlConfig fitWidth = new HtmlConfig();
    fitWidth.viewportMode = HtmlViewportMode.FIT_WIDTH;
    assertTrue(
        renderOdt(fitWidth)
            .contains(
                "<meta name=\"viewport\" content=\"width=device-width,user-scalable=yes\"/>"));

    // only paged content has a width to fit, hence the margins
    HtmlConfig byView = new HtmlConfig();
    byView.viewportMode = HtmlViewportMode.FIT_WIDTH_BY_VIEW;
    byView.textDocumentMargin = true;
    assertTrue(renderOdt(byView).contains("--odr-fit:view"));

    HtmlConfig raw = new HtmlConfig();
    raw.viewportContent = "width=420";
    assertTrue(renderOdt(raw).contains("<meta name=\"viewport\" content=\"width=420\"/>"));
  }

  /** The C++ suite covers what the scheme paints; this only proves it crosses JNI. */
  @Test
  void colorSchemeReachesTheHtml() throws IOException {
    assertEquals(HtmlColorScheme.LIGHT, new HtmlConfig().colorScheme);
    assertTrue(!renderOdt(new HtmlConfig()).contains("prefers-color-scheme"));

    HtmlConfig system = new HtmlConfig();
    system.colorScheme = HtmlColorScheme.SYSTEM;
    assertTrue(renderOdt(system).contains("media=\"screen and (prefers-color-scheme: dark)\""));

    DecodedFile file = Odr.open(TestFiles.odtFile(tempDir).toString());
    HtmlConfig readBack = Html.translate(file, system).config();
    assertEquals(HtmlColorScheme.SYSTEM, readBack.colorScheme);
  }

  @Test
  void translateText() throws IOException {
    Html html = translateOffline(TestFiles.txtFile(tempDir));
    List<HtmlPage> pages = html.pages();
    assertEquals(1, pages.size());
    String content = Files.readString(Path.of(pages.get(0).path));
    assertTrue(content.contains("hello text file"));
  }

  @Test
  void translateCsv() throws IOException {
    Html html = translateOffline(TestFiles.csvFile(tempDir));
    // a spreadsheet: a document view plus one per sheet
    assertEquals(2, html.pages().size());
    String content = Files.readString(Path.of(html.pages().get(1).path));
    assertTrue(content.contains("alpha"));
    assertTrue(content.contains("<table"));
  }

  @Test
  void translateDocument() throws IOException {
    Html html = translateOffline(TestFiles.odtFile(tempDir));
    assertEquals(1, html.pages().size());
    String content = Files.readString(Path.of(html.pages().get(0).path));
    assertTrue(content.contains(TestFiles.ODT_WORD));
  }

  /** The C++ suite covers where the limits land; this proves the pair crosses JNI. */
  @Test
  void spreadsheetCutReachesTheView() throws IOException {
    assertEquals(Long.valueOf(500000L), new HtmlConfig().spreadsheetCellLimit);

    DecodedFile file = Odr.open(TestFiles.csvFile(tempDir).toString());

    HtmlConfig full = new HtmlConfig();
    for (HtmlView view : Html.translate(file, full).listViews()) {
      assertNull(view.sheetCut());
    }

    HtmlConfig cut = new HtmlConfig();
    cut.spreadsheetLimit = new TableDimensions(2, 1);
    cut.spreadsheetCellLimit = null;
    HtmlService service = Html.translate(file, cut);

    assertNull(service.config().spreadsheetCellLimit);
    HtmlSheetCut sheetCut = service.listViews().get(1).sheetCut();
    assertNotNull(sheetCut);
    assertEquals(3, sheetCut.content.rows);
    assertEquals(2, sheetCut.content.columns);
    assertEquals(2, sheetCut.rendered.rows);
    assertEquals(1, sheetCut.rendered.columns);
  }

  @Test
  void htmlServiceViews() throws IOException {
    DecodedFile file = Odr.open(TestFiles.odtFile(tempDir).toString());
    HtmlService service = Html.translate(file, new HtmlConfig());

    List<HtmlView> views = service.listViews();
    assertEquals(1, views.size());
    assertTrue(service.exists(views.get(0).path()));
    String missing = "missing-😀.html";
    OdrException error =
        assertThrows(OdrException.FileNotFound.class, () -> service.write(missing));
    assertEquals("file not found: Unknown path: " + missing, error.getMessage());

    Html.Content content = views.get(0).writeHtml();
    assertTrue(content.html.contains(TestFiles.ODT_WORD));

    Html offline = service.bringOffline(tempDir.resolve("selected").toString(), views);
    assertEquals(1, offline.pages().size());
    assertTrue(Files.readString(Path.of(offline.pages().get(0).path)).contains(TestFiles.ODT_WORD));
    assertTrue(service.bringOffline(tempDir.resolve("empty").toString(), List.of()).pages().isEmpty());
  }
}
