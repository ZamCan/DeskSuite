package app.opendocument.core;

/**
 * HTML output configuration. Mirrors {@code odr::HtmlConfig}; field defaults
 * match the C++ defaults. The C++ {@code resource_locator} is not exposed; the
 * standard resource locator is always used.
 */
public final class HtmlConfig {
  public String documentOutputFileName = "document.html";

  public String slideOutputFileName = "slide{index}.html";
  public String sheetOutputFileName = "sheet{index}.html";
  public String pageOutputFileName = "page{index}.html";

  public boolean embedImages = true;
  /**
   * Load the images a document names outside itself, and keep its relative links. Off, only a
   * navigable scheme leaves the view, in a new window.
   */
  public boolean allowExternalContent = false;
  public boolean embedShippedResources = true;

  /** {@code null} keeps the native default (the odr core data path). */
  public String resourcePath;
  public boolean relativeResourcePaths = true;

  public boolean editable = false;
  /** How far an edit in a document view may reach; the page refuses the rest. */
  public HtmlEditingScope editingScope = HtmlEditingScope.DOCUMENT;

  /** Whether the view's scripts take the keys that move the selection. */
  public boolean keyboardNavigation = true;
  /** Whether the view's scripts take the editing chords: undo and redo. */
  public boolean keyboardShortcuts = true;

  /** Whether a click opens the sheet editor; {@code null} asks the pointer. */
  public Boolean sheetEditOnClick;

  /**
   * The function, as a path from {@code window}, that takes every {@code odr.on*} callback as a
   * JSON string, e.g. {@code "odrHost.postMessage"}. Empty sends nothing.
   */
  public String hostMessageHandler = "";

  public boolean textDocumentMargin = false;

  /** The colors a document renders against. */
  public HtmlColorScheme colorScheme = HtmlColorScheme.LIGHT;

  /** {@code null} disables the spreadsheet limit. */
  public TableDimensions spreadsheetLimit = new TableDimensions(100000, 500);

  /**
   * Most cells written for one sheet; bounds the rows by the sheet's width. {@code null} disables
   * the budget.
   */
  public Long spreadsheetCellLimit = 500000L;

  public boolean spreadsheetLimitByContent = true;
  public HtmlTableGridlines spreadsheetGridlines = HtmlTableGridlines.SOFT;
  /** How much of a sheet's body is held back while the head collects its classes. */
  public long spreadsheetStyleBuffer = 128L << 20;

  /** Initial zoom on mobile. */
  public HtmlViewportMode viewportMode = HtmlViewportMode.AUTOMATIC;
  /** Overrides {@link #viewportMode} for spreadsheet content; {@code null} keeps it. */
  public HtmlViewportMode spreadsheetViewportMode;
  /** Raw {@code content} for the viewport meta tag; overrides the modes above when set. */
  public String viewportContent;
  /** The width the output is shown at, in css pixels; fits paged content to it. */
  public Integer viewportWidth;
  /** The zoom the view opens at, 1 being actual size; {@code null} follows the fit. */
  public Double initialZoom;
  /** Lay out only the lines, rows, pages and slides near the viewport. */
  public boolean lazyLayout = true;
  /**
   * Load the chunks of a text file, a sheet and a pdf after the first as the reader comes near,
   * and write a search index of their text beside them.
   */
  public boolean lazyLoading = false;

  /**
   * The least distance the generated content keeps from the view's border. A set side raises the
   * inset the view already has, never lowers it.
   */
  public DirectionalMeasure minContentMargin =
      new DirectionalMeasure(null, null, null, null);

  public boolean formatHtml = false;
  public int htmlIndent = 1;
  public String htmlIndentString = "\t";

  public int pageRangeBegin = 0;
  /** {@code null} renders to the end of the document. */
  public Integer pageRangeEnd;

  public PdfTextMode pdfTextMode = PdfTextMode.DUAL_LAYER;
  public String[] pdfDualLayerFallbackFonts = {
    "Arial", "Helvetica", "Liberation Sans", "DejaVu Sans", "Nimbus Sans"
  };
  public double pdfDualLayerFallbackFontSizeAdjust = 0.5;
  /** Whether an armed annotation tool marks each selection as it is made. */
  public boolean pdfAnnotationMarkOnSelection = false;
  /** Honor {@link PdfFile#permissions}, as pdf.js {@code enablePermissions} does. */
  public boolean pdfEnforcePermissions = false;

  /** {@code null} keeps output in the cache directory. */
  public String outputPath;
}
