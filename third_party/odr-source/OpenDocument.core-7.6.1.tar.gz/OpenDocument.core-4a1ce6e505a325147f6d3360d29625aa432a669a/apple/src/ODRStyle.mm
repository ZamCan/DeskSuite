#import <OdrCoreObjC/ODRStyle.h>

#import "ODRInternal.h"
#import "ODRPrivate.h"

#include <odr/exceptions.hpp>
#include <odr/style.hpp>

#include <optional>

using odr::apple::guarded_value;
using odr::apple::to_nsstring;
using odr::apple::to_string;

ODR_SAME_ENUM(ODRFontWeightNormal, odr::FontWeight::normal);
ODR_SAME_ENUM(ODRFontWeightBold, odr::FontWeight::bold);
ODR_SAME_ENUM(ODRFontStyleNormal, odr::FontStyle::normal);
ODR_SAME_ENUM(ODRFontStyleItalic, odr::FontStyle::italic);
ODR_SAME_ENUM(ODRFontPositionNormal, odr::FontPosition::normal);
ODR_SAME_ENUM(ODRFontPositionSuper, odr::FontPosition::super);
ODR_SAME_ENUM(ODRFontPositionSub, odr::FontPosition::sub);
ODR_SAME_ENUM(ODRBreakTypeNone, odr::BreakType::none);
ODR_SAME_ENUM(ODRBreakTypePage, odr::BreakType::page);
ODR_SAME_ENUM(ODRBreakTypeColumn, odr::BreakType::column);
ODR_SAME_ENUM(ODRTextAlignLeft, odr::TextAlign::left);
ODR_SAME_ENUM(ODRTextAlignRight, odr::TextAlign::right);
ODR_SAME_ENUM(ODRTextAlignCenter, odr::TextAlign::center);
ODR_SAME_ENUM(ODRTextAlignJustify, odr::TextAlign::justify);
ODR_SAME_ENUM(ODRTextAlignStart, odr::TextAlign::start);
ODR_SAME_ENUM(ODRTextAlignEnd, odr::TextAlign::end);

ODR_SAME_ENUM(ODRTextDirectionLeftToRight, odr::TextDirection::left_to_right);
ODR_SAME_ENUM(ODRTextDirectionRightToLeft, odr::TextDirection::right_to_left);
ODR_SAME_ENUM(ODRHorizontalAlignLeft, odr::HorizontalAlign::left);
ODR_SAME_ENUM(ODRHorizontalAlignCenter, odr::HorizontalAlign::center);
ODR_SAME_ENUM(ODRHorizontalAlignRight, odr::HorizontalAlign::right);
ODR_SAME_ENUM(ODRHorizontalAlignGeneral, odr::HorizontalAlign::general);
ODR_SAME_ENUM(ODRVerticalAlignTop, odr::VerticalAlign::top);
ODR_SAME_ENUM(ODRVerticalAlignMiddle, odr::VerticalAlign::middle);
ODR_SAME_ENUM(ODRVerticalAlignBottom, odr::VerticalAlign::bottom);
ODR_SAME_ENUM(ODRPrintOrientationPortrait, odr::PrintOrientation::portrait);
ODR_SAME_ENUM(ODRPrintOrientationLandscape, odr::PrintOrientation::landscape);
ODR_SAME_ENUM(ODRTextWrapNone, odr::TextWrap::none);
ODR_SAME_ENUM(ODRTextWrapBefore, odr::TextWrap::before);
ODR_SAME_ENUM(ODRTextWrapAfter, odr::TextWrap::after);
ODR_SAME_ENUM(ODRTextWrapRunThrough, odr::TextWrap::run_through);

static_assert(sizeof(ODRColor) == sizeof(odr::Color),
              "ODRColor drifted from odr::Color");

// Reopened as `odr` so `apple::` below is a meaningful qualification rather
// than a redundant one — see ODRInternal.mm.
namespace odr {

NSValue *_Nullable apple::box(const std::optional<odr::Color> &color) {
  if (!color.has_value()) {
    return nil;
  }
  const ODRColor boxed =
      ODRColorMake(color->red, color->green, color->blue, color->alpha);
  return [NSValue valueWithBytes:&boxed objCType:@encode(ODRColor)];
}

ODRMeasure *_Nullable apple::box(const std::optional<odr::Measure> &measure) {
  return measure.has_value() ? [ODRMeasure measureWithHandle:*measure] : nil;
}

} // namespace odr

using odr::apple::box;

namespace {

/// An absent `std::optional` boxes as `nil` and not as a sentinel: a style that
/// does not set a property is different from one that sets it to a default, and
/// only the caller knows what to fall back to.
template <typename T>
NSNumber *_Nullable box_number(const std::optional<T> &value) {
  return value.has_value() ? @(*value) : nil;
}

template <typename Enum>
NSNumber *_Nullable box_enum(const std::optional<Enum> &value) {
  return value.has_value() ? @(static_cast<NSInteger>(*value)) : nil;
}

NSString *_Nullable box_string(const std::optional<std::string> &value) {
  return value.has_value() ? to_nsstring(*value) : nil;
}

odr::Color unbox_color(NSValue *const value) {
  ODRColor color{};
  [value getValue:&color size:sizeof(color)];
  return {color.red, color.green, color.blue, color.alpha};
}

} // namespace

#pragma mark - ODRMeasure

@implementation ODRMeasure {
  std::optional<odr::Measure> _handle;
}

+ (instancetype)measureWithHandle:(const odr::Measure &)handle {
  ODRMeasure *const result = [[ODRMeasure alloc] init];
  result->_handle = handle;
  return result;
}

- (double)magnitude {
  return guarded_value([&] { return _handle->magnitude(); }, 0.0);
}

- (NSString *)unit {
  return guarded_value([&] { return to_nsstring(_handle->unit().name()); },
                       @"");
}

- (NSString *)stringValue {
  return guarded_value([&] { return to_nsstring(_handle->to_string()); }, @"");
}

- (nullable instancetype)initWithString:(NSString *)string {
  if ((self = [super init]) == nil) {
    return nil;
  }
  return guarded_value(
      [&]() -> ODRMeasure * {
        _handle = odr::Measure(to_string(string));
        return self;
      },
      nil);
}

- (instancetype)initWithMagnitude:(double)magnitude unit:(NSString *)unit {
  if ((self = [super init]) == nil) {
    return nil;
  }
  _handle = odr::Measure(magnitude, odr::DynamicUnit(to_string(unit)));
  return self;
}

- (const std::optional<odr::Measure> &)handle {
  return _handle;
}

- (NSString *)description {
  return self.stringValue;
}

@end

#pragma mark - directional

@implementation ODRDirectionalMeasure

+ (instancetype)directionalWithHandle:
    (const odr::DirectionalStyle<odr::Measure> &)handle {
  ODRDirectionalMeasure *const result = [[ODRDirectionalMeasure alloc] init];
  result->_right = box(handle.right);
  result->_top = box(handle.top);
  result->_left = box(handle.left);
  result->_bottom = box(handle.bottom);
  return result;
}

- (instancetype)initWithRight:(ODRMeasure *)right
                          top:(ODRMeasure *)top
                         left:(ODRMeasure *)left
                       bottom:(ODRMeasure *)bottom {
  if ((self = [super init]) == nil) {
    return nil;
  }
  _right = right;
  _top = top;
  _left = left;
  _bottom = bottom;
  return self;
}

- (odr::DirectionalStyle<odr::Measure>)handle {
  odr::DirectionalStyle<odr::Measure> result;
  result.right = _right != nil ? _right.handle : std::nullopt;
  result.top = _top != nil ? _top.handle : std::nullopt;
  result.left = _left != nil ? _left.handle : std::nullopt;
  result.bottom = _bottom != nil ? _bottom.handle : std::nullopt;
  return result;
}

@end

@implementation ODRDirectionalString

+ (instancetype)directionalWithHandle:
    (const odr::DirectionalStyle<std::string> &)handle {
  ODRDirectionalString *const result = [[ODRDirectionalString alloc] init];
  result->_right = box_string(handle.right);
  result->_top = box_string(handle.top);
  result->_left = box_string(handle.left);
  result->_bottom = box_string(handle.bottom);
  return result;
}

@end

#pragma mark - styles

@implementation ODRTextStyle

+ (instancetype)styleWithHandle:(const odr::TextStyle &)handle {
  ODRTextStyle *const result = [[ODRTextStyle alloc] init];
  result->_fontName = box_string(handle.font_name);
  result->_fontSize = box(handle.font_size);
  result->_fontWeight = box_enum(handle.font_weight);
  result->_fontStyle = box_enum(handle.font_style);
  result->_fontUnderline = box_number(handle.font_underline);
  result->_fontLineThrough = box_number(handle.font_line_through);
  result->_fontShadow = box_string(handle.font_shadow);
  result->_fontColor = box(handle.font_color);
  result->_backgroundColor = box(handle.background_color);
  result->_fontPosition = box_enum(handle.font_position);
  return result;
}

- (odr::TextStyle)handle {
  odr::TextStyle result;
  if (_fontName != nil) {
    result.font_name = to_string(_fontName);
  }
  if (_fontSize != nil) {
    result.font_size = _fontSize.handle;
  }
  if (_fontWeight != nil) {
    result.font_weight = static_cast<odr::FontWeight>(_fontWeight.integerValue);
  }
  if (_fontStyle != nil) {
    result.font_style = static_cast<odr::FontStyle>(_fontStyle.integerValue);
  }
  if (_fontUnderline != nil) {
    result.font_underline = _fontUnderline.boolValue != NO;
  }
  if (_fontLineThrough != nil) {
    result.font_line_through = _fontLineThrough.boolValue != NO;
  }
  if (_fontShadow != nil) {
    result.font_shadow = to_string(_fontShadow);
  }
  if (_fontColor != nil) {
    result.font_color = unbox_color(_fontColor);
  }
  if (_backgroundColor != nil) {
    result.background_color = unbox_color(_backgroundColor);
  }
  if (_fontPosition != nil) {
    result.font_position =
        static_cast<odr::FontPosition>(_fontPosition.integerValue);
  }
  return result;
}

@end

@implementation ODRParagraphStyle

- (instancetype)init {
  if ((self = [super init]) != nil) {
    _margin = [ODRDirectionalMeasure
        directionalWithHandle:odr::DirectionalStyle<odr::Measure>()];
  }
  return self;
}

- (odr::ParagraphStyle)handle {
  if (_direction != nil || _margin.right != nil || _margin.top != nil ||
      _margin.left != nil || _margin.bottom != nil || _lineHeight != nil ||
      _textIndent != nil || _breakBefore != nil || _breakAfter != nil) {
    throw odr::UnsupportedOperation();
  }
  odr::ParagraphStyle result;
  if (_textAlign != nil) {
    result.text_align = static_cast<odr::TextAlign>(_textAlign.integerValue);
  }
  return result;
}

+ (instancetype)styleWithHandle:(const odr::ParagraphStyle &)handle {
  ODRParagraphStyle *const result = [[ODRParagraphStyle alloc] init];
  result->_textAlign = box_enum(handle.text_align);
  result->_direction = box_enum(handle.direction);
  result->_margin = [ODRDirectionalMeasure directionalWithHandle:handle.margin];
  result->_lineHeight = box(handle.line_height);
  result->_textIndent = box(handle.text_indent);
  result->_breakBefore = box_enum(handle.break_before);
  result->_breakAfter = box_enum(handle.break_after);
  return result;
}

@end

@implementation ODRTableStyle

+ (instancetype)styleWithHandle:(const odr::TableStyle &)handle {
  ODRTableStyle *const result = [[ODRTableStyle alloc] init];
  result->_width = box(handle.width);
  result->_border = [ODRDirectionalString directionalWithHandle:handle.border];
  result->_borderInsideHorizontal = box_string(handle.border_inside_horizontal);
  result->_borderInsideVertical = box_string(handle.border_inside_vertical);
  return result;
}

@end

@implementation ODRTableColumnStyle

+ (instancetype)styleWithHandle:(const odr::TableColumnStyle &)handle {
  ODRTableColumnStyle *const result = [[ODRTableColumnStyle alloc] init];
  result->_width = box(handle.width);
  return result;
}

@end

@implementation ODRTableRowStyle

+ (instancetype)styleWithHandle:(const odr::TableRowStyle &)handle {
  ODRTableRowStyle *const result = [[ODRTableRowStyle alloc] init];
  result->_height = box(handle.height);
  return result;
}

@end

@implementation ODRTableCellStyle

- (instancetype)init {
  if ((self = [super init]) != nil) {
    _padding = [ODRDirectionalMeasure
        directionalWithHandle:odr::DirectionalStyle<odr::Measure>()];
    _border = [ODRDirectionalString
        directionalWithHandle:odr::DirectionalStyle<std::string>()];
  }
  return self;
}

- (odr::TableCellStyle)handle {
  if (_padding.right != nil || _padding.top != nil || _padding.left != nil ||
      _padding.bottom != nil || _border.right != nil || _border.top != nil ||
      _border.left != nil || _border.bottom != nil) {
    throw odr::UnsupportedOperation();
  }
  odr::TableCellStyle result;
  if (_horizontalAlign != nil) {
    result.horizontal_align =
        static_cast<odr::HorizontalAlign>(_horizontalAlign.integerValue);
  }
  if (_verticalAlign != nil) {
    result.vertical_align =
        static_cast<odr::VerticalAlign>(_verticalAlign.integerValue);
  }
  if (_backgroundColor != nil) {
    result.background_color = unbox_color(_backgroundColor);
  }
  if (_textRotation != nil) {
    result.text_rotation = _textRotation.doubleValue;
  }
  if (_wrapText != nil) {
    result.wrap_text = _wrapText.boolValue != NO;
  }
  return result;
}

+ (instancetype)styleWithHandle:(const odr::TableCellStyle &)handle {
  ODRTableCellStyle *const result = [[ODRTableCellStyle alloc] init];
  result->_horizontalAlign = box_enum(handle.horizontal_align);
  result->_verticalAlign = box_enum(handle.vertical_align);
  result->_backgroundColor = box(handle.background_color);
  result->_padding =
      [ODRDirectionalMeasure directionalWithHandle:handle.padding];
  result->_border = [ODRDirectionalString directionalWithHandle:handle.border];
  result->_textRotation = box_number(handle.text_rotation);
  result->_wrapText = box_number(handle.wrap_text);
  return result;
}

@end

@implementation ODRGraphicStyle

+ (instancetype)styleWithHandle:(const odr::GraphicStyle &)handle {
  ODRGraphicStyle *const result = [[ODRGraphicStyle alloc] init];
  result->_strokeWidth = box(handle.stroke_width);
  result->_strokeColor = box(handle.stroke_color);
  result->_fillColor = box(handle.fill_color);
  result->_verticalAlign = box_enum(handle.vertical_align);
  result->_textWrap = box_enum(handle.text_wrap);
  result->_horizontalPosition = box_enum(handle.horizontal_position);
  return result;
}

@end

@implementation ODRPageLayout

+ (instancetype)layoutWithHandle:(const odr::PageLayout &)handle {
  ODRPageLayout *const result = [[ODRPageLayout alloc] init];
  result->_width = box(handle.width);
  result->_height = box(handle.height);
  result->_printOrientation = box_enum(handle.print_orientation);
  result->_margin = [ODRDirectionalMeasure directionalWithHandle:handle.margin];
  result->_backgroundColor = box(handle.background_color);
  result->_direction = box_enum(handle.direction);
  return result;
}

@end
