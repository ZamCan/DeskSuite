# Design

## Principles

- One API for every format. The format specifics stay behind it.
- Public handles share document state; edits are visible through every handle.
- Element IDs are stable. Removed elements and their descendants reject access;
  traversal does not provide a snapshot across edits.
- Saving depends on the recorded changes, not on the internal representation
  of the document.
- Sparse tables are not stored densely in memory.

## Documents

- [Editing design](editing.md): in-browser editing. The browser records an op
  log, and C++ replays it on save. Elements are addressed by stable ids.
- [Document editing design](document-editing.md): the editor of the document
  view. Runs, paragraphs and inline formatting.
- [Spreadsheet editing design](spreadsheet-editing.md): cells edited and
  formatted by position, and formulas computed in the page.
- [Plain-text editing design](txt-editing.md): the editor of the plain-text
  view. One `setContent` op.
- [Lazy loading design](lazy-loading.md): a large file as chunks that the
  browser lays out only near the viewport, and that core renders on demand;
  a search over the chunks that have not loaded, and images that load near
  the viewport.
- [Document creation design](document-creation.md): a new odt, ods, docx or
  xlsx, generated in code and opened through the read path.

## Diagrams

- [PDF CJK text: the `code → CID → Unicode` path](pdf-cjk-code-cid-unicode.html):
  why a composite (Type0) font needs the legacy CMap tables, and how the
  `pdf_cid_data` lookup works. Open it in a browser.
