#include "bindings.hpp"

#include <odr/error_code.hpp>
#include <odr/exceptions.hpp>
#include <odr/file.hpp>
#include <odr/logger.hpp>
#include <odr/odr.hpp>

#include <pybind11/stl.h>

#include <string>
#include <vector>

namespace py = pybind11;

void odr_python::bind_core(py::module_ &m) {
  m.def("version", &odr::version, "Version of the underlying odrcore library.");
  m.def("commit_hash", &odr::commit_hash,
        "Git commit hash of the underlying odrcore library.");
  m.def("is_dirty", &odr::is_dirty);
  m.def("is_debug", &odr::is_debug);
  m.def("identify", &odr::identify,
        "Identification string of the underlying odrcore library.");

  py::enum_<odr::ErrorCode> error_code(m, "ErrorCode");
  for (const odr::ErrorCode code : odr::all_error_codes()) {
    error_code.value(std::string(odr::error_code_name(code)).c_str(), code);
  }
  // No `export_values`: `range` and its neighbours would land in the module.

  // Mirrors odr::Exception, so `except odr.Error` catches the whole library.
  // `register_exception`, not `py::exception`: the latter has no translator.
  // Registered first so it is tried last - pybind11 reverses that order.
  const py::exception<odr::Exception> &error =
      py::register_exception<odr::Exception>(m, "Error", PyExc_RuntimeError);

  py::register_exception<odr::UnsupportedOperation>(m, "UnsupportedOperation",
                                                    error);
  // The one deliberate exception: mapping onto Python's own FileNotFoundError
  // is worth more here than sitting under `Error`.
  py::register_exception<odr::FileNotFound>(m, "FileNotFound",
                                            PyExc_FileNotFoundError);
  py::register_exception<odr::UnknownFileType>(m, "UnknownFileTypeError",
                                               error);
  py::register_exception<odr::UnsupportedFileType>(
      m, "UnsupportedFileTypeError", error);
  py::register_exception<odr::FileReadError>(m, "FileReadError", error);
  py::register_exception<odr::FileWriteError>(m, "FileWriteError", error);
  py::register_exception<odr::NoDocumentFile>(m, "NoDocumentFileError", error);
  py::register_exception<odr::UnknownDocumentType>(
      m, "UnknownDocumentTypeError", error);
  py::register_exception<odr::UnsupportedCryptoAlgorithm>(
      m, "UnsupportedCryptoAlgorithmError", error);
  py::register_exception<odr::WrongPasswordError>(m, "WrongPasswordError",
                                                  error);
  py::register_exception<odr::DecryptionFailed>(m, "DecryptionFailedError",
                                                error);
  py::register_exception<odr::NotEncryptedError>(m, "NotEncryptedError", error);
  py::register_exception<odr::FileEncryptedError>(m, "FileEncryptedError",
                                                  error);
  py::register_exception<odr::DocumentCopyProtectedException>(
      m, "DocumentCopyProtectedError", error);
}

void odr_python::bind_functions(py::module_ &m) {
  // pybind11 has no caster for a span
  m.def(
      "all_file_types",
      [] {
        const auto types = odr::all_file_types();
        return std::vector<odr::FileType>(types.begin(), types.end());
      },
      "Every file type this library knows about.");
  m.def(
      "all_text_encodings",
      [] {
        const auto encodings = odr::all_text_encodings();
        return std::vector<odr::TextEncoding>(encodings.begin(),
                                              encodings.end());
      },
      "Every text encoding the library knows about, excluding `unknown`.");
  m.def(
      "text_encoding_to_string",
      [](const odr::TextEncoding encoding) {
        return std::string(odr::text_encoding_to_string(encoding));
      },
      py::arg("encoding"),
      "The canonical name, a label a browser accepts. Raises for `unknown`.");
  m.def("text_encoding_by_name", &odr::text_encoding_by_name, py::arg("name"),
        "The encoding for a name, `unknown` if none. Case and any `-`, `_` or "
        "space are ignored.");
  m.def(
      "text_encoding_names",
      [](const odr::TextEncoding encoding) {
        std::vector<std::string> result;
        for (const std::string_view name : odr::text_encoding_names(encoding)) {
          result.emplace_back(name);
        }
        return result;
      },
      py::arg("encoding"), "Every accepted name, canonical first.");
  m.def("text_encoding_is_decodable", &odr::text_encoding_is_decodable,
        py::arg("encoding"),
        "Whether the library can decode this encoding, as opposed to merely "
        "naming it.");

  m.def("file_type_by_file_extension", &odr::file_type_by_file_extension,
        py::arg("extension"));
  m.def(
      "file_extensions_by_file_type",
      [](const odr::FileType type) {
        const auto extensions = odr::file_extensions_by_file_type(type);
        return std::vector<std::string>(extensions.begin(), extensions.end());
      },
      py::arg("type"), "Every file extension accepted for the file type.");
  m.def(
      "file_extension_by_file_type",
      [](const odr::FileType type) {
        return std::string(odr::file_extension_by_file_type(type));
      },
      py::arg("type"));
  m.def("file_category_by_file_type", &odr::file_category_by_file_type,
        py::arg("type"));
  m.def("document_type_by_file_type", &odr::document_type_by_file_type,
        py::arg("type"));
  m.def("file_type_to_string", &odr::file_type_to_string, py::arg("type"));
  m.def("file_category_to_string", &odr::file_category_to_string,
        py::arg("category"));
  m.def("document_type_to_string", &odr::document_type_to_string,
        py::arg("type"));
  m.def(
      "file_type_by_mimetype",
      [](const std::string &mimetype) {
        return odr::file_type_by_mimetype(mimetype);
      },
      py::arg("mimetype"));
  m.def(
      "mimetype_by_file_type",
      [](const odr::FileType type) {
        return std::string(odr::mimetype_by_file_type(type));
      },
      py::arg("type"));
  m.def(
      "mimetypes_by_file_type",
      [](const odr::FileType type) {
        const auto mimetypes = odr::mimetypes_by_file_type(type);
        return std::vector<std::string>(mimetypes.begin(), mimetypes.end());
      },
      py::arg("type"), "Every MIME type accepted for the file type.");
  m.def("capabilities_by_file_type", &odr::capabilities_by_file_type,
        py::arg("type"), "What this library can do with the file type.");

  // Each of these is bound for `File` as well as for a path: a caller holding
  // bytes (`File.from_memory`) must be able to reach everything a caller
  // holding a path can.
  m.def(
      "list_file_types",
      [](const odr::File &file, const odr::Logger &logger) {
        return odr::list_file_types(file, logger);
      },
      py::arg("file"), py::arg("logger") = odr::Logger::null(),
      "Determine the possible file types of a file.");
  m.def(
      "list_file_types",
      [](const std::string &path, const odr::Logger &logger) {
        return odr::list_file_types(path, logger);
      },
      py::arg("path"), py::arg("logger") = odr::Logger::null(),
      "Determine the possible file types of a file.");
  m.def(
      "mimetype",
      [](const odr::File &file, const odr::Logger &logger) {
        return std::string(odr::mimetype(file, logger));
      },
      py::arg("file"), py::arg("logger") = odr::Logger::null(),
      "Determine the MIME type of a file.");
  m.def(
      "mimetype",
      [](const std::string &path, const odr::Logger &logger) {
        return std::string(odr::mimetype(path, logger));
      },
      py::arg("path"), py::arg("logger") = odr::Logger::null(),
      "Determine the MIME type of a file.");

  // Decoding is long-running, so it must not hold the GIL. Re-entry is safe: a
  // Python `ILogger` re-acquires it in the trampoline.
  m.def(
      "open",
      [](const odr::File &file, const odr::DecodeOptions &options,
         const odr::Logger &logger) {
        return odr::open(file, options, logger);
      },
      py::arg("file"), py::arg("options") = odr::DecodeOptions{},
      py::arg("logger") = odr::Logger::null(),
      py::call_guard<py::gil_scoped_release>(), "Decode a file.");
  m.def(
      "open",
      [](const std::string &path, const odr::DecodeOptions &options,
         const odr::Logger &logger) {
        return odr::open(path, options, logger);
      },
      py::arg("path"), py::arg("options") = odr::DecodeOptions{},
      py::arg("logger") = odr::Logger::null(),
      py::call_guard<py::gil_scoped_release>(), "Open and decode a file.");

  m.def("create_document", &odr::create_document, py::arg("type"),
        "A new document of the type, with one empty paragraph or one empty "
        "sheet. Raises `UnsupportedFileTypeError` for a type whose "
        "capabilities do not state `create`.");
}
