#include "bindings.hpp"

#include <odr/document.hpp>
#include <odr/document_element.hpp>
#include <odr/file.hpp>
#include <odr/filesystem.hpp>
#include <odr/sheet_position.hpp>
#include <odr/style.hpp>
#include <odr/table_dimension.hpp>
#include <odr/table_position.hpp>

#include <pybind11/operators.h>
#include <pybind11/stl.h>

#include <sstream>
#include <string>

namespace py = pybind11;

namespace {

// Ties the returned object to `self`: navigation handles keep the originating
// `Document` alive transitively.
constexpr auto keep_self_alive = py::keep_alive<0, 1>();

py::object make_element_iterator(const odr::ElementRange &range) {
  // The elements need the same tie: pybind11 hands them out by value, which
  // drops the keep-alive `reference_internal` would otherwise imply.
  return py::make_iterator(range.begin(), range.end(), keep_self_alive);
}

py::object make_children_iterator(const odr::Element &element) {
  return make_element_iterator(element.children());
}

/// `__bool__` has to come from the derived type: `Element::operator bool`
/// ignores the typed adapter, so a failed `as_*` cast would look valid.
template <typename T, typename... Extra>
py::class_<T, odr::Element> bind_element(py::module_ &m, const char *name,
                                         const Extra &...extra) {
  return py::class_<T, odr::Element>(m, name, extra...)
      .def("__bool__", &T::operator bool);
}

} // namespace

void odr_python::bind_document(py::module_ &m) {
  py::enum_<odr::ElementType>(m, "ElementType")
      .value("none", odr::ElementType::none)
      .value("root", odr::ElementType::root)
      .value("slide", odr::ElementType::slide)
      .value("sheet", odr::ElementType::sheet)
      .value("page", odr::ElementType::page)
      .value("master_page", odr::ElementType::master_page)
      .value("sheet_cell", odr::ElementType::sheet_cell)
      .value("text", odr::ElementType::text)
      .value("line_break", odr::ElementType::line_break)
      .value("page_break", odr::ElementType::page_break)
      .value("paragraph", odr::ElementType::paragraph)
      .value("span", odr::ElementType::span)
      .value("link", odr::ElementType::link)
      .value("bookmark", odr::ElementType::bookmark)
      .value("list", odr::ElementType::list)
      .value("list_item", odr::ElementType::list_item)
      .value("table", odr::ElementType::table)
      .value("table_column", odr::ElementType::table_column)
      .value("table_row", odr::ElementType::table_row)
      .value("table_cell", odr::ElementType::table_cell)
      .value("frame", odr::ElementType::frame)
      .value("image", odr::ElementType::image)
      .value("group", odr::ElementType::group);

  py::enum_<odr::ShapeType>(m, "ShapeType")
      .value("none", odr::ShapeType::none)
      .value("rect", odr::ShapeType::rect)
      .value("ellipse", odr::ShapeType::ellipse)
      .value("line", odr::ShapeType::line)
      .value("custom", odr::ShapeType::custom);

  py::enum_<odr::AnchorType>(m, "AnchorType")
      .value("none", odr::AnchorType::none)
      .value("as_char", odr::AnchorType::as_char)
      .value("at_char", odr::AnchorType::at_char)
      .value("at_frame", odr::AnchorType::at_frame)
      .value("at_page", odr::AnchorType::at_page)
      .value("at_paragraph", odr::AnchorType::at_paragraph);

  py::enum_<odr::ListType>(m, "ListType")
      .value("unordered", odr::ListType::unordered)
      .value("ordered", odr::ListType::ordered);

  py::enum_<odr::ValueType>(m, "ValueType")
      .value("unknown", odr::ValueType::unknown)
      .value("string", odr::ValueType::string)
      .value("float_number", odr::ValueType::float_number)
      .value("boolean", odr::ValueType::boolean)
      .value("date", odr::ValueType::date)
      .value("time", odr::ValueType::time)
      .value("error", odr::ValueType::error);

  py::class_<odr::TableDimensions>(m, "TableDimensions")
      .def(py::init<>())
      .def(py::init<std::uint32_t, std::uint32_t>(), py::arg("rows"),
           py::arg("columns"))
      .def_readwrite("rows", &odr::TableDimensions::rows)
      .def_readwrite("columns", &odr::TableDimensions::columns)
      .def("__repr__", [](const odr::TableDimensions &dimensions) {
        return "TableDimensions(rows=" + std::to_string(dimensions.rows) +
               ", columns=" + std::to_string(dimensions.columns) + ")";
      });

  py::class_<odr::TablePosition>(m, "TablePosition")
      .def(py::init<>())
      .def(py::init<std::uint32_t, std::uint32_t>(), py::arg("column"),
           py::arg("row"))
      .def_readwrite("column", &odr::TablePosition::column)
      .def_readwrite("row", &odr::TablePosition::row)
      .def_static("to_column_num", &odr::TablePosition::to_column_num,
                  py::arg("string"))
      .def_static("to_row_num", &odr::TablePosition::to_row_num,
                  py::arg("string"))
      .def_static("to_column_string", &odr::TablePosition::to_column_string,
                  py::arg("column"))
      .def_static("to_row_string", &odr::TablePosition::to_row_string,
                  py::arg("row"));

  py::class_<odr::SheetPosition>(m, "SheetPosition")
      .def(py::init<std::uint32_t, std::uint32_t, std::uint32_t>(),
           py::arg("sheet"), py::arg("column"), py::arg("row"))
      .def_readonly("sheet", &odr::SheetPosition::sheet)
      .def_property_readonly("column",
                             [](const odr::SheetPosition &position) {
                               return position.cell.column;
                             })
      .def_property_readonly(
          "row",
          [](const odr::SheetPosition &position) { return position.cell.row; })
      .def(py::self == py::self)
      .def("__repr__", [](const odr::SheetPosition &position) {
        return "SheetPosition(" + position.to_string() + ")";
      });

  py::class_<odr::Recalculation>(m, "Recalculation")
      .def("changed", &odr::Recalculation::changed,
           "The formula cells whose result changed, or that had none before.")
      .def("circular", &odr::Recalculation::circular,
           "The cells of a cycle, which have no result.")
      .def("unevaluated", &odr::Recalculation::unevaluated,
           "The stale formula cells nothing here computes.");

  py::class_<odr::Element>(m, "Element")
      .def(py::init<>())
      .def("__bool__", &odr::Element::operator bool)
      .def(
          "__eq__",
          [](const odr::Element &lhs, const odr::Element &rhs) {
            return lhs == rhs;
          },
          py::is_operator())
      .def("type", &odr::Element::type)
      .def("identifier", &odr::Element::identifier)
      .def("parent", &odr::Element::parent, keep_self_alive)
      .def("first_child", &odr::Element::first_child, keep_self_alive)
      .def("previous_sibling", &odr::Element::previous_sibling, keep_self_alive)
      .def("next_sibling", &odr::Element::next_sibling, keep_self_alive)
      .def("is_unique", &odr::Element::is_unique)
      .def("is_self_locatable", &odr::Element::is_self_locatable)
      .def("is_editable", &odr::Element::is_editable)
      .def("children", &make_children_iterator, keep_self_alive)
      .def("__iter__", &make_children_iterator, keep_self_alive)
      .def("as_text_root", &odr::Element::as_text_root, keep_self_alive)
      .def("as_slide", &odr::Element::as_slide, keep_self_alive)
      .def("as_sheet", &odr::Element::as_sheet, keep_self_alive)
      .def("as_page", &odr::Element::as_page, keep_self_alive)
      .def("as_sheet_cell", &odr::Element::as_sheet_cell, keep_self_alive)
      .def("as_master_page", &odr::Element::as_master_page, keep_self_alive)
      .def("as_line_break", &odr::Element::as_line_break, keep_self_alive)
      .def("as_paragraph", &odr::Element::as_paragraph, keep_self_alive)
      .def("as_span", &odr::Element::as_span, keep_self_alive)
      .def("as_text", &odr::Element::as_text, keep_self_alive)
      .def("as_link", &odr::Element::as_link, keep_self_alive)
      .def("as_list", &odr::Element::as_list, keep_self_alive)
      .def("as_bookmark", &odr::Element::as_bookmark, keep_self_alive)
      .def("as_list_item", &odr::Element::as_list_item, keep_self_alive)
      .def("as_table", &odr::Element::as_table, keep_self_alive)
      .def("as_table_column", &odr::Element::as_table_column, keep_self_alive)
      .def("as_table_row", &odr::Element::as_table_row, keep_self_alive)
      .def("as_table_cell", &odr::Element::as_table_cell, keep_self_alive)
      .def("as_frame", &odr::Element::as_frame, keep_self_alive)
      .def("as_image", &odr::Element::as_image, keep_self_alive);

  bind_element<odr::TextRoot>(m, "TextRoot")
      .def("page_layout", &odr::TextRoot::page_layout)
      .def("first_master_page", &odr::TextRoot::first_master_page,
           keep_self_alive);

  bind_element<odr::Slide>(m, "Slide")
      .def("name", &odr::Slide::name)
      .def("page_layout", &odr::Slide::page_layout)
      .def("master_page", &odr::Slide::master_page, keep_self_alive);

  bind_element<odr::Sheet>(m, "Sheet")
      .def("name", &odr::Sheet::name)
      .def("page_layout", &odr::Sheet::page_layout)
      .def("dimensions", &odr::Sheet::dimensions)
      .def("content", &odr::Sheet::content, py::arg("range"))
      .def("cell", &odr::Sheet::cell, py::arg("column"), py::arg("row"),
           keep_self_alive)
      .def(
          "shapes",
          [](const odr::Sheet &sheet) {
            return make_element_iterator(sheet.shapes());
          },
          keep_self_alive)
      .def("style", &odr::Sheet::style)
      .def("column_style", &odr::Sheet::column_style, py::arg("column"))
      .def("row_style", &odr::Sheet::row_style, py::arg("row"))
      .def("cell_style", &odr::Sheet::cell_style, py::arg("column"),
           py::arg("row"))
      .def("set_cell_style", &odr::Sheet::set_cell_style, py::arg("column"),
           py::arg("row"), py::arg("cell_style"), py::arg("text_style"))
      .def("set_row_style", &odr::Sheet::set_row_style, py::arg("row"),
           py::arg("cell_style"), py::arg("text_style"))
      .def("set_column_style", &odr::Sheet::set_column_style, py::arg("column"),
           py::arg("cell_style"), py::arg("text_style"))
      .def("insert_rows", &odr::Sheet::insert_rows, py::arg("row"),
           py::arg("count"))
      .def("delete_rows", &odr::Sheet::delete_rows, py::arg("row"),
           py::arg("count"))
      .def("insert_columns", &odr::Sheet::insert_columns, py::arg("column"),
           py::arg("count"))
      .def("delete_columns", &odr::Sheet::delete_columns, py::arg("column"),
           py::arg("count"));

  bind_element<odr::SheetCell>(m, "SheetCell")
      .def("position", &odr::SheetCell::position)
      .def("is_covered", &odr::SheetCell::is_covered)
      .def("span", &odr::SheetCell::span)
      .def("value_type", &odr::SheetCell::value_type)
      .def("number_format", &odr::SheetCell::number_format);

  bind_element<odr::Page>(m, "Page")
      .def("name", &odr::Page::name)
      .def("page_layout", &odr::Page::page_layout)
      .def("master_page", &odr::Page::master_page, keep_self_alive);

  bind_element<odr::MasterPage>(m, "MasterPage")
      .def("page_layout", &odr::MasterPage::page_layout);

  bind_element<odr::LineBreak>(m, "LineBreak")
      .def("style", &odr::LineBreak::style);

  bind_element<odr::Paragraph>(m, "Paragraph")
      .def("style", &odr::Paragraph::style)
      .def("set_style", &odr::Paragraph::set_style, py::arg("style"))
      .def("text_style", &odr::Paragraph::text_style);

  bind_element<odr::Span>(m, "Span").def("style", &odr::Span::style);

  bind_element<odr::Text>(m, "Text")
      .def("content", &odr::Text::content)
      .def("set_content", &odr::Text::set_content, py::arg("text"))
      .def("set_style", &odr::Text::set_style, py::arg("style"))
      .def("style", &odr::Text::style);

  bind_element<odr::Link>(m, "Link").def("href", &odr::Link::href);

  bind_element<odr::Bookmark>(m, "Bookmark").def("name", &odr::Bookmark::name);

  bind_element<odr::List>(m, "List").def("list_type", &odr::List::type);

  bind_element<odr::ListItem>(m, "ListItem")
      .def("style", &odr::ListItem::style)
      .def("marker", &odr::ListItem::marker)
      .def("number", &odr::ListItem::number);

  bind_element<odr::Table>(m, "Table")
      .def("first_row", &odr::Table::first_row, keep_self_alive)
      .def("first_column", &odr::Table::first_column, keep_self_alive)
      .def(
          "columns",
          [](const odr::Table &table) {
            return make_element_iterator(table.columns());
          },
          keep_self_alive)
      .def(
          "rows",
          [](const odr::Table &table) {
            return make_element_iterator(table.rows());
          },
          keep_self_alive)
      .def("dimensions", &odr::Table::dimensions)
      .def("style", &odr::Table::style);

  bind_element<odr::TableColumn>(m, "TableColumn")
      .def("style", &odr::TableColumn::style);

  bind_element<odr::TableRow>(m, "TableRow")
      .def("style", &odr::TableRow::style);

  bind_element<odr::TableCell>(m, "TableCell")
      .def("is_covered", &odr::TableCell::is_covered)
      .def("span", &odr::TableCell::span)
      .def("value_type", &odr::TableCell::value_type)
      .def("style", &odr::TableCell::style);

  py::class_<odr::DrawingPath>(m, "DrawingPath")
      .def(py::init<>())
      .def_readwrite("data", &odr::DrawingPath::data)
      .def_readwrite("x", &odr::DrawingPath::x)
      .def_readwrite("y", &odr::DrawingPath::y)
      .def_readwrite("width", &odr::DrawingPath::width)
      .def_readwrite("height", &odr::DrawingPath::height);

  py::class_<odr::DrawingLine>(m, "DrawingLine")
      .def(py::init<>())
      .def_readwrite("x1", &odr::DrawingLine::x1)
      .def_readwrite("y1", &odr::DrawingLine::y1)
      .def_readwrite("x2", &odr::DrawingLine::x2)
      .def_readwrite("y2", &odr::DrawingLine::y2);

  py::class_<odr::DrawingTransform>(m, "DrawingTransform")
      .def(py::init<>())
      .def_readwrite("a", &odr::DrawingTransform::a)
      .def_readwrite("b", &odr::DrawingTransform::b)
      .def_readwrite("c", &odr::DrawingTransform::c)
      .def_readwrite("d", &odr::DrawingTransform::d)
      .def_readwrite("e", &odr::DrawingTransform::e)
      .def_readwrite("f", &odr::DrawingTransform::f);

  bind_element<odr::Frame>(m, "Frame")
      .def("shape_type", &odr::Frame::shape_type)
      .def("anchor_type", &odr::Frame::anchor_type)
      .def("x", &odr::Frame::x)
      .def("y", &odr::Frame::y)
      .def("width", &odr::Frame::width)
      .def("height", &odr::Frame::height)
      .def("z_index", &odr::Frame::z_index)
      .def("transform", &odr::Frame::transform)
      .def("path", &odr::Frame::path)
      .def("line", &odr::Frame::line)
      .def("style", &odr::Frame::style);

  bind_element<odr::Image>(m, "Image")
      .def("is_internal", &odr::Image::is_internal)
      .def("file", &odr::Image::file)
      .def("href", &odr::Image::href);

  py::class_<odr::Document>(m, "Document")
      .def("is_editable", &odr::Document::is_editable)
      .def(
          "edit",
          [](const odr::Document &document, const std::string &operations) {
            document.edit(operations);
          },
          py::arg("operations"),
          "Apply the operations our browser-side editor produces.")
      .def("element_by_id", &odr::Document::element_by_id,
           py::arg("identifier"), keep_self_alive)
      // Structural edits. Each raises for an engine that cannot write, and for
      // an element of another document.
      .def("remove", &odr::Document::remove, py::arg("element"),
           "Remove an element and its subtree.")
      .def("insert_text_before", &odr::Document::insert_text_before,
           py::arg("anchor"), py::arg("text"), keep_self_alive,
           "A run before another, in the same parent, so it takes the same "
           "style.")
      .def("insert_text_after", &odr::Document::insert_text_after,
           py::arg("anchor"), py::arg("text"), keep_self_alive,
           "A run after another, in the same parent.")
      .def("append_text", &odr::Document::append_text, py::arg("parent"),
           py::arg("text"), keep_self_alive,
           "A run as the last child of an element.")
      .def("split_paragraph", &odr::Document::split_paragraph,
           py::arg("paragraph"), py::arg("after") = odr::Element(),
           keep_self_alive,
           "Split a paragraph after one of its descendants into a new "
           "paragraph of the same style. The default splits before every "
           "child.")
      .def("merge_paragraph_with_next",
           &odr::Document::merge_paragraph_with_next, py::arg("paragraph"),
           "Take the children of the paragraph after this one, which then "
           "goes.")
      .def("insert_paragraph_after", &odr::Document::insert_paragraph_after,
           py::arg("paragraph"), keep_self_alive,
           "An empty paragraph after this one, of the same style.")
      .def("recalculate", &odr::Document::recalculate,
           py::call_guard<py::gil_scoped_release>(),
           "Compute the stale formula cells and write each result into the "
           "document. A save does so first where an edit left one stale.")
      .def("is_savable", &odr::Document::is_savable,
           py::arg("encrypted") = false)
      // saving serialises the whole document; holding the GIL for it blocks
      // every other Python thread
      .def("save",
           py::overload_cast<const std::string &>(&odr::Document::save,
                                                  py::const_),
           py::arg("path"), py::call_guard<py::gil_scoped_release>())
      .def("save",
           py::overload_cast<const std::string &, const std::string &>(
               &odr::Document::save, py::const_),
           py::arg("path"), py::arg("password"),
           py::call_guard<py::gil_scoped_release>())
      .def(
          "save_to_memory",
          [](const odr::Document &document) {
            std::ostringstream out;
            {
              py::gil_scoped_release release;
              document.save(out);
            }
            return py::bytes(out.str());
          },
          "Save the document and return its bytes.")
      .def(
          "save_to_memory",
          [](const odr::Document &document, const std::string &password) {
            std::ostringstream out;
            {
              py::gil_scoped_release release;
              document.save(out, password);
            }
            return py::bytes(out.str());
          },
          py::arg("password"),
          "Save the document encrypted and return its bytes.")
      .def("file_type", &odr::Document::file_type)
      .def("document_type", &odr::Document::document_type)
      .def("locale", &odr::Document::locale)
      .def("root_element", &odr::Document::root_element, keep_self_alive)
      .def("as_filesystem", &odr::Document::as_filesystem);
}
